"""Step-by-step reconciliation from the published analysis (R0) to the revised analysis (R1).

Each step adds one change to the previous one, so the effect of every change on the decisions is visible
(ESM Table S3 and the response letter). Output: analysis_r1/ledger.csv, analysis_r1/ledger_sets.json
"""
import json, os, copy
import numpy as np, pandas as pd
import gas_engine as G

ATTR = "inputs/GW_input_attr.gpkg"      # District inventory: chloride concentration and trend class (as in the original analysis)
ORIG = dict(G.R1_ORIGINAL_CODE, WRITE_GEO=False)

STEPS = [
    ("L0", "Original code as received (FINAL6/Final5NEW), District attribute data", ATTR, dict()),
    ("L1", "+ safeguard thresholds of Table S1 (LOO Q85, S_GI 0.80, P_chl 0.85) = published analysis", ATTR,
     dict(SAFEGUARD=(0.85, 0.80, 0.85))),
    ("L2", "+ values stated in the manuscript: trend scores 1.0/0.5/0.0 (Eq. 7), calibration structural value with S_GI (Eq. 20), small-cluster graph-role shrinkage for n < 3", ATTR,
     dict(TREND_SCORES={"DECREASING": 1.0, "STABLE": 0.5, "INCREASING": 0.0}, CALIB_STRUCT_WITH_SGI=True, SMALL_CLUSTER_MAX_N=2)),
    ("L3", "+ candidate scoring as stated (adaptive AS weights in E-GAS, LIMG 0.25/0.15/0.40/0.20, fusion 0.35/0.35/0.30, validation gain within the aquifer group); sites on land only", ATTR,
     dict(AS_ADAPTIVE=True, LIMG_W=(0.25, 0.15, 0.40, 0.20), CAND_W=(0.35, 0.35, 0.30), VGAIN_SAME_AQUIFER=True, LAND_MASK="inputs/florida_land.gpkg")),
    ("L4", "+ MST correction for co-located wells", ATTR, dict(FIX_MST=True)),
    ("L5", "+ spring vents evaluated as a separate station class (revised analysis)", ATTR, dict(SPRINGS_SEPARATE=True)),
]


def summarize(tag, desc, res):
    w = res["wells"].copy()
    w["SID"] = w.SID.astype(str)
    scr = set(w.loc[w.FinalDecision_BGAS == "CANDIDATE_REMOVE", "SID"])
    conf = set(w.loc[w.FinalDecision == "CANDIDATE_REMOVE", "SID"])
    aq = res["aquifers"].set_index("Aquifer_group")
    row = dict(step=tag, change=desc, n_stations=len(w),
               n_isolated=int(w.Isolated_within_Ell.sum()),
               n_critical=int(w.IsCritical.astype(int).sum()),
               n_components=int(aq.N_components.sum()),
               ell_ufa=float(aq.loc["upper floridan", "Ell_aquifer_m"]),
               ell_haw=float(aq.loc["hawthorn", "Ell_aquifer_m"]),
               ell_sur=float(aq.loc["surficial", "Ell_aquifer_m"]),
               n_screened_BGAS=len(scr), n_confirmed_EGAS=len(conf),
               n_review_EGAS=int((w.FinalDecision == "REVIEW").sum()),
               loo_q85=float(w.get("Safeguard_LOO_threshold", pd.Series([np.nan])).iloc[0]),
               n_cand_BGAS=len(res["cand_bgas"]), n_cand_EGAS=len(res["cand_egas"]),
               confirmed=";".join(sorted(conf)))
    for k, v in res["weights"].items():
        row[f"w_{k}"] = round(float(v), 4)
    return row, sorted(scr), sorted(conf)


def main():
    os.makedirs("analysis_r1", exist_ok=True)
    cfg = dict(ORIG)
    rows, sets = [], {}
    prev = None
    for tag, desc, inp, upd in STEPS:
        cfg.update(upd)
        G.configure(**cfg)
        res = G.run(inp, f"runs/{tag}", verbose=False)
        row, scr, conf = summarize(tag, desc, res)
        if prev is not None:
            a, b = set(prev), set(scr)
            row["jaccard_screened_vs_prev"] = round(len(a & b) / max(len(a | b), 1), 3)
        prev = scr
        rows.append(row)
        sets[tag] = dict(screened=scr, confirmed=conf)
        print(tag, row["n_stations"], row["n_screened_BGAS"], row["n_confirmed_EGAS"], row["confirmed"])
    pd.DataFrame(rows).to_csv("analysis_r1/ledger.csv", index=False)
    json.dump(sets, open("analysis_r1/ledger_sets.json", "w"), indent=1)


if __name__ == "__main__":
    main()
