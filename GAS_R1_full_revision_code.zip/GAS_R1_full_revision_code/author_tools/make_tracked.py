"""Create a tracked-changes manuscript (original submission -> revision) with LibreOffice 'Compare Document'.
Usage: python3 make_tracked.py ORIGINAL.docx REVISED.docx OUT.docx"""
import os, subprocess, sys, time
import uno
from com.sun.star.beans import PropertyValue


def prop(n, v):
    p = PropertyValue(); p.Name = n; p.Value = v
    return p


def main(orig, rev, out):
    orig, rev, out = (os.path.abspath(x) for x in (orig, rev, out))
    proc = subprocess.Popen(["soffice", "--headless", "--invisible", "--norestore",
                             "--accept=socket,host=localhost,port=2002;urp;"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    ctx = None
    local = uno.getComponentContext()
    resolver = local.ServiceManager.createInstanceWithContext("com.sun.star.bridge.UnoUrlResolver", local)
    for _ in range(60):
        try:
            ctx = resolver.resolve("uno:socket,host=localhost,port=2002;urp;StarOffice.ComponentContext")
            break
        except Exception:
            time.sleep(1)
    smgr = ctx.ServiceManager
    desktop = smgr.createInstanceWithContext("com.sun.star.frame.Desktop", ctx)
    doc = desktop.loadComponentFromURL(uno.systemPathToFileUrl(rev), "_blank", 0, (prop("Hidden", True),))
    disp = smgr.createInstanceWithContext("com.sun.star.frame.DispatchHelper", ctx)
    frame = doc.getCurrentController().getFrame()
    disp.executeDispatch(frame, ".uno:CompareDocuments", "", 0,
                         (prop("URL", uno.systemPathToFileUrl(orig)), prop("NoAcceptDialog", True)))
    doc.storeToURL(uno.systemPathToFileUrl(out), (prop("FilterName", "MS Word 2007 XML"),))
    doc.close(True)
    try:
        desktop.terminate()
    except Exception:
        pass
    proc.wait(timeout=60)





def set_author(path, author="Seyed Mostafa Biazar"):
    """LibreOffice writes 'Unknown Author' on every revision; replace it with the corresponding author."""
    import zipfile, os
    tmp = path + ".tmp"
    with zipfile.ZipFile(path) as zin, zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED) as zout:
        for it in zin.infolist():
            data = zin.read(it.filename)
            if it.filename.endswith(".xml"):
                data = data.decode("utf-8").replace('w:author="Unknown Author"', f'w:author="{author}"').encode("utf-8")
            zout.writestr(it, data)
    os.replace(tmp, path)


if __name__ == "__main__":
    main(*sys.argv[1:4])
    set_author(sys.argv[3])
