"""Line numbers for the response letter (R1).
'old'   = submitted manuscript (HYJO-D-26-00546.pdf, line numbers printed by Editorial Manager),
'clean' = clean revised manuscript, 'track' = revised manuscript with tracked changes (All Markup),
both read from LibreOffice PDF renderings of the .docx files (Word may differ by a few lines)."""
import json, re, sys
from linemap import LineMap, _norm, fmt
OLD = {  # submitted manuscript (HYJO-D-26-00546.pdf), read from the PDF
    "title": "1–2", "abstract": "13–26", "keywords": "27–28", "intro": "36–132", "intro_obj": "106–132",
    "study": "134–184", "fig1": "184", "framework": "185–232", "fig2": "223–232", "graph": "233–272",
    "scoring": "273–370", "chloride_terms": "286–301", "decision": "371–407", "candidates": "408–441",
    "egas": "443–471", "aigas": "472–535", "eval": "536–587", "param": "588–611", "results": "612–1128",
    "tables": "622–645", "aigas_results": "911–995", "cross": "996–1128", "pareto": "1024–1058",
    "baselines": "1083–1128", "discussion": "1129–1283", "conclusion": "1284–1362",
    "figcaps": "184, 226, 674, 746, 776, 870, 908, 1018, 1053",
}

MD = open("ms/ms_r1_filled.md", encoding="utf-8").read()


def plain(s):
    s = re.sub(r"!\[(.*?)\]\(.*?\)\{.*?\}", r"\1", s, flags=re.S)
    s = re.sub(r"\$\$.*?\$\$", " ", s, flags=re.S)
    s = re.sub(r"\$.*?\$", " ", s)
    return s.replace("**", "").replace("*", "").replace("~", "").replace("^", "").replace("\\", "")


def section(head):
    """(start, end) phrases of a manuscript section: its heading and the last words of its last text paragraph."""
    i = MD.index(head)
    j = MD.find("\n#", i + len(head))
    body = MD[i:j if j > 0 else len(MD)]
    paras = [p for p in body.split("\n\n") if p.strip() and not p.lstrip().startswith(("|", "![", "$$", "Table:", "<<"))]
    last = plain(paras[-1]).strip()
    return plain(head.lstrip("# ")).strip(), last[-45:]


def para(start, n_end=45):
    """(start, end) of the paragraph that begins with 'start'."""
    i = MD.index(start)
    j = MD.find("\n\n", i)
    p = plain(MD[i:j if j > 0 else len(MD)]).strip()
    return plain(start).strip(), p[-n_end:]


def caption(label):
    m = re.search(r"!\[\*\*" + re.escape(label) + r"\*\*(.*?)\]\(", MD, flags=re.S) or \
        re.search(r"Table: \*\*" + re.escape(label) + r"\*\*(.*?)\n", MD, flags=re.S)
    cap = plain(m.group(1)).strip()
    return label + " " + cap[:25], cap[-40:]


NEW = {
    "title": ("Beyond spatial redundancy: a graph-based", "monitoring network optimization"),
    "abstract": para("Groundwater monitoring networks are reviewed periodically"),
    "keywords": ("Keywords Groundwater monitoring", "Salt-water/fresh-water relations"),
    "abbrev": section("# Abbreviations"),
    "intro": section("# 1 Introduction"),
    "intro_gap": para("Design methods include simulation"),
    "intro_coupling": para("Second, reduction and reinforcement"),
    "intro_bed": ("Data-worth analysis and Bayesian experimental design", "reduction of operational networks."),
    "intro_objective": para("The value of a monitoring well can only be judged"),
    "intro_framework": para("This study presents a graph-aware active-sensing (GAS) framework"),
    "study_area": section("## 2.1 Study area and hydrogeologic setting"),
    "fig1": caption("Fig. 1"),
    "data": section("## 2.2 Monitoring network and data"),
    "data_springs": para("The District groundwater-quality station inventory contains"),
    "data_edp": para("The inputs for each well are aquifer group"),
    "data_critical": ("Of the 301 wells, 281 carry", "critical in the majority of their records; Sect. 3.7)."),
    "decision": section("## 2.3 Decision problem and framework overview"),
    "eq1": ("Let x", para("where $\\mathcal{K}$ is the set")[1]),
    "classes": para("Four classes are used throughout"),
    "table1": caption("Table 1"),
    "fig2": caption("Fig. 2"),
    "graph": section("## 2.4 Graph construction"),
    "graph_mst": para("For each aquifer group *a*, a minimum spanning tree"),
    "graph_w": ("is the 90th percentile of nearest-neighbour distances", para("Wells without a neighbour are isolated")[1]),
    "evidence": section("## 2.5 Evidence for the retention of existing wells"),
    "chloride": ("Chloride concentration. Retention support", "between about 1,100 and 2,900 mg/L."),
    "chl_mid": para("The midpoint of 2,000 mg/L"),
    "trend": ("Chloride trend. As in the original analysis", "fresh wells with a decreasing trend."),
    "status_depth": ("The status score is 0.85 for active", "(Gaussian kernel density)."),
    "joint": ("Joint quality. This term combines", "all values are limited to [0, 1]."),
    "spatial": ("Spatial redundancy. Within each redundancy cluster", para("where clip(")[1]),
    "info": ("Information uniqueness. A feature vector", "and the trend and status scores:"),
    "dep": ("Dependency uniqueness. Hydrochemical duplication", "absolute difference of the normalized attribute:"),
    "graphrole": ("Graph role. In each cluster", "when well i is removed from its cluster."),
    "reliab": ("Aquifer reliability. Because well counts", "for the five-well surficial aquifer."),
    "weights": section("## 2.6 Weights, utility and probabilistic resolution"),
    "entropy": para("The weights of the nine scores"),
    "mc": para("Uncertainty is propagated by Monte Carlo"),
    "confirm_m": section("## 2.7 Confirmation of screened wells (E-GAS)"),
    "cand_m": section("## 2.8 Candidate generation and scoring"),
    "cand_grid": ("Candidate sites are plan-view locations", "around high-influence wells (top 20 %)."),
    "cand_terms": para("where *g*~unc~ is the distance-weighted mean uncertainty"),
    "cand_greedy": ("with a = 0.3 for the first three terms", "is the distance to the site just selected (B-GAS)."),
    "limg": ("The Hydro-LIMG score evaluates each site", "(Eqs. S1–S4)."),
    "vgain": ("The validation gain", "comparable only within an aquifer group."),
    "egas_pen": ("The E-GAS greedy update multiplies", "(and 0.8ℓa) apart."),
    "eval": section("## 2.9 Evaluation"),
    "eval_budget": ("Equal-budget comparison. Three established", "(reported as a factor) and to chloride (mg/L)."),
    "jaccard": ("the number of components touched, the Jaccard overlap", "(Jaccard 1912)"),
    "eval_temporal": para("*Out-of-period test.*"),
    "eval_prosp": para("*Pseudo-prospective tests.*"),
    "eval_sens": para("*Sensitivity.*"),
    "repro": section("## 2.10 Reproducibility"),
    "res_structure": section("## 3.1 Network structure"),
    "fig3": caption("Fig. 3"),
    "res_detect": section("## 3.2 Detection (B-GAS)"),
    "res_dist": ("Their distance keep score was higher", "not with close spacing."),
    "table2": caption("Table 2"),
    "res_confirm": section("## 3.3 Confirmation (E-GAS)"),
    "res_nn": ("B-GAS removal would increase the aquifer-weighted mean NN distance", "E-GAS leaves it unchanged."),
    "fig4": caption("Fig. 4"),
    "res_cand": section("## 3.4 Candidate sites"),
    "fig5": caption("Fig. 5"),
    "res_budget": section("## 3.5 Comparison with established reduction methods at equal budgets"),
    "table3": caption("Table 3"),
    "res_temporal": section("## 3.6 Out-of-period and pseudo-prospective tests"),
    "res_temporal_a": para("The 2021–2026 median chloride of the screened wells"),
    "res_prosp": para("With randomly withheld wells"),
    "fig6": caption("Fig. 6"),
    "res_sens": section("## 3.7 Sensitivity"),
    "res_sens_struct": para("Two structural choices change the outcome"),
    "disc": ("4 Discussion", section("## 4.4 Limitations and perspectives")[1]),
    "disc_prox": section("## 4.1 Redundancy is a network property, not proximity"),
    "disc_ik": ("Ordinary-kriging variance depends only on the well locations", "(Cong-Thi et al. 2026)."),
    "disc_mps": ("That two-point measures miss higher-order structure", "(Bunn et al. 2000; Urban and Keitt 2001)."),
    "disc_detect": section("## 4.2 Detection and confirmation are different questions"),
    "disc_reversible": ("Discontinuation need not be final", "with stable neighbours."),
    "disc_transition": para("Two properties of the confirmation stage need care"),
    "disc_graph": section("## 4.3 What the graph represents"),
    "disc_lim": section("## 4.4 Limitations and perspectives"),
    "lim_wl": ("(1) The results come from one regional", "need their own objective and scores."),
    "lim_ts": ("(4) Chloride is summarized by a median", "would need their own scores."),
    "lim_seq": ("Sites are also chosen one step ahead", "(Mern and Caers 2023; Arief et al. 2025)."),
    "concl": section("# 5 Conclusions"),
    "declarations": ("Funding There is no funding for this research", "as found in the Instructions for Authors"),
    "data_avail": ("Data availability The chloride data are available", "will be made available on request."),
    "code_avail": ("Code availability The code of the framework", "supplementary material (ESM 2)."),
}


def robust_span(M, a, b):
    """span with fall-backs for passages that the tracked comparison interleaves with deleted text."""
    r = M.span(a, b)
    if r:
        return r
    for k in (60, 40, 28, 18):
        aa = a[:k]
        if len(_norm(aa)) < 10:
            continue
        s = M.find(aa)
        if s is None:
            continue
        for kk in (45, 30, 20, 14):
            e = M.find(b[-kk:], start_after=s[0])
            if e:
                return s[0], e[1]
        return s
    return None


def build(clean_pdf, track_pdf):
    C, T = LineMap(clean_pdf), LineMap(track_pdf)
    out = {"old": OLD, "clean": {}, "track": {}, "missing": []}
    for k, (a, b) in NEW.items():
        rc, rt = robust_span(C, a, b), robust_span(T, a, b)
        out["clean"][k], out["track"][k] = fmt(rc), fmt(rt)
        if rc is None or rt is None:
            out["missing"].append(k)
    return out


if __name__ == "__main__":
    L = build("deliverables/Biazar_Manuscript_R1_clean.pdf", "deliverables/Biazar_Manuscript_R1_tracked.pdf")
    json.dump(L, open("analysis_r1/response_lines.json", "w"), indent=1, ensure_ascii=False)
    for k in NEW:
        print(f"{k:18s} clean {L['clean'][k]:>10s}   tracked {L['track'][k]:>10s}")
    print("missing:", L["missing"])
