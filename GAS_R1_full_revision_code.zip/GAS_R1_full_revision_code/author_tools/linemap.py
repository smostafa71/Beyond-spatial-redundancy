"""Map phrases to manuscript line numbers from a line-numbered PDF (pdftotext -layout)."""
import re, subprocess, unicodedata


def _norm(s):
    s = unicodedata.normalize("NFKC", s)
    s = s.replace("‐", "-").replace("–", "-").replace("—", "-").replace("’", "'").replace("“", '"').replace("”", '"')
    return re.sub(r"[^a-z0-9]+", "", s.lower())


class LineMap:
    def __init__(self, pdf):
        txt = subprocess.run(["pdftotext", "-layout", pdf, "-"], capture_output=True, text=True).stdout
        self.buf, self.pos = "", []          # normalized text and line number of every character
        for raw in txt.splitlines():
            m = re.match(r"^\s{0,12}(\d{1,5})\s{2,}(\S.*)$", raw)
            if not m:
                continue
            ln, body = int(m.group(1)), m.group(2)
            n = _norm(body)
            self.buf += n
            self.pos += [ln] * len(n)

    def find(self, phrase, start_after=0, last=False):
        """Line number(s) where the phrase starts and ends: (first, last) or None."""
        p = _norm(phrase)
        i = self.buf.find(p)
        while i >= 0 and self.pos[i] < start_after:
            i = self.buf.find(p, i + 1)
        if i < 0:
            return None
        return self.pos[i], self.pos[i + len(p) - 1]

    def span(self, start_phrase, end_phrase):
        a = self.find(start_phrase)
        if a is None:
            return None
        b = self.find(end_phrase, start_after=a[0])
        return (a[0], b[1]) if b else a


def fmt(r):
    if r is None:
        return "?"
    a, b = r
    return f"{a}" if a == b else f"{a}–{b}"
