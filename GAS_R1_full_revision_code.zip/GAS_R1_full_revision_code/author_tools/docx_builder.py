"""Small helpers to write a Hydrogeology Journal manuscript with python-docx."""
import re
from docx import Document
from docx.shared import Pt, Cm, Mm, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_LINE_SPACING, WD_BREAK
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.oxml.ns import qn
from docx.oxml import OxmlElement

FONT = "Times New Roman"


def new_document(line_numbers=True, double=True, size=11):
    d = Document()
    st = d.styles["Normal"]
    st.font.name = FONT; st.font.size = Pt(size)
    st.element.rPr.rFonts.set(qn("w:eastAsia"), FONT)
    pf = st.paragraph_format
    pf.line_spacing_rule = WD_LINE_SPACING.DOUBLE if double else WD_LINE_SPACING.ONE_POINT_FIVE
    pf.space_after = Pt(0); pf.space_before = Pt(0)
    sec = d.sections[0]
    sec.page_height = Mm(279.4); sec.page_width = Mm(215.9)
    for side in ["left_margin", "right_margin", "top_margin", "bottom_margin"]:
        setattr(sec, side, Cm(2.54))
    if line_numbers:
        ln = OxmlElement("w:lnNumType")
        ln.set(qn("w:countBy"), "1"); ln.set(qn("w:restart"), "continuous"); ln.set(qn("w:distance"), "283")
        sec._sectPr.append(ln)
    # page numbers in footer
    p = sec.footer.paragraphs[0]; p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    _field(p, "PAGE")
    for name, sz in [("Heading 1", size + 1), ("Heading 2", size), ("Heading 3", size)]:
        h = d.styles[name]
        h.font.name = FONT; h.font.size = Pt(sz); h.font.bold = True; h.font.italic = (name == "Heading 3")
        h.font.color.rgb = RGBColor(0, 0, 0)
        h.element.rPr.rFonts.set(qn("w:eastAsia"), FONT)
        rf = h.element.rPr.rFonts
        rf.set(qn("w:ascii"), FONT); rf.set(qn("w:hAnsi"), FONT); rf.set(qn("w:cs"), FONT)
        for att in ("w:asciiTheme", "w:hAnsiTheme", "w:eastAsiaTheme", "w:cstheme"):
            if rf.get(qn(att)) is not None:
                del rf.attrib[qn(att)]
        h.paragraph_format.space_before = Pt(6); h.paragraph_format.space_after = Pt(0)
        h.paragraph_format.line_spacing_rule = WD_LINE_SPACING.DOUBLE if double else WD_LINE_SPACING.ONE_POINT_FIVE
        h.paragraph_format.keep_with_next = True
    _force_font(d)
    return d


def _force_font(d):
    """Replace every theme-font reference in styles.xml with the body font (Times New Roman)."""
    root = d.styles.element
    for rf in root.iter(qn("w:rFonts")):
        for att in ("w:asciiTheme", "w:hAnsiTheme", "w:eastAsiaTheme", "w:cstheme"):
            if rf.get(qn(att)) is not None:
                del rf.attrib[qn(att)]
        for att in ("w:ascii", "w:hAnsi", "w:cs", "w:eastAsia"):
            rf.set(qn(att), FONT)


def _field(p, code):
    r = p.add_run()
    f1 = OxmlElement("w:fldChar"); f1.set(qn("w:fldCharType"), "begin")
    it = OxmlElement("w:instrText"); it.set(qn("xml:space"), "preserve"); it.text = code
    f2 = OxmlElement("w:fldChar"); f2.set(qn("w:fldCharType"), "end")
    r._r.append(f1); r._r.append(it); r._r.append(f2)


INLINE = re.compile(r"(\*\*[^*]+\*\*|\*[^*]+\*|_\{[^}]+\}|\^\{[^}]+\})")


def add_runs(p, text, size=None, color=None):
    """Very small markup: **bold**, *italic*, _{sub}, ^{sup}."""
    for part in INLINE.split(text):
        if not part:
            continue
        if part.startswith("**"):
            r = p.add_run(part[2:-2]); r.bold = True
        elif part.startswith("*"):
            r = p.add_run(part[1:-1]); r.italic = True
        elif part.startswith("_{"):
            r = p.add_run(part[2:-1]); r.font.subscript = True
        elif part.startswith("^{"):
            r = p.add_run(part[2:-1]); r.font.superscript = True
        else:
            r = p.add_run(part)
        if size:
            r.font.size = Pt(size)
        if color:
            r.font.color.rgb = RGBColor(*color)
    return p


def para(d, text, align=None, indent=True, size=None, keep=False):
    p = d.add_paragraph()
    if indent:
        p.paragraph_format.first_line_indent = Cm(0.6)
    if align == "center":
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    elif align == "justify":
        p.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
    if keep:
        p.paragraph_format.keep_with_next = True
    add_runs(p, text, size=size)
    return p


def equation(d, text, number):
    t = d.add_table(rows=1, cols=2)
    t.alignment = WD_TABLE_ALIGNMENT.CENTER
    t.autofit = False
    w = [Cm(14.5), Cm(1.8)]
    for i, c in enumerate(t.rows[0].cells):
        c.width = w[i]
    p0 = t.rows[0].cells[0].paragraphs[0]; p0.alignment = WD_ALIGN_PARAGRAPH.CENTER
    add_runs(p0, text)
    p1 = t.rows[0].cells[1].paragraphs[0]; p1.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    p1.add_run(f"({number})")
    return t


def heading(d, text, level):
    return d.add_heading(text, level=level)


def table(d, header, rows, caption, widths=None, size=8.5, note=None):
    cp = d.add_paragraph(); add_runs(cp, caption); cp.paragraph_format.keep_with_next = True
    cp.paragraph_format.line_spacing_rule = WD_LINE_SPACING.SINGLE
    t = d.add_table(rows=1 + len(rows), cols=len(header))
    t.style = "Table Grid"
    t.alignment = WD_TABLE_ALIGNMENT.CENTER
    for j, h in enumerate(header):
        c = t.rows[0].cells[j]; c.paragraphs[0].paragraph_format.line_spacing_rule = WD_LINE_SPACING.SINGLE
        r = c.paragraphs[0].add_run(h); r.bold = True; r.font.size = Pt(size)
    for i, row in enumerate(rows):
        for j, v in enumerate(row):
            c = t.rows[i + 1].cells[j]; c.paragraphs[0].paragraph_format.line_spacing_rule = WD_LINE_SPACING.SINGLE
            add_runs(c.paragraphs[0], str(v), size=size)
    if widths:
        t.autofit = False
        for row in t.rows:
            for j, wd in enumerate(widths):
                row.cells[j].width = Cm(wd)
        # make the grid and the table width explicit so that Word and LibreOffice honour the column widths
        tbl = t._tbl
        grid = tbl.tblGrid
        for j, gc in enumerate(grid.findall(qn("w:gridCol"))):
            if j < len(widths):
                gc.set(qn("w:w"), str(int(Cm(widths[j]).twips)))
        tblPr = tbl.tblPr
        tw = tblPr.find(qn("w:tblW"))
        if tw is None:
            tw = OxmlElement("w:tblW"); tblPr.append(tw)
        tw.set(qn("w:type"), "dxa"); tw.set(qn("w:w"), str(int(sum(Cm(w).twips for w in widths))))
        lay = OxmlElement("w:tblLayout"); lay.set(qn("w:type"), "fixed"); tblPr.append(lay)
    # light borders: top/bottom only look
    if note:
        n = d.add_paragraph(); add_runs(n, note, size=size); n.paragraph_format.line_spacing_rule = WD_LINE_SPACING.SINGLE
    d.add_paragraph()
    return t


def figure(d, path, caption, width_cm=16.5):
    p = d.add_paragraph(); p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.add_run().add_picture(path, width=Cm(width_cm))
    p.paragraph_format.keep_with_next = True
    c = d.add_paragraph(); add_runs(c, caption)
    return c


def page_break(d):
    d.add_paragraph().add_run().add_break(WD_BREAK.PAGE)
