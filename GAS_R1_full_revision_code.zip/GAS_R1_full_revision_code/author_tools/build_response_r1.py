# -*- coding: utf-8 -*-
"""Response to the Editor, Associate Editor and Reviewer 2 (HYJO-D-26-00546, R1).
Reviewer comments are copied verbatim from raw_input/decision_letter.txt.
Line numbers come from analysis_r1/response_lines.json (resp_lines_r1.py):
  'old'   submitted manuscript (Editorial Manager PDF),
  'clean' clean revised manuscript, 'track' revised manuscript with tracked changes (All Markup).
Usage: python3 build_response_r1.py OUT.docx"""
import json, re, sys
from docx.shared import Pt, Cm, RGBColor
from docx.enum.text import WD_COLOR_INDEX
import docx_builder as DB

L = json.load(open("analysis_r1/response_lines.json"))
N = json.load(open("analysis_r1/numbers.json"))


def _pages(pdf):
    import subprocess, re
    out = subprocess.run(["pdfinfo", pdf], capture_output=True, text=True).stdout
    return int(re.search(r"Pages:\s+(\d+)", out).group(1))


def _ref_pages(pdf):
    import subprocess
    n = _pages(pdf)
    for pg in range(n, 0, -1):
        t = subprocess.run(["pdftotext", "-f", str(pg), "-l", str(pg), "-layout", pdf, "-"], capture_output=True, text=True).stdout
        if any(l.strip().split()[-1:] == ["References"] for l in t.splitlines()):
            return n - pg + 1
    return None


N["ms_pages"] = _pages("deliverables/Biazar_Manuscript_R1_clean.pdf")
N["esm_pages"] = _pages("deliverables/ESM1_Supporting_Information_R1.pdf")
N["ref_pages"] = _ref_pages("deliverables/Biazar_Manuscript_R1_clean.pdf")


def _main_words():
    import re
    s = open("ms/ms_r1_filled.md", encoding="utf-8").read()
    b = s[s.index("# 1 Introduction"):s.index("# Declarations")]
    b = re.sub(r"\$\$.*?\$\$", " ", b, flags=re.S)
    b = re.sub(r"!\[.*?\]\(.*?\)\{.*?\}", " ", b, flags=re.S)
    b = "\n".join(l for l in b.split("\n") if not l.startswith(("|", "Table:", "+-", "+=", ":")))
    return int(round(len(b.split()), -2))


N["ms_words"] = f"{_main_words():,}"
AEL = json.load(open("raw_input/ae/annotation_lines.json"))
AEA = json.load(open("raw_input/ae/annotations.json"))
LET = open("raw_input/decision_letter.txt", encoding="utf-8").read().splitlines()
TITLE = "Beyond spatial redundancy: a graph-based and uncertainty-aware framework for groundwater monitoring network optimization"


def letter(a, b=None):
    """Verbatim text of decision-letter lines a..b (1-based, inclusive)."""
    b = b or a
    return "\n".join(LET[i - 1].strip() for i in range(a, b + 1) if LET[i - 1].strip())


def where(new=None, old=None):
    """'Revised manuscript lines a–b (tracked a'–b'); submitted version lines c–d.'"""
    out = []
    if new:
        ks = [new] if isinstance(new, str) else new
        c = ", ".join(L["clean"][k] for k in ks)
        t = ", ".join(L["track"][k] for k in ks)
        one = len(ks) == 1 and "–" not in c
        out.append(f"Revised manuscript, line{'' if one else 's'} {c} (tracked version {t})")
    if old:
        ks = [old] if isinstance(old, str) else old
        out.append("submitted version, lines " + ", ".join(L["old"][k] for k in ks))
    return ("[" + "; ".join(out) + "]") if out else ""


def comment(d, label, text):
    first = True
    for block in text.split("\n"):
        p = d.add_paragraph()
        p.paragraph_format.space_before = Pt(8 if first else 2)
        p.paragraph_format.left_indent = Cm(0.5)
        if first:
            r = p.add_run(label + " "); r.bold = True
        r = p.add_run(block); r.italic = True; r.font.color.rgb = RGBColor(0x1F, 0x3A, 0x68)
        first = False


def resp(d, *paras, loc=None, items=None, after=()):
    for i, t in enumerate(paras):
        p = d.add_paragraph(); p.paragraph_format.space_before = Pt(4)
        if i == 0:
            r = p.add_run("Response: "); r.bold = True
        DB.add_runs(p, t)
    if items:
        bullets(d, items)
    for t in after:
        p = d.add_paragraph(); p.paragraph_format.space_before = Pt(4)
        DB.add_runs(p, t)
    if loc:
        p = d.add_paragraph(); p.paragraph_format.space_before = Pt(2)
        r = p.add_run(loc); r.font.size = Pt(10)


def bullets(d, items, indent=0.6):
    for t in items:
        p = d.add_paragraph(); p.paragraph_format.left_indent = Cm(indent); p.paragraph_format.first_line_indent = Cm(-0.4)
        p.paragraph_format.space_before = Pt(1)
        DB.add_runs(p, "– " + t)


def placeholder(d, text):
    p = d.add_paragraph(); p.paragraph_format.space_before = Pt(4)
    r = p.add_run(text); r.font.highlight_color = WD_COLOR_INDEX.YELLOW


# Responses to the annotations of the Associate Editor: (annotation number, response, locations in the revised manuscript)
AE_RESPONSES = [
    (1, "We agree. The abstract was rewritten at a general level (see also AE3). It describes the two steps in plain words, the "
        "detection of wells whose information appears to be duplicated by their neighbours and the confirmation that their removal is "
        "safe given the uncertainty, and it no longer uses terms such as safeguard, network component or the names of the "
        "configurations. The highlights were removed, because the abstract now carries the main results; if the journal requires "
        "highlights, we will write them in the same terms.", ["abstract"]),
    (2, "We agree that the value of a well depends on the purpose of the network. The Introduction now states that water-level and "
        "water-quality networks sample variables with different spatial correlation and need different criteria, and it defines the "
        "objective of this network (the chloride concentration of the freshwater resource in each aquifer unit). The point "
        "is taken up again in the limitations (Sect. 4.4, item 1): a water-level network would need its own objective and scores.",
        ["intro_objective", "lim_wl"]),
    (3, "Thank you for the references. The Introduction now acknowledges that data-worth analysis and Bayesian experimental design "
        "propagate uncertainty into such decisions in the wider hydrogeological literature (Nowak et al. 2010; Thibaut et al. 2021; "
        "Delottier et al. 2026), and our statement is limited to the reduction of operational networks.", ["intro_bed"]),
    (4, "See annotation 5.", None),
    (5, "We agree, and the sentence was removed. If wells are removed because they are redundant, no gap should appear, and the "
        "submitted version did not test this. The revision tests it in two ways: the change in nearest-neighbour distance caused by "
        "the removals (Eq. 31; Sects. 3.3 and 3.5), and a withholding test in which a spatial gap is opened deliberately (all wells "
        "within 1.5ℓ of a random well are withheld) and the candidate sites of the rerun are compared with the gap (Sect. 2.9; "
        f"Sect. 3.6, Fig. 6c). In that test B-GAS sites fell into the gap more often than random sites ({N['ppb_b_any']} and {N['ppb_r_any']} % of "
        f"the replicates), but B-GAS also selected more sites ({N['ppb_kb']} against {N['ppb_ke']} per replicate); E-GAS sites did not differ "
        "significantly from random sites.",
        ["res_nn", "eval_prosp", "res_prosp"]),
    (6, "We agree, and thank you for the references. The framework selects sites one step ahead, with a geometric penalty instead of "
        "the information that the first new well would provide. This is now stated as a limitation, with sequential acquisition "
        "planning as the perspective (Sect. 4.4, item 5), citing Mern and Caers (2023) and the POMDP study you mention (Arief et al. "
        "2025, arXiv:2502.05690). The statement in the Introduction was also softened (reduction and reinforcement are 'usually' "
        "treated separately).", ["lim_seq", "intro_coupling"]),
    (7, "Hydro-LIMG (hydrogeologic multi-level information gain) is now spelled out at first use in the Introduction and listed "
        "among the abbreviations.", ["abbrev", "intro_framework"]),
    (8, "Thank you for this suggestion, which we followed. Table 1 lists the steps of the framework in order, each with its input, "
        "its rule (equation numbers) and its output, and Fig. 2 shows them as a workflow. Sect. 2.4 now starts with the input and output "
        "of the MST: it is built from the n × 2 matrix of well coordinates and contains n − 1 edges, which are then cut by Eq. (3).", ["table1", "fig2", "graph_mst"]),
    (9, "The Methods now follow the order of the computation. The MST and the neighbourhoods use only the well coordinates (Sect. 2.4); "
        "the attributes enter afterwards, through the feature vector of Eq. (11) and the agreement terms of Eq. (12). To make attributes "
        "with different units comparable, all four features are scaled to [0, 1] before distances are computed: chloride and depth by "
        "min–max scaling, trend and status through their scores (Eq. 7 and Sect. 2.5).", ["graph_mst", "info", "dep"]),
    (10, "Section 4.4 is now titled 'Limitations and perspectives' and gives the perspective that follows from each limitation.",
         ["disc_lim"]),
    (11, "Yes. The distance between wells could be computed on the chloride time series without changing the rest of the framework, "
         "and the trend attribute would then be redundant. This is now given as a perspective (Sect. 4.4, item 4).", ["lim_ts"]),
    (12, "The distance weight is now Eq. (5), and it is cited by this number where it is used again (Sect. 2.5).", ["graph_w", "spatial"]),
    (13, "The entropy weight method is not new. It is now introduced as an existing method with a reference (Zou et al. 2006) and "
         "written as Eq. (16); the constraints that we added (the cap on the correlated network family and the floor for each score) "
         "are stated after the equation.", ["entropy"]),
    (14, "Thank you for raising this. The analysis of chloride trends is not an objective of this study, and the revised text says so "
         "(Sect. 2.5). The trend class is an attribute of the District station inventory, computed by the District from the "
         "2013–2020 record, and it enters the framework only as one of the nine retention scores. It is scored as in the submitted "
         "analysis (decreasing 1.0, stable 0.5, increasing 0.0; Eq. 7), because declining trends increase monitoring value, and the joint "
         "term (Eq. 8) lowers the support of saline wells with an increasing trend. We agree that a network designed for the early "
         "detection of salinization would order the trend scores differently, as you suggest; this would be a different monitoring "
         "objective, which we now mention among the perspectives (Sect. 4.4, item 4).", ["data_edp", "trend", "lim_ts"]),
    (15, "The midpoint of 2,000 mg/L is the regional threshold recommended by the District's hydrogeologists for salinity management, "
         "and the text now says so. It also relates the value to published limits: for water of seawater composition it corresponds to "
         "about 3,600 mg/L dissolved solids (Hem 1985), just above the 3,000 mg/L limit between fresh and moderately saline water used in "
         "the District's water-use permitting (SWFWMD 2022), and it lies within the chloride range of the coastal mixing zone of the "
         "Floridan aquifer, 250–19,000 mg/L (Causseaux and Fretwell 1983). The decisions do not change when the midpoint is moved to 1,500 "
         f"or 2,500 mg/L (Sect. 3.7). In the joint perturbation no well was confirmed in {N['lhs_conf_pct']} % of the runs; the two runs "
         "that confirmed wells combined a lower midpoint (about 1,570 mg/L) with a wider transition and a higher threshold for "
         "criterion (iii) (Sect. 3.7).",
         ["chl_mid", "res_sens"]),
    (16, "We agree that a trend is not a measure of water quality. The name of the joint-quality term was kept, but the term is now "
         "defined explicitly as the combination of the chloride-level and trend scores (Eq. 8), and the text no longer describes the "
         "trend as an indicator of water quality.", ["joint"]),
    (17, "Both are now stated explicitly: the status score is 0.85 for active and 0.2 for inactive wells, and the depth score is "
         "0.35 + 0.55 × rarity, where rarity is one minus the scaled Gaussian kernel density of the well's depth within its aquifer "
         "group (Sect. 2.5; ESM Table S1).", ["status_depth"]),
    (18, "The adjustment is now given as Eq. (8).", ["joint"]),
    (19, "Operational status is the active or inactive status of the well in the District inventory (Sect. 2.2); its score is given in "
         "Sect. 2.5.", ["data_edp", "status_depth"]),
    (20, "See annotation 12: the weight is Eq. (5), and the aggregate proximity weight is defined as W = Σ_{j} w_{ij} before Eq. (9).",
         ["spatial"]),
    (21, "The three quantities are now defined: N is the number of neighbours, W = Σ_{j} w_{ij} the aggregate proximity weight and D the "
         "mean distance to the neighbours. All three are min–max scaled over the wells of the same redundancy cluster (wells linked "
         "through chains of neighbours, Sect. 2.4), not over the whole data set.", ["spatial"]),
    (22, "The compactness term is now Comp_{i} (Eq. 10), and C denotes only chloride. We checked the other symbols for the same "
         "problem and renamed the redundancy intensity (Red_{i}, Eq. 10), the three terms of the graph-influence score (Δ^{comp}, "
         "Δ^{str} and Δ^{MST}, Eq. 14), the status terms of the joint-quality layer (h^{−} and h^{+}, Eq. 8) and the five terms of "
         "the active-sensing score (g_{unc} to g_{dep}, Eq. 24).", ["spatial", "graphrole", "cand_terms"]),
    (23, "The repeated definition was removed; Eq. (10) defines the term once.", ["spatial"]),
    (24, "clip(x, a, b) is now defined at its first use, after Eq. (10).", ["spatial"]),
    (25, "Lower-case s is now used only for the pairwise similarities (s^{info} and s^{dep}, Eqs. 11–12), and upper-case S only for the "
         "graph-influence score S_{GI} (Eq. 14); the node strength is written Strength_{i}. The other symbols that were used for two "
         "quantities were renamed as well (see annotation 22).", ["info", "dep", "graphrole"]),
    (26, "Yes: the strength is the row sum of the adjacency matrix, Strength_{i} = Σ_{j} A_{ij}, and the asterisk denotes min–max scaling "
         "within the cluster. Both are now written in Eq. (13), with the same notation throughout. The outputs of the graph steps are "
         "listed in Table 1: components, neighbourhoods and redundancy clusters (Sect. 2.4), and adjacency, strength, cohesion and graph "
         "influence (Eqs. 13–14).", ["graphrole", "table1"]),
    (27, "Cohesion is computed from the adjacency matrix and is now given by its formula in Eq. (13): the mean adjacency between pairs of "
         "neighbours of the well.", ["graphrole"]),
    (28, "The uncertainty u of each score is now introduced with the scores (Sect. 2.5) and defined in ESM Table S1; for chloride, for "
         "example, u = clip(0.55 − 0.35|C − 2000|/2000, 0.10, 0.55). It is increased for small aquifer groups by the reliability term "
         "after Eq. (15) and enters the Monte Carlo simulation through Eq. (18).", ["reliab", "mc"]),
    (29, "We agree. The sensitivity is now shown explicitly (Sects. 2.9 and 3.7; ESM S7), in two ways: one-at-a-time variations of "
         "parameters and structural choices (ESM Table S10), and a joint Latin hypercube perturbation of "
         f"{N['lhs_k']} fixed parameters in {N['lhs_n']} runs, which includes the interactions among the sequential thresholds "
         "(ESM Table S11, Fig. S3). "
         f"{N['lhs_text'].split(', the median Jaccard')[0].replace('the number of screened wells', 'The number of screened wells')}, and "
         f"no well was confirmed in {N['lhs_conf_pct']} % of the runs.", ["eval_sens", "res_sens"]),
    (30, "The grid is hexagonal (Eq. 23) and is placed only within the support domain; the expression 'uniform grid' was removed. The "
         "steps are illustrated in the new ESM Fig. S1.", ["cand_grid"]),
    (31, "We added ESM Fig. S1, which shows the generation of candidate sites for two components: the support domain, the hexagonal "
         "grid, the points excluded near existing wells, the injected points, the candidate pool after thinning and removal of points "
         "in open water, and the selected sites.", ["cand_grid"]),
    (32, "The five terms of the active-sensing score (now Eq. 24) are defined after the equation: g_{unc}, the distance-weighted mean "
         "uncertainty of the surrounding wells; g_{sup}, the distance to the nearest well relative to ℓ; g_{gra}, their weighted mean "
         "graph influence; and g_{rep} and g_{dep}, the weighted dispersion of their feature and dependency attributes. The adaptation of the weights is "
         "Eq. (25).", ["cand_terms", "cand_greedy"]),
    (33, "The penalty is now Eq. (30): the remaining scores are multiplied by one minus the weighted sum of a spatial kernel and of the "
         "similarities of the Hydro-LIMG score and of the vector of gain terms to those of the site just selected.", ["egas_pen"]),
    (34, "The B-GAS update is now given as Eq. (26). We agree that the penalty only discourages a second site close to the first and "
         "does not use what the first new well would measure; this is now stated in Sect. 4.4 (item 5), with sequential acquisition "
         "planning as the perspective (see annotation 6).", ["cand_greedy", "lim_seq"]),
    (35, "See annotation 36.", None),
    (36, "The four levels of Hydro-LIMG are combined in Eq. (28), and each level is now defined by an equation in ESM S1 (Eqs. S1–S4), "
         "with references to the feature vector (Eq. 11) and the graph-influence score (Eq. 14). These are the equations implemented in "
         "the code. The validation gain is Eq. (29) and the fusion of the three scores Eq. (27).", ["limg", "vgain"]),
    (37, "AI-GAS has been removed (see AE1). We agree with this assessment: a surrogate trained on B-GAS can at best reproduce B-GAS, and "
         "the submitted version established neither a computational nor another gain.", None),
    (38, "Removed with AI-GAS (see annotation 37).", None),
    (39, "The value-of-information formulation was removed. As you note, no monetary value was attached to information, so it was not a "
         "value-of-information analysis in the usual sense. The decision problem is now stated as an expected loss with explicit costs "
         "of wrong removal and wrong retention (Eq. 1), and the evaluation uses the measures of Sect. 2.9.", ["eq1", "eval"]),
    (40, "The Jaccard index is now defined, |A ∩ B|/|A ∪ B|, with its reference (Jaccard 1912).", ["jaccard"]),
    (41, "Removed from the Methods; results are reported only in Sect. 3.", None),
    (42, "The cross-reference was wrong. The comparison is now defined in Sect. 2.9, and its results are given in Sect. 3.5 and Table 3.",
         ["eval_budget", "res_budget"]),
    (43, "Thank you; the reference was added where the joint sensitivity analysis is introduced (Sect. 2.9).", ["eval_sens"]),
    (44, "You are right; see annotation 48 for the explanation and the correction.", None),
    (45, "Done throughout the Results and Discussion: the mechanisms are referred to by equation number (for example Eqs. 7, 15, 19 and "
         "22 in Sects. 3.1–3.3).", ["res_detect", "res_confirm"]),
    (46, "Fig. 3b is now a zoom on the dominant Upper Floridan component in Citrus, Hernando and Pasco counties, which contains all screened "
         "Upper Floridan wells. It shows the neighbour links within ℓ, distinguishes wells with and without a critical designation and "
         "labels the screened wells with their SIDs, so that their spacing can be judged.", ["fig3"]),
    (47, "We agree. The reconstruction errors used to evaluate the framework are now computed on log10 chloride and reported as a factor "
         "(Eq. 32), which is a relative error; errors in mg/L are given alongside for the established methods (Table 3). The safeguard "
         "criterion (i) (Eq. 22) and the validation gain (Eq. 29) still use the absolute error, as in the submitted framework. In this "
         "network the choice does not affect the confirmation, because every screened well is returned to REVIEW by criterion (iii) "
         "alone (Sect. 3.3).", ["eval_budget", "res_temporal_a", "res_confirm"]),
    (48, "You are right, and the interpretation in the submitted version was wrong. The median nearest-neighbour distance of the retained "
         "Upper Floridan wells fell (from 1,121 to 929 m) because most removed wells had nearest-neighbour distances above the median "
         "(median 1,991 m; 15 of the 22 above 1,121 m). Removing values above the median lowers the median, although the distances of "
         "their neighbours increase. The removed wells were therefore not the most closely spaced wells. The revision reports the "
         "aquifer-weighted change in mean nearest-neighbour distance (Eq. 31) and shows directly "
         "that the screened wells are not the most closely spaced wells (higher distance keep score, Sect. 3.2).",
         ["res_dist", "res_nn"]),
    (49, "Agreed; this is now stated as a limitation (Sect. 4.4, item 5; see annotations 6 and 34).", ["lim_seq"]),
    (50, "Fig. 5 shows the final score of each selected site (marker area). The scores of all candidate sites, with each term of "
         "Eqs. (24)–(29), are written by the code (ESM 2).", ["fig5"]),
    (51, "Removed with AI-GAS.", None),
    (52, "Removed with AI-GAS (see annotation 37).", None),
    (53, "No. The statement was not supported, and it was removed with AI-GAS.", None),
    (54, "The Supporting Information was reduced from 20 figures to 3 and now contains supporting material only: the illustration of the "
         "candidate generation (Fig. S1), the equal-budget comparison in graphical form (Fig. S2; the values are in Table 3 of the main "
         "text) and the sensitivity analysis (Fig. S3). All results needed for the conclusions are in the main text.", None),
    (55, "Figure 8 and this statement were removed with the comparison of configurations.", None),
    (56, "The figure was removed. In the revised figures, colour identifies the aquifer group, the decision class or the configuration "
         "and is used in the same way in all figures.", None),
    (57, "Removed (see annotation 55).", None),
    (58, "Removed with the Pareto/hypervolume comparison.", None),
    (59, "Removed with AI-GAS.", None),
    (60, "Removed with AI-GAS.", None),
    (61, "Corrected; the section was rewritten.", None),
    (62, "Thank you for this point and the reference. Yes: the ordinary-kriging variance depends only on the well locations, which is one "
         "reason why it selected different wells. An indicator-kriging variance, which depends on the data through the probability of "
         "exceeding a chloride threshold, would be a stronger geostatistical baseline in salinized aquifers. We did not add it as a "
         "fourth method, because the variogram of log chloride is mostly unstructured at the spacing of this network (ESM Table S7), "
         "but Sect. 4.1 now discusses it as the better geostatistical alternative (Cong-Thi et al. 2026).", ["disc_ik"]),
    (63, "The Discussion now has four subsections (4.1–4.4).", ["disc"]),
    (64, "Thank you; we agree and added this to the Discussion (Sect. 4.2): discontinuation need not be final, the record of a "
         "discontinued well remains, and a well can be re-activated if its neighbours change behaviour, which suggests an adaptive "
         "scheme that suspends stable wells with stable neighbours. On the leave-one-out criterion: the past chloride of a removed well "
         "is known, and the criterion asks a different question, whether the remaining wells carry the same information, so that a "
         "future change at that location would be seen by them. Leave-one-out errors on the data used for the decision cannot show "
         "this, and the revision therefore tests it with the 2021–2026 record, which is not used in the decision (Sects. 2.9 and 3.6). "
         "The statements on irreversibility were removed.", ["disc_reversible", "eval_temporal", "res_temporal_a"]),
    (65, "We agree, and the claim was removed. The revision tests the candidate ranking against random and space-filling sites in two "
         "withholding tests: the ranked sites did not recover informative withheld wells consistently better than random sites "
         "(Sect. 3.6). The abstract and the Conclusions say so, and the coupling of reduction and reinforcement is presented as a "
         "design choice, not as a demonstrated advantage.", ["res_prosp", "concl"]),
    (66, "The Conclusions were reduced to one paragraph that does not repeat the Discussion.", ["concl"]),
    (67, "Thank you for the reference. With AI-GAS removed, this comparison no longer appears in the paper, so we did not add it.", None),
    (68, "We agree that this is well known. The sentence now says so, with the references you suggest (Strebelle 2002; Mariethoz and "
         "Caers 2014).", ["disc_mps"]),
    (69, f"The code will be deposited in a public repository with a DOI; the link ({N['code_url']}) is given in the Code availability "
         "statement, and the code is also provided as ESM 2. The data are available on request (Data availability statement).",
         ["code_avail", "data_avail"]),
]
assert [x[0] for x in AE_RESPONSES] == list(range(1, 70))


def build(path):
    d = DB.new_document(line_numbers=False, double=False, size=11)
    p = d.add_paragraph(); r = p.add_run("Response to the Editor, the Associate Editor and Reviewer 2"); r.bold = True; r.font.size = Pt(13)
    DB.para(d, "**Manuscript** HYJO-D-26-00546", indent=False)
    DB.para(d, "**Title** " + TITLE, indent=False)
    DB.para(d, "**Authors** Seyed Mostafa Biazar, Samantha Smith, Jason Patterson", indent=False)
    DB.para(d, "**Line numbers.** Locations are given for the clean revised manuscript and, in parentheses, for the revised manuscript "
               "with tracked changes (All Markup view). Because most of the text was rewritten rather than edited, the comparison file "
               "shows the revised text first and the deleted text of the submitted version after the Conclusions. Where useful, line "
               "numbers of the submitted version are also given.", indent=False)

    DB.heading(d, "Dear Prof. Schafmeister, dear Dr. Hermans,", 2)
    DB.para(d, "Thank you for handling our manuscript, and thank you, Dr. Hermans, for reviewing it yourself when the other reviewers did "
               "not respond. We also thank Reviewer 2 for a detailed and constructive report. The comments agree on the main points: the "
               "manuscript was too long, the methods could not be followed or reproduced, the AI part did not belong in this paper, the "
               "monitoring objective was not stated, and the evaluation was not independent of the data used for the decisions. We "
               "accept all of these points. The main changes are:", indent=False)
    bullets(d, [
        "AI-GAS has been removed, together with the Pareto/hypervolume comparison of the configurations.",
        "The methods were rewritten around a formal statement of the decision problem (Eqs. 1–2). Every criterion now has a numbered "
        "equation (Eqs. 3–32), Table 1 lists the input, rule and output of each step, a list of abbreviations was added, and all fixed "
        "parameters are listed in ESM Table S1 with the equation in which they are used.",
        "The monitoring objective is stated (salinity: the characterization of the chloride concentration of the freshwater resource "
        "in each aquifer unit), and each score is linked to it.",
        "The evaluation now uses tests that do not feed back into the decisions: an equal-budget comparison with three established "
        "reduction methods and with random removal, an out-of-period test with the 2021–2026 record, two pseudo-prospective withholding "
        f"tests, one-at-a-time and structural sensitivity tests (including a graph with hydrostratigraphic barriers), and a joint "
        f"(Latin hypercube) sensitivity analysis of {N['lhs_k']} parameters.",
        f"The main text is less than half as long as before (about {N['ms_words']} instead of 16,100 words from Introduction to "
        "Conclusions), the Supporting Information has 3 figures instead of 20, and the hydrogeologic setting is described with a "
        "schematic cross-section (Fig. 1c).",
    ])
    DB.para(d, "While revising, we checked the code line by line against the manuscript and compiled the 2021–2026 chloride record "
               "from the District's Environmental Data Portal (EDP) for the new tests. This brought up issues that the reviewers could not have seen from the text, and we "
               "report them in a separate section at the end of this letter (Additional changes by the authors). The most important one "
               f"is that {N['n_springs']} of the 354 stations analysed in the submitted version were spring vents, not wells, and that both "
               "removals confirmed in the submitted version were spring vents (Halls River Head Main Spring and Crystal Beach Spring). "
               f"Spring vents are now a separate station class. With this and the other corrections, the framework screens {N['n_screened']} "
               f"of the {N['n_wells']} wells as potentially redundant and confirms none of them for removal. ESM S3 (Table S5) reconciles "
               "the submitted and the revised results step by step. The core of the paper is unchanged: a graph-based screening of the "
               "network, the separation of detection from confirmation, and candidate sites ranked with the evidence from the existing wells.",
            indent=False)
    DB.para(d, "Below, each comment is reproduced in italics, followed by our response and the location of the change.", indent=False)
    DB.para(d, "Sincerely,", indent=False)
    DB.para(d, "Seyed Mostafa Biazar, on behalf of all authors", indent=False)

    # ------------------------------------------------------------------ Editor
    DB.heading(d, "Editor (Prof. M.-Th. Schafmeister)", 2)
    comment(d, "E1", letter(72))
    resp(d,
         "The manuscript was shortened throughout. AI-GAS and the comparison of configurations were removed; each method is now "
         "defined once, by an equation, instead of being explained in several places; each result is reported once; and the Discussion "
         f"and Conclusions no longer repeat the Results. The main text (Introduction to Conclusions) went from about 16,100 to about {N['ms_words']} "
         "words, the main-text figures from 9 to 6 and the tables from 5 to 3. The Supporting Information was replaced by ESM 1 "
         f"({N['esm_pages']} pages, 3 figures instead of 20, 11 tables) and ESM 2 (code).",
         f"The revised manuscript has {N['ms_pages']} pages instead of 74, of which {N['ref_pages']} are references; it is set in "
         "10-point Times New Roman with double spacing and continuous line numbers, as in the Instructions for Authors. The remaining "
         "length is mostly material that the Associate Editor and Reviewer 2 asked for: the formal decision problem, numbered equations, "
         "the table of steps with their inputs and outputs, and the independent tests. If the Editor prefers, Table 1 and Fig. 2 can be "
         "moved to the ESM.")
    comment(d, "E2", letter(74))
    resp(d,
         "Section 2.1 was rewritten as a short description of the three monitored units, following the current hydrostratigraphic "
         "framework of the District (LaRoche and Horstman 2023): the surficial aquifer; the Hawthorn aquifer system (formerly the "
         "intermediate aquifer system) with the Peace River, upper Arcadia and lower Arcadia aquifers, which pinches out north of central "
         "Hillsborough County; and the Floridan aquifer system, whose upper part is unconfined or thinly confined and karstic in the north, "
         "with numerous springs, and confined in the south. The section also describes where the freshwater–saltwater transition zone lies "
         "relative to the monitored interval, because this explains why wells close together in plan view can sample different water. "
         "A schematic north–south cross-section along the coast was added as Fig. 1c.",
         loc=where(["study_area", "fig1"], "study"))

    # ------------------------------------------------------------------ Associate Editor
    DB.heading(d, "Associate Editor (Dr. T. Hermans)", 2)
    comment(d, "AE0", letter(80, 81))
    resp(d, "Thank you. The comments made in the annotated PDF are answered in the last section of this letter.")
    comment(d, "AE1", letter(82))
    resp(d,
         "We agree, and AI-GAS has been removed from all parts of the paper and of the ESM. The rationale for the surrogate was not "
         "developed in the submitted version, and as the reviewers point out, a model trained on B-GAS outputs can only reproduce B-GAS. "
         "We removed the Pareto/hypervolume comparison at the same time, because it compared configurations with different budgets "
         "(see R2.2). The paper now concentrates on the two elements identified by the Associate Editor: the graph representation of the "
         "network and the separation of detection from confirmation. A surrogate with a clear purpose, its training and validation and "
         "its computational gain may be the subject of a separate paper.",
         loc="[Deleted: submitted version, lines " + ", ".join(L["old"][k] for k in ["aigas", "aigas_results", "pareto"]) + "]")
    comment(d, "AE2", letter(83))
    resp(d,
         "The methods section was rewritten as suggested:",
         items=[
        "A list of abbreviations follows the keywords.",
        "Section 2.3 states the decision problem (Eqs. 1–2: decision variables, asymmetric loss, constraints) and gives an overview of "
        "the framework. Table 1 lists, for each step, its input, rule (equation numbers) and output, and Fig. 2 shows the workflow.",
        "Every criterion and definition has a numbered equation: graph construction (Eqs. 3–5), retention evidence (Eqs. 6–15), weights, "
        "utility and probabilistic resolution (Eqs. 16–21), confirmation (Eq. 22), candidate generation and scoring (Eqs. 23–30) and the "
        "evaluation measures (Eqs. 31–32). The Results refer to these numbers.",
        "ESM Table S1 lists every fixed parameter with its value, the equation in which it is used, and where it was documented "
        "(manuscript, Supporting Information or code only).",
        "The code (ESM 2) reproduces every number, table and figure of the paper from the station inventory and the EDP record.",
         ],
         loc=where(["abbrev", "decision", "graph", "evidence", "weights", "confirm_m", "cand_m", "eval"]))
    comment(d, "AE3", letter(84))
    resp(d,
         "The abstract was rewritten in general terms. It states the problem (proximity as a proxy for redundancy in layered coastal "
         "aquifers), the approach, the data, the main results and the conclusion, without the names of configurations, indices or "
         "parameters.",
         loc=where("abstract", "abstract"))
    comment(d, "AE4", letter(85))
    resp(d,
         "The Discussion now has four subsections: 4.1 Redundancy is a network property, not proximity; 4.2 Detection and confirmation are "
         "different questions; 4.3 What the graph represents; 4.4 Limitations and perspectives. Section 4.4 lists eight limitations with "
         "the corresponding perspectives (one regional network; the dominant role of the District designation; reported total depth "
         "instead of open intervals; chloride as the only constituent; candidate sites; fixed coefficients and costs; the short test "
         "period; spring vents). The Conclusions were reduced to one paragraph that does not repeat the Discussion.",
         loc=where(["disc", "concl"], ["discussion", "conclusion"]))
    comment(d, "AE5", letter(86))
    resp(d,
         "All figures were redrawn at 600 dpi with larger fonts, one colour per aquifer group throughout the paper and a colour-blind-safe "
         "palette. Continuous colour scales were removed: colour now identifies the aquifer group, the decision class or the configuration, and "
         "magnitudes are shown by position or marker size. The captions explain every panel, symbol and colour. The Supporting "
         "Information was reduced from 20 figures to 3 (ESM Figs. S1–S3), and the remaining material is given as tables.",
         loc=where(["fig1", "fig2", "fig3", "fig4", "fig5", "fig6"]))
    comment(d, "AE6", letter(87))
    resp(d, "These points are answered in detail in our responses to Reviewer 2 below (R2.2 on the comparison of methods, R2.4 on the "
            "formulation of the problem, R2.5 on independent validation).")

    # ------------------------------------------------------------------ Reviewer 2
    DB.heading(d, "Reviewer 2", 2)
    comment(d, "R2.0", letter(94, 95))
    resp(d,
         "Thank you for this assessment. We streamlined the paper (see E1 and AE1), justified the components and parameters (Sects. 2.4–2.8, "
         "ESM Table S1), and stated the hydrogeologic objective explicitly (R2.1). The specific comments are answered below.")

    comment(d, "R2.1", letter(98, 100))
    resp(d,
         "We agree that the value of a well can only be judged against a stated objective, and this was missing. The network is a "
         "groundwater-quality network in a coastal aquifer system whose main management concern is salinity. Its objective is now stated "
         "in the Introduction as the characterization of the chloride concentration of the freshwater resource in each aquifer unit. A "
         "well is redundant only when its chloride level and trend class are duplicated by neighbours in the same aquifer unit and its "
         "removal does not disrupt the structure of the network.",
         "Each element of the framework is now linked to this objective. The chloride score (Eq. 6) gives high retention support to fresh "
         "wells, with the regional management threshold of 2,000 mg/L as midpoint; the trend class of the District inventory enters as an "
         "attribute of the well (Eq. 7; the analysis of trends is not an objective of the study); information and dependency uniqueness "
         "(Eqs. 11–12) measure whether a well's chloride is reproduced by its neighbours; and the graph terms describe the role of the well "
         "in the network. The evaluation uses a measure that follows from the same objective: the error with which the later (2021–2026) "
         "chloride of a well is reconstructed from the remaining wells.",
         "The explicit objective also exposed a limitation that we now discuss (Sect. 4.2): the chloride score encodes a freshwater-resource "
         "objective, so brackish wells receive low retention support. Without the District designation, the wells that would be confirmed "
         "for removal are transition-zone monitors (Sect. 3.7). In this network they are protected by their designation; elsewhere, an "
         f"explicit transition-zone criterion would be needed. The same property decides the confirmation in this network: all {N['n_noncrit']} "
         f"wells without a critical designation are fresh (chloride ≤ {N['noncrit_cl_max']} mg/L), so the chloride criterion returns every "
         "screened well to REVIEW (Sect. 3.3).",
         loc=where(["intro_objective", "chloride", "res_sens_struct", "disc_transition"]))

    comment(d, "R2.2", letter(101, 104))
    resp(d,
         "We agree. The submitted comparison of B-GAS, E-GAS and AI-GAS compared removal sets of different sizes, and the hypervolume "
         "comparison inherited this problem. We changed the evaluation in three ways.",
         "First, B-GAS and E-GAS are no longer presented as competing designs. They are two stages of one procedure: detection (B-GAS) and "
         "confirmation of the detected wells (E-GAS). Removal statistics of the two stages are no longer compared with each other, and the "
         "hypervolume comparison was removed.",
         f"Second, the detection stage is compared with three established reduction methods at an equal budget of {N['n_screened']} "
         "removals: distance thinning, reconstructability (information-based removal) and kriging-variance reduction, and with 1,000 random "
         "removal sets of the same size. Each method was applied to all wells and to the wells without a critical designation, which is "
         "the pool available to GAS (Sect. 2.9; Table 3; ESM S5). Applied to all wells, the established methods selected almost entirely "
         f"different wells (Jaccard overlap {N['j_dist']}–{N['j_rec']}), removed {N['crit_rec']}–{N['crit_dist']} wells with a critical "
         f"designation and increased the mean nearest-neighbour distance by {N['dnn_krig']}–{N['dnn_dist']} m, compared with {N['dnn_gas']} m "
         f"for GAS. Within the eligible pool, GAS produced a smaller increase in nearest-neighbour distance than the three established methods ({N['dnn_gas']} against {N['dnnr_krig']}–{N['dnnr_dist']} m). The later record did not separate the "
         "methods, and we say so.",
         "Third, candidate sites are evaluated against sites drawn at random from the same candidate pool and against space-filling "
         "sites, in two withholding tests (Sect. 2.9). The random and space-filling sites are drawn in the number selected by E-GAS, so "
         "that their budget is that of E-GAS; B-GAS selects a somewhat larger number (ESM Tables S8–S9). The ranked sites did not recover "
         "informative withheld wells consistently better than random sites (see R2.5).",
         loc=where(["eval_budget", "res_budget", "table3", "eval_prosp", "res_prosp"], ["cross", "pareto", "baselines"]))

    comment(d, "R2.3", letter(105, 108))
    resp(d,
         "We agree with this reading of AI-GAS. The surrogate was trained on targets derived from B-GAS and could therefore only approximate "
         "B-GAS; its agreement with B-GAS is not evidence of hydrogeologic learning, and the conclusion about the bounded contribution of AI "
         "did not follow from the analysis. The reviewer is also right that the Methods did not explain the role of the surrogate in the "
         "decisions on existing wells. Following the Associate Editor's recommendation, AI-GAS has been removed from the paper, together with "
         "the related conclusions.",
         loc="[Deleted: submitted version, lines " + ", ".join(L["old"][k] for k in ["aigas", "aigas_results"]) + "]")

    comment(d, "R2.4", letter(109, 113))
    resp(d,
         "We agree that the framework is a multi-criteria decision-support procedure and not a numerical optimizer, and the paper now says "
         "so. Section 2.3 formulates the decision problem: binary decision variables for discontinuing wells (and for selecting candidate "
         "sites), an asymmetric expected loss in which wrongly discontinuing a well costs more than keeping a redundant one (Eq. 1), and "
         "constraints for wells with a critical designation, isolated wells, wells with a removal-risk signal and the number of candidate "
         "sites (Eq. 2). Without constraints, Eq. (1) discontinues a well only when its probability of being replaceable exceeds "
         "c_{R}/(c_{R} + c_{K}); GAS approximates this rule with explicit criteria, Monte Carlo probabilities and the confirmation step. The "
         "Introduction describes the framework as a decision-support procedure for network redesign, solved with explicit rules rather than "
         "by a numerical optimizer. We kept the word optimization in the title in the broad sense of network redesign used in the "
         "monitoring-design literature, and the text now defines it.",
         f"For the interactions among parameters, we replaced the local perturbation by a joint analysis: {N['lhs_n']} parameter sets were "
         f"drawn by Latin hypercube sampling over {N['lhs_k']} fixed parameters (±25 %; ±10 % for the cluster review, second-anchor and hard-resolver thresholds, "
         "±0.10 for the safeguard thresholds, 80th–95th percentile for the neighbourhood length) and run through the "
         "complete sequence of thresholds, with partial rank correlation coefficients for parameter influence and an additive rank model to "
         "measure interactions. "
         f"{N['lhs_text'].split(', the median Jaccard')[0].replace('the number of screened wells', 'The number of screened wells')}, and no well was "
         f"confirmed in {N['lhs_conf_pct']} % of the runs. The additive model explained {N['lhs_r2n']} % of the variance of the number of screened "
         f"wells and {N['lhs_r2j']} % of that of the overlap with the reference set; the remainder reflects interactions among the "
         "sequential thresholds. "
         "One-at-a-time and structural variants are reported as well (ESM S7).",
         loc=where(["eq1", "intro_framework", "eval_sens", "res_sens"], "param"))

    comment(d, "R2.5", letter(114, 118))
    resp(d,
         "We agree on both points. On validation: the leave-one-out errors of the submitted version used the same chloride data that enter "
         "the scores, and they were also used in the safeguard and the validation gain. They are no longer presented as validation; the "
         "paper states that they cannot show performance (Sects. 2.9 and 4.2). We added the two tests that the reviewer proposed, both "
         "independent of the decisions:",
         items=[
        "Temporal validation. The decisions use the 2013–2020 chloride data of the District inventory; the 2021–2026 record (EDP, median "
        f"{N['val_n_median']} sampling days per well) is used only for testing. The later chloride of the screened wells was not "
        f"reconstructed from neighbouring wells better than that of other wells (median error factor {N['tv_scr']} against {N['tv_oth']}; "
        f"one-sided Mann–Whitney p = {N['tv_p']}), and chloride rose in some of the screened wells after 2020. This is consistent with the "
        "decision not to confirm them, although the difference from other wells is not significant.",
        "Pseudo-prospective tests. Wells were withheld, the framework was rerun on the remaining wells, and the candidate sites were "
        f"compared with the withheld wells, both for wells withheld at random (15 %, {N['pp_reps']} replicates) and for spatial gaps (all wells within "
        f"1.5ℓ of a random well, {N['ppb_reps']} replicates). The result does not support the candidate ranking: with wells withheld at "
        f"random, B-GAS and space-filling sites recovered informative withheld wells less often than random sites from the same pool "
        f"(paired Wilcoxon p {N['pp_p_b']} and {N['pp_p_s']}) and E-GAS sites did not differ from them (p {N['pp_p_e']}); with spatial "
        f"gaps, B-GAS sites, which were more numerous, were within ℓ of more withheld wells than random sites (p {N['ppb_p_b']}), and "
        f"E-GAS sites again did not differ (p {N['ppb_p_e']}). We report this in the Results, the abstract and the Conclusions, and we "
        "toned down the claims about candidate placement accordingly (Sect. 4.4, item 5).",
         ],
         after=["On the interpretation of the graph: the paper now states that the graph describes monitoring-network topology within an aquifer "
         "group, informed by hydrochemical similarity, and that it is not a model of hydraulic connection; terms such as bridge or "
         "connectivity refer to this topology (Sects. 2.4 and 4.3). We tested the effect of known hydrostratigraphic barriers by rebuilding the "
         "graph without minimum-spanning-tree edges between wells assigned to different hydrostratigraphic zones (Upper Floridan aquifer and "
         "Avon Park high-permeability zone; Peace River, upper and lower Arcadia aquifers), with a strict and a lenient rule for wells without "
         f"a zone assignment. This {N['oat_hs_text']} of the screened set ({N['oat_hs_strict']} and {N['oat_hs_len']} screened wells instead of "
         f"{N['n_screened']}) and no well was confirmed (Sect. 3.7; ESM Table S10). Potentiometric gradients, flow direction and "
         "transmissivity are not available at the spacing of this network for all three units; Sect. 4.3 discusses how they could be used "
         "to weight the edges."],
         loc=where(["eval_temporal", "eval_prosp", "res_temporal", "fig6", "disc_detect", "graph", "res_sens", "disc_graph"]))

    DB.heading(d, "Reviewer 2: suggested modifications", 3)
    comment(d, "R2.6", letter(121))
    resp(d,
         "Figure 1 was redrawn. Panel a locates the study area in Florida, panel b shows all stations with a latitude–longitude frame, "
         "county names, a scale bar and a north arrow, and panel c is the new schematic hydrostratigraphic section. The caption explains "
         "every panel and symbol, and panel b is described in Sect. 2.2.",
         loc=where(["fig1", "data_springs"]))
    comment(d, "R2.7", letter(122))
    resp(d,
         "All figures were redrawn (see AE5) at their print width, with axis labels and legends of 7–8 pt and the same symbols and "
         "colours throughout the paper. Figure 8 of the submitted version, one of the two figures mentioned, compared the configurations "
         "and was removed with AI-GAS; the maps (Figs. 1, 3 and 5) now use the full page width.")
    comment(d, "R2.8", letter(123))
    resp(d,
         "All captions were rewritten so that each figure can be read without the text: every panel, symbol, colour, abbreviation and "
         "quantity is explained, and the captions refer to the equations that define the plotted quantities.",
         loc=where(["fig1", "fig2", "fig3", "fig4", "fig5", "fig6"]))
    comment(d, "R2.9", letter(124))
    resp(d,
         "The terms are defined once, in Sect. 2.3 and Table 1, and used consistently: KEEP, REVIEW and CANDIDATE_REMOVE are the classes "
         "of the probabilistic resolution; a screened well is a well classified CANDIDATE_REMOVE by the detection stage (B-GAS); a confirmed "
         "well is a screened well without a removal-risk signal (Eq. 22); screened wells with a removal-risk signal are returned to REVIEW. "
         "The term REMOVE is no longer used.",
         loc=where("decision"))
    comment(d, "R2.10", letter(125))
    resp(d,
         "The repetitions were removed. The AI message no longer exists, each result is stated once in the Results, the Discussion "
         "interprets rather than repeats it, and the Conclusions are one paragraph.",
         loc=where(["disc", "concl"]))

    # ------------------------------------------------------------------ additional changes
    DB.heading(d, "Additional changes by the authors", 2)
    DB.para(d, "The following changes were not requested by the reviewers. We report them because they change the results. ESM S3 "
               "(Table S5) shows the effect of each change, starting from the submitted code and data, which reproduce the published "
               "result exactly (23 screened, 2 confirmed) once the safeguard thresholds of the submitted Supporting Information are used; "
               "the code as received used other thresholds and confirmed one station (step L0).", indent=False)
    DB.para(d, f"**A1. Spring vents as a separate class.** {N['n_springs']} of the 354 stations were spring vents. A vent samples the "
               "integrated discharge of a springshed rather than an aquifer interval, has no well depth, and its chloride responds to tide "
               "and discharge, so its redundancy cannot be judged with the criteria for wells. Both removals confirmed in the submitted "
               "version were spring vents (SIDs 20056 and 21106). With the vents in the well graph, the revised framework confirms the same "
               f"two vents (Sect. 3.7). The {N['n_wells']} wells are now analysed, and the code keeps the vents as a separate class; "
               "they need their own screening based on discharge, springshed and vent chemistry (Sect. 4.4).",
            indent=False)
    DB.para(d, "**A2. Agreement between code and text.** Where the code differed from the values stated in the submitted manuscript or "
               "Supporting Information, the stated values are now used: the trend scores 1.0/0.5/0.0 (Eq. 7; the code used 0.80/0.65/0.25), "
               "the graph-role shrinkage for clusters of fewer than three wells (Eq. 13; the code applied it to clusters of three or fewer), "
               "the structural value of the calibration step including the graph-influence score (Eq. 20), the safeguard thresholds of "
               "the submitted Table S1 (Eq. 22), the adaptive active-sensing weights in E-GAS (Eq. 25), and the fusion and Hydro-LIMG level "
               "weights (Eqs. 27–28). The validation gain (Eq. 29) used the leave-one-out errors of the screened wells of all aquifer "
               "groups, so that Hawthorn and surficial candidate sites were ranked by Upper Floridan wells; it now uses the screened wells "
               "of the candidate's own aquifer group, because the aquifer groups are processed independently. The candidate domain was not "
               "clipped to the shoreline, so that some sites fell in Tampa Bay or the Gulf of Mexico; such points are now removed. Two functions that the "
               "submitted FINAL6 code called but did not contain were restored from the B-GAS script submitted with it (Final5NEW; ESM S3, change C0). Three descriptions that could not "
               "be implemented as written (the three-class cluster rule, the small-cluster shrinkage 'towards 0.55' and the adaptive weights "
               "'±30 %') are now stated as coded (Eqs. 13, 19 and 25; ESM S3), and the four levels of Hydro-LIMG, which the submitted "
               "version described only in words, are given as equations of the code (ESM S1, Eqs. S1–S4). All values are listed in ESM "
               "Table S1 with their source.",
            indent=False)
    DB.para(d, "**A3. Correction of the minimum spanning tree.** The MST was computed on a Delaunay triangulation, which ignores points "
               "that share coordinates with another point. Wells at multi-depth sites with identical coordinates therefore received no "
               "edge and were classed as isolated. The MST is now built on the complete distance graph (Sect. 2.10). The screened set did not "
               "change, either at this step of the reconciliation (ESM Table S5, step L4) or in the revised analysis (ESM Table S10).",
            indent=False)
    DB.para(d, f"**A4. Role of the District designation.** The designation of critical wells is applied as in the submitted analysis (a "
               "well is critical when any of its records carries the designation). The revision states its consequence: "
               f"{N['n_critical']} of the {N['n_wells']} wells ({N['crit_pct']} %) are critical, so the decision space consists of "
               f"{N['n_noncrit']} wells. The results without the designation, and with the designation of the dominant record, are "
               "reported in Sect. 3.7.",
            indent=False)

    # ------------------------------------------------------------------ annotated PDF
    DB.heading(d, "Associate Editor: comments in the annotated PDF", 2)
    DB.para(d, "The annotations are numbered in the order in which they appear in the PDF. Page and line numbers refer to the submitted "
               "version (Editorial Manager PDF); the highlighted text is quoted where the annotation has no comment.", indent=False)
    for n, text, keys in AE_RESPONSES:
        a, ln = AEA[n - 1], AEL[n - 1]["lines"]
        lines = f"line {ln[0]}" if ln[0] == ln[1] else f"lines {ln[0]}–{ln[1]}"
        c = re.sub(r"\n\s*\n", "\n", (a.get("comment") or "").strip())
        if not c and not a["highlight"].strip():
            c = "[strike-out without comment of the full stop in \u201c(kriging-variance) reduction. were applied\u201d]"
        elif not c:
            c = "[highlight without comment] \u201c" + " ".join(w for w in a["highlight"].split() if not w.isdigit()).strip() + "\u201d"
        comment(d, f"Annotation {n} (p. {a['page']}, {lines}).", c)
        resp(d, text, loc=where(keys) if keys else None)
    d.save(path)


if __name__ == "__main__":
    build(sys.argv[1] if len(sys.argv) > 1 else "deliverables/Response_to_Reviewers_R1.docx")
    print("written")
