"""Line numbers (submitted manuscript) of every AE annotation: annotation rectangle -> nearest margin line number."""
import json, re, subprocess, sys
from pypdf import PdfReader
PDF = "raw_input/ae/HYJO-D-26-00546_AE_annotated.pdf"
r = PdfReader(PDF)
xml = subprocess.run(["pdftotext", "-bbox", PDF, "-"], capture_output=True, text=True).stdout
pages = re.split(r"<page ", xml)[1:]
nums = []          # per page: list of (y_center, line_number)
for p in pages:
    L = []
    for m in re.finditer(r'<word xMin="([\d.]+)" yMin="([\d.]+)" xMax="([\d.]+)" yMax="([\d.]+)">(\d{1,4})</word>', p):
        x0, y0, x1, y1, t = float(m[1]), float(m[2]), float(m[3]), float(m[4]), int(m[5])
        if x1 < 70:                               # left-margin line numbers
            L.append(((y0 + y1) / 2, t))
    nums.append(L)
out = []
for pi, pg in enumerate(r.pages):
    H = float(pg.mediabox.height)
    for a in pg.get("/Annots") or []:
        a = a.get_object()
        st = a.get("/Subtype")
        if st not in ("/Highlight", "/Text", "/StrikeOut"):
            continue
        q = a.get("/QuadPoints")
        if q:
            ys = [H - float(q[i]) for i in range(1, len(q), 2)]
        else:
            rc = [float(x) for x in a["/Rect"]]; ys = [H - rc[1], H - rc[3]]
        lo, hi = min(ys), max(ys)
        L = nums[pi]
        hit = sorted(t for y, t in L if lo - 3 <= y <= hi + 3)
        if not hit and L:
            yc = (lo + hi) / 2
            hit = [min(L, key=lambda z: abs(z[0] - yc))[1]]
        out.append({"page": pi + 1, "kind": str(st), "lines": (hit[0], hit[-1]) if hit else None})
FIX = {5: (114, 114), 36: (464, 466)}          # highlight rectangles that span more than the highlighted text
for k, v in FIX.items():
    out[k - 1]["lines"] = v
json.dump(out, open("raw_input/ae/annotation_lines.json", "w"))
A = json.load(open("raw_input/ae/annotations.json"))
assert len(A) == len(out), (len(A), len(out))
for i, (a, o) in enumerate(zip(A, out), 1):
    assert a["page"] == o["page"]
    print(i, o["page"], o["kind"], o["lines"], (a.get("highlight") or "")[:50])
