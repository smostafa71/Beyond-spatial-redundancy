"""Fig. 3 Monitoring-network topology: (a) MST backbone after the robust long-edge cut, components and isolated wells;
(b) dominant Upper Floridan component in Citrus and Hernando counties: neighbour edges within ell, policy designation and
the wells screened by B-GAS; (c) component sizes by aquifer group."""
import sys, numpy as np, pandas as pd, geopandas as gpd, matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import Rectangle
from figstyle import *
sys.path.insert(0, ".")
import gas_engine as G

setup()
R = "analysis_r1/reference/"
W = pd.read_csv(R + "Retention_probabilities_perSID_B4_9_GRAPH_AWARE_ACTIVE_SENSING.csv", dtype={"SID": str})
E = pd.read_csv(R + "Edges_singleEll_withCoords.csv", dtype={"SID": str, "Neighbor_SID": str})
A = pd.read_csv(R + "Aquifer_summary.csv").set_index("Aquifer_group")
cty = gpd.read_file(f"{BASE}/cb_2023_us_county_500k/cb_2023_us_county_500k.shp").to_crs(4326)
lakes = gpd.read_file(f"{BASE}/ne_10m_lakes/ne_10m_lakes.shp").to_crs(4326)
fl = cty[cty.STATEFP == "12"]
W = W.copy()
W["IsCritical"] = W.IsCritical.astype(int).astype(bool)
W["iso"] = W.Isolated_within_Ell.astype(bool)
scr = W.FinalDecision_BGAS.eq("CANDIDATE_REMOVE")

fig = plt.figure(figsize=(DOUBLE, 6.4))
gs = fig.add_gridspec(2, 2, width_ratios=[0.80, 1.0], height_ratios=[1, 0.36], wspace=0.12, hspace=0.10)
axa = fig.add_subplot(gs[:, 0]); axb = fig.add_subplot(gs[0, 1]); axc = fig.add_subplot(gs[1, 1]); axc.axis("off")


def basemap(ax, ext):
    ax.set_facecolor(WATER)
    fl.plot(ax=ax, color=LAND, edgecolor=COUNTY, lw=0.35)
    lakes.plot(ax=ax, color=WATER, edgecolor="none")
    ax.set_xlim(ext[0], ext[1]); ax.set_ylim(ext[2], ext[3]); geo_aspect(ax, 28)
    ax.set_xlabel(""); ax.set_ylabel("")
    for s_ in ["top", "right"]:
        ax.spines[s_].set_visible(True)


# (a) MST backbone and components
ext = (-82.95, -81.50, 26.75, 29.12)
basemap(axa, ext)
for aq in ["upper floridan", "hawthorn", "surficial"]:
    g = W[W.Aquifer_group == aq].reset_index(drop=True)
    xy = g[["X_m", "Y_m"]].to_numpy(float)
    cut = A.loc[aq, "cut_value"]
    sizes = g.groupby("Component_id").size()
    dom = sizes.idxmax()
    for i, j, d in G._mst_edges_complete(xy):
        kept = d <= cut
        axa.plot([g.Lon[i], g.Lon[j]], [g.Lat[i], g.Lat[j]], color=AQ_COL[aq] if kept else MUTED,
                 lw=0.8 if kept else 0.5, ls="-" if kept else (0, (2, 1.5)), alpha=0.9 if kept else 0.8, zorder=4)
    big = g.Component_id.eq(dom)
    axa.scatter(g.Lon[big & ~g.iso], g.Lat[big & ~g.iso], s=9, color=AQ_COL[aq], edgecolor="white", lw=0.3, zorder=6)
    axa.scatter(g.Lon[~big & ~g.iso], g.Lat[~big & ~g.iso], s=9, color="white", edgecolor=AQ_COL[aq], lw=0.8, zorder=6)
    axa.scatter(g.Lon[g.iso], g.Lat[g.iso], s=12, marker="s", color="white", edgecolor=INK, lw=0.6, zorder=6)
bx = (-82.70, -82.33, 28.37, 28.98)
axa.add_patch(Rectangle((bx[0], bx[2]), bx[1] - bx[0], bx[3] - bx[2], fill=False, ec="#b03030", lw=1.0, zorder=10))
axa.text(bx[1] + 0.02, bx[3] - 0.02, "b", color="#b03030", fontsize=8, fontweight="bold", va="top")
lonlat_ticks(axa, [-82.8, -82.4, -82.0, -81.6], [27.0, 27.5, 28.0, 28.5, 29.0])
scalebar(axa, -82.90, 26.80, 50, 27.0)
h = [Line2D([], [], color=AQ_COL["upper floridan"], lw=1, label="MST edge kept (Upper Floridan)"),
     Line2D([], [], color=AQ_COL["hawthorn"], lw=1, label="MST edge kept (Hawthorn)"),
     Line2D([], [], color=AQ_COL["surficial"], lw=1, label="MST edge kept (surficial)"),
     Line2D([], [], color=MUTED, lw=0.7, ls=(0, (2, 1.5)), label="long edge cut (Eq. 3)"),
     Line2D([], [], marker="o", ls="", color=INK2, ms=4, label="well in largest component"),
     Line2D([], [], marker="o", ls="", mfc="white", mec=INK2, ms=4, label="well in smaller component"),
     Line2D([], [], marker="s", ls="", mfc="white", mec=INK, ms=4, label="isolated well (no neighbour within ℓ)")]
leg1 = axc.legend(handles=h, loc="upper left", fontsize=6.3, title="Panel a", title_fontsize=6.8, alignment="left",
                  handlelength=1.6, borderaxespad=0, bbox_to_anchor=(0.0, 1.0))
axc.add_artist(leg1)
panel(axa, "a")

# (b) zoom: neighbour edges, designation, screened wells
basemap(axb, (bx[0], bx[1], bx[2], bx[3]))
g = W[(W.Aquifer_group == "upper floridan")]
inb = g.Lon.between(bx[0], bx[1]) & g.Lat.between(bx[2], bx[3])
e = E[(E.Aquifer_group == "upper floridan") & (E.SID < E.Neighbor_SID)]
e = e[e.SID_Lon.between(bx[0] - 0.1, bx[1] + 0.1) & e.SID_Lat.between(bx[2] - 0.1, bx[3] + 0.1)]
for _, r in e.iterrows():
    axb.plot([r.SID_Lon, r.Neighbor_Lon], [r.SID_Lat, r.Neighbor_Lat], color="#9fbfe6", lw=0.35, alpha=0.7, zorder=3)
gg = g[inb]
k1 = gg.IsCritical & ~scr[gg.index]
k2 = ~gg.IsCritical & ~scr[gg.index]
axb.scatter(gg.Lon[k1], gg.Lat[k1], s=14, color=C_KEEP, edgecolor=INK2, lw=0.4, zorder=6, label="KEEP, District 'critical' designation")
axb.scatter(gg.Lon[k2], gg.Lat[k2], s=16, color="white", edgecolor=INK, lw=0.8, zorder=6, label="KEEP, not designated critical")
ss = gg[scr[gg.index]]
axb.scatter(ss.Lon, ss.Lat, s=30, marker="D", color=C_REVIEW, edgecolor="white", lw=0.5, zorder=8,
            label="screened by B-GAS (CANDIDATE_REMOVE);\nall returned to REVIEW by the E-GAS safeguard")
OFF = {"20693": (2, 4), "20695": (-14, 6), "20560": (5, -9), "20836": (-6, -9), "20837": (5, -9), "20869": (6, -4), "20181": (-6, -11)}
for _, r in ss.iterrows():
    axb.annotate(r.SID, (r.Lon, r.Lat), xytext=OFF.get(r.SID, (3, 2)), textcoords="offset points", fontsize=5.6, color=INK, zorder=9)
lonlat_ticks(axb, [-82.6, -82.5, -82.4], [28.5, 28.7, 28.9])
for nm, (x, y) in {"Citrus": (-82.47, 28.93), "Hernando": (-82.40, 28.47), "Pasco": (-82.40, 28.39), "Gulf of Mexico": (-82.68, 28.70)}.items():
    axb.text(x, y, nm, fontsize=6.5, color=MUTED if nm != "Gulf of Mexico" else "#3d6a8f", style="italic" if nm == "Gulf of Mexico" else "normal",
             ha="center", rotation=90 if nm == "Gulf of Mexico" else 0)
hb, lb = axb.get_legend_handles_labels()
hb.append(Line2D([], [], color="#9fbfe6", lw=0.8)); lb.append("neighbour pair within ℓ (same component)")
axc.legend(hb, lb, loc="upper left", fontsize=6.3, title="Panel b", title_fontsize=6.8,
           alignment="left", borderaxespad=0, bbox_to_anchor=(0.50, 1.0), handletextpad=0.3)
scalebar(axb, -82.46, 28.80, 10, 28.6, h=0.006)
panel(axb, "b")

save(fig, "Fig3_network_topology")
print("ok")
