"""Fig. 6 Independent tests: out-of-period (2021-2026) record and pseudo-prospective withholding."""
import numpy as np, pandas as pd, matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from figstyle import *
import sys
sys.path.insert(0, ".")
from r1common import loo_single, load_edp

setup()
A = "analysis_r1/"
W = pd.read_csv(A + "reference/Retention_probabilities_perSID_B4_9_GRAPH_AWARE_ACTIVE_SENSING.csv", dtype={"SID": str})
S = load_edp()
W = W.copy(); W["Cl_val"] = W.SID.map(S.val_median)
wl = W[W.Cl_val.notna()].copy()
wl["later"] = loo_single(wl.assign(V=wl.Cl_val), "V", log=True)
scr = wl.FinalDecision_BGAS.eq("CANDIDATE_REMOVE"); iso = wl.Isolated_within_Ell.astype(bool)
groups = [("Screened", wl.later[scr], C_REVIEW), ("Other wells\nwith\nneighbours", wl.later[~scr & ~iso], C_UFA), ("Isolated", wl.later[iso], MUTED)]

fig = plt.figure(figsize=(DOUBLE, 2.9))
gs = fig.add_gridspec(1, 3, wspace=0.42, width_ratios=[1.05, 1.1, 1.1])
ax = fig.add_subplot(gs[0, 0])
rng = np.random.default_rng(4)
for i, (lab, v, col) in enumerate(groups):
    f = 10 ** v.to_numpy()
    ax.boxplot([f], positions=[i], widths=0.5, showfliers=False, medianprops=dict(color=INK, lw=1.2),
               boxprops=dict(color=INK2, lw=0.7), whiskerprops=dict(color=INK2, lw=0.7), capprops=dict(color=INK2, lw=0.7))
    ax.scatter(i + rng.uniform(-0.17, 0.17, len(f)), f, s=7 if len(f) > 50 else 16, color=col, alpha=0.55 if len(f) > 50 else 0.95,
               edgecolor="none" if len(f) > 50 else "white", lw=0.4, zorder=3)
    ax.text(i, 900, f"n = {len(f)}\n×{10 ** np.median(v.to_numpy()):.1f}", ha="center", va="top", fontsize=5.8, color=INK2)
ax.set_yscale("log"); ax.set_ylim(1, 1000)
ax.set_yticks([1, 2, 5, 10, 30, 100]); ax.set_yticklabels(["1", "2", "5", "10", "30", "100"]); ax.minorticks_off()
ax.set_xticks(range(3)); ax.set_xticklabels([g[0] for g in groups], fontsize=6.2)
ax.set_ylabel("LOO error of 2021–2026 chloride\n(factor, log scale)")
ax.grid(axis="y", color=GRID, lw=0.5); ax.set_axisbelow(True)
panel(ax, "a")

ax = fig.add_subplot(gs[0, 1])
PP = pd.read_csv(A + "prospective_pooled.csv")
PP = PP[PP.radius == 1.0].set_index("method")
meth = ["GAS-E", "GAS-B", "Random (pool)", "Space-filling"]
mlab = ["E-GAS", "B-GAS", "Random\n(pool)", "Space-\nfilling"]
mcol = [C_HAW, C_UFA, MUTED, "#4a3aa7"]
x = np.arange(len(meth))
ax.bar(x - 0.18, [PP.loc[m, "hit_high"] for m in meth], width=0.34, color=mcol, edgecolor="white", lw=0.5, label="informative withheld wells")
ax.bar(x + 0.18, [PP.loc[m, "hit_low"] for m in meth], width=0.34, color="white", edgecolor=mcol, lw=1.0, hatch="////", label="other withheld wells")
ax.set_xticks(x); ax.set_xticklabels(mlab, fontsize=6.6)
ax.set_ylabel("Withheld wells with a site\nwithin ℓ (share)")
ax.set_ylim(0, 0.3); ax.grid(axis="y", color=GRID, lw=0.5); ax.set_axisbelow(True)
ax.legend(handles=[plt.Rectangle((0, 0), 1, 1, fc=INK2, ec="white"), plt.Rectangle((0, 0), 1, 1, fc="white", ec=INK2, hatch="////")],
          labels=["informative withheld wells", "other withheld wells"], fontsize=6.2, loc="upper left", frameon=False)
ax.set_title("(b) Random withholding (15 %)", fontsize=7.5, loc="left", fontweight="bold")

ax = fig.add_subplot(gs[0, 2])
try:
    PB = pd.read_csv(A + "prospective_blocks_summary.csv").set_index("method")
    ax.bar(x - 0.18, [PB.loc[m, "any_in_hole"] for m in meth], width=0.34, color=mcol, edgecolor="white", lw=0.5)
    ax.bar(x + 0.18, [PB.loc[m, "hit_all"] for m in meth], width=0.34, color="white", edgecolor=mcol, lw=1.0, hatch="....")
    ax.legend(handles=[plt.Rectangle((0, 0), 1, 1, fc=INK2, ec="white"), plt.Rectangle((0, 0), 1, 1, fc="white", ec=INK2, hatch="....")],
              labels=["replicates with ≥ 1 site in the gap", "withheld wells with a site within ℓ"], fontsize=6.2, loc="upper right", frameon=False)
    ax.set_ylim(0, 0.62); ax.set_yticks(np.arange(0, 0.51, 0.1))
except FileNotFoundError:
    ax.text(0.5, 0.5, "pending", transform=ax.transAxes, ha="center")
ax.set_xticks(x); ax.set_xticklabels(mlab, fontsize=6.6)
ax.set_ylabel("Share"); ax.grid(axis="y", color=GRID, lw=0.5); ax.set_axisbelow(True)
ax.set_title("(c) Spatial gaps (1.5ℓ)", fontsize=7.5, loc="left", fontweight="bold")
save(fig, "Fig6_validation")
print("ok")
