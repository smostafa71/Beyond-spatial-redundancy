"""ESM Fig. S2 GAS (B-GAS screening) vs established reduction methods at an equal budget."""
import json, numpy as np, pandas as pd, matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import Patch
from figstyle import *

setup()
B = pd.read_csv("analysis_r1/baselines_equal_budget.csv")
RA = pd.read_csv("analysis_r1/baselines_random_all.csv"); RP = pd.read_csv("analysis_r1/baselines_random_policy.csv")
methods = ["GAS (B-GAS screening)", "Distance thinning", "Reconstructability", "Kriging variance"]
labels = ["GAS (B-GAS)", "Distance thinning", "Reconstructability", "Kriging variance"]
cols = {"GAS (B-GAS screening)": C_REVIEW, "Distance thinning": "#4a3aa7", "Reconstructability": "#1baf7a", "Kriging variance": "#eda100"}
pools = [("all wells", RA, "o", True), ("policy-eligible (not critical)", RP, "o", False)]
metrics = [("loo_mean_mgL", "Mean LOO chloride error\nof removed wells (mg/L)", True),
           ("dNN_m", "Change in mean NN\ndistance, Eq. 31 (m)", False),
           ("n_critical", "Removed wells with a\ncritical designation", False),
           ("n_dev_rising", "Removed wells with an\nincreasing trend class", False),
           ("later_rec_median_factor", "Reconstruction error of\n2021–2026 chloride (factor)", True)]
fig, axs = plt.subplots(2, 3, figsize=(DOUBLE, 4.6), gridspec_kw=dict(hspace=0.62, wspace=0.12))
axs = axs.ravel()
for k, (m, lab, logx) in enumerate(metrics):
    ax = axs[k]
    for i, meth in enumerate(methods):
        y = len(methods) - 1 - i
        for j, (pool, R, mk, filled) in enumerate(pools):
            off = 0.15 if filled else -0.15
            if i == 0:
                lo, hi = R[m].quantile(0.05), R[m].quantile(0.95)
            v = B[(B.pool == pool) & (B.method == meth)][m].iloc[0]
            ax.scatter([v], [y + off], marker="D" if i == 0 else "o", s=26, facecolor=cols[meth] if filled else "white",
                       edgecolor=cols[meth], lw=1.0, zorder=5)
    # random 5-95 % bands (one row each pool) at the bottom
    for j, (pool, R, mk, filled) in enumerate(pools):
        yb = -1.0 + (0.15 if filled else -0.15)
        lo, hi = R[m].quantile(0.05), R[m].quantile(0.95)
        ax.plot([lo, hi], [yb, yb], color="#9d9b95", lw=3.5 if filled else 2.0, solid_capstyle="butt", alpha=0.9 if filled else 0.6, zorder=3)
        ax.scatter([R[m].mean()], [yb], marker="|", s=40, color=INK2, zorder=4)
    ax.set_yticks(range(-1, len(methods)))
    ax.set_yticklabels(["Random sets\n(5–95 %, mean)"] + labels[::-1] if k % 3 == 0 else [], fontsize=6.6)
    ax.set_ylim(-1.6, len(methods) - 0.4)
    if logx:
        ax.set_xscale("log")
        tk = [100, 300, 1000, 3000] if m == "loo_mean_mgL" else [2, 3, 4, 6]
        ax.set_xticks(tk); ax.set_xticklabels([f"{t:,}" for t in tk]); ax.minorticks_off()
    ax.set_xlabel(lab, fontsize=6.8)
    ax.grid(axis="x", color=GRID, lw=0.5); ax.set_axisbelow(True)
    ax.tick_params(axis="x", labelsize=6.4)
    panel(ax, "abcde"[k])
axs[1].set_xlim(-60, 320)
ax = axs[5]; ax.axis("off")
h = [Line2D([], [], marker="o", ls="", mfc=INK2, mec=INK2, ms=5, label="method applied to all wells"),
     Line2D([], [], marker="o", ls="", mfc="white", mec=INK2, ms=5, label="method applied to wells without\na critical designation (GAS pool)"),
     Line2D([], [], color="#9d9b95", lw=3.5, label="1,000 random sets, all wells"),
     Line2D([], [], color="#9d9b95", lw=2.0, alpha=0.6, label="1,000 random sets, GAS pool")]
ax.legend(handles=h, loc="center left", fontsize=6.4, frameon=False, borderaxespad=0)
ax.text(0.0, 0.08, "Budget: 12 removals (number screened by B-GAS).\nGAS removes the same wells in both pools.", transform=ax.transAxes, fontsize=6.2, color=INK2)
save(fig, "FigS2_equal_budget")
print("ok")
