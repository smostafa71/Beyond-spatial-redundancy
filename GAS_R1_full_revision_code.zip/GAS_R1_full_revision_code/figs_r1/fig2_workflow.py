"""Fig. 2 Architecture of the GAS framework (B-GAS backbone, E-GAS extension, external evaluation)."""
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch
from figstyle import *

setup()
fig, ax = plt.subplots(figsize=(DOUBLE, 7.2))
ax.set_xlim(0, 100); ax.set_ylim(0, 89); ax.axis("off")
FB, FE, FG, FI = "#eaf1fa", "#fcece4", "#f1f0ec", "#f7f6f2"
EB, EE = "#2a78d6", "#eb6834"


def box(x, y, w, h, title, body, fc, ec=INK2, lw=0.8, tc=INK):
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.25,rounding_size=1.0", fc=fc, ec=ec, lw=lw))
    ax.text(x + 1.2, y + h - 1.2, title, ha="left", va="top", fontsize=7.3, fontweight="bold", color=tc)
    ax.text(x + 1.2, y + h - 4.4, body, ha="left", va="top", fontsize=6.3, color=INK, linespacing=1.35)


def arrow(x1, y1, x2, y2, col=INK2, ls="-"):
    ax.annotate("", xy=(x2, y2), xytext=(x1, y1),
                arrowprops=dict(arrowstyle="-|>", lw=0.9, color=col, mutation_scale=8, linestyle=ls, shrinkA=0, shrinkB=0))


box(1, 79, 98, 9, "Inputs (Sect. 2.2)",
    "301 wells (Upper Floridan 208, Hawthorn 88, surficial 5): chloride = EDP median 2013–2020, trend = Mann–Kendall,\n"
    "reported depth, status, District designation.   Spring vents (53): separate class.   Confining-unit wells (3): excluded.", FI)
box(1, 66, 98, 10, "1  Graph construction (Eqs. 3–5)",
    "per aquifer group: Euclidean MST; long edges cut at median + 3 MAD → components; ℓ = P90 of nearest-neighbour distance;\n"
    "neighbours within ℓ, w = exp(−d/ℓ); isolated wells; redundancy clusters. Edges describe network topology, not hydraulic connection.", FB, ec=EB)
box(1, 38, 47, 25, "2  Evidence for retention (Eqs. 6–15)",
    "chloride concentration: logistic, midpoint 2,000 mg/L (6)\nchloride trend: rising Cl 1.0, none 0.5, falling 0.0 (7)\n"
    "joint quality of chloride, trend and status (8)\nspatial redundancy (9, 10)\ninformation uniqueness (11)\n"
    "dependency uniqueness (12)\ngraph role and bridge proxy (13)\ngraph influence $S_{GI}$ (14)\n"
    "aquifer reliability shrinkage (15)\neach score carries an uncertainty u", FB, ec=EB)
box(52, 38, 47, 25, "3  Weights and resolution (Eqs. 16–21)",
    "entropy weights; network family ≤ 0.36 (16)\nutility U = Σ ω P (17)\nBeta sampling, κ = 2 + 48(1 − u); 3,000 realizations (18)\n"
    "per cluster: anchor kept; U ≥ 0.66 or critical → REVIEW;\n  otherwise CANDIDATE_REMOVE (19)\ncalibration, consensus votes, ties → KEEP (20)\n"
    "information stability index (21)\nB-GAS output: KEEP or CANDIDATE_REMOVE (screened)", FB, ec=EB)
box(52, 16.5, 47, 18, "4  E-GAS confirmation (Eq. 22)",
    "a screened well returns to REVIEW (stays active) if\n  (i) LOO chloride error ≥ 85th percentile of screened set, or\n"
    "  (ii) graph influence $S_{GI}$ ≥ 0.80, or\n  (iii) chloride keep score $P_{chl,adj}$ ≥ 0.85\notherwise: confirmed CANDIDATE_REMOVE (site review)", FE, ec=EE)
box(1, 26.0, 47, 8.5, "5a  Candidate sites, B-GAS (Eqs. 23–26)",
    "support domain and hexagonal grid (23)\nactive sensing AS (24, 25); greedy selection (26)", FB, ec=EB)
box(1, 16.5, 47, 8.0, "5b  Candidate sites, E-GAS (Eqs. 27–30)",
    "AS + Hydro-LIMG + validation gain (27–29)\nmulti-component greedy penalty (30)", FE, ec=EE)
arrow(25, 25.7, 25, 24.8)
box(1, 1.0, 98, 12.5, "Evaluation, without feedback into the decisions (Sect. 2.9)",
    "equal-budget comparison with distance thinning, reconstructability, kriging variance and random sets (31, 32)\n"
    "out-of-period test with the 2021–2026 record;  pseudo-prospective tests (random and spatial-gap withholding)\n"
    "one-at-a-time and structural sensitivity (incl. hydrostratigraphic edges);  joint Latin-hypercube perturbation", FG, ec=MUTED)
arrow(50, 78.7, 50, 76.3)
arrow(25, 65.7, 25, 63.3)
arrow(48.4, 50.5, 51.6, 50.5)
arrow(75.5, 37.7, 75.5, 34.8)
arrow(51.6, 40.5, 48.4, 32.0, col=INK2, ls=(0, (3, 2)))
ax.text(50.0, 37.2, "u, $S_{GI}$, LOO", fontsize=5.8, color=INK2, ha="center", va="center", bbox=dict(fc="white", ec="none", pad=0.5))
for x0, lab, col in [(62, "B-GAS backbone", EB), (79, "E-GAS extension", EE)]:
    ax.add_patch(FancyBboxPatch((x0 - 0.2, 11.2), 1.6, 1.3, boxstyle="round,pad=0.1", fc=FB if col == EB else FE, ec=col, lw=0.8))
    ax.text(x0 + 2.2, 11.85, lab, fontsize=6.2, va="center", color=INK2)
save(fig, "Fig2_framework")
print("ok")
