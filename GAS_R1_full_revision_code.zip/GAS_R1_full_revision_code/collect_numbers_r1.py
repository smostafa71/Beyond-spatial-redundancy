"""Collects every number quoted in the revised manuscript into analysis_r1/numbers.json (single source of truth)."""
import json, re, os
import numpy as np, pandas as pd
import geopandas as gpd

A = "analysis_r1/"; R = A + "reference/"
N = {}
WORDS = {0: "no", 1: "one", 2: "two", 3: "three", 4: "four", 5: "five", 6: "six", 7: "seven", 8: "eight", 9: "nine", 10: "ten",
         11: "eleven", 12: "twelve", 13: "thirteen", 14: "fourteen", 15: "fifteen", 16: "sixteen", 17: "seventeen", 18: "eighteen",
         19: "nineteen", 20: "twenty"}


def f(x, d=0):
    """number with thousands separator; d decimals; halves rounded up (160.5 -> 161)"""
    from decimal import Decimal, ROUND_HALF_UP
    q = Decimal(1).scaleb(-d)
    return f"{float(Decimal(str(float(x))).quantize(q, rounding=ROUND_HALF_UP)):,.{d}f}"


S = json.load(open(A + "summary.json"))
L = json.load(open(A + "edp_build_log.json"))
T = pd.read_csv(A + "structure_aquifers.csv").set_index("aquifer")
C = pd.read_csv(A + "structure_contrasts.csv").set_index("metric")
W = pd.read_csv(R + "Retention_probabilities_perSID_B4_9_GRAPH_AWARE_ACTIVE_SENSING.csv", dtype={"SID": str})
ST = pd.read_csv(A + "edp_station_chloride.csv", dtype={"SID": str}).set_index("SID")
AV = pd.read_csv(A + "attribute_vs_edp.csv", dtype={"SID": str})
inv_sids = AV.SID.nunique()

# ---- data
N["n_sids"] = f(inv_sids); N["n_confining"] = S["n_excluded_confining"]; N["n_springs"] = S["n_springs"]
N["n_wells"] = S["n_wells"]; N["n_ufa"] = S["n_by_aquifer"]["upper floridan"]; N["n_haw"] = S["n_by_aquifer"]["hawthorn"]; N["n_sur"] = S["n_by_aquifer"]["surficial"]
N["edp_records"] = f(L["wq139_records"]); N["edp_wq140"] = L["wq140_records_excluded"]
N["edp_dups"] = f(L["wq139_records"] - L["after_exact_duplicate_removal"]); N["edp_invalid"] = L["non_numeric_removed"] + L["non_positive_removed"]
wells = W.SID
N["dev_n_median"] = int(ST.loc[wells, "dev_n"].median()); N["val_n_median"] = int(ST.loc[wells, "val_n"].median())
dd = ST.loc[wells, "dev_dir"].value_counts()
N["n_trend_nd"] = int(dd.get("NOT DETERMINED", 0)); N["n_rising"] = int(dd.get("RISING", 0)); N["n_falling"] = int(dd.get("FALLING", 0))
N["edp_notrend_n"] = int(dd.get("NO TREND", 0))
aw = AV[AV.SID.isin(wells)]
N["attr_ratio_median"] = f"{aw.ratio_attr_edp.median():.2f}"
N["attr_gt25"] = int(((aw.ratio_attr_edp > 1.25) | (aw.ratio_attr_edp < 0.8)).sum())
N["attr_stable_n"] = int((aw.CHLORIDE_T_ATTR == "STABLE").sum())
_tc = W.CHLORIDE_T.astype(str).str.strip().str.upper().value_counts()     # inventory trend class (analysis input)
N["n_trend_dec"] = int(_tc.get("DECREASING", 0)); N["n_trend_sta"] = int(_tc.get("STABLE", 0)); N["n_trend_inc"] = int(_tc.get("INCREASING", 0))
assert N["n_trend_dec"] + N["n_trend_sta"] + N["n_trend_inc"] == len(W), _tc.to_dict()
N["n_depth_missing"] = int(W.Depth_missing_imputed.sum())
N["n_critical"] = S["n_critical"]; N["n_critical_dom"] = S["n_critical_dominant"]
N["crit_pct"] = f"{100 * S['n_critical'] / S['n_wells']:.0f}"
noncrit = W[W.IsCritical.astype(int) == 0]
N["n_noncrit"] = len(noncrit); N["n_noncrit_noniso"] = int((~noncrit.Isolated_within_Ell.astype(bool)).sum())
N["n_noncrit_noniso_ufa"] = int(((noncrit.Aquifer_group == "upper floridan") & ~noncrit.Isolated_within_Ell.astype(bool)).sum())
N["n_noncrit_noniso_ch"] = int(((noncrit.Aquifer_group == "upper floridan") & ~noncrit.Isolated_within_Ell.astype(bool) & noncrit.COUNTY.isin(["Citrus", "Hernando", "Pasco"])).sum())

# ---- structure
N["n_components"] = S["n_components"]; N["n_isolated"] = S["n_isolated"]
for a, k in [("upper floridan", "ufa"), ("hawthorn", "haw"), ("surficial", "sur")]:
    N[f"ell_{k}"] = f(T.loc[a, "ell_m"]); N[f"nn_{k}"] = f(T.loc[a, "mean_nn_m"]); N[f"iso_{k}"] = int(T.loc[a, "n_isolated"])
N["dom_ufa"] = int(T.loc["upper floridan", "dominant_size"]); N["dom_ufa_pct"] = f"{100 * T.loc['upper floridan', 'dominant_share']:.0f}"
N["n_comp_ufa_minus1"] = int(T.loc["upper floridan", "n_components"]) - 1; N["n_single_ufa"] = int(T.loc["upper floridan", "n_singleton_components"])
N["n_comp_haw"] = int(T.loc["hawthorn", "n_components"]); N["dom_haw"] = int(T.loc["hawthorn", "dominant_size"])
N["dom_haw_pct"] = f"{100 * T.loc['hawthorn', 'dominant_share']:.0f}"

# ---- weights and detection
w = S["weights"]
for k in ["information", "joint_quality", "distance", "trend", "dependency", "chloride", "graph_role", "depth", "status"]:
    N[f"w_{k}"] = f"{w[k]:.3f}"
N["w_family"] = f"{S['network_family_weight']:.2f}"
N["w_trend_r0"] = "0.098"      # original submission (Validation_Summary of FINAL6)
_LG = pd.read_csv(A + "ledger.csv").set_index("step")
N["w_trend_l1"] = f"{_LG.loc['L1', 'w_trend']:.3f}"; N["w_trend_l2"] = f"{_LG.loc['L2', 'w_trend']:.3f}"
pre = S["pre_hard_resolve"]
N["pre_keep"] = pre.get("KEEP", 0); N["pre_review"] = pre.get("REVIEW", 0); N["pre_cr"] = pre.get("CANDIDATE_REMOVE", 0)
N["mean_pk"] = f"{S['mean_P_keep']:.3f}"; N["mean_pr"] = f"{S['mean_P_review']:.3f}"; N["mean_pcr"] = f"{S['mean_P_remove']:.3f}"
hr = S["hard_resolve_sources"]
N["hr_crit"] = hr.get("critical_force_keep", 0); N["hr_votes"] = hr.get("hard_review_to_keep_consensus", 0); N["hr_tie"] = hr.get("hard_review_to_keep_conservative_tie", 0)
N["hr_remove"] = hr.get("hard_review_to_remove_consensus", 0)
_k = [(N["hr_crit"], "by the critical rule"), (N["hr_votes"], "by votes"), (N["hr_tie"], "by the tie rule")]
_k = [f"{n} {t}" for n, t in _k if n]
N["hr_text"] = (f"{N['hr_crit'] + N['hr_votes'] + N['hr_tie']} were resolved to KEEP (" + (", ".join(_k[:-1]) + " and " + _k[-1] if len(_k) > 1 else _k[0]) + ")"
                + (f" and {WORDS[N['hr_remove']]} to CANDIDATE_REMOVE by votes (Eq. 20)" if N["hr_remove"] else ""))
assert N["hr_crit"] + N["hr_votes"] + N["hr_tie"] + N["hr_remove"] == N["pre_review"], hr
N["n_screened"] = S["n_screened"]; N["n_screened_w"] = WORDS[S["n_screened"]]; N["n_screened_W"] = WORDS[S["n_screened"]].capitalize()
N["scr_pct"] = f"{100 * S['n_screened'] / S['n_wells']:.1f}"
N["scr_ufa"] = int((W.FinalDecision_BGAS.eq("CANDIDATE_REMOVE") & W.Aquifer_group.eq("upper floridan")).sum())
N["scr_pcr_pct"] = f"{100 * S['screened_P_remove_mean']:.0f}"
N["isi_scr"] = f"{S['ISI_screened_mean']:.2f}"; N["isi_ret"] = f"{S['ISI_retained_mean']:.2f}"; N["isi_mean"] = f"{S['ISI_mean']:.2f}"
N["isi_high"] = S["ISI_classes"].get("HIGH", 0); N["isi_med"] = S["ISI_classes"].get("MEDIUM", 0); N["isi_low"] = S["ISI_classes"].get("LOW", 0)
for key, m in [("sgi", "GraphInfluence_score"), ("graph", "P_keep_graph_role_base"), ("bridge", "GraphRole_bridge_proxy"),
               ("info", "P_keep_information_base"), ("dep", "P_keep_dependency_base"), ("dist", "P_keep_distance_base")]:
    N[f"c_{key}_s"] = f"{C.loc[m, 'screened_mean']:.2f}"; N[f"c_{key}_r"] = f"{C.loc[m, 'retained_nonisolated_mean']:.2f}"
    _pv = C.loc[m, 'mw_p_vs_nonisolated']
    N[f"c_{key}_p"] = f"{_pv:.2f}" if _pv >= 0.1 else (f"{_pv:.3f}" if _pv >= 0.001 else "< 0.001")

# ---- confirmation
N["scr_cl_min"] = f"{S['screened_Cl_min']:.0f}"; N["scr_cl_max"] = f"{S['screened_Cl_max']:.0f}"
N["scr_pchl_min"] = f"{np.floor(S['screened_Pchl_min'] * 100) / 100:.2f}"
_sids = lambda L: " and ".join([", ".join(L[:-1]), L[-1]]) if len(L) > 1 else "".join(L)
_scr = W[W.FinalDecision_BGAS == "CANDIDATE_REMOVE"]
_ci = sorted(_scr.SID[_scr.Safeguard_trig_LOO.astype(str).str.lower() == "true"])
N["crit_i_n"] = WORDS[len(_ci)].capitalize(); N["crit_i_sids"] = _sids(_ci)
_cty = sorted(_scr[_scr.Aquifer_group == "upper floridan"].COUNTY.dropna().unique())
N["scr_ufa_counties"] = _sids(_cty) + (" counties" if len(_cty) > 1 else " County")
N["loo_q85"] = f(S["loo_q85"]); N["scr_sgi_min"] = f"{S['screened_SGI_min']:.2f}"; N["scr_sgi_max"] = f"{S['screened_SGI_max']:.2f}"
N["dnn_b"] = f"{S['dNN_BGAS']:.0f}"

# ---- candidates
for tag, k in [("BGAS", "cb"), ("EGAS", "ce")]:
    ba = S[f"cand_{tag}_by_aquifer"]
    N[f"{k}_n"] = S[f"cand_{tag}_n"]; N[f"{k}_ufa"] = ba.get("upper floridan", 0); N[f"{k}_haw"] = ba.get("hawthorn", 0); N[f"{k}_sur"] = ba.get("surficial", 0)
    N[f"{k}_comp"] = S[f"cand_{tag}_components"]; N[f"{k}_min"] = f"{S[f'cand_{tag}_score_min']:.2f}"; N[f"{k}_max"] = f"{S[f'cand_{tag}_score_max']:.2f}"
    N[f"{k}_mean"] = f"{S[f'cand_{tag}_score_mean']:.2f}"; N[f"{k}_dist"] = f"{S[f'cand_{tag}_dist_mean_m'] / 1000:.1f}"
_cty = gpd.read_file("basemap/cb_2023_us_county_500k/cb_2023_us_county_500k.shp")
_cty = _cty[_cty.STATEFP == "12"].to_crs(4326)[["NAME", "geometry"]]
for _f, k in [("Candidate_new_wells_BGAS.csv", "cb"), ("Candidate_new_wells_B4_9.csv", "ce")]:
    _C = pd.read_csv(A + "reference/" + _f)
    _g = gpd.sjoin(gpd.GeoDataFrame(_C, geometry=gpd.points_from_xy(_C.Lon, _C.Lat), crs=4326), _cty, how="left")
    _nh = int(((_g.Aquifer_group == "hawthorn") & _g.NAME.isin(["Pinellas"])).sum())
    N[f"{k}_haw_north"] = "none" if _nh == 0 else WORDS[_nh]
    N[f"{k}_water"] = int(_g.NAME.isna().sum())
aw_ = S["AS_weights_by_aquifer"]["upper floridan"]
N["as_w_ufa"] = ", ".join(f"{aw_[k]:.2f}" for k in ["AS_w_unc", "AS_w_sup", "AS_w_gra", "AS_w_rep", "AS_w_dep"])

# ---- baselines
B = pd.read_csv(A + "baselines_equal_budget.csv")
ba = B[B.pool == "all wells"].set_index("method"); bp = B[B.pool != "all wells"].set_index("method")
M = {"dist": "Distance thinning", "rec": "Reconstructability", "krig": "Kriging variance", "gas": "GAS (B-GAS screening)"}
for k, m in M.items():
    N[f"j_{k}"] = f"{ba.loc[m, 'jaccard_vs_GAS']:.2f}"; N[f"crit_{k}"] = int(ba.loc[m, "n_critical"])
    N[f"dnn_{k}"] = f"{ba.loc[m, 'dNN_m']:.0f}"; N[f"loo_{k}"] = f(ba.loc[m, "loo_mean_mgL"])
    N[f"dnnr_{k}"] = f"{bp.loc[m, 'dNN_m']:.0f}"; N[f"riser_{k}"] = int(bp.loc[m, "n_dev_rising"])
N["crit_rand"] = f"{ba.loc['Random (mean of 1000)', 'n_critical']:.1f}"
N["dnnr_rand"] = f"{bp.loc['Random (mean of 1000)', 'dNN_m']:.0f}".replace("-", "−")
jr = [bp.loc[M[k], "jaccard_vs_GAS"] for k in ("dist", "rec", "krig")]
N["jr_min"] = f"{min(jr):.2f}"; N["jr_max"] = f"{max(jr):.2f}"; N["jr_rand"] = f"{bp.loc['Random (mean of 1000)', 'jaccard_vs_GAS']:.2f}"
N["rise_gas"] = int(bp.loc[M["gas"], "n_dev_rising"])
N["riser_rand"] = f"{bp.loc['Random (mean of 1000)', 'n_dev_rising']:.1f}"; N["riser_rand05"] = f"{bp.loc['Random 5th pct', 'n_dev_rising']:.0f}"
N["later_gas"] = f"{bp.loc[M['gas'], 'later_rec_median_factor']:.1f}"
N["later_rand05"] = f"{bp.loc['Random 5th pct', 'later_rec_median_factor']:.1f}"; N["later_rand95"] = f"{bp.loc['Random 95th pct', 'later_rec_median_factor']:.1f}"
N["later_rise_max"] = int(max(B[B.method.isin(M.values())].n_val_rising))
vg = json.load(open(A + "baselines_variograms.json"))["upper floridan"]
N["vg_ufa"] = f"nugget {vg['nugget']:.2f} and partial sill {vg['sill']:.2f} (log~10~ mg/L)^2^"

# ---- eligible (non-critical) wells and Avon Park wells
_W = pd.read_csv(A + "reference/Retention_probabilities_perSID_B4_9_GRAPH_AWARE_ACTIVE_SENSING.csv", low_memory=False)
_nc = _W[_W.IsCritical.astype(int) == 0]
N["noncrit_cl_max"] = f(_nc.CHLORIDE.max()); N["noncrit_pchl_min"] = f"{np.floor(_nc.P_keep_chloride_adj.min() * 100) / 100:.2f}"
N["pchl85_n"] = int((_W.P_keep_chloride_adj >= 0.85).sum()); N["pchl85_clmax"] = f(_W.loc[_W.P_keep_chloride_adj >= 0.85, "CHLORIDE"].max())
_ap = _W[_W.Waterbod_1_raw.astype(str).str.contains("Avon Park")]
N["n_appz"] = len(_ap); N["n_appz_south"] = int((_ap.Lat < 27.95).sum())     # south of central Polk County

# ---- co-located wells (sites with two or more wells < 150 m apart)
from scipy.spatial import cKDTree
from scipy.sparse import coo_matrix
from scipy.sparse.csgraph import connected_components
from pyproj import Transformer
_R = pd.read_csv(A + "reference/Retention_probabilities_perSID_B4_9_GRAPH_AWARE_ACTIVE_SENSING.csv", low_memory=False)
_x, _y = Transformer.from_crs(4326, 3087, always_xy=True).transform(_R.LONGITUDE.values, _R.LATITUDE.values)
_pr = np.array(sorted(cKDTree(np.c_[_x, _y]).query_pairs(150.0)))
_G = coo_matrix((np.ones(len(_pr)), (_pr[:, 0], _pr[:, 1])), shape=(len(_R), len(_R)))
_R = _R.assign(site=connected_components(_G, directed=False)[1], cl=_R.CHLORIDE.clip(lower=0.1))
_sz = _R.groupby("site").size(); _multi = _R[_R.site.isin(_sz[_sz >= 2].index)]
_rat = lambda g: g.cl.max() / g.cl.min() > 10
N["coloc_sites"] = int(_multi.site.nunique()); N["coloc_wells"] = int(len(_multi))
N["coloc_contrast"] = int(_multi.groupby("site").apply(_rat).sum())
N["coloc_contrast_same"] = int(_multi.groupby("site").apply(lambda g: any(len(h) > 1 and _rat(h) for _, h in g.groupby("Aquifer_group"))).sum())
N["coloc_diffaq"] = int((_multi.groupby("site").Aquifer_group.nunique() > 1).sum())

# ---- temporal
TV = json.load(open(A + "temporal_summary.json"))
TS = pd.read_csv(A + "temporal_screened_wells.csv", dtype={"SID": str}).set_index("SID")
TG = pd.read_csv(A + "temporal_groups.csv").set_index("group")
N["scr_ratio_min"] = f"{TV['screened_ratio_min']:.2f}"; N["scr_ratio_max"] = f"{TV['screened_ratio_max']:.2f}"
N["cl_20181_dev"] = f"{TS.loc['20181', 'CHLORIDE']:.1f}"; N["cl_20181_val"] = f"{TS.loc['20181', 'Cl_val']:.1f}"
N["tv_scr"] = f"{TG.loc['screened', 'later_loo_median_factor']:.1f}"; N["tv_oth"] = f"{TG.loc['other non-isolated', 'later_loo_median_factor']:.1f}"
N["tv_iso"] = f"{TG.loc['isolated', 'later_loo_median_factor']:.1f}"; N["tv_p"] = f"{TV['mw_p']:.2f}"
_vr = sorted(TS.index[TS.val_dir == "RISING"])                     # screened wells with significantly rising 2021-2026 chloride
N["scr_val_rising_n"] = WORDS[len(_vr)]; N["scr_val_rising_sids"] = " and ".join([", ".join(_vr[:-1]), _vr[-1]]) if len(_vr) > 1 else "".join(_vr)

# ---- pseudo-prospective (random withholding)
_D = pd.read_csv(A + "prospective_reps.csv")          # pooled recovery recomputed from the replicates (no intermediate rounding)
_D = _D[_D.radius == 1.0].assign(w_hi=lambda d: d.n_high, w_lo=lambda d: d.n_held - d.n_high)
PP = _D.groupby("method").apply(lambda g: pd.Series(dict(
    hit_high=np.nansum(g.hit_high * g.w_hi) / g.w_hi[g.hit_high.notna()].sum(),
    hit_low=np.nansum(g.hit_low * g.w_lo) / g.w_lo[g.hit_low.notna()].sum())))
PR = pd.read_csv(A + "prospective_reps.csv")
N["pp_reps"] = int(PR.rep.nunique())
q = PR[(PR.radius == 1.0) & (PR.method == "GAS-E")]
N["pp_high_pct"] = f"{100 * q.n_high.sum() / q.n_held.sum():.0f}"
for k, m in [("e", "GAS-E"), ("b", "GAS-B"), ("r", "Random (pool)"), ("s", "Space-filling")]:
    N[f"pp_{k}_hi"] = f"{PP.loc[m, 'hit_high']:.2f}"; N[f"pp_{k}_lo"] = f"{PP.loc[m, 'hit_low']:.2f}"
fp = lambda v: "< 0.001" if v < 0.001 else f"= {v:.3f}"
tp = json.load(open(A + "prospective_tests.json"))
for k, m in [("e", "GAS-E"), ("b", "GAS-B"), ("s", "Space-filling")]:
    N[f"pp_p_{k}"] = fp(tp[m]["wilcoxon_p"])

# ---- pseudo-prospective (spatial gaps)
if os.path.exists(A + "prospective_blocks_summary.csv"):
    PB = pd.read_csv(A + "prospective_blocks_summary.csv").set_index("method")
    PBr = pd.read_csv(A + "prospective_blocks_reps.csv")
    tb = json.load(open(A + "prospective_blocks_tests.json"))
    N["ppb_reps"] = int(PBr.rep.nunique()); N["ppb_held"] = f"{PB.loc['GAS-E', 'n_held']:.0f}"
    PB = PBr.groupby("method")[["any_in_hole", "hit_all", "n_held"]].mean()          # from the replicates, no intermediate rounding
    g = lambda m, c: PB.loc[m, c]
    _lab = {"GAS-B": "B-GAS", "GAS-E": "E-GAS", "Space-filling": "space-filling"}
    _sig = [m for m in ["GAS-B", "GAS-E", "Space-filling"] if tb[m]["wilcoxon_p"] < 0.05]
    _ns = [m for m in ["GAS-B", "GAS-E", "Space-filling"] if m not in _sig]
    _pf = lambda v: "< 0.001" if v < 0.001 else f"= {v:.3f}" if v < 0.1 else f"= {v:.2f}"
    _ss = "; ".join(f"{_lab[m]} sites were within ℓ~a~ of {'more' if tb[m]['mean_diff_hit_all'] > 0 else 'fewer'} withheld wells than random "
                    f"sites (paired Wilcoxon *p* {_pf(tb[m]['wilcoxon_p'])})" for m in _sig)
    _nn = (" and ".join(_lab[m] for m in _ns) + " sites did not differ significantly from random sites (*p* = "
           + " and ".join(f"{tb[m]['wilcoxon_p']:.2f}" for m in _ns) + ")") if _ns else ""
    N["ppb_text"] = (f"at least one site fell into the gap in {100 * g('GAS-B', 'any_in_hole'):.0f} % of the replicates for B-GAS, "
                     f"{100 * g('GAS-E', 'any_in_hole'):.0f} % for E-GAS, {100 * g('Space-filling', 'any_in_hole'):.0f} % for space-filling and "
                     f"{100 * g('Random (pool)', 'any_in_hole'):.0f} % for random sites, and the sites were within ℓ~a~ of "
                     f"{100 * g('GAS-B', 'hit_all'):.0f} %, {100 * g('GAS-E', 'hit_all'):.0f} %, {100 * g('Space-filling', 'hit_all'):.0f} % and "
                     f"{100 * g('Random (pool)', 'hit_all'):.0f} % of the withheld wells. "
                     + (_ss[0].upper() + _ss[1:] + (", whereas " + _nn if _nn else "") + "." if _ss else _nn[0].upper() + _nn[1:] + ".")
                     + " [[ppb_interp]]")
    _kb, _ke = PBr[PBr.method == "GAS-B"].k.mean(), PBr[PBr.method == "GAS-E"].k.mean()
    N["ppb_kb"] = f"{_kb:.1f}"; N["ppb_ke"] = f"{_ke:.1f}"
    for _k, _m in [("b", "GAS-B"), ("e", "GAS-E"), ("r", "Random (pool)"), ("s", "Space-filling")]:
        N[f"ppb_{_k}_any"] = f"{100 * g(_m, 'any_in_hole'):.0f}"; N[f"ppb_{_k}_hit"] = f"{100 * g(_m, 'hit_all'):.0f}"
    N["ppb_p_b"] = _pf(tb["GAS-B"]["wilcoxon_p"]); N["ppb_p_e"] = _pf(tb["GAS-E"]["wilcoxon_p"])
else:
    N["ppb_reps"] = "–"; N["ppb_held"] = "–"; N["ppb_text"] = "(pending)"

# ---- one-at-a-time
O = pd.read_csv(A + "oat.csv").set_index("variant")
base = O.loc[[v for v in O.index if not v.startswith(("Critical rule", "Spring vents"))]]
N["oat_min"] = int(base.n_screened.min()); N["oat_max"] = int(base.n_screened.max()); N["oat_jmin"] = f"{base.jaccard_screened_vs_ref.min():.2f}"
_ref = set(str(O.loc["Reference", "screened"]).split(";"))
_ch = lambda v: (len(set(str(O.loc[v, "screened"]).split(";")) - _ref), len(_ref - set(str(O.loc[v, "screened"]).split(";"))))
_mc = [max(_ch(v)) for v in ["Seed 1", "Seed 2", "Seed 3", "Seed 4", "N_MC 1000", "N_MC 10000"]]
N["oat_mc_text"] = "did not change the screened set" if max(_mc) == 0 else f"exchanged at most {max(_mc)} well" + ("s" if max(_mc) > 1 else "")
_a, _r = _ch("Trend scores 0.80/0.65/0.25 (code)")
_w = {0: "no", 1: "one", 2: "two", 3: "three", 4: "four"}
N["oat_trend_text"] = ("did not change the screened set" if _a == 0 and _r == 0 else
                      f"added {_w[_a]} well{'s' if _a > 1 else ''} and removed {_w[_r]}" if _r else f"added {_w[_a]} well{'s' if _a > 1 else ''}")
_hs = [sum(_ch(v)) for v in ["Hydrostratigraphic edges (strict)", "Hydrostratigraphic edges (lenient)"]]
N["oat_hs_text"] = "changed one well" if max(_hs) == 1 else f"changed up to {_w.get(max(_hs), max(_hs))} wells"
N["oat_hs_strict"] = int(O.loc["Hydrostratigraphic edges (strict)", "n_screened"]); N["oat_hs_len"] = int(O.loc["Hydrostratigraphic edges (lenient)", "n_screened"])
_unch = ["Seed 1", "Seed 2", "Seed 3", "Seed 4", "N_MC 1000", "N_MC 10000", "Chloride midpoint 1,500 mg/L", "Chloride midpoint 2,500 mg/L",
         "Chloride scale 300 mg/L", "Chloride scale 500 mg/L", "Trend scores 0.80/0.65/0.25 (code)", "Safeguard Q75/0.75/0.80",
         "Safeguard Q95/0.90/0.95", "Original MST (no co-location fix)", "EDP 2013-2020 median chloride"]
assert all(sum(_ch(v)) == 0 and O.loc[v, "n_confirmed"] == 0 for v in _unch), "Sect. 3.7 lists these variants as unchanged"
N["oat_ell80"] = int(O.loc["ell = P80", "n_screened"]); N["oat_rev60"] = int(O.loc["Review threshold 0.60", "n_screened"])
_mst = sum(_ch("Original MST (no co-location fix)"))
N["oat_mst_text"] = "did not change the screened set" if _mst == 0 else f"changed {_w.get(_mst, _mst)} screened well" + ("s" if _mst > 1 else "")
N["oat_spr_s"] = int(O.loc["Spring vents in the well graph", "n_screened"]); N["oat_spr_c"] = WORDS[int(O.loc["Spring vents in the well graph", "n_confirmed"])]
N["oat_none_s"] = int(O.loc["Critical rule: none", "n_screened"]); N["oat_none_c"] = int(O.loc["Critical rule: none", "n_confirmed"])
N["oat_dom_s"] = int(O.loc["Critical rule: dominant record", "n_screened"]); N["oat_dom_c"] = int(O.loc["Critical rule: dominant record", "n_confirmed"])
_nsids = str(O.loc["Critical rule: none", "confirmed"]).split(";")          # wells confirmed without the designation
_dsids = str(O.loc["Critical rule: dominant record", "confirmed"]).split(";")
_com = sorted(set(_nsids) & set(_dsids))
N["dom_none_common"] = f"the same {WORDS[len(_com)]} well{'s' if len(_com) > 1 else ''} (SID{'s' if len(_com) > 1 else ''} {_sids(_com)})"
_Wc = pd.read_csv(A + "reference/Retention_probabilities_perSID_B4_9_GRAPH_AWARE_ACTIVE_SENSING.csv", low_memory=False, dtype={"SID": str})
cc = _Wc[_Wc.SID.isin(_nsids)]
N["none_cl_min"] = f(cc.CHLORIDE.min()); N["none_cl_max"] = f(cc.CHLORIDE.max())

# ---- joint (LHS) perturbation
if os.path.exists(A + "lhs_summary.json"):
    LS = json.load(open(A + "lhs_summary.json"))
    N["lhs_n"] = LS["n"]; N["lhs_k"] = 31
    zero = 100 * LS["frac_runs_confirmed_zero"]
    top = LS.get("top_prcc_n_screened", [])
    tops = "; ".join(f"{p} {v:+.2f}" for p, v, _ in top[:3])
    N["lhs_text"] = (f"the number of screened wells ranged from {LS['n_screened_min']} to {LS['n_screened_max']} (median {LS['n_screened_median']:.0f}; "
                     f"5th–95th percentile {LS['n_screened_p05']:.0f}–{LS['n_screened_p95']:.0f}), the median Jaccard overlap with the reference "
                     f"screened set was {LS['jaccard_median']:.2f}, and no well was confirmed in {zero:.1f} % of the runs. [[lhs_interp]]")
    N["lhs_top"] = tops
    _D = pd.read_csv(A + "lhs_runs.csv"); _F = pd.read_csv(A + "lhs_well_frequency.csv", index_col=0)
    _Wr = pd.read_csv(A + "reference/Retention_probabilities_perSID_B4_9_GRAPH_AWARE_ACTIVE_SENSING.csv", low_memory=False, dtype={"SID": str}).set_index("SID")
    _c = _D[_D.n_confirmed > 0]
    _cs = sorted(set(";".join(_c.confirmed.astype(str)).split(";"))) if len(_c) else []
    _same = len(_c) > 0 and _c.confirmed.nunique() == 1
    _nw = {1: "One run", 2: "Two runs", 3: "Three runs", 4: "Four runs"}.get(len(_c), f"{len(_c)} runs")
    conf_txt = "" if len(_c) == 0 else (
        (f" {_nw} confirmed the same {WORDS[len(_cs)]} well{'s' if len(_cs) > 1 else ''} " if _same else f" {_nw} confirmed wells ") +
        f"(SIDs {' and '.join(_cs)}, {' and '.join(f(_Wr.loc[x, 'CHLORIDE']) for x in _cs)} mg/L), because a chloride midpoint of "
        f"{_c.CHL_THRESHOLD.min():,.0f}–{_c.CHL_THRESHOLD.max():,.0f} mg/L, a transition width near {_c.CHL_SIGMOID_SCALE.mean():.0f} mg/L and a criterion-(iii) "
        f"threshold of {_c.SG_PCHL.min():.3f}–{_c.SG_PCHL.max():.3f} left these fresh wells unprotected by criterion (iii).")
    _p = [x for x in top[:3]]
    _PL = {"ELL_FROM_NN_PCTL": "the percentile that defines ℓ~a~", "REVIEW_THRESHOLD": "the cluster review threshold",
           "NETWORK_FAMILY_MAX_WEIGHT": "the network-family cap", "SECOND_KEEP_MIN_UTILITY": "the second-anchor threshold",
           "MAD_MULT": "the MAD multiplier of the edge cut", "CHL_THRESHOLD": "the chloride midpoint"}
    N["lhs_interp"] = (f"{WORDS[int((_F.screen_freq == 1).sum())].capitalize()} wells were screened in every run, and all {int((_F.screen_freq > 0).sum())} wells ever "
                       f"screened lack a critical designation.{conf_txt} {_PL[_p[0][0]].capitalize()}, {_PL[_p[1][0]]} and {_PL[_p[2][0]]} "
                       f"had the largest effects on the number screened (PRCC {_p[0][1]:+.2f}, {_p[1][1]:+.2f} and {_p[2][1]:+.2f}; "
                       f"ESM Table S11). An additive rank model explained {100 * LS['r2_rank_additive_n_screened']:.0f} % of the variance of the number screened "
                       f"and {100 * LS['r2_rank_additive_jaccard_vs_ref']:.0f} % of that of the overlap with the reference set; the remainder reflects "
                       f"interactions among the sequential thresholds.")
    N["lhs_text"] = N["lhs_text"].replace("[[lhs_interp]]", N["lhs_interp"])
    N["lhs_r2n"] = f"{100 * LS['r2_rank_additive_n_screened']:.0f}"; N["lhs_r2j"] = f"{100 * LS['r2_rank_additive_jaccard_vs_ref']:.0f}"
    N["lhs_conf_pct"] = f"{100 * LS['frac_runs_confirmed_zero']:.1f}"
else:
    N["lhs_n"] = "–"; N["lhs_k"] = 31; N["lhs_text"] = "(pending)"

# second-pass placeholders (interpretation sentences written after inspection) are kept in numbers_text.json
if os.path.exists(A + "numbers_text.json"):
    extra = json.load(open(A + "numbers_text.json"))
    for k, v in list(N.items()):
        if isinstance(v, str):
            for kk, vv in extra.items():
                v = v.replace(f"[[{kk}]]", vv)
            N[k] = v
    N.update({k: v for k, v in extra.items() if k not in N})
for k, v in list(N.items()):                           # numbers inside the interpretation sentences
    if isinstance(v, str):
        N[k] = re.sub(r"\[\[([A-Za-z0-9_]+)\]\]", lambda m: str(N.get(m.group(1), m.group(0))), v)
json.dump({k: (v.item() if hasattr(v, "item") else v) for k, v in N.items()}, open(A + "numbers.json", "w"), indent=1, ensure_ascii=False)
print(len(N), "numbers written")
