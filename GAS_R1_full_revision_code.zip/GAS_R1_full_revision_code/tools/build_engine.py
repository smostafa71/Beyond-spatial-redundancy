"""Builds gas_engine.py (code of record for the revised submission) from the original FINAL6 script.

Every change is an explicit, anchored replacement so that the difference between the code that produced the
original submission and the code of the revision can be audited line by line (see FINAL6_to_gas_engine.diff).

Changes (R1 ledger identifiers in brackets):
  [C0]  build_final_decision_reason and compute_adaptive_active_sensing_weights were missing from the FINAL6 file
        and are restored verbatim from Final5NEW (same framework version, B-GAS script).
  [C1]  MST construction: the Delaunay-based MST ignores wells that share coordinates with another well
        (multi-depth sites), so those wells received no edge and were classified as isolated. The MST is now built
        on the complete distance graph. Switch: R1["FIX_MST"].
  [C2]  Trend keep scores follow Section 2.4.1 of the manuscript (1.0 / 0.5 / 0.0) instead of the values hard-coded
        in compute_trend_keep (0.80 / 0.65 / 0.25). Switch: R1["TREND_SCORES"].
  [C3]  Calibration layer: structural value = mean of {P_info, P_dep, P_graph, S_GI} as stated in Section 2.5
        (the code used the first three only). Switch: R1["CALIB_STRUCT_WITH_SGI"].
  [C4]  Active-sensing score in E-GAS: the adaptive Table S1 weights (computed but not used in FINAL6, which applied
        fixed 0.50/0.35/0.10/0.03/0.02) are applied, as in the B-GAS script (Final5NEW), which always used them.
        Switch: R1["AS_ADAPTIVE"] (affects the E-GAS selection only).
  [C5]  Hydro-LIMG level weights 0.25/0.15/0.40/0.20 (Table S1; code had 0.30/0.20/0.30/0.20). R1["LIMG_W"].
  [C6]  E-GAS fusion weights 0.35/0.35/0.30 (Eq. 18, Table S1; code had 0.40/0.40/0.20). R1["CAND_W"].
  [C7]  Remove-risk safeguard thresholds LOO Q85, S_GI >= 0.80, P_chl_adj >= 0.85 (Section 2.7.1, Table S1; code had
        Q75 / 0.75 / 0.80). These are the values that reproduce the published E-GAS result. R1["SAFEGUARD"].
  [C8]  Validation gain V(c) of E-GAS: computed from the screened wells of the candidate's own aquifer group. The code
        used the LOO errors of the screened wells of all aquifer groups, so that Hawthorn and surficial candidates were
        ranked by Upper Floridan wells, although the aquifer groups are processed independently and the manuscript
        defines V(c) from "nearby candidate-remove wells". R1["VGAIN_SAME_AQUIFER"].
  [C9]  Graph-role shrinkage for small clusters applied to clusters with fewer than three wells, as stated in the
        manuscript and Table S1 ("n < 3"); the code used n <= 3. R1["SMALL_CLUSTER_MAX_N"].
  [C10] Candidate points are restricted to land: points of the support domain that fall in Tampa Bay or the Gulf of Mexico
        (outside the 1:500,000 Census shoreline of Florida, inputs/florida_land.gpkg) are removed before scoring.
        R1["LAND_MASK"] (path or None).
  [D1]  Spring vents are evaluated as a separate station class and do not enter the well graph. R1["SPRINGS_SEPARATE"].
  [S1]  B-GAS and E-GAS candidate sets are produced in the same run from the same candidate pool: B-GAS uses the
        active-sensing score and the B-GAS greedy rule (Final5NEW), E-GAS adds Hydro-LIMG, validation gain and the
        multi-component greedy penalty (FINAL6). Existing-well logic is identical in both scripts (verified).
  [S2]  run() accepts input/output paths, returns its results, and can skip the GeoPackage/zip exports.
Nothing else in the original code is changed.
"""
import re, sys, os

SRC = sys.argv[1] if len(sys.argv) > 1 else "final6_patched.py"
DST = sys.argv[2] if len(sys.argv) > 2 else "gas_engine.py"
s = open(SRC, encoding="utf-8").read()


def rep(old, new, count=1):
    global s
    n = s.count(old)
    assert n == count, f"anchor found {n} times (expected {count}):\n{old[:200]}"
    s = s.replace(old, new)


HEADER = '''# ============================================================
# GAS engine, revised submission (HYJO-D-26-00546.R1)
# Built from FINAL6 (B4.9 graph-aware active sensing + E-GAS extension) by tools/build_engine.py.
# All changes are marked "R1" and listed in tools/build_engine.py; the switches below reproduce the
# original code (R1_ORIGINAL_CODE) or the revised configuration (R1_DEFAULT).
# ============================================================
R1_DEFAULT = dict(
    FIX_MST=True,                                   # [C1]
    TREND_SCORES={"DECREASING": 1.0, "STABLE": 0.5, "INCREASING": 0.0},   # [C2] manuscript Sect. 2.4.1
    CALIB_STRUCT_WITH_SGI=True,                     # [C3]
    AS_ADAPTIVE=True,                               # [C4]
    LIMG_W=(0.25, 0.15, 0.40, 0.20),                # [C5] global / aquifer / local / blended
    CAND_W=(0.35, 0.35, 0.30),                      # [C6] AS / Hydro-LIMG / validation gain
    SAFEGUARD=(0.85, 0.80, 0.85),                   # [C7] LOO quantile / S_GI / P_chl_adj
    VGAIN_SAME_AQUIFER=True,                        # [C8]
    SMALL_CLUSTER_MAX_N=2,                          # [C9] manuscript: clusters with fewer than three wells
    LAND_MASK="inputs/florida_land.gpkg",           # [C10] candidate sites on land only
    SPRINGS_SEPARATE=True,                          # [D1]
    WRITE_GEO=False,                                # [S2] GeoPackage + zip exports
    EDGE_ZONE_FILTER=None,                          # sensitivity: None | 'strict' | callable(zone_i, zone_j) -> edge allowed
    CRITICAL_RULE="any",                            # original: any record "Critical"; sensitivity: dominant | none
)
R1_ORIGINAL_CODE = dict(
    FIX_MST=False,
    TREND_SCORES={"DECREASING": 0.80, "STABLE": 0.65, "INCREASING": 0.25},
    CALIB_STRUCT_WITH_SGI=False,
    AS_ADAPTIVE=False,
    LIMG_W=(0.30, 0.20, 0.30, 0.20),
    CAND_W=(0.40, 0.40, 0.20),
    SAFEGUARD=(0.75, 0.75, 0.80),
    VGAIN_SAME_AQUIFER=False,
    SMALL_CLUSTER_MAX_N=3,
    LAND_MASK=None,
    SPRINGS_SEPARATE=False,
    WRITE_GEO=True,
    EDGE_ZONE_FILTER=None,
    CRITICAL_RULE="any",
)
R1 = dict(R1_DEFAULT)


def configure(**kw):
    """Set R1 switches and the module-level constants that depend on them. Unknown keys are module constants."""
    global CAND_W_AS, CAND_W_LIMG, CAND_W_VALID, REMOVE_RISK_LOO_Q, REMOVE_RISK_GRAPH_THR, REMOVE_RISK_CHL_THR
    for k, v in kw.items():
        if k in R1:
            R1[k] = v
        elif k in globals():
            globals()[k] = v
        else:
            raise KeyError(k)
    CAND_W_AS, CAND_W_LIMG, CAND_W_VALID = R1["CAND_W"]
    REMOVE_RISK_LOO_Q, REMOVE_RISK_GRAPH_THR, REMOVE_RISK_CHL_THR = R1["SAFEGUARD"]

'''
rep("import os\nimport math\nimport zipfile\n", HEADER + "import os\nimport math\nimport zipfile\n")

# paths: environment-driven, no directory creation at import time
rep("os.makedirs(OUT_DIR, exist_ok=True)\n", "")

# [C1] MST
rep("def mst_edges_from_points(coords_xy: np.ndarray):\n    n = coords_xy.shape[0]",
    '''def mst_edges_from_points(coords_xy: np.ndarray):
    # R1 [C1]: complete-graph MST (co-located wells at multi-depth sites keep their zero-length edge)
    if R1["FIX_MST"]:
        return _mst_edges_complete(coords_xy)
    return _mst_edges_delaunay_original(coords_xy)


def _mst_edges_complete(coords_xy: np.ndarray):
    xy = np.asarray(coords_xy, dtype=float)
    n = xy.shape[0]
    if n <= 1:
        return []
    D = np.sqrt(((xy[:, None, :] - xy[None, :, :]) ** 2).sum(-1))
    W = np.where(D > 0, D, 1e-3)          # csgraph treats 0 as "no edge": zero distances become 1 mm
    np.fill_diagonal(W, 0.0)
    T = minimum_spanning_tree(W).tocoo()
    return [(int(min(i, j)), int(max(i, j)), float(D[i, j])) for i, j in zip(T.row, T.col)]


def _mst_edges_delaunay_original(coords_xy: np.ndarray):
    n = coords_xy.shape[0]''')

# [C2] trend scores
rep('''        if lab == "INCREASING":
            base[i] = 0.25
            unc[i] = 0.15
        elif lab == "DECREASING":
            base[i] = 0.80
            unc[i] = 0.15
        elif lab == "STABLE":
            base[i] = 0.65
            unc[i] = 0.20''',
    '''        if lab == "INCREASING":                      # R1 [C2]: scores from R1["TREND_SCORES"]
            base[i] = R1["TREND_SCORES"]["INCREASING"]
            unc[i] = 0.15
        elif lab == "DECREASING":
            base[i] = R1["TREND_SCORES"]["DECREASING"]
            unc[i] = 0.15
        elif lab == "STABLE":
            base[i] = R1["TREND_SCORES"]["STABLE"]
            unc[i] = 0.20''')

# [C3] calibration structural value
rep("    structural = np.nanmean(np.column_stack([info_keep, dep_keep, graph_keep]), axis=1)\n",
    '''    structural = np.nanmean(np.column_stack([info_keep, dep_keep, graph_keep]), axis=1)
    if R1["CALIB_STRUCT_WITH_SGI"]:                  # R1 [C3]: {P_info, P_dep, P_graph, S_GI} (Sect. 2.5)
        sgi = pd.to_numeric(out.get("GraphInfluence_score", 0.5), errors="coerce").fillna(0.5).to_numpy(dtype=float)
        structural = np.nanmean(np.column_stack([info_keep, dep_keep, graph_keep, sgi]), axis=1)
''')

# [C4] active-sensing weights
rep('''        final_score = np.clip(
            0.50 * expected_unc_reduction
            + 0.35 * support_improvement
            + 0.10 * expected_graph_improvement
            + 0.03 * expected_representation_gain
            + 0.02 * expected_dependency_gain,
            0, 1
        )''',
    '''        if R1["AS_ADAPTIVE"]:                         # R1 [C4]: Eq. 17 with Table S1 adaptive weights
            final_score = np.clip(
                w_unc * expected_unc_reduction + w_sup * support_improvement + w_gra * expected_graph_improvement
                + w_rep * expected_representation_gain + w_dep * expected_dependency_gain, 0, 1)
        else:
            final_score = np.clip(
                0.50 * expected_unc_reduction
                + 0.35 * support_improvement
                + 0.10 * expected_graph_improvement
                + 0.03 * expected_representation_gain
                + 0.02 * expected_dependency_gain,
                0, 1
            )
        cand.loc[cand_idx, "AS_w_unc"], cand.loc[cand_idx, "AS_w_sup"] = float(w_unc), float(w_sup)
        cand.loc[cand_idx, "AS_w_gra"], cand.loc[cand_idx, "AS_w_rep"], cand.loc[cand_idx, "AS_w_dep"] = float(w_gra), float(w_rep), float(w_dep)''')

# [C5] LIMG level weights
rep('''    w_global = 0.30
    w_aq = 0.20
    w_local = 0.30 if USE_LOCAL_GRAPH_LEVEL else 0.0
    w_blended = 0.20''',
    '''    w_global, w_aq, w_local, w_blended = R1["LIMG_W"]   # R1 [C5]
    w_local = w_local if USE_LOCAL_GRAPH_LEVEL else 0.0''')


# compute_chloride_keep binds CHL_THRESHOLD as a default argument at definition time; pass it at call time so that
# the sensitivity analysis can vary it (no change in the reference run)
rep('compute_chloride_keep(g_out[COL_CHL], g_out["Aquifer_group"])', 'compute_chloride_keep(g_out[COL_CHL], g_out["Aquifer_group"], threshold=CHL_THRESHOLD)')
# hard-coded coefficients exposed as module constants (same values) for the global sensitivity analysis
rep("        proximity_intensity = 0.60 * wsum_n + 0.40 * (1.0 - mdist_n)\n",
    "        proximity_intensity = PROX_W_WSUM * wsum_n + (1.0 - PROX_W_WSUM) * (1.0 - mdist_n)\n")
rep("""            0.45 * comp_score
            + 0.35 * strength_score
            + 0.20 * mst_score,""", """            GI_W[0] * comp_score
            + GI_W[1] * strength_score
            + GI_W[2] * mst_score,""")
rep("    kappa = 2.0 + (1.0 - u) * 48.0\n", "    kappa = 2.0 + (1.0 - u) * BETA_KAPPA_SPAN\n")
rep("N_MC = 3000\n", "N_MC = 3000\nPROX_W_WSUM = 0.60          # Eq. 4\nGI_W = (0.45, 0.35, 0.20)   # Eq. 11\nBETA_KAPPA_SPAN = 48.0      # Eq. 13\n")
# hydrostratigraphic-edge test: callable compatibility rule on the zone labels


# critical-designation rule (sensitivity): original = any record of the SID ranked "Critical"
rep('    g0["IsCritical"] = g0[rank_col_used].astype(str).str.strip().str.upper().eq("CRITICAL")\n',
    """    g0["IsCritical"] = g0[rank_col_used].astype(str).str.strip().str.upper().eq("CRITICAL")
    g0["IsCritical_dominant"] = g0[COL_RANK].astype(str).str.strip().str.upper().eq("CRITICAL") if COL_RANK in g0.columns else False
    if R1["CRITICAL_RULE"] == "dominant":           # sensitivity only
        g0["IsCritical"] = g0["IsCritical_dominant"]
    elif R1["CRITICAL_RULE"] == "none":
        g0["IsCritical"] = False
""")

# [S1] B-GAS greedy (verbatim from Final5NEW, renamed)
BG = '''
def select_candidates_sequentially_bgas(
    cand: gpd.GeoDataFrame,
    sub: gpd.GeoDataFrame,
    ell_aquifer: float,
    max_keep: int,
    min_spacing: float,
) -> gpd.GeoDataFrame:
    """B-GAS sequential greedy selection (verbatim from Final5NEW): pick best, penalize nearby candidates, repeat."""
    if len(cand) == 0 or max_keep <= 0:
        return cand.copy()
    work = cand.copy().reset_index(drop=True)
    work["OriginalScore"] = work["CandidateScore"].copy()
    kept = []
    remaining = list(range(len(work)))
    ell_use = ell_aquifer if np.isfinite(ell_aquifer) and ell_aquifer > 0 else ELL_MIN_M
    penalty_dist = 0.7 * ell_use
    while len(kept) < max_keep and remaining:
        scores = work.loc[remaining, "CandidateScore"].values
        best_idx = remaining[np.argmax(scores)]
        kept.append(best_idx)
        kept_coords = np.array([work.geometry.iloc[kept[-1]].coords[0]])
        if len(remaining) > 1:
            rem_coords = np.column_stack([work.geometry.iloc[remaining].x, work.geometry.iloc[remaining].y])
            d = np.sqrt(((rem_coords - kept_coords) ** 2).sum(axis=1))
            distance_penalty = np.exp(-d / penalty_dist)
            overlap_penalty = np.clip(0.3 * (1.0 - d / (1.5 * ell_use)), 0, 0.3)
            work.loc[remaining, "CandidateScore"] = (
                work.loc[remaining, "OriginalScore"].values
                * (1.0 - 0.45 * distance_penalty)
                * (1.0 - overlap_penalty)
            )
        remaining = [i for i in remaining if i not in kept]
    out = work.iloc[kept].copy().reset_index(drop=True)
    out = thin_candidates_by_spacing(out, min_spacing=min_spacing, score_col="CandidateScore", max_keep=max_keep)
    return out


_LAND = {}


def _land_polygon(crs):
    """R1 [C10]: land polygon (Census 1:500,000 shoreline) in the CRS of the candidate points."""
    key = (R1["LAND_MASK"], str(crs))
    if key not in _LAND:
        g = gpd.read_file(R1["LAND_MASK"]).to_crs(crs)
        _LAND[key] = g.geometry.union_all() if hasattr(g.geometry, "union_all") else g.geometry.unary_union
    return _LAND[key]


def _finish_candidate_frame(cand, aq, ell_aquifer):
    cand["Aquifer_group"] = aq
    cand["Ell_aquifer_m"] = float(ell_aquifer)
    cand = cand.sort_values("CandidateScore", ascending=False).reset_index(drop=True)
    cand["CandidateRank_inAquifer"] = np.arange(1, len(cand) + 1)
    cand_ll = cand.to_crs(epsg=4326)
    cand["Lat"] = cand_ll.geometry.y.values
    cand["Lon"] = cand_ll.geometry.x.values
    cand["X_m"] = cand.geometry.x
    cand["Y_m"] = cand.geometry.y
    cand["CandidateReason"] = cand.apply(build_candidate_reason, axis=1)
    return cand


def generate_candidates_r1(g_out, loo_df):
    """R1 [S1]: one candidate pool per aquifer; B-GAS and E-GAS selections from the same pool."""
    frames_e, frames_b, frames_p = [], [], []
    if GENERATE_CANDIDATE_WELLS:
        for aq, sub in g_out.groupby("Aquifer_group"):
            aq = str(aq).strip().lower()
            sub = sub.copy()
            ell_vals = pd.to_numeric(sub["Ell_aquifer_m"], errors="coerce")
            ell_aquifer = float(np.nanmedian(ell_vals)) if ell_vals.notna().any() else ELL_MIN_M
            if not np.isfinite(ell_aquifer) or ell_aquifer <= 0:
                ell_aquifer = ELL_MIN_M
            pool0 = create_candidate_points_for_aquifer(sub, ell_aquifer)
            if R1["LAND_MASK"] and len(pool0) > 0:          # R1 [C10]: candidate sites on land only
                pool0 = pool0[pool0.within(_land_polygon(pool0.crs))].copy()
            if len(pool0) == 0:
                continue
            # B-GAS (Final5NEW) always used the adaptive Table S1 weights; FINAL6 (E-GAS) did not ([C4])
            flag = R1["AS_ADAPTIVE"]
            R1["AS_ADAPTIVE"] = True
            pool = score_candidate_points_active_sensing(pool0.copy(), sub, ell_aquifer)
            R1["AS_ADAPTIVE"] = flag
            pool_e = pool if flag else score_candidate_points_active_sensing(pool0.copy(), sub, ell_aquifer)
            post_min_spacing = max(
                CAND_POSTSCORE_MIN_SEPARATION_FACTOR * float(np.clip(CAND_GRID_FACTOR * ell_aquifer, CAND_MIN_GRID_M, CAND_MAX_GRID_M)),
                0.80 * ell_aquifer,
            )
            pp = pool.copy(); pp["Aquifer_group"] = aq; pp["Ell_aquifer_m"] = float(ell_aquifer); pp["PostMinSpacing_m"] = post_min_spacing
            frames_p.append(pp)
            cb = select_candidates_sequentially_bgas(pool.copy(), sub, ell_aquifer, TOP_CANDIDATES_PER_AQUIFER, post_min_spacing)
            frames_b.append(_finish_candidate_frame(cb, aq, ell_aquifer))
            ce = pool_e.copy()
            if USE_HYDRO_LIMG:
                loo_v = loo_df                                   # R1 [C8]: screened wells of the same aquifer group
                if R1["VGAIN_SAME_AQUIFER"] and loo_df is not None and "Aquifer_group" in loo_df.columns:
                    loo_v = loo_df[loo_df["Aquifer_group"].astype(str).str.strip().str.lower() == aq]
                ce = score_candidate_points_hydro_limg(cand=ce, sub=sub, ell_aquifer=ell_aquifer, loo_remove_df=loo_v)
            ce = select_candidates_sequentially(cand=ce, ell_use=ell_aquifer, min_spacing=post_min_spacing,
                                                max_keep=TOP_CANDIDATES_PER_AQUIFER)
            frames_e.append(_finish_candidate_frame(ce, aq, ell_aquifer))
    crs = g_out.crs
    def _cat(fr):
        if len(fr) == 0:
            return gpd.GeoDataFrame(columns=["geometry"], geometry="geometry", crs=crs)
        return gpd.GeoDataFrame(pd.concat(fr, ignore_index=True), geometry="geometry", crs=crs)
    global LAST_CANDIDATE_POOL
    LAST_CANDIDATE_POOL = _cat(frames_p)
    return _cat(frames_e), _cat(frames_b)


'''
rep("# --- restored from Final5NEW (missing in FINAL6 file) ---\n",
    BG + "# --- R1 [C0]: restored verbatim from Final5NEW (missing in the FINAL6 file) ---\n")

# [S2] run signature + paths
rep("def run():\n    rng = np.random.default_rng(RNG_SEED)\n    print(\"Reading:\", IN_PATH)\n    gdf = gpd.read_file(IN_PATH)",
    '''def run(in_path=None, out_dir=None, verbose=True, wells_filter=None):
    """R1 [S2]: in_path/out_dir override the environment paths; wells_filter(g0_m) -> bool mask removes stations
    before the graph is built (used by the hold-out and pseudo-prospective tests); returns the results."""
    global IN_PATH, OUT_DIR
    if in_path is not None:
        IN_PATH = in_path
    if out_dir is not None:
        OUT_DIR = out_dir
    os.makedirs(OUT_DIR, exist_ok=True)
    configure()
    rng = np.random.default_rng(RNG_SEED)
    if verbose:
        print("Reading:", IN_PATH)
    gdf = gpd.read_file(IN_PATH)''')

for p in ['    print("rows before collapse:", len(gdf))\n', '    print("unique SID before collapse:", gdf[SID_COL].astype(str).nunique())\n',
          '    print("rows after collapse:", len(g0))\n', '    print("unique SID after collapse:", g0[SID_COL].astype(str).nunique())\n',
          '    print("Entropy-derived weights (B4.9-GRAPH-AWARE-ACTIVE-SENSING):")\n', '    print(entropy_w)\n',
          '    print("final rows entering summary:", len(g_out))\n', '    print("final unique SID entering summary:", g_out[SID_COL].astype(str).nunique())\n']:
    rep(p, p.replace("    print(", "    if verbose: print("))

# [D1] springs as separate class (+ optional external filter)
rep('''    eligible = (~g0_m["IsConfinement"].to_numpy(bool)) if EXCLUDE_CONFINEMENT else np.ones(len(g0_m), bool)
    g_elig = g0_m[eligible].copy()
    g_excl = g0_m[~eligible].copy()''',
    '''    eligible = (~g0_m["IsConfinement"].to_numpy(bool)) if EXCLUDE_CONFINEMENT else np.ones(len(g0_m), bool)
    # R1 [D1]: spring vents are a separate station class (not part of the well graph)
    g0_m["IsSpring"] = g0_m["WATERBODY_"].astype(str).str.strip().str.lower().str.startswith("spring") if "WATERBODY_" in g0_m.columns else False
    if R1["SPRINGS_SEPARATE"]:
        g_spr = g0_m[eligible & g0_m["IsSpring"].to_numpy(bool)].copy()
        g_spr.drop(columns="geometry").to_csv(os.path.join(OUT_DIR, "Springs_separate_class.csv"), index=False)
        eligible = eligible & (~g0_m["IsSpring"].to_numpy(bool))
    if wells_filter is not None:
        eligible = eligible & np.asarray(wells_filter(g0_m), bool)
    g_elig = g0_m[eligible].copy()
    g_excl = g0_m[~eligible & g0_m["IsConfinement"].to_numpy(bool)].copy()''')

# zone-constrained MST for the hydrostratigraphic-edge sensitivity test
rep('''        mst_edges = mst_edges_from_points(coords)
        mst_dists = np.array([e[2] for e in mst_edges], dtype=float)
        cut_val, cut_info = mst_cut_threshold(mst_dists)''',
    '''        mst_edges = mst_edges_from_points(coords)
        mst_dists = np.array([e[2] for e in mst_edges], dtype=float)
        cut_val, cut_info = mst_cut_threshold(mst_dists)
        if R1["EDGE_ZONE_FILTER"]:                    # sensitivity: no edge between incompatible hydrostratigraphic zones
            f = R1["EDGE_ZONE_FILTER"]
            zz = sub["Waterbod_1_raw"].astype(str).to_numpy()
            ok = (lambda a, b: a == b) if f == "strict" else f
            mst_edges = [(i, j, d) if ok(zz[i], zz[j]) else (i, j, np.inf) for (i, j, d) in mst_edges]''')

# B-GAS decision recorded before the safeguard
rep('''    if USE_REMOVE_RISK_SAFEGUARD and len(loo_df) > 0:
        loo_map''', '''    g_out["FinalDecision_BGAS"] = g_out["FinalDecision"].astype(str)      # R1: B-GAS screening outcome
    if USE_REMOVE_RISK_SAFEGUARD and len(loo_df) > 0:
        loo_map''')
rep('''        g_out.loc[mask_rescue, "FinalDecision"] = "REVIEW"
        g_out.loc[mask_rescue, "DecisionSource"] = "remove_risk_safeguard"
''', '''        g_out.loc[mask_rescue, "FinalDecision"] = "REVIEW"
        g_out.loc[mask_rescue, "DecisionSource"] = "remove_risk_safeguard"
        g_out["Safeguard_LOO_threshold"] = loo_thr                       # R1: criterion-level record
        g_out["Safeguard_trig_LOO"] = g_out["FinalDecision_BGAS"].eq("CANDIDATE_REMOVE") & (pd.to_numeric(g_out["AbsError_without_well"], errors="coerce") >= loo_thr)
        g_out["Safeguard_trig_SGI"] = g_out["FinalDecision_BGAS"].eq("CANDIDATE_REMOVE") & (pd.to_numeric(g_out["GraphInfluence_score"], errors="coerce") >= REMOVE_RISK_GRAPH_THR)
        g_out["Safeguard_trig_CHL"] = g_out["FinalDecision_BGAS"].eq("CANDIDATE_REMOVE") & (pd.to_numeric(g_out["P_keep_chloride_adj"], errors="coerce") >= REMOVE_RISK_CHL_THR)
''')

# candidate block -> generate_candidates_r1
i0 = s.index("    cand_frames = []\n    if GENERATE_CANDIDATE_WELLS:\n        for aq, sub in g_out.groupby(\"Aquifer_group\"):")
i1 = s.index('        cand_gdf = gpd.GeoDataFrame(columns=["geometry"], geometry="geometry", crs=g_out.crs)\n', i0)
i1 = i1 + len('        cand_gdf = gpd.GeoDataFrame(columns=["geometry"], geometry="geometry", crs=g_out.crs)\n')
s = s[:i0] + "    cand_gdf, cand_gdf_b = generate_candidates_r1(g_out, loo_df)   # R1 [S1]\n" + s[i1:]

# geo exports and zip optional
rep('    write_points_output(g_out, name="wells_uniqueSID_prob_retention_b4_9_graph_aware_active_sensing", layer_name="wells")\n',
    '    if R1["WRITE_GEO"]: write_points_output(g_out, name="wells_uniqueSID_prob_retention_b4_9_graph_aware_active_sensing", layer_name="wells")\n')
rep('        write_edges_output(e_gdf, name="edges_singleEll_b4_9_graph_aware_active_sensing", layer_name="edges")\n',
    '        if R1["WRITE_GEO"]: write_edges_output(e_gdf, name="edges_singleEll_b4_9_graph_aware_active_sensing", layer_name="edges")\n')
rep('        write_edges_output(dep_gdf, name="dependency_graph_edges_b4_9_graph_aware_active_sensing", layer_name="dependency_edges")\n',
    '        if R1["WRITE_GEO"]: write_edges_output(dep_gdf, name="dependency_graph_edges_b4_9_graph_aware_active_sensing", layer_name="dependency_edges")\n')
rep('        write_points_output(cand_gdf[cand_cols + ["geometry"]], name="candidate_new_wells_b4_9_graph_aware_active_sensing", layer_name="candidates")\n',
    '''        if R1["WRITE_GEO"]: write_points_output(cand_gdf[cand_cols + ["geometry"]], name="candidate_new_wells_b4_9_graph_aware_active_sensing", layer_name="candidates")
        if len(cand_gdf_b) > 0:
            cand_gdf_b[[c for c in cand_cols if c in cand_gdf_b.columns]].to_csv(os.path.join(OUT_DIR, "Candidate_new_wells_BGAS.csv"), index=False)
''')
i0 = s.index('    zip_name = "b4_9_graph_aware_active_sensing_outputs.zip"')
i1 = s.index('    print("Outputs written to:", OUT_DIR)\n', i0) + len('    print("Outputs written to:", OUT_DIR)\n')
s = s[:i0] + '''    if R1["WRITE_GEO"]:
        zip_name = "b4_9_graph_aware_active_sensing_outputs.zip"
        zip_path = os.path.join(OUT_DIR, zip_name)
        with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as z:
            for root, _, files in os.walk(OUT_DIR):
                for f in files:
                    if f.lower() == zip_name.lower():
                        continue
                    fp = os.path.join(root, f)
                    z.write(fp, arcname=os.path.relpath(fp, OUT_DIR))
    if verbose:
        print("DONE - GAS engine (R1). Outputs written to:", OUT_DIR)
    return dict(wells=g_out, cand_egas=cand_gdf, cand_bgas=cand_gdf_b, cand_pool=LAST_CANDIDATE_POOL if GENERATE_CANDIDATE_WELLS else None,
                loo=loo_df, weights=entropy_w,
                aquifers=pd.DataFrame(aquifer_summary), components=pd.DataFrame(comp_summary),
                edges=edges_df, dep_edges=dep_edges_df, excluded=g_excl)
''' + s[i1:]

s += '''

# R1 [S2]: snapshot of every module constant, so that repeated runs in one process (sensitivity analyses) start
# from the documented configuration
import copy as _copy
_CONST_SNAPSHOT = {k: _copy.deepcopy(v) for k, v in list(globals().items())
                   if k.isupper() and not k.startswith("_") and not callable(v) and not isinstance(v, type(os))}


def reset():
    """Restore all module constants and the R1 switches to the revised (reference) configuration."""
    globals().update(_copy.deepcopy(_CONST_SNAPSHOT))
    R1.clear(); R1.update(_copy.deepcopy(R1_DEFAULT))
    configure()
'''
# [C9] small-cluster graph-role shrinkage: clusters with fewer than three wells (manuscript, Table S1)
rep("        if len(idxs) <= GRAPH_ROLE_SMALL_CLUSTER_MAX_N:\n            keep_score = shrink_score_to_neutral(keep_score, GRAPH_ROLE_SMALL_CLUSTER_SHRINK)",
    "        if len(idxs) <= R1[\"SMALL_CLUSTER_MAX_N\"]:          # R1 [C9]\n            keep_score = shrink_score_to_neutral(keep_score, GRAPH_ROLE_SMALL_CLUSTER_SHRINK)")

open(DST, "w", encoding="utf-8").write(s)
print("written", DST, len(s.splitlines()), "lines")
