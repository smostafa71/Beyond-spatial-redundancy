# ============================================================
# VERSION B4.9-GRAPH-AWARE-ACTIVE-SENSING
# GRAPH-REASONING-AWARE INFORMATION-OPTIMAL ADAPTIVE MONITORING NETWORK
#
# B4.9 TARGETED UPGRADES:
# 1) Graph influence analysis added
# 2) Active sensing scoring added for candidate wells
# 3) Active-sensing candidate injection in pool generation
# 4) Sequential greedy selection for final candidates
#
# Goal:
# Preserve the existing-well decision framework while improving
# graph diagnostics and candidate well suggestion.
#
# NOTE:
# Existing-well logic, stability index, safeguards, and hard resolver are preserved.
# ============================================================
# ============================================================
# GAS engine, revised submission (HYJO-D-26-00546.R1)
# Built from FINAL6 (B4.9 graph-aware active sensing + E-GAS extension) by tools/build_engine.py.
# All changes are marked "R1" and listed in tools/build_engine.py; the switches below reproduce the
# original code (R1_ORIGINAL_CODE) or the revised configuration (R1_DEFAULT).
# ============================================================
R1_DEFAULT = dict(
    FIX_MST=True,                                   # [C1]
    TREND_SCORES={"DECREASING": 1.0, "STABLE": 0.5, "INCREASING": 0.0},   # [C2] manuscript Sect. 2.4.1
    CALIB_STRUCT_WITH_SGI=True,                     # [C3]
    AS_ADAPTIVE=True,                               # [C4]
    LIMG_W=(0.25, 0.15, 0.40, 0.20),                # [C5] global / aquifer / local / blended
    CAND_W=(0.35, 0.35, 0.30),                      # [C6] AS / Hydro-LIMG / validation gain
    SAFEGUARD=(0.85, 0.80, 0.85),                   # [C7] LOO quantile / S_GI / P_chl_adj
    VGAIN_SAME_AQUIFER=True,                        # [C8]
    SMALL_CLUSTER_MAX_N=2,                          # [C9] manuscript: clusters with fewer than three wells
    LAND_MASK="inputs/florida_land.gpkg",           # [C10] candidate sites on land only
    SPRINGS_SEPARATE=True,                          # [D1]
    WRITE_GEO=False,                                # [S2] GeoPackage + zip exports
    EDGE_ZONE_FILTER=None,                          # sensitivity: None | 'strict' | callable(zone_i, zone_j) -> edge allowed
    CRITICAL_RULE="any",                            # original: any record "Critical"; sensitivity: dominant | none
)
R1_ORIGINAL_CODE = dict(
    FIX_MST=False,
    TREND_SCORES={"DECREASING": 0.80, "STABLE": 0.65, "INCREASING": 0.25},
    CALIB_STRUCT_WITH_SGI=False,
    AS_ADAPTIVE=False,
    LIMG_W=(0.30, 0.20, 0.30, 0.20),
    CAND_W=(0.40, 0.40, 0.20),
    SAFEGUARD=(0.75, 0.75, 0.80),
    VGAIN_SAME_AQUIFER=False,
    SMALL_CLUSTER_MAX_N=3,
    LAND_MASK=None,
    SPRINGS_SEPARATE=False,
    WRITE_GEO=True,
    EDGE_ZONE_FILTER=None,
    CRITICAL_RULE="any",
)
R1 = dict(R1_DEFAULT)


def configure(**kw):
    """Set R1 switches and the module-level constants that depend on them. Unknown keys are module constants."""
    global CAND_W_AS, CAND_W_LIMG, CAND_W_VALID, REMOVE_RISK_LOO_Q, REMOVE_RISK_GRAPH_THR, REMOVE_RISK_CHL_THR
    for k, v in kw.items():
        if k in R1:
            R1[k] = v
        elif k in globals():
            globals()[k] = v
        else:
            raise KeyError(k)
    CAND_W_AS, CAND_W_LIMG, CAND_W_VALID = R1["CAND_W"]
    REMOVE_RISK_LOO_Q, REMOVE_RISK_GRAPH_THR, REMOVE_RISK_CHL_THR = R1["SAFEGUARD"]

import os
import math
import zipfile
from typing import Dict, Any, List, Tuple, Optional
import numpy as np
import pandas as pd
# --- geopandas compatibility patch for pandas>=2 ---
if not hasattr(pd, "Int64Index"):
    pd.Int64Index = pd.Index # type: ignore
import geopandas as gpd
from shapely.geometry import LineString, Point, box, MultiPoint
from shapely.ops import polygonize, unary_union
from scipy.spatial import cKDTree, Delaunay
from scipy.sparse import coo_matrix
from scipy.sparse.csgraph import minimum_spanning_tree
# -----------------------------
# USER PATHS
# -----------------------------
IN_PATH = os.environ.get(
    "GW_IN_PATH", r"D:\Projects\Groundwater Quality\Meeting with Jason regarding list\Results\gwshape\GW_Stations_Final.shp",
)
OUT_DIR = os.environ.get(
    "GW_OUT_DIR", r"D:\Projects\Groundwater Quality\Meeting with Jason regarding list\Results\gwshape\Phase2 b4.9_revised",
)
WRITE_GPKG_INSTEAD_OF_SHP = True
# -----------------------------
# CORE SETTINGS
# -----------------------------
METRIC_EPSG = 3087 # Florida Albers
WB_COL = "Waterbod_1"
SID_COL = "SID"
EXCLUDE_CONFINEMENT = True
CONFINEMENT_LABELS = {
    "Confining unit", "Middle confining unit II",
}
SPLIT_HAWTHORN = False
CUT_RULE = "median_plus_mad" # or "p95"
MAD_MULT = 3.0
ELL_FROM_NN_PCTL = 90
ELL_MIN_M = 250.0
ELL_MAX_M = 20000.0
ELL_ROUND_TO_M = 10.0
WEIGHT_FORMULA = "exp(-Distance_m / Ell_aquifer_m)"
# -----------------------------
# PHASE 2 SETTINGS
# -----------------------------
COL_CHL = "CHLORIDE"
COL_TREND = "CHLORIDE_T"
COL_RANK = "rank"
COL_STATUS = "status"
COL_DEPTH = "Well_Depth"
CHL_THRESHOLD = 2000.0
CHL_SIGMOID_SCALE = 400.0
TREND_SCORE_MAP = {"DECREASING": 1.0, "STABLE": 0.5, "INCREASING": 0.0}
STATUS_SCORE_MAP = {"ACTIVE": 1.0}
DEPTH_BINS_MIN = 3
DEPTH_BINS_MAX = 5
DEPTH_MIN_VALID_PER_AQUIFER = 5
DEPTH_FILL_METHOD = "median"
DIST_REDUNDANCY_W_NEIGH = 0.40
DIST_REDUNDANCY_W_PROX = 0.42
DIST_REDUNDANCY_W_COMPACT = 0.18
REVIEW_THRESHOLD = 0.66
ISO_REVIEW_THRESHOLD = 0.35
# -----------------------------
# MONTE CARLO SETTINGS
# -----------------------------
N_MC = 3000
PROX_W_WSUM = 0.60          # Eq. 4
GI_W = (0.45, 0.35, 0.20)   # Eq. 11
BETA_KAPPA_SPAN = 48.0      # Eq. 13
RNG_SEED = 12345
# -----------------------------
# QUALITY DEPENDENCY LAYER SETTINGS
# -----------------------------
INTERACTION_BAD_CHL_BAD_TREND = 0.22
INTERACTION_GOOD_CHL_GOOD_TREND = 0.10
INTERACTION_BAD_STATUS_BAD_QUALITY = 0.10
INTERACTION_ACTIVE_STATUS_GOOD_QUALITY = 0.05
JOINT_QUALITY_WEIGHT = 0.03
# -----------------------------
# WEIGHT STABILIZATION SETTINGS
# -----------------------------
MIN_COMPONENT_WEIGHT = 0.03
MAX_JOINT_QUALITY_WEIGHT = 0.18
WEIGHT_STABILIZATION_PASSES = 2
# -----------------------------
# INFORMATION / DEPENDENCY SETTINGS
# -----------------------------
INFO_SIM_DECAY = 1.25
DEP_GRAPH_W_TREND = 0.35
DEP_GRAPH_W_CHL = 0.30
DEP_GRAPH_W_DEPTH = 0.20
DEP_GRAPH_W_STATUS = 0.15
# -----------------------------
# GRAPH ROLE SETTINGS
# -----------------------------
GRAPH_ROLE_EDGE_USE_SPATIAL = True
GRAPH_ROLE_MIN_EDGE_WEIGHT = 0.05
GRAPH_ROLE_W_BRIDGE = 0.65
GRAPH_ROLE_W_LOW_COHESION = 0.20
GRAPH_ROLE_W_NEIGHBOR_SPREAD = 0.15
GRAPH_ROLE_SMALL_CLUSTER_MAX_N = 3
GRAPH_ROLE_SMALL_CLUSTER_SHRINK = 0.55
GRAPH_ROLE_SMALL_CLUSTER_UNC_BOOST = 0.10
# -----------------------------
# CANDIDATE WELL SETTINGS
# -----------------------------
GENERATE_CANDIDATE_WELLS = True
CAND_GRID_FACTOR = 0.75
CAND_MIN_GRID_M = 1000.0
CAND_MAX_GRID_M = 10000.0
CAND_BUFFER_FACTOR = 1.00
CAND_EXPANSION_FACTOR = 1.50
CAND_MIN_DIST_EXISTING_FACTOR = 0.60
TOP_CANDIDATES_PER_AQUIFER = 20
CAND_W_SPATIAL_GAP = 0.22
CAND_W_INFO_GAP = 0.18
CAND_W_DEP_GAP = 0.14
CAND_W_GRAPH_GAIN = 0.18
CAND_W_EXPLORATION = 0.28
CAND_DOMAIN_COMPONENT_AWARE = True
CAND_DOMAIN_SMOOTHING_FRAC = 0.35
CAND_DOMAIN_SUPPORT_MIN_POINTS = 1
CAND_HEX_GRID = True
CAND_POINT_SUPPORT_FACTOR = 0.55
CAND_MST_CORRIDOR_FACTOR = 0.40
CAND_ALPHA_RADIUS_FACTOR = 1.15
CAND_MIN_SEPARATION_FACTOR = 0.90
CAND_POSTSCORE_MIN_SEPARATION_FACTOR = 0.85
CAND_MAX_PER_COMPONENT = 8
CAND_TARGET_GAP_FACTOR = 0.95
CAND_TARGET_GAP_SIGMA_FACTOR = 0.45
CAND_SUPPORT_DECAY_FACTOR = 1.00
CAND_BRIDGE_DECAY_FACTOR = 0.60
CAND_COMPONENT_SCOPE_SCORING = True
# -----------------------------
# ACTIVE SENSING SETTINGS (B4.9)
# -----------------------------
AS_W_UNCERTAINTY_REDUCTION = 0.34
AS_W_SUPPORT_IMPROVEMENT = 0.24
AS_W_GRAPH_IMPROVEMENT = 0.20
AS_W_REPRESENTATION_GAIN = 0.14
AS_W_DEPENDENCY_GAIN = 0.08
AS_USE_ADAPTIVE_WEIGHTS = True
AS_ADAPTIVE_ALPHA_UNC = 0.30
AS_ADAPTIVE_ALPHA_SUPPORT = 0.25
AS_ADAPTIVE_ALPHA_GRAPH = 0.25
AS_ADAPTIVE_ALPHA_REPR = 0.20
AS_ADAPTIVE_ALPHA_DEP = 0.20
AS_ADAPTIVE_FACTOR_MIN = 0.80
AS_ADAPTIVE_FACTOR_MAX = 1.20
AS_PRESSURE_NEUTRAL = 0.50
# -----------------------------
# FINAL6 EXTENSION FLAGS
# -----------------------------
USE_HYDRO_LIMG = True
USE_LOCAL_GRAPH_LEVEL = True
USE_VALIDATION_GAIN = True
USE_MULTI_OVERLAP_PENALTY = True
USE_REMOVE_RISK_SAFEGUARD = True

# candidate-score fusion
CAND_W_AS = 0.40
CAND_W_LIMG = 0.40
CAND_W_VALID = 0.20

# local graph level
LIMG_LOCAL_K = 8

# validation gain
VALID_GAIN_RADIUS_FACTOR = 1.10
VALID_GAIN_HIGH_ERR_Q = 0.75

# greedy overlap penalties
GREEDY_PEN_W_SPATIAL = 0.45
GREEDY_PEN_W_GRAPH = 0.30
GREEDY_PEN_W_SIGNAL = 0.25

# remove-risk safeguard
REMOVE_RISK_LOO_Q = 0.75
REMOVE_RISK_GRAPH_THR = 0.75
REMOVE_RISK_CHL_THR = 0.80
# -----------------------------
# AQUIFER RELIABILITY SETTINGS
# -----------------------------
AQUIFER_RELIABILITY_MIN_N = 5
AQUIFER_RELIABILITY_FULL_N = 20
AQUIFER_RELIABILITY_MIN = 0.35
TREND_IMBALANCE_SOFTEN_MAX = 0.35
TREND_IMBALANCE_UNC_BOOST = 0.15
DEPTH_KDE_MIN_BW = 1.0
DEPTH_KDE_RANGE_FRACTION = 0.12
CHL_SOFT_RELIABILITY_STRENGTH = 0.35
CHL_SOFT_RELIABILITY_UNC_EXTRA = 0.08
# -----------------------------
# WEIGHT BALANCING / OVERCOUNT CONTROL
# -----------------------------
ENTROPY_GLOBAL_BLEND = 0.50
NETWORK_FAMILY_MAX_WEIGHT = 0.36
NETWORK_FAMILY_KEYS = ["information", "dependency", "graph_role"]
INFO_VS_DISTANCE_DEOVERCOUNT_STRENGTH = 0.10
DEP_VS_BACKBONE_DEOVERCOUNT_STRENGTH = 0.34
GRAPH_VS_BACKBONE_DEOVERCOUNT_STRENGTH = 0.30
INFO_OVERLAP_UNC_BOOST = 0.04
DEP_OVERLAP_UNC_BOOST = 0.09
GRAPH_OVERLAP_UNC_BOOST = 0.08
# -----------------------------
# SOFT CLUSTER KEEP SETTINGS
# -----------------------------
SECOND_KEEP_UTILITY_GAP = 0.10
SECOND_KEEP_MIN_UTILITY = 0.64
SECOND_KEEP_MIN_INFO = 0.56
SECOND_KEEP_MIN_GRAPH = 0.56
SECOND_KEEP_MIN_CLUSTER_N = 3
SECOND_KEEP_MIN_EXTENT_RATIO = 1.20
SECOND_KEEP_MIN_HETEROGENEITY = 0.10
SECOND_KEEP_SOFT_KEEP_FLOOR = 0.58
SECOND_KEEP_SOFT_REVIEW_FLOOR = 0.46
SECOND_KEEP_STABILITY_UNC_PENALTY = 0.22
SECOND_KEEP_STABILITY_GRAPH_BONUS = 0.06
SECOND_KEEP_STABILITY_INFO_BONUS = 0.04
# -----------------------------
# SMALL CLUSTER STABILIZATION
# -----------------------------
SMALL_CLUSTER_BLEND_RULE = {
    2: 0.75, 3: 0.60, 4: 0.40,
}
# -----------------------------
# DECISION CALIBRATION SETTINGS
# -----------------------------
DECISION_AMBIG_MARGIN = 0.12
DECISION_AMBIG_UNCERTAINTY = 0.42
DECISION_KEEP_PROB_MIN = 0.42
DECISION_KEEP_UTILITY_MIN = 0.50
DECISION_KEEP_STRUCTURAL_MIN = 0.52
DECISION_REMOVE_PROB_MIN = 0.46
DECISION_REMOVE_UTILITY_MAX = 0.50
DECISION_REMOVE_STRUCTURAL_MAX = 0.46
DECISION_REMOVE_DISTANCE_MAX = 0.48
DECISION_REMOVE_UNCERTAINTY_MAX = 0.42
# -----------------------------
# HARD FINAL RESOLVER SETTINGS (REVISED - evidence consensus voting)
# -----------------------------
HARD_RESOLVE_KEEP_PK_MIN = 0.50
HARD_RESOLVE_KEEP_UTIL_MIN = 0.52
HARD_RESOLVE_KEEP_STRUCTURAL_MIN = 0.54
HARD_RESOLVE_KEEP_STABILITY_MIN = 0.58
HARD_RESOLVE_REMOVE_PREM_MIN = 0.52
HARD_RESOLVE_REMOVE_UTIL_MAX = 0.48
HARD_RESOLVE_REMOVE_STRUCTURAL_MAX = 0.46
HARD_RESOLVE_REMOVE_STABILITY_MAX = 0.50
HARD_RESOLVE_REMOVE_UNCERTAINTY_MAX = 0.44
HARD_RESOLVE_MIN_KEEP_VOTES = 2
HARD_RESOLVE_MIN_REMOVE_VOTES = 3
HARD_RESOLVE_CONSERVATIVE_TIE_TO_KEEP = True
# -----------------------------
# SAFEGUARD SETTINGS
# -----------------------------
SAFEGUARD_KEEP_MIN_PROB = 0.30
SAFEGUARD_KEEP_MIN_UTILITY = 0.52
SAFEGUARD_KEEP_MIN_EVIDENCE = 0.42
SAFEGUARD_REVIEW_LABEL = "policy_review_only"
# ============================================================
# HELPERS (unchanged)
# ============================================================
def canon_text(x) -> str:
    if x is None:
        return "unknown"
    s = str(x).strip()
    s = " ".join(s.split())
    return s if s else "unknown"
CONFINEMENT_LABELS_CANON = {canon_text(x) for x in CONFINEMENT_LABELS}
def mode_nonnull(series: pd.Series):
    s = series.dropna()
    if s.empty:
        return np.nan
    m = s.mode()
    return m.iloc[0] if len(m) else s.iloc[0]
def round_to(x: float, step: float) -> float:
    if not np.isfinite(x):
        return x
    return float(round(x / step) * step)
def mad(x: np.ndarray) -> float:
    x = np.array(x, dtype=float)
    x = x[np.isfinite(x)]
    if x.size == 0:
        return np.nan
    med = np.median(x)
    return float(np.median(np.abs(x - med)))
def _clip01(x):
    return np.clip(np.asarray(x, dtype=float), 0.0, 1.0)
def _safe_col(df: pd.DataFrame, col: str) -> bool:
    return (col is not None) and (col in df.columns)
def _normalize(v: np.ndarray, fallback: float = 0.5) -> np.ndarray:
    v = np.asarray(v, dtype=float)
    mask = np.isfinite(v)
    out = np.full(v.shape, fallback, dtype=float)
    if mask.sum() == 0:
        return out
    lo = np.nanmin(v[mask])
    hi = np.nanmax(v[mask])
    if not np.isfinite(lo) or not np.isfinite(hi) or hi <= lo:
        out[mask] = fallback
        return out
    out[mask] = (v[mask] - lo) / (hi - lo)
    return out
def _minmax_norm_arr(a: np.ndarray) -> np.ndarray:
    a = np.asarray(a, dtype=float)
    ok = np.isfinite(a)
    if not ok.any():
        return np.full_like(a, 0.5, dtype=float)
    lo = float(np.nanmin(a[ok]))
    hi = float(np.nanmax(a[ok]))
    if (not np.isfinite(lo)) or (not np.isfinite(hi)) or hi <= lo:
        return np.full_like(a, 0.5, dtype=float)
    out = (a - lo) / (hi - lo)
    out = np.clip(out, 0, 1)
    out[~ok] = 0.5
    return out
def _sigmoid(z):
    z = np.asarray(z, dtype=float)
    return 1.0 / (1.0 + np.exp(-z))
def _sym_rescale(a: np.ndarray, fallback: float = 0.0) -> np.ndarray:
    a = np.asarray(a, dtype=float)
    ok = np.isfinite(a)
    out = np.full(a.shape, fallback, dtype=float)
    if not ok.any():
        return out
    mx = float(np.nanmax(np.abs(a[ok])))
    if (not np.isfinite(mx)) or mx <= 0:
        out[ok] = fallback
        return out
    out[ok] = np.clip(a[ok] / mx, -1.0, 1.0)
    return out
def deovercount_score_against_reference(
    score: np.ndarray, reference: np.ndarray, strength: float,
) -> np.ndarray:
    s = np.asarray(score, dtype=float)
    r = np.asarray(reference, dtype=float)
    resid = _sym_rescale(s - r, fallback=0.0)
    resid_score = np.clip(0.5 + 0.5 * resid, 0, 1)
    out = (1.0 - strength) * s + strength * resid_score
    return np.clip(out, 0, 1)
def boost_uncertainty_from_overlap(
    score: np.ndarray, reference: np.ndarray, unc: np.ndarray, max_boost: float,
) -> np.ndarray:
    s = np.asarray(score, dtype=float)
    r = np.asarray(reference, dtype=float)
    u = np.asarray(unc, dtype=float)
    similarity = 1.0 - np.abs(s - r)
    similarity = np.clip(similarity, 0, 1)
    return np.clip(u + max_boost * similarity, 0, 1)
def final_label_from_probs(pk: float, pr: float, prem: float) -> str:
    vals = {"KEEP": pk, "REVIEW": pr, "CANDIDATE_REMOVE": prem}
    return max(vals, key=vals.get)
def confidence_class(pk: float, pr: float, prem: float) -> str:
    mx = max(pk, pr, prem)
    if mx >= 0.85:
        return "HIGH"
    if mx >= 0.65:
        return "MEDIUM"
    return "LOW"
def pipe_join(values, fmt=None):
    if values is None or len(values) == 0:
        return ""
    out = []
    for v in values:
        if pd.isna(v):
            out.append("")
        else:
            out.append(fmt(v) if fmt else str(v))
    return "|".join(out)
def write_points_output(gdf: gpd.GeoDataFrame, name: str, layer_name: str = "wells"):
    if WRITE_GPKG_INSTEAD_OF_SHP:
        out_path = os.path.join(OUT_DIR, f"{name}.gpkg")
        gdf.to_file(out_path, layer=layer_name, driver="GPKG")
    else:
        out_path = os.path.join(OUT_DIR, f"{name}.shp")
        gdf.to_file(out_path, index=False)
def write_edges_output(gdf: gpd.GeoDataFrame, name: str, layer_name: str = "edges"):
    if WRITE_GPKG_INSTEAD_OF_SHP:
        out_path = os.path.join(OUT_DIR, f"{name}.gpkg")
        gdf.to_file(out_path, layer=layer_name, driver="GPKG")
    else:
        out_path = os.path.join(OUT_DIR, f"{name}.shp")
        gdf.to_file(out_path, index=False)
def rank_aggregate_per_sid(series: pd.Series) -> str:
    s = series.astype(str).str.strip().str.upper()
    if (s == "CRITICAL").any():
        return "CRITICAL"
    if (s == "SUPPORTS").any():
        return "SUPPORTS"
    return "unknown"
def is_confinement_label(wb_label: str) -> bool:
    return canon_text(wb_label) in CONFINEMENT_LABELS_CANON
def aquifer_group_from_waterbod1(wb_label: str) -> str:
    s = canon_text(wb_label)
    if s == "Surficial aquifer":
        return "surficial"
    hawthorn_set = {
        "Hawthorn aquifer system (former Intermediate)",
        "Peace River aquifer (former zone 1)",
        "Upper Arcadia aquifer (former zone 2)",
        "Lower Arcadia aquifer (former zone 3)",
    }
    if s in hawthorn_set:
        if not SPLIT_HAWTHORN:
            return "hawthorn"
        if s == "Peace River aquifer (former zone 1)":
            return "peace river"
        if s == "Upper Arcadia aquifer (former zone 2)":
            return "upper arcadia"
        if s == "Lower Arcadia aquifer (former zone 3)":
            return "lower arcadia"
        return "hawthorn (unclassified)"
    floridan_set = {
        "Upper Floridan aquifer",
        "Avon Park high-permeability zone",
        "Ocala low-permeability zone",
        "Floridan aquifer system",
    }
    if s in floridan_set:
        return "upper floridan"
    return "unknown"
def collapse_to_unique_sid_keep_all(gdf: gpd.GeoDataFrame, sid_col: str) -> gpd.GeoDataFrame:
    df = gdf.copy()
    agg: Dict[str, Any] = {}
    for c in df.columns:
        if c in ["geometry", sid_col]:
            continue
        if pd.api.types.is_numeric_dtype(df[c]):
            agg[c] = "median"
        else:
            agg[c] = mode_nonnull
    df2 = pd.DataFrame(df.drop(columns="geometry"))
    df2["geometry"] = df.geometry
    collapsed = (
        df2.groupby(sid_col, dropna=False)
        .agg({**agg, "geometry": "first"})
        .reset_index()
    )
    out = gpd.GeoDataFrame(collapsed, geometry="geometry", crs=gdf.crs)
    out = out[out[sid_col].notna()].copy()
    return out
def aquifer_reliability_from_n(n: int) -> float:
    if n <= AQUIFER_RELIABILITY_MIN_N:
        return float(AQUIFER_RELIABILITY_MIN)
    if n >= AQUIFER_RELIABILITY_FULL_N:
        return 1.0
    frac = (n - AQUIFER_RELIABILITY_MIN_N) / max(AQUIFER_RELIABILITY_FULL_N - AQUIFER_RELIABILITY_MIN_N, 1)
    return float(AQUIFER_RELIABILITY_MIN + frac * (1.0 - AQUIFER_RELIABILITY_MIN))
def shrink_score_to_neutral(score: np.ndarray, reliability: float) -> np.ndarray:
    s = np.asarray(score, dtype=float)
    return np.clip(0.5 + reliability * (s - 0.5), 0, 1)
def soften_observed_signal_to_neutral(score: np.ndarray, reliability: float, strength: float = 0.35) -> np.ndarray:
    s = np.asarray(score, dtype=float)
    eff_rel = 1.0 - strength * (1.0 - float(reliability))
    return np.clip(0.5 + eff_rel * (s - 0.5), 0, 1)
def inflate_uncertainty(unc: np.ndarray, reliability: float, extra: float = 0.20) -> np.ndarray:
    u = np.asarray(unc, dtype=float)
    return np.clip(u + (1.0 - reliability) * extra, 0, 1)
def _group_positions(series_like) -> Dict[Any, np.ndarray]:
    s = pd.Series(series_like).reset_index(drop=True)
    groups = s.groupby(s, sort=False).groups
    out: Dict[Any, np.ndarray] = {}
    for grp, idx in groups.items():
        out[grp] = np.asarray(list(idx), dtype=int)
    return out
def apply_aquifer_reliability_adjustment(
    df: pd.DataFrame, score: np.ndarray, unc: np.ndarray, score_name: str = "", unc_extra: float = 0.18,
) -> Tuple[np.ndarray, np.ndarray]:
    out_score = np.asarray(score, dtype=float).copy()
    out_unc = np.asarray(unc, dtype=float).copy()
    aq_groups = _group_positions(df["Aquifer_group"].astype(str))
    for _, idx in aq_groups.items():
        rel = aquifer_reliability_from_n(len(idx))
        out_score[idx] = shrink_score_to_neutral(out_score[idx], rel)
        out_unc[idx] = inflate_uncertainty(out_unc[idx], rel, extra=unc_extra)
    return np.clip(out_score, 0, 1), np.clip(out_unc, 0, 1)
def robust_bandwidth_1d(x: np.ndarray) -> float:
    x = np.asarray(x, dtype=float)
    x = x[np.isfinite(x)]
    if x.size <= 1:
        return DEPTH_KDE_MIN_BW
    sd = float(np.nanstd(x, ddof=1)) if x.size > 1 else 0.0
    q75, q25 = np.nanpercentile(x, [75, 25])
    iqr = float(q75 - q25)
    scale = min(sd if np.isfinite(sd) and sd > 0 else np.inf, iqr / 1.34 if iqr > 0 else np.inf)
    if (not np.isfinite(scale)) or scale <= 0:
        xr = float(np.nanmax(x) - np.nanmin(x))
        scale = max(DEPTH_KDE_MIN_BW, DEPTH_KDE_RANGE_FRACTION * xr, 1.0)
    bw = 0.9 * scale * (x.size ** (-1.0 / 5.0))
    if (not np.isfinite(bw)) or bw <= 0:
        xr = float(np.nanmax(x) - np.nanmin(x))
        bw = max(DEPTH_KDE_MIN_BW, DEPTH_KDE_RANGE_FRACTION * xr, 1.0)
    return float(max(bw, DEPTH_KDE_MIN_BW))
def local_gaussian_density_1d(x: np.ndarray, bw: float) -> np.ndarray:
    x = np.asarray(x, dtype=float)
    if x.size == 0:
        return np.array([], dtype=float)
    z = (x[:, None] - x[None, :]) / max(bw, 1e-9)
    ker = np.exp(-0.5 * z * z)
    dens = np.mean(ker, axis=1)
    return np.asarray(dens, dtype=float)
def small_cluster_score_blend(raw_score: np.ndarray, norm_score: np.ndarray, cluster_n: int) -> np.ndarray:
    raw_score = np.clip(np.asarray(raw_score, dtype=float), 0, 1)
    norm_score = np.clip(np.asarray(norm_score, dtype=float), 0, 1)
    raw_w = SMALL_CLUSTER_BLEND_RULE.get(int(cluster_n), 0.0)
    if raw_w <= 0:
        return norm_score
    return np.clip(raw_w * raw_score + (1.0 - raw_w) * norm_score, 0, 1)
def mean_component_uncertainty_for_idx(df: pd.DataFrame, idx: int) -> float:
    cols = [
        "P_keep_information_unc", "P_keep_dependency_unc", "P_keep_graph_role_unc",
        "P_keep_distance_unc", "P_keep_joint_quality_unc",
    ]
    vals = []
    for c in cols:
        if c in df.columns:
            v = pd.to_numeric(pd.Series([df.loc[idx, c]]), errors="coerce").iloc[0]
            if pd.notna(v):
                vals.append(float(v))
    if len(vals) == 0:
        return 0.5
    return float(np.clip(np.mean(vals), 0, 1))
def second_anchor_stability_score(df: pd.DataFrame, idx: int) -> float:
    util = float(df.loc[idx, "UtilityDeterministic_keep"])
    graph = float(df.loc[idx, "P_keep_graph_role_base"])
    info = float(df.loc[idx, "P_keep_information_base"])
    unc = mean_component_uncertainty_for_idx(df, idx)
    score = (
        util
        - SECOND_KEEP_STABILITY_UNC_PENALTY * unc
        + SECOND_KEEP_STABILITY_GRAPH_BONUS * graph
        + SECOND_KEEP_STABILITY_INFO_BONUS * info
    )
    return float(score)
class UnionFind:
    def __init__(self, n: int):
        self.parent = list(range(n))
        self.rank = [0] * n
    def find(self, a: int) -> int:
        while self.parent[a] != a:
            self.parent[a] = self.parent[self.parent[a]]
            a = self.parent[a]
        return a
    def union(self, a: int, b: int) -> None:
        ra, rb = self.find(a), self.find(b)
        if ra == rb:
            return
        if self.rank[ra] < self.rank[rb]:
            self.parent[ra] = rb
        elif self.rank[ra] > self.rank[rb]:
            self.parent[rb] = ra
        else:
            self.parent[rb] = ra
            self.rank[ra] += 1
    def components(self):
        roots: Dict[int, List[int]] = {}
        for i in range(len(self.parent)):
            r = self.find(i)
            roots.setdefault(r, []).append(i)
        return list(roots.values())
def mst_edges_from_points(coords_xy: np.ndarray):
    # R1 [C1]: complete-graph MST (co-located wells at multi-depth sites keep their zero-length edge)
    if R1["FIX_MST"]:
        return _mst_edges_complete(coords_xy)
    return _mst_edges_delaunay_original(coords_xy)


def _mst_edges_complete(coords_xy: np.ndarray):
    xy = np.asarray(coords_xy, dtype=float)
    n = xy.shape[0]
    if n <= 1:
        return []
    D = np.sqrt(((xy[:, None, :] - xy[None, :, :]) ** 2).sum(-1))
    W = np.where(D > 0, D, 1e-3)          # csgraph treats 0 as "no edge": zero distances become 1 mm
    np.fill_diagonal(W, 0.0)
    T = minimum_spanning_tree(W).tocoo()
    return [(int(min(i, j)), int(max(i, j)), float(D[i, j])) for i, j in zip(T.row, T.col)]


def _mst_edges_delaunay_original(coords_xy: np.ndarray):
    n = coords_xy.shape[0]
    if n <= 1:
        return []
    if n == 2:
        d = float(np.linalg.norm(coords_xy[1] - coords_xy[0]))
        return [(0, 1, d)]
    try:
        tri = Delaunay(coords_xy)
        edges = set()
        for simplex in tri.simplices:
            a, b, c = simplex
            edges.add(tuple(sorted((a, b))))
            edges.add(tuple(sorted((b, c))))
            edges.add(tuple(sorted((a, c))))
        I, J, Ww = [], [], []
        for i, j in edges:
            d = float(np.linalg.norm(coords_xy[j] - coords_xy[i]))
            I.append(i); J.append(j); Ww.append(d)
            I.append(j); J.append(i); Ww.append(d)
        G = coo_matrix((Ww, (I, J)), shape=(n, n)).tocsr()
        mst = minimum_spanning_tree(G)
        coo = mst.tocoo()
        return [(int(i), int(j), float(d)) for i, j, d in zip(coo.row, coo.col, coo.data)]
    except Exception:
        tree = cKDTree(coords_xy)
        k = min(11, n)
        _, idxs = tree.query(coords_xy, k=k)
        edges = set()
        for i in range(n):
            for t in range(1, k):
                j = int(idxs[i, t])
                if j == i:
                    continue
                a, b = (i, j) if i < j else (j, i)
                edges.add((a, b))
        I, J, Ww = [], [], []
        for i, j in edges:
            d = float(np.linalg.norm(coords_xy[j] - coords_xy[i]))
            I.append(i); J.append(j); Ww.append(d)
            I.append(j); J.append(i); Ww.append(d)
        G = coo_matrix((Ww, (I, J)), shape=(n, n)).tocsr()
        mst = minimum_spanning_tree(G)
        coo = mst.tocoo()
        return [(int(i), int(j), float(d)) for i, j, d in zip(coo.row, coo.col, coo.data)]
def mst_cut_threshold(mst_dists: np.ndarray):
    d = np.array(mst_dists, dtype=float)
    d = d[np.isfinite(d) & (d > 0)]
    if d.size == 0:
        return np.nan, {"note": "mst_empty"}
    if CUT_RULE == "p95":
        t = float(np.quantile(d, 0.95))
        return t, {"cut_rule": "p95", "cut_value": t}
    medv = float(np.median(d))
    madv = mad(d)
    if not np.isfinite(madv) or madv == 0:
        t = float(np.quantile(d, 0.95))
        return t, {"cut_rule": "median_plus_mad_fallback_p95", "cut_value": t, "median": medv, "mad": madv}
    t = float(medv + MAD_MULT * madv)
    return t, {"cut_rule": f"median_plus_{MAD_MULT}mad", "cut_value": t, "median": medv, "mad": float(madv)}
def nearest_neighbor_distances(coords_xy: np.ndarray) -> np.ndarray:
    n = coords_xy.shape[0]
    if n <= 1:
        return np.array([np.nan] * n, dtype=float)
    tree = cKDTree(coords_xy)
    d, _ = tree.query(coords_xy, k=2)
    return d[:, 1].astype(float)
def pairwise_distance_matrix(coords_xy: np.ndarray) -> np.ndarray:
    coords_xy = np.asarray(coords_xy, dtype=float)
    diff = coords_xy[:, None, :] - coords_xy[None, :, :]
    return np.sqrt(np.sum(diff * diff, axis=2))
def pairwise_feature_similarity(features: np.ndarray) -> np.ndarray:
    features = np.asarray(features, dtype=float)
    diff = features[:, None, :] - features[None, :, :]
    dist = np.sqrt(np.sum(diff * diff, axis=2) / max(features.shape[1], 1))
    sim = np.exp(-dist / max(INFO_SIM_DECAY, 1e-6))
    np.fill_diagonal(sim, 0.0)
    return np.clip(sim, 0, 1)
def weighted_mean_excluding_self(weight_mat: np.ndarray, value_mat: np.ndarray) -> np.ndarray:
    num = np.sum(weight_mat * value_mat, axis=1)
    den = np.sum(weight_mat, axis=1)
    out = np.full(weight_mat.shape[0], 0.5, dtype=float)
    ok = den > 0
    out[ok] = num[ok] / den[ok]
    return np.clip(out, 0, 1)
def top_n_reason_labels(score_dict: Dict[str, float], n: int = 3, descending: bool = True) -> List[str]:
    items = [(k, float(v)) for k, v in score_dict.items() if np.isfinite(v)]
    items = sorted(items, key=lambda x: x[1], reverse=descending)
    return [k for k, _ in items[:n]]
def entropy_weights_from_matrix(comps: pd.DataFrame) -> Dict[str, float]:
    X = comps.to_numpy(dtype=float)
    col_sums = X.sum(axis=0)
    col_sums[col_sums == 0] = 1.0
    P = X / col_sums
    n = X.shape[0]
    keys = list(comps.columns)
    if n <= 1:
        return {k: 1.0 / len(keys) for k in keys}
    k_const = 1.0 / math.log(n)
    entropy = -k_const * np.nansum(P * np.log(P + 1e-12), axis=0)
    diversity = 1.0 - entropy
    if "joint_quality" in keys:
        j = keys.index("joint_quality")
        diversity[j] = diversity[j] + JOINT_QUALITY_WEIGHT
    if np.isclose(diversity.sum(), 0.0):
        weights = np.repeat(1.0 / len(keys), len(keys))
    else:
        weights = diversity / diversity.sum()
    return {k: float(v) for k, v in zip(keys, weights)}
def cap_network_family_weights(weights: Dict[str, float]) -> Dict[str, float]:
    w = {k: float(v) for k, v in weights.items()}
    fam_sum = sum(w.get(k, 0.0) for k in NETWORK_FAMILY_KEYS)
    if fam_sum <= NETWORK_FAMILY_MAX_WEIGHT + 1e-12:
        s = sum(w.values())
        return {k: v / s for k, v in w.items()} if s > 0 else w
    excess = fam_sum - NETWORK_FAMILY_MAX_WEIGHT
    if fam_sum > 0:
        scale = NETWORK_FAMILY_MAX_WEIGHT / fam_sum
        for k in NETWORK_FAMILY_KEYS:
            w[k] = w.get(k, 0.0) * scale
    nonfam = [k for k in w.keys() if k not in NETWORK_FAMILY_KEYS]
    nonfam_sum = sum(w[k] for k in nonfam)
    if nonfam_sum > 0:
        for k in nonfam:
            w[k] += excess * (w[k] / nonfam_sum)
    else:
        add = excess / max(len(nonfam), 1)
        for k in nonfam:
            w[k] += add
    total = sum(w.values())
    if total <= 0:
        return {k: 1.0 / len(w) for k in w}
    return {k: v / total for k, v in w.items()}
def _renormalize_weight_dict(weights: Dict[str, float]) -> Dict[str, float]:
    w = {k: max(float(v), 0.0) for k, v in weights.items()}
    s = sum(w.values())
    if s <= 0:
        n = max(len(w), 1)
        return {k: 1.0 / n for k in w}
    return {k: v / s for k, v in w.items()}
def stabilize_component_weights(
    weights: Dict[str, float],
    min_component_weight: float = MIN_COMPONENT_WEIGHT,
    max_joint_quality_weight: float = MAX_JOINT_QUALITY_WEIGHT,
) -> Dict[str, float]:
    w = _renormalize_weight_dict(weights)
    if "joint_quality" in w and w["joint_quality"] > max_joint_quality_weight:
        excess = w["joint_quality"] - max_joint_quality_weight
        w["joint_quality"] = max_joint_quality_weight
        recips = [k for k in w.keys() if k != "joint_quality"]
        recip_sum = sum(w[k] for k in recips)
        if recip_sum > 0:
            for k in recips:
                w[k] += excess * (w[k] / recip_sum)
        else:
            add = excess / max(len(recips), 1)
            for k in recips:
                w[k] += add
    w = _renormalize_weight_dict(w)
    for _ in range(10):
        below = [k for k, v in w.items() if v < min_component_weight]
        if len(below) == 0:
            break
        deficits = {k: (min_component_weight - w[k]) for k in below}
        total_need = sum(deficits.values())
        donors = [k for k, v in w.items() if (k not in below) and (v > min_component_weight)]
        donor_margin = sum(w[k] - min_component_weight for k in donors)
        if donor_margin <= 0:
            break
        take = min(total_need, donor_margin)
        for k in donors:
            margin = w[k] - min_component_weight
            delta = take * (margin / donor_margin)
            w[k] -= delta
        if total_need > 0:
            for k in below:
                w[k] += take * (deficits[k] / total_need)
        w = _renormalize_weight_dict(w)
    if "joint_quality" in w and w["joint_quality"] > max_joint_quality_weight:
        excess = w["joint_quality"] - max_joint_quality_weight
        w["joint_quality"] = max_joint_quality_weight
        recips = [k for k in w.keys() if k != "joint_quality"]
        recip_sum = sum(w[k] for k in recips)
        if recip_sum > 0:
            for k in recips:
                w[k] += excess * (w[k] / recip_sum)
        else:
            add = excess / max(len(recips), 1)
            for k in recips:
                w[k] += add
    w = _renormalize_weight_dict(w)
    return _renormalize_weight_dict(w)
def stabilize_entropy_weights(weights: Dict[str, float]) -> Dict[str, float]:
    w = {k: float(v) for k, v in weights.items()}
    for _ in range(WEIGHT_STABILIZATION_PASSES):
        w = cap_network_family_weights(w)
        w = stabilize_component_weights(
            w, min_component_weight=MIN_COMPONENT_WEIGHT, max_joint_quality_weight=MAX_JOINT_QUALITY_WEIGHT
        )
    return _renormalize_weight_dict(w)
def dissolve_geoms(geoseries):
    try:
        return geoseries.union_all()
    except Exception:
        try:
            return geoseries.unary_union
        except Exception:
            return None
def cluster_pairwise_max_distance(coords: np.ndarray) -> float:
    if len(coords) <= 1:
        return 0.0
    dmat = pairwise_distance_matrix(coords)
    return float(np.nanmax(dmat))
def alpha_shape_polygon(points_xy: np.ndarray, alpha_radius: float):
    pts = np.asarray(points_xy, dtype=float)
    if len(pts) == 0:
        return None
    if len(pts) < 4:
        return MultiPoint([Point(xy) for xy in pts]).convex_hull
    try:
        tri = Delaunay(pts)
    except Exception:
        return MultiPoint([Point(xy) for xy in pts]).convex_hull
    edges = set()
    for simplex in tri.simplices:
        pa, pb, pc = pts[simplex[0]], pts[simplex[1]], pts[simplex[2]]
        a = float(np.linalg.norm(pb - pc))
        b = float(np.linalg.norm(pa - pc))
        c = float(np.linalg.norm(pa - pb))
        s = 0.5 * (a + b + c)
        area_sq = s * (s - a) * (s - b) * (s - c)
        if area_sq <= 0:
            continue
        area = math.sqrt(area_sq)
        circum_r = (a * b * c) / max(4.0 * area, 1e-12)
        if circum_r <= alpha_radius:
            i, j, k = simplex
            edges.add(tuple(sorted((int(i), int(j)))))
            edges.add(tuple(sorted((int(j), int(k)))))
            edges.add(tuple(sorted((int(i), int(k)))))
    if len(edges) == 0:
        return MultiPoint([Point(xy) for xy in pts]).convex_hull
    edge_lines = [LineString([tuple(pts[i]), tuple(pts[j])]) for i, j in edges]
    polys = list(polygonize(edge_lines))
    if len(polys) == 0:
        return MultiPoint([Point(xy) for xy in pts]).convex_hull
    try:
        geom = unary_union(polys)
    except Exception:
        geom = MultiPoint([Point(xy) for xy in pts]).convex_hull
    return geom
def _build_network_corridor_geometry(sub_comp: gpd.GeoDataFrame, ell_use: float):
    coords = np.column_stack([sub_comp.geometry.x.values, sub_comp.geometry.y.values])
    if len(coords) == 0:
        return None
    point_support_r = max(CAND_POINT_SUPPORT_FACTOR * ell_use, 1.0)
    point_support = dissolve_geoms(sub_comp.geometry.buffer(point_support_r))
    if len(coords) == 1:
        return point_support
    mst = mst_edges_from_points(coords)
    if len(mst) == 0:
        return point_support
    corridor_r = max(CAND_MST_CORRIDOR_FACTOR * ell_use, 1.0)
    segs = []
    for i, j, _ in mst:
        seg = LineString([tuple(coords[i]), tuple(coords[j])]).buffer(corridor_r)
        segs.append(seg)
    try:
        corridor = unary_union(segs)
    except Exception:
        corridor = point_support
    try:
        return corridor.union(point_support)
    except Exception:
        return point_support
def thin_candidates_by_spacing(
    cand: gpd.GeoDataFrame, min_spacing: float, score_col: str = "CandidateScore", max_keep: Optional[int] = None,
) -> gpd.GeoDataFrame:
    if len(cand) <= 1:
        return cand.copy()
    work = cand.sort_values(score_col, ascending=False).copy().reset_index(drop=True)
    coords = np.column_stack([work.geometry.x.values, work.geometry.y.values])
    kept = []
    for i in range(len(work)):
        if len(kept) == 0:
            kept.append(i)
        else:
            d = np.sqrt(np.sum((coords[kept] - coords[i]) ** 2, axis=1))
            if np.all(d >= min_spacing):
                kept.append(i)
        if (max_keep is not None) and (len(kept) >= max_keep):
            break
    out = work.iloc[kept].copy().reset_index(drop=True)
    return out
def _point_to_segment_distance(points: np.ndarray, a: np.ndarray, b: np.ndarray) -> np.ndarray:
    p = np.asarray(points, dtype=float)
    a = np.asarray(a, dtype=float)
    b = np.asarray(b, dtype=float)
    ab = b - a
    ab2 = float(np.dot(ab, ab))
    if ab2 <= 1e-12:
        return np.sqrt(np.sum((p - a[None, :]) ** 2, axis=1))
    ap = p - a[None, :]
    t = np.sum(ap * ab[None, :], axis=1) / ab2
    t = np.clip(t, 0.0, 1.0)
    proj = a[None, :] + t[:, None] * ab[None, :]
    return np.sqrt(np.sum((p - proj) ** 2, axis=1))
def _weighted_feature_dispersion(values: np.ndarray, weights: np.ndarray) -> np.ndarray:
    den = weights.sum(axis=1)
    out = np.full(weights.shape[0], 0.5, dtype=float)
    ok = den > 1e-12
    if not ok.any():
        return out
    mean_feat = (weights[ok, :] @ values) / den[ok][:, None]
    diff = np.abs(values[None, :, :] - mean_feat[:, None, :])
    mad = np.sum(weights[ok, :, None] * diff, axis=1) / den[ok][:, None]
    out[ok] = np.mean(mad, axis=1)
    return out
def _mst_bridge_gain(cand_coords: np.ndarray, ex_coords: np.ndarray, ell_use: float) -> Tuple[np.ndarray, np.ndarray]:
    n = ex_coords.shape[0]
    if n <= 1:
        return np.full(len(cand_coords), 0.5, dtype=float), np.full(len(cand_coords), np.nan, dtype=float)
    mst = mst_edges_from_points(ex_coords)
    if len(mst) == 0:
        return np.full(len(cand_coords), 0.5, dtype=float), np.full(len(cand_coords), np.nan, dtype=float)
    edge_lengths = np.array([e[2] for e in mst], dtype=float)
    edge_len_norm = _minmax_norm_arr(edge_lengths)
    raw = np.zeros(len(cand_coords), dtype=float)
    best_dist = np.full(len(cand_coords), np.inf, dtype=float)
    decay = max(CAND_BRIDGE_DECAY_FACTOR * ell_use, 1.0)
    for (edge_idx, (i, j, d)) in enumerate(mst):
        a = ex_coords[i]
        b = ex_coords[j]
        dist_seg = _point_to_segment_distance(cand_coords, a, b)
        best_dist = np.minimum(best_dist, dist_seg)
        proximity = np.exp(-dist_seg / decay)
        raw += edge_len_norm[edge_idx] * proximity
    raw = _minmax_norm_arr(raw)
    best_dist[~np.isfinite(best_dist)] = np.nan
    return raw, best_dist
# ============================================================
# COMPONENT SCORING (unchanged)
# ============================================================
def compute_chloride_keep(chl: pd.Series, aquifer: pd.Series = None, threshold: float = CHL_THRESHOLD) -> Tuple[np.ndarray, np.ndarray]:
    x = pd.to_numeric(pd.Series(chl).reset_index(drop=True), errors="coerce").to_numpy(dtype=float)
    out = np.full_like(x, 0.5, dtype=float)
    unc = np.full_like(x, 0.45, dtype=float)
    mask = np.isfinite(x)
    if mask.any():
        z = (threshold - x[mask]) / max(CHL_SIGMOID_SCALE, 1e-6)
        out[mask] = _sigmoid(z)
        dist = np.abs(x[mask] - threshold) / max(threshold, 1.0)
        unc[mask] = np.clip(0.55 - 0.35 * dist, 0.10, 0.55)
    if aquifer is not None:
        aq_groups = _group_positions(pd.Series(aquifer).astype(str))
        for _, idx in aq_groups.items():
            rel = aquifer_reliability_from_n(len(idx))
            out[idx] = soften_observed_signal_to_neutral(
                out[idx], rel, strength=CHL_SOFT_RELIABILITY_STRENGTH
            )
            unc[idx] = inflate_uncertainty(
                unc[idx], rel, extra=CHL_SOFT_RELIABILITY_UNC_EXTRA
            )
    return _clip01(out), _clip01(unc)
def compute_status_keep(status: pd.Series) -> Tuple[np.ndarray, np.ndarray]:
    vals = pd.Series(status).reset_index(drop=True).astype(str).str.strip().str.lower()
    base = np.full(len(vals), 0.55, dtype=float)
    unc = np.full(len(vals), 0.35, dtype=float)
    active_words = ["active", "operational", "monitor", "use", "sample"]
    bad_words = ["abandon", "destroy", "inactive", "retired", "plug", "remove"]
    unknown_words = ["unknown", "na", "none", "nan", ""]
    for i, s in enumerate(vals):
        if any(w in s for w in active_words):
            base[i] = 0.85
            unc[i] = 0.15
        elif any(w in s for w in bad_words):
            base[i] = 0.20
            unc[i] = 0.15
        elif any(w in s for w in unknown_words):
            base[i] = 0.50
            unc[i] = 0.50
        else:
            base[i] = 0.60
            unc[i] = 0.30
    return _clip01(base), _clip01(unc)
def _trend_label_from_text(s: str) -> str:
    s = str(s).strip().lower()
    up_words = ["inc", "increas", "up", "rise", "positive"]
    down_words = ["dec", "decreas", "down", "fall", "negative"]
    stable_words = ["stable", "flat", "no trend", "neutral"]
    if any(w in s for w in up_words):
        return "INCREASING"
    if any(w in s for w in down_words):
        return "DECREASING"
    if any(w in s for w in stable_words):
        return "STABLE"
    try:
        v = float(s)
        if v > 0:
            return "INCREASING"
        elif v < 0:
            return "DECREASING"
        else:
            return "STABLE"
    except Exception:
        return "UNKNOWN"
def compute_trend_keep(trend: pd.Series, aquifer: pd.Series = None) -> Tuple[np.ndarray, np.ndarray]:
    t_raw = pd.Series(trend).reset_index(drop=True).astype(str).str.strip().str.lower()
    base = np.full(len(t_raw), 0.55, dtype=float)
    unc = np.full(len(t_raw), 0.40, dtype=float)
    trend_class = np.array([_trend_label_from_text(s) for s in t_raw], dtype=object)
    for i, s in enumerate(t_raw):
        lab = trend_class[i]
        if lab == "INCREASING":                      # R1 [C2]: scores from R1["TREND_SCORES"]
            base[i] = R1["TREND_SCORES"]["INCREASING"]
            unc[i] = 0.15
        elif lab == "DECREASING":
            base[i] = R1["TREND_SCORES"]["DECREASING"]
            unc[i] = 0.15
        elif lab == "STABLE":
            base[i] = R1["TREND_SCORES"]["STABLE"]
            unc[i] = 0.20
        else:
            base[i] = 0.55
            unc[i] = 0.50
    if aquifer is not None:
        aq_groups = _group_positions(pd.Series(aquifer).astype(str))
        for _, idx in aq_groups.items():
            if len(idx) == 0:
                continue
            rel = aquifer_reliability_from_n(len(idx))
            counts = pd.Series(trend_class[idx]).value_counts()
            counts = counts[counts.index != "UNKNOWN"]
            if counts.sum() > 0:
                dominance = float(counts.max() / counts.sum())
            else:
                dominance = 1.0
            imbalance = np.clip((dominance - 0.60) / 0.40, 0.0, 1.0)
            soften = TREND_IMBALANCE_SOFTEN_MAX * imbalance * (1.0 - 0.3 * rel)
            base[idx] = 0.5 + (base[idx] - 0.5) * (1.0 - soften)
            unc[idx] = np.clip(unc[idx] + TREND_IMBALANCE_UNC_BOOST * imbalance, 0, 1)
            base[idx] = shrink_score_to_neutral(base[idx], rel)
            unc[idx] = inflate_uncertainty(unc[idx], rel, extra=0.14)
    return _clip01(base), _clip01(unc)
def compute_depth_keep(depth: pd.Series, aquifer: pd.Series) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    d = pd.to_numeric(pd.Series(depth).reset_index(drop=True), errors="coerce")
    d = d.mask(d <= 0, np.nan)
    wb = pd.Series(aquifer).reset_index(drop=True).astype(str)
    missing_flag = d.isna().to_numpy(dtype=int)
    d_fill = d.copy()
    wb_groups = _group_positions(wb)
    for _, idx in wb_groups.items():
        med = d.iloc[idx].median()
        if pd.isna(med):
            med = d.median()
        if pd.isna(med):
            med = 0.0
        d_fill.iloc[idx] = d_fill.iloc[idx].fillna(med)
    base = np.full(len(d_fill), 0.5, dtype=float)
    unc = np.full(len(d_fill), 0.25, dtype=float)
    for _, idx in wb_groups.items():
        vals_raw = d.iloc[idx].to_numpy(dtype=float)
        vals = d_fill.iloc[idx].to_numpy(dtype=float)
        n_valid = int(np.isfinite(vals_raw).sum())
        rel = aquifer_reliability_from_n(len(idx))
        if n_valid < DEPTH_MIN_VALID_PER_AQUIFER:
            base[idx] = 0.55
            base[idx] = shrink_score_to_neutral(base[idx], rel)
            unc[idx] = np.where(missing_flag[idx] == 1, 0.50, 0.35)
            unc[idx] = inflate_uncertainty(unc[idx], rel, extra=0.15)
            continue
        bw = robust_bandwidth_1d(vals[np.isfinite(vals)])
        dens = local_gaussian_density_1d(vals, bw=bw)
        dens_n = _minmax_norm_arr(dens)
        rarity = 1.0 - dens_n
        depth_score = 0.35 + 0.55 * rarity
        if missing_flag[idx].sum() > 0:
            depth_score = np.where(
                missing_flag[idx] == 1,
                0.5 + 0.50 * (depth_score - 0.5),
                depth_score
            )
        depth_score = shrink_score_to_neutral(depth_score, rel)
        depth_unc = np.where(missing_flag[idx] == 1, 0.45, 0.20)
        depth_unc = inflate_uncertainty(depth_unc, rel, extra=0.15)
        base[idx] = np.clip(depth_score, 0, 1)
        unc[idx] = np.clip(depth_unc, 0, 1)
    return _clip01(base), _clip01(unc), missing_flag
def build_feature_columns(
    df: pd.DataFrame, p_chl_base: np.ndarray, p_trend_base: np.ndarray, p_status_base: np.ndarray,
) -> pd.DataFrame:
    out = df.copy()
    if COL_CHL in out.columns:
        chl_raw = pd.to_numeric(out[COL_CHL], errors="coerce").to_numpy(dtype=float)
        out["Feat_chl_norm"] = _minmax_norm_arr(chl_raw)
    else:
        out["Feat_chl_norm"] = 0.5
    out["Feat_trend_norm"] = _clip01(p_trend_base)
    out["Feat_status_norm"] = _clip01(p_status_base)
    depth_raw = pd.to_numeric(out[COL_DEPTH], errors="coerce") if COL_DEPTH in out.columns else pd.Series(np.nan, index=out.index)
    depth_raw = depth_raw.mask(depth_raw <= 0, np.nan)
    out["Feat_depth_norm"] = 0.5
    for aq, idx in out.groupby("Aquifer_group").groups.items():
        vals = pd.to_numeric(depth_raw.loc[idx], errors="coerce").to_numpy(dtype=float)
        if np.isfinite(vals).any():
            med = np.nanmedian(vals)
            vals = np.where(np.isfinite(vals), vals, med)
            out.loc[idx, "Feat_depth_norm"] = _minmax_norm_arr(vals)
    out["Feat_quality_norm"] = _clip01(p_chl_base)
    return out
def score_distance_keep_clusterwise(df: pd.DataFrame) -> Tuple[np.ndarray, np.ndarray]:
    n = len(df)
    out = np.full(n, 0.5, dtype=float)
    unc = np.full(n, 0.25, dtype=float)
    iso = df["Isolated_within_Ell"].fillna(False).astype(bool).to_numpy()
    aq_arr = df["Aquifer_group"].astype(str).str.strip().str.lower().to_numpy()
    rid_arr = df["Redundancy_cluster_id"].fillna("NA").astype(str).to_numpy()
    neigh = pd.to_numeric(df.get("Neighbors_n_used", 0), errors="coerce").to_numpy(dtype=float)
    wsum = pd.to_numeric(df.get("Neighbors_Wsum", 0), errors="coerce").to_numpy(dtype=float)
    mdist = pd.to_numeric(df.get("Neighbors_meanDist", np.nan), errors="coerce").to_numpy(dtype=float)
    out[iso] = 1.0
    unc[iso] = 0.10
    group_map: Dict[tuple, List[int]] = {}
    for i in range(n):
        if iso[i]:
            continue
        key = (aq_arr[i], rid_arr[i])
        group_map.setdefault(key, []).append(i)
    for key, idxs in group_map.items():
        idxs = np.array(idxs, dtype=int)
        if (key[1] == "NA") or (len(idxs) <= 1):
            out[idxs] = 1.0
            unc[idxs] = 0.10
            continue
        neigh_n = _minmax_norm_arr(neigh[idxs])
        wsum_n = _minmax_norm_arr(wsum[idxs])
        mdist_n = _minmax_norm_arr(mdist[idxs])
        proximity_intensity = PROX_W_WSUM * wsum_n + (1.0 - PROX_W_WSUM) * (1.0 - mdist_n)
        compact_raw = 1.0 - mdist_n
        compact_excess = np.clip(compact_raw - proximity_intensity, -1.0, 1.0)
        compact_excess_score = np.clip(0.5 + 0.5 * compact_excess, 0, 1)
        redundancy = (
            DIST_REDUNDANCY_W_NEIGH * neigh_n
            + DIST_REDUNDANCY_W_PROX * proximity_intensity
            + DIST_REDUNDANCY_W_COMPACT * compact_excess_score
        )
        keep_raw = 1.0 - redundancy
        keep_norm = _minmax_norm_arr(keep_raw)
        keep_score = small_cluster_score_blend(keep_raw, keep_norm, len(idxs))
        out[idxs] = np.clip(keep_score, 0, 1)
        spread = float(np.nanstd(keep_score)) if np.isfinite(keep_score).any() else 0.0
        tie_like = 1.0 - np.clip(spread / 0.25, 0.0, 1.0)
        unc[idxs] = np.clip(0.18 + 0.18 * tie_like, 0.15, 0.40)
    return np.clip(out, 0, 1), np.clip(unc, 0, 1)
def compute_information_keep_clusterwise(df: pd.DataFrame) -> Tuple[np.ndarray, np.ndarray]:
    n = len(df)
    out = np.full(n, 0.5, dtype=float)
    unc = np.full(n, 0.25, dtype=float)
    iso = df["Isolated_within_Ell"].fillna(False).astype(bool).to_numpy()
    aq_arr = df["Aquifer_group"].astype(str).str.strip().str.lower().to_numpy()
    rid_arr = df["Redundancy_cluster_id"].fillna("NA").astype(str).to_numpy()
    feature_cols = ["Feat_chl_norm", "Feat_trend_norm", "Feat_depth_norm", "Feat_status_norm"]
    feat_all = df[feature_cols].apply(pd.to_numeric, errors="coerce").fillna(0.5).to_numpy(dtype=float)
    x_all = pd.to_numeric(df["X_m"], errors="coerce").to_numpy(dtype=float)
    y_all = pd.to_numeric(df["Y_m"], errors="coerce").to_numpy(dtype=float)
    ell_all = pd.to_numeric(df["Ell_aquifer_m"], errors="coerce").to_numpy(dtype=float)
    out[iso] = 1.0
    unc[iso] = 0.10
    group_map: Dict[tuple, List[int]] = {}
    for i in range(n):
        if iso[i]:
            continue
        key = (aq_arr[i], rid_arr[i])
        group_map.setdefault(key, []).append(i)
    for key, idxs in group_map.items():
        idxs = np.array(idxs, dtype=int)
        if (key[1] == "NA") or (len(idxs) <= 1):
            out[idxs] = 1.0
            unc[idxs] = 0.10
            continue
        coords = np.column_stack([x_all[idxs], y_all[idxs]])
        ell_grp = np.nanmedian(ell_all[idxs])
        if not np.isfinite(ell_grp) or ell_grp <= 0:
            ell_grp = ELL_MIN_M
        dmat = pairwise_distance_matrix(coords)
        spatial_w = np.exp(-dmat / max(ell_grp, 1e-6))
        np.fill_diagonal(spatial_w, 0.0)
        feat_sim = pairwise_feature_similarity(feat_all[idxs])
        info_overlap = weighted_mean_excluding_self(spatial_w, feat_sim)
        keep_raw = 1.0 - np.clip(info_overlap, 0, 1)
        keep_norm = 1.0 - _minmax_norm_arr(info_overlap)
        if np.allclose(np.nanstd(keep_norm), 0.0):
            keep_norm = keep_raw.copy()
        keep_score = small_cluster_score_blend(keep_raw, keep_norm, len(idxs))
        out[idxs] = np.clip(keep_score, 0, 1)
        spread = float(np.nanstd(info_overlap)) if np.isfinite(info_overlap).any() else 0.0
        unc[idxs] = np.clip(0.18 + 0.20 * (1.0 - np.clip(spread / 0.25, 0.0, 1.0)), 0.15, 0.45)
    return np.clip(out, 0, 1), np.clip(unc, 0, 1)
def compute_dependency_keep_clusterwise(df: pd.DataFrame) -> Tuple[np.ndarray, np.ndarray, pd.DataFrame]:
    n = len(df)
    out = np.full(n, 0.5, dtype=float)
    unc = np.full(n, 0.25, dtype=float)
    edge_rows = []
    iso = df["Isolated_within_Ell"].fillna(False).astype(bool).to_numpy()
    aq_arr = df["Aquifer_group"].astype(str).str.strip().str.lower().to_numpy()
    rid_arr = df["Redundancy_cluster_id"].fillna("NA").astype(str).to_numpy()
    x_all = pd.to_numeric(df["X_m"], errors="coerce").to_numpy(dtype=float)
    y_all = pd.to_numeric(df["Y_m"], errors="coerce").to_numpy(dtype=float)
    ell_all = pd.to_numeric(df["Ell_aquifer_m"], errors="coerce").to_numpy(dtype=float)
    sid_all = df[SID_COL].astype(str).to_numpy()
    trend_feat = pd.to_numeric(df["Feat_trend_norm"], errors="coerce").fillna(0.5).to_numpy(dtype=float)
    chl_feat = pd.to_numeric(df["Feat_chl_norm"], errors="coerce").fillna(0.5).to_numpy(dtype=float)
    depth_feat = pd.to_numeric(df["Feat_depth_norm"], errors="coerce").fillna(0.5).to_numpy(dtype=float)
    status_feat = pd.to_numeric(df["Feat_status_norm"], errors="coerce").fillna(0.5).to_numpy(dtype=float)
    out[iso] = 1.0
    unc[iso] = 0.10
    group_map: Dict[tuple, List[int]] = {}
    for i in range(n):
        if iso[i]:
            continue
        key = (aq_arr[i], rid_arr[i])
        group_map.setdefault(key, []).append(i)
    for (aq, rid), idxs in group_map.items():
        idxs = np.array(idxs, dtype=int)
        if (rid == "NA") or (len(idxs) <= 1):
            out[idxs] = 1.0
            unc[idxs] = 0.10
            continue
        coords = np.column_stack([x_all[idxs], y_all[idxs]])
        ell_grp = np.nanmedian(ell_all[idxs])
        if not np.isfinite(ell_grp) or ell_grp <= 0:
            ell_grp = ELL_MIN_M
        dmat = pairwise_distance_matrix(coords)
        spatial_w = np.exp(-dmat / max(ell_grp, 1e-6))
        np.fill_diagonal(spatial_w, 0.0)
        trend_agree = 1.0 - np.abs(trend_feat[idxs][:, None] - trend_feat[idxs][None, :])
        chl_sim = 1.0 - np.abs(chl_feat[idxs][:, None] - chl_feat[idxs][None, :])
        depth_sim = 1.0 - np.abs(depth_feat[idxs][:, None] - depth_feat[idxs][None, :])
        status_sim = 1.0 - np.abs(status_feat[idxs][:, None] - status_feat[idxs][None, :])
        dep_sim = (
            DEP_GRAPH_W_TREND * trend_agree
            + DEP_GRAPH_W_CHL * chl_sim
            + DEP_GRAPH_W_DEPTH * depth_sim
            + DEP_GRAPH_W_STATUS * status_sim
        )
        dep_sim = np.clip(dep_sim, 0, 1)
        np.fill_diagonal(dep_sim, 0.0)
        dep_strength = weighted_mean_excluding_self(spatial_w, dep_sim)
        keep_raw = 1.0 - np.clip(dep_strength, 0, 1)
        keep_norm = 1.0 - _minmax_norm_arr(dep_strength)
        if np.allclose(np.nanstd(keep_norm), 0.0):
            keep_norm = keep_raw.copy()
        keep_score = small_cluster_score_blend(keep_raw, keep_norm, len(idxs))
        out[idxs] = np.clip(keep_score, 0, 1)
        spread = float(np.nanstd(dep_strength)) if np.isfinite(dep_strength).any() else 0.0
        unc[idxs] = np.clip(0.18 + 0.20 * (1.0 - np.clip(spread / 0.25, 0.0, 1.0)), 0.15, 0.45)
        local_sid = sid_all[idxs]
        for ii in range(len(idxs)):
            for jj in range(ii + 1, len(idxs)):
                if spatial_w[ii, jj] <= 0:
                    continue
                if dmat[ii, jj] > ell_grp:
                    continue
                edge_rows.append({
                    "Aquifer_group": aq,
                    "Redundancy_cluster_id": rid,
                    SID_COL: local_sid[ii],
                    "Neighbor_SID": local_sid[jj],
                    "Distance_m": float(dmat[ii, jj]),
                    "SpatialWeight": float(spatial_w[ii, jj]),
                    "TrendAgreement": float(trend_agree[ii, jj]),
                    "ChlorideSimilarity": float(chl_sim[ii, jj]),
                    "DepthSimilarity": float(depth_sim[ii, jj]),
                    "StatusSimilarity": float(status_sim[ii, jj]),
                    "DependencyWeight": float(dep_sim[ii, jj]),
                    "X1_m": float(coords[ii, 0]),
                    "Y1_m": float(coords[ii, 1]),
                    "X2_m": float(coords[jj, 0]),
                    "Y2_m": float(coords[jj, 1]),
                })
    edge_df = pd.DataFrame(edge_rows)
    return np.clip(out, 0, 1), np.clip(unc, 0, 1), edge_df
def compute_graph_role_keep_clusterwise(df: pd.DataFrame) -> Tuple[np.ndarray, np.ndarray, pd.DataFrame]:
    n = len(df)
    out = np.full(n, 0.5, dtype=float)
    unc = np.full(n, 0.25, dtype=float)
    diag_strength = np.full(n, np.nan, dtype=float)
    diag_strength_norm = np.full(n, np.nan, dtype=float)
    diag_neighbor_cohesion = np.full(n, np.nan, dtype=float)
    diag_neighbor_spread = np.full(n, np.nan, dtype=float)
    diag_bridge_proxy = np.full(n, np.nan, dtype=float)
    iso = df["Isolated_within_Ell"].fillna(False).astype(bool).to_numpy()
    aq_arr = df["Aquifer_group"].astype(str).str.strip().str.lower().to_numpy()
    rid_arr = df["Redundancy_cluster_id"].fillna("NA").astype(str).to_numpy()
    x_all = pd.to_numeric(df["X_m"], errors="coerce").to_numpy(dtype=float)
    y_all = pd.to_numeric(df["Y_m"], errors="coerce").to_numpy(dtype=float)
    ell_all = pd.to_numeric(df["Ell_aquifer_m"], errors="coerce").to_numpy(dtype=float)
    trend_feat = pd.to_numeric(df["Feat_trend_norm"], errors="coerce").fillna(0.5).to_numpy(dtype=float)
    chl_feat = pd.to_numeric(df["Feat_chl_norm"], errors="coerce").fillna(0.5).to_numpy(dtype=float)
    depth_feat = pd.to_numeric(df["Feat_depth_norm"], errors="coerce").fillna(0.5).to_numpy(dtype=float)
    status_feat = pd.to_numeric(df["Feat_status_norm"], errors="coerce").fillna(0.5).to_numpy(dtype=float)
    out[iso] = 1.0
    unc[iso] = 0.10
    group_map: Dict[tuple, List[int]] = {}
    for i in range(n):
        if iso[i]:
            continue
        key = (aq_arr[i], rid_arr[i])
        group_map.setdefault(key, []).append(i)
    for key, idxs in group_map.items():
        idxs = np.array(idxs, dtype=int)
        if (key[1] == "NA") or (len(idxs) <= 1):
            out[idxs] = 1.0
            unc[idxs] = 0.10
            continue
        coords = np.column_stack([x_all[idxs], y_all[idxs]])
        ell_grp = np.nanmedian(ell_all[idxs])
        if not np.isfinite(ell_grp) or ell_grp <= 0:
            ell_grp = ELL_MIN_M
        dmat = pairwise_distance_matrix(coords)
        spatial_w = np.exp(-dmat / max(ell_grp, 1e-6))
        np.fill_diagonal(spatial_w, 0.0)
        trend_agree = 1.0 - np.abs(trend_feat[idxs][:, None] - trend_feat[idxs][None, :])
        chl_sim = 1.0 - np.abs(chl_feat[idxs][:, None] - chl_feat[idxs][None, :])
        depth_sim = 1.0 - np.abs(depth_feat[idxs][:, None] - depth_feat[idxs][None, :])
        status_sim = 1.0 - np.abs(status_feat[idxs][:, None] - status_feat[idxs][None, :])
        dep_sim = (
            DEP_GRAPH_W_TREND * trend_agree
            + DEP_GRAPH_W_CHL * chl_sim
            + DEP_GRAPH_W_DEPTH * depth_sim
            + DEP_GRAPH_W_STATUS * status_sim
        )
        dep_sim = np.clip(dep_sim, 0, 1)
        np.fill_diagonal(dep_sim, 0.0)
        if GRAPH_ROLE_EDGE_USE_SPATIAL:
            A = dep_sim * spatial_w
        else:
            A = dep_sim.copy()
        A = np.clip(A, 0, 1)
        A[A < GRAPH_ROLE_MIN_EDGE_WEIGHT] = 0.0
        np.fill_diagonal(A, 0.0)
        strength = np.sum(A, axis=1)
        strength_norm = _minmax_norm_arr(strength)
        neighbor_cohesion = np.zeros(len(idxs), dtype=float)
        neighbor_spread = np.zeros(len(idxs), dtype=float)
        local_feat = np.column_stack([
            chl_feat[idxs], trend_feat[idxs], depth_feat[idxs], status_feat[idxs],
        ])
        for ii in range(len(idxs)):
            nbrs = np.where(A[ii, :] > 0)[0]
            nbrs = nbrs[nbrs != ii]
            if len(nbrs) < 2:
                neighbor_cohesion[ii] = 0.0
                if len(nbrs) == 1:
                    neighbor_spread[ii] = float(
                        np.mean(np.abs(local_feat[nbrs[0], :] - local_feat[ii, :]))
                    )
                else:
                    neighbor_spread[ii] = 0.0
                continue
            subA = A[np.ix_(nbrs, nbrs)].copy()
            np.fill_diagonal(subA, 0.0)
            neighbor_cohesion[ii] = float(np.sum(subA) / max(len(nbrs) * (len(nbrs) - 1), 1))
            nbr_feat = local_feat[nbrs, :]
            nbr_mean = np.nanmean(nbr_feat, axis=0)
            neighbor_spread[ii] = float(np.mean(np.abs(nbr_feat - nbr_mean[None, :])))
        neighbor_cohesion = np.clip(neighbor_cohesion, 0, 1)
        neighbor_spread = _minmax_norm_arr(neighbor_spread)
        bridge_proxy = strength_norm * (1.0 - neighbor_cohesion)
        role_raw = (
            GRAPH_ROLE_W_BRIDGE * bridge_proxy
            + GRAPH_ROLE_W_LOW_COHESION * (1.0 - neighbor_cohesion)
            + GRAPH_ROLE_W_NEIGHBOR_SPREAD * neighbor_spread
        )
        role_raw = np.clip(role_raw, 0, 1)
        role_norm = _minmax_norm_arr(role_raw)
        if np.allclose(np.nanstd(role_norm), 0.0):
            role_norm = role_raw.copy()
        keep_score = small_cluster_score_blend(role_raw, role_norm, len(idxs))
        if len(idxs) <= R1["SMALL_CLUSTER_MAX_N"]:          # R1 [C9]
            keep_score = shrink_score_to_neutral(keep_score, GRAPH_ROLE_SMALL_CLUSTER_SHRINK)
            unc[idxs] = np.clip(unc[idxs] + GRAPH_ROLE_SMALL_CLUSTER_UNC_BOOST, 0, 1)
        out[idxs] = np.clip(keep_score, 0, 1)
        spread = float(np.nanstd(role_raw)) if np.isfinite(role_raw).any() else 0.0
        base_unc = np.clip(0.18 + 0.22 * (1.0 - np.clip(spread / 0.25, 0.0, 1.0)), 0.15, 0.45)
        unc[idxs] = np.maximum(unc[idxs], base_unc)
        diag_strength[idxs] = strength
        diag_strength_norm[idxs] = strength_norm
        diag_neighbor_cohesion[idxs] = neighbor_cohesion
        diag_neighbor_spread[idxs] = neighbor_spread
        diag_bridge_proxy[idxs] = bridge_proxy
    diag_df = pd.DataFrame({
        "GraphRole_strength": diag_strength,
        "GraphRole_strength_norm": diag_strength_norm,
        "GraphRole_neighbor_cohesion": diag_neighbor_cohesion,
        "GraphRole_neighbor_spread": diag_neighbor_spread,
        "GraphRole_bridge_proxy": diag_bridge_proxy,
    })
    return np.clip(out, 0, 1), np.clip(unc, 0, 1), diag_df
# ============================================================
# NEW: GRAPH INFLUENCE ANALYSIS (B4.9 - diagnostic)
# ============================================================
def _count_components_from_adjacency(A: np.ndarray) -> int:
    n = A.shape[0]
    if n == 0:
        return 0
    seen = np.zeros(n, dtype=bool)
    comps = 0
    for i in range(n):
        if seen[i]:
            continue
        comps += 1
        stack = [i]
        seen[i] = True
        while stack:
            u = stack.pop()
            nbrs = np.where(A[u] > 0)[0]
            for v in nbrs:
                if not seen[v]:
                    seen[v] = True
                    stack.append(v)
    return comps
def compute_graph_influence_analysis(df: pd.DataFrame) -> pd.DataFrame:
    n = len(df)
    comp_delta = np.full(n, 0.0, dtype=float)
    strength_loss = np.full(n, 0.0, dtype=float)
    mst_delta = np.full(n, 0.0, dtype=float)
    influence = np.full(n, 0.5, dtype=float)
    iso = df["Isolated_within_Ell"].fillna(False).astype(bool).to_numpy()
    aq_arr = df["Aquifer_group"].astype(str).str.strip().str.lower().to_numpy()
    rid_arr = df["Redundancy_cluster_id"].fillna("NA").astype(str).to_numpy()
    x_all = pd.to_numeric(df["X_m"], errors="coerce").to_numpy(dtype=float)
    y_all = pd.to_numeric(df["Y_m"], errors="coerce").to_numpy(dtype=float)
    ell_all = pd.to_numeric(df["Ell_aquifer_m"], errors="coerce").to_numpy(dtype=float)
    trend_feat = pd.to_numeric(df["Feat_trend_norm"], errors="coerce").fillna(0.5).to_numpy(dtype=float)
    chl_feat = pd.to_numeric(df["Feat_chl_norm"], errors="coerce").fillna(0.5).to_numpy(dtype=float)
    depth_feat = pd.to_numeric(df["Feat_depth_norm"], errors="coerce").fillna(0.5).to_numpy(dtype=float)
    status_feat = pd.to_numeric(df["Feat_status_norm"], errors="coerce").fillna(0.5).to_numpy(dtype=float)
    group_map: Dict[tuple, List[int]] = {}
    for i in range(n):
        if iso[i]:
            continue
        key = (aq_arr[i], rid_arr[i])
        group_map.setdefault(key, []).append(i)
    for key, idxs in group_map.items():
        idxs = np.array(idxs, dtype=int)
        if (key[1] == "NA") or (len(idxs) <= 2):
            influence[idxs] = 0.5
            continue
        coords = np.column_stack([x_all[idxs], y_all[idxs]])
        ell_grp = np.nanmedian(ell_all[idxs])
        if not np.isfinite(ell_grp) or ell_grp <= 0:
            ell_grp = ELL_MIN_M
        dmat = pairwise_distance_matrix(coords)
        spatial_w = np.exp(-dmat / max(ell_grp, 1e-6))
        np.fill_diagonal(spatial_w, 0.0)
        trend_agree = 1.0 - np.abs(trend_feat[idxs][:, None] - trend_feat[idxs][None, :])
        chl_sim = 1.0 - np.abs(chl_feat[idxs][:, None] - chl_feat[idxs][None, :])
        depth_sim = 1.0 - np.abs(depth_feat[idxs][:, None] - depth_feat[idxs][None, :])
        status_sim = 1.0 - np.abs(status_feat[idxs][:, None] - status_feat[idxs][None, :])
        dep_sim = (
            DEP_GRAPH_W_TREND * trend_agree
            + DEP_GRAPH_W_CHL * chl_sim
            + DEP_GRAPH_W_DEPTH * depth_sim
            + DEP_GRAPH_W_STATUS * status_sim
        )
        dep_sim = np.clip(dep_sim, 0, 1)
        np.fill_diagonal(dep_sim, 0.0)
        A = dep_sim * spatial_w if GRAPH_ROLE_EDGE_USE_SPATIAL else dep_sim.copy()
        A = np.clip(A, 0, 1)
        A[A < GRAPH_ROLE_MIN_EDGE_WEIGHT] = 0.0
        np.fill_diagonal(A, 0.0)
        base_components = _count_components_from_adjacency(A)
        base_strength = float(np.sum(A) / 2.0)
        mst_edges = mst_edges_from_points(coords)
        base_mst_len = float(np.sum([e[2] for e in mst_edges])) if len(mst_edges) > 0 else 0.0
        local_comp_delta = np.zeros(len(idxs), dtype=float)
        local_strength_loss = np.zeros(len(idxs), dtype=float)
        local_mst_delta = np.zeros(len(idxs), dtype=float)
        for ii in range(len(idxs)):
            keep = np.ones(len(idxs), dtype=bool)
            keep[ii] = False
            A2 = A[np.ix_(keep, keep)]
            coords2 = coords[keep]
            new_components = _count_components_from_adjacency(A2)
            new_strength = float(np.sum(A2) / 2.0)
            mst_edges2 = mst_edges_from_points(coords2)
            new_mst_len = float(np.sum([e[2] for e in mst_edges2])) if len(mst_edges2) > 0 else 0.0
            local_comp_delta[ii] = max(new_components - base_components, 0)
            if base_strength > 0:
                local_strength_loss[ii] = np.clip((base_strength - new_strength) / base_strength, 0, 1)
            else:
                local_strength_loss[ii] = 0.0
            if base_mst_len > 0:
                local_mst_delta[ii] = np.clip((new_mst_len - base_mst_len) / base_mst_len, 0, 1)
            else:
                local_mst_delta[ii] = 0.0
        comp_score = _minmax_norm_arr(local_comp_delta)
        strength_score = _minmax_norm_arr(local_strength_loss)
        mst_score = _minmax_norm_arr(local_mst_delta)
        local_infl = np.clip(
            GI_W[0] * comp_score
            + GI_W[1] * strength_score
            + GI_W[2] * mst_score,
            0, 1
        )
        comp_delta[idxs] = local_comp_delta
        strength_loss[idxs] = local_strength_loss
        mst_delta[idxs] = local_mst_delta
        influence[idxs] = local_infl
    out = pd.DataFrame({
        "GraphInfluence_component_delta": comp_delta,
        "GraphInfluence_strength_loss": strength_loss,
        "GraphInfluence_mst_delta": mst_delta,
        "GraphInfluence_score": influence,
    })
    return out
# ============================================================
# QUALITY DEPENDENCY LAYER (unchanged)
# ============================================================
def apply_bayesian_dependency_layer(
    p_chl: np.ndarray, u_chl: np.ndarray,
    p_trend: np.ndarray, u_trend: np.ndarray,
    p_status: np.ndarray, u_status: np.ndarray,
    p_depth: np.ndarray, u_depth: np.ndarray,
) -> Dict[str, np.ndarray]:
    p_chl = _clip01(p_chl)
    p_trend = _clip01(p_trend)
    p_status = _clip01(p_status)
    p_depth = _clip01(p_depth)
    u_chl = _clip01(u_chl)
    u_trend = _clip01(u_trend)
    u_status = _clip01(u_status)
    u_depth = _clip01(u_depth)
    risk_chl = 1.0 - p_chl
    risk_trend = 1.0 - p_trend
    risk_status = 1.0 - p_status
    bad_joint = risk_chl * risk_trend
    good_joint = p_chl * p_trend
    joint_quality_keep = 1.0 - (risk_chl + risk_trend - risk_chl * risk_trend)
    bad_status_bad_quality = risk_status * (1.0 - joint_quality_keep)
    active_status_good_quality = p_status * joint_quality_keep
    p_chl_adj = p_chl - INTERACTION_BAD_CHL_BAD_TREND * bad_joint + 0.04 * good_joint
    p_trend_adj = p_trend - INTERACTION_BAD_CHL_BAD_TREND * bad_joint + INTERACTION_GOOD_CHL_GOOD_TREND * good_joint
    p_status_adj = p_status - INTERACTION_BAD_STATUS_BAD_QUALITY * bad_status_bad_quality + INTERACTION_ACTIVE_STATUS_GOOD_QUALITY * active_status_good_quality
    p_depth_adj = p_depth + 0.03 * (joint_quality_keep - 0.5)
    joint_quality_keep = joint_quality_keep - 0.10 * bad_status_bad_quality + 0.05 * active_status_good_quality
    p_chl_adj = _clip01(p_chl_adj)
    p_trend_adj = _clip01(p_trend_adj)
    p_status_adj = _clip01(p_status_adj)
    p_depth_adj = _clip01(p_depth_adj)
    joint_quality_keep = _clip01(joint_quality_keep)
    dependency_conflict = np.abs(p_chl - p_trend)
    joint_unc = np.clip(0.15 + 0.40 * dependency_conflict, 0.12, 0.55)
    u_chl_adj = _clip01(np.maximum(u_chl, 0.60 * joint_unc))
    u_trend_adj = _clip01(np.maximum(u_trend, 0.60 * joint_unc))
    u_status_adj = _clip01(np.maximum(u_status, 0.45 * joint_unc))
    u_depth_adj = _clip01(np.maximum(u_depth, 0.25 * joint_unc))
    return {
        "P_keep_chloride_adj": p_chl_adj,
        "P_keep_chloride_adj_unc": u_chl_adj,
        "P_keep_trend_adj": p_trend_adj,
        "P_keep_trend_adj_unc": u_trend_adj,
        "P_keep_status_adj": p_status_adj,
        "P_keep_status_adj_unc": u_status_adj,
        "P_keep_depth_adj": p_depth_adj,
        "P_keep_depth_adj_unc": u_depth_adj,
        "P_keep_joint_quality": joint_quality_keep,
        "P_keep_joint_quality_unc": joint_unc,
        "BadJoint_chl_trend": bad_joint,
        "GoodJoint_chl_trend": good_joint,
        "BadStatusBadQuality": bad_status_bad_quality,
    }
# ============================================================
# ENTROPY WEIGHTS (unchanged)
# ============================================================
def enforce_final_weight_constraints(weights: Dict[str, float]) -> Dict[str, float]:
    w = _renormalize_weight_dict(weights)
    for _ in range(25):
        changed = False
        if "joint_quality" in w and w["joint_quality"] > MAX_JOINT_QUALITY_WEIGHT + 1e-12:
            excess = w["joint_quality"] - MAX_JOINT_QUALITY_WEIGHT
            w["joint_quality"] = MAX_JOINT_QUALITY_WEIGHT
            recips = [k for k in w.keys() if k != "joint_quality"]
            recip_sum = sum(w[k] for k in recips)
            if recip_sum > 0:
                for k in recips:
                    w[k] += excess * (w[k] / recip_sum)
            else:
                add = excess / max(len(recips), 1)
                for k in recips:
                    w[k] += add
            w = _renormalize_weight_dict(w)
            changed = True
        fam_sum = sum(w.get(k, 0.0) for k in NETWORK_FAMILY_KEYS)
        if fam_sum > NETWORK_FAMILY_MAX_WEIGHT + 1e-12:
            excess = fam_sum - NETWORK_FAMILY_MAX_WEIGHT
            scale = NETWORK_FAMILY_MAX_WEIGHT / max(fam_sum, 1e-12)
            for k in NETWORK_FAMILY_KEYS:
                w[k] = w.get(k, 0.0) * scale
            nonfam = [k for k in w.keys() if k not in NETWORK_FAMILY_KEYS]
            nonfam_sum = sum(w[k] for k in nonfam)
            if nonfam_sum > 0:
                for k in nonfam:
                    w[k] += excess * (w[k] / nonfam_sum)
            else:
                add = excess / max(len(nonfam), 1)
                for k in nonfam:
                    w[k] += add
            w = _renormalize_weight_dict(w)
            changed = True
        if not changed:
            break
    return _renormalize_weight_dict(w)
def entropy_weights_from_components(df: pd.DataFrame) -> Dict[str, float]:
    keys = [
        "chloride", "distance", "information", "dependency", "graph_role",
        "depth", "trend", "status", "joint_quality",
    ]
    comps = pd.DataFrame({
        "chloride": df["P_keep_chloride_adj"],
        "distance": df["P_keep_distance_base"],
        "information": df["P_keep_information_base"],
        "dependency": df["P_keep_dependency_base"],
        "graph_role": df["P_keep_graph_role_base"],
        "depth": df["P_keep_depth_adj"],
        "trend": df["P_keep_trend_adj"],
        "status": df["P_keep_status_adj"],
        "joint_quality": df["P_keep_joint_quality"],
    }).copy()
    w_global = entropy_weights_from_matrix(comps)
    aq_means = (
        pd.concat([df[["Aquifer_group"]].copy(), comps], axis=1)
        .groupby("Aquifer_group", dropna=False)
        .mean(numeric_only=True)
        .reset_index(drop=True)
    )
    w_balanced = entropy_weights_from_matrix(aq_means[keys])
    w_blend = {}
    for k in keys:
        w_blend[k] = (
            ENTROPY_GLOBAL_BLEND * w_global[k]
            + (1.0 - ENTROPY_GLOBAL_BLEND) * w_balanced[k]
        )
    w_capped = cap_network_family_weights(w_blend)
    w_final = stabilize_entropy_weights(w_capped)
    w_final = enforce_final_weight_constraints(w_final)
    return w_final
# ============================================================
# UTILITY (unchanged)
# ============================================================
def weighted_keep_utility(
    p_chl, p_dist, p_info, p_dep, p_graph, p_depth, p_trend, p_status, p_joint, weights,
):
    w = weights
    denom = float(sum(w.values()))
    util = (
        w["chloride"] * np.asarray(p_chl, dtype=float)
        + w["distance"] * np.asarray(p_dist, dtype=float)
        + w["information"] * np.asarray(p_info, dtype=float)
        + w["dependency"] * np.asarray(p_dep, dtype=float)
        + w["graph_role"] * np.asarray(p_graph, dtype=float)
        + w["depth"] * np.asarray(p_depth, dtype=float)
        + w["trend"] * np.asarray(p_trend, dtype=float)
        + w["status"] * np.asarray(p_status, dtype=float)
        + w["joint_quality"] * np.asarray(p_joint, dtype=float)
    ) / denom
    return np.clip(util, 0, 1)
# ============================================================
# BETA SAMPLER (unchanged)
# ============================================================
def sample_beta_from_mean_uncertainty(mean: np.ndarray, unc: np.ndarray, rng: np.random.Generator) -> np.ndarray:
    m = np.clip(np.asarray(mean, dtype=float), 1e-4, 1 - 1e-4)
    u = np.clip(np.asarray(unc, dtype=float), 1e-4, 1.0)
    kappa = 2.0 + (1.0 - u) * BETA_KAPPA_SPAN
    alpha = np.clip(m * kappa, 1e-3, None)
    beta = np.clip((1.0 - m) * kappa, 1e-3, None)
    return rng.beta(alpha, beta)
# ============================================================
# DECISION CALIBRATION LAYER
# ============================================================
def _top2_margin(p_keep: np.ndarray, p_review: np.ndarray, p_remove: np.ndarray) -> np.ndarray:
    probs = np.column_stack([p_keep, p_review, p_remove])
    sorted_p = np.sort(probs, axis=1)[:, ::-1]
    return sorted_p[:, 0] - sorted_p[:, 1]
def compute_composite_decision_uncertainty(df: pd.DataFrame) -> np.ndarray:
    unc_cols = [
        "P_keep_chloride_adj_unc",
        "P_keep_trend_adj_unc",
        "P_keep_status_adj_unc",
        "P_keep_depth_adj_unc",
        "P_keep_joint_quality_unc",
        "P_keep_information_unc",
        "P_keep_dependency_unc",
        "P_keep_graph_role_unc",
        "P_keep_distance_unc",
    ]
    available = [c for c in unc_cols if c in df.columns]
    if not available:
        return np.full(len(df), 0.5, dtype=float)
    return df[available].mean(axis=1).to_numpy(dtype=float)
def calibrate_pre_safeguard_decisions(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    pk = pd.to_numeric(out["Prob_KEEP"], errors="coerce").fillna(0.0).to_numpy(dtype=float)
    pr = pd.to_numeric(out["Prob_REVIEW"], errors="coerce").fillna(0.0).to_numpy(dtype=float)
    prem = pd.to_numeric(out["Prob_CANDIDATE_REMOVE"], errors="coerce").fillna(0.0).to_numpy(dtype=float)
    util = pd.to_numeric(out["UtilityScore_mean"], errors="coerce").fillna(0.5).to_numpy(dtype=float)
    dist_keep = pd.to_numeric(out["P_keep_distance_base"], errors="coerce").fillna(0.5).to_numpy(dtype=float)
    info_keep = pd.to_numeric(out["P_keep_information_base"], errors="coerce").fillna(0.5).to_numpy(dtype=float)
    dep_keep = pd.to_numeric(out["P_keep_dependency_base"], errors="coerce").fillna(0.5).to_numpy(dtype=float)
    graph_keep = pd.to_numeric(out["P_keep_graph_role_base"], errors="coerce").fillna(0.5).to_numpy(dtype=float)
    structural = np.nanmean(np.column_stack([info_keep, dep_keep, graph_keep]), axis=1)
    if R1["CALIB_STRUCT_WITH_SGI"]:                  # R1 [C3]: {P_info, P_dep, P_graph, S_GI} (Sect. 2.5)
        sgi = pd.to_numeric(out.get("GraphInfluence_score", 0.5), errors="coerce").fillna(0.5).to_numpy(dtype=float)
        structural = np.nanmean(np.column_stack([info_keep, dep_keep, graph_keep, sgi]), axis=1)
    comp_unc = compute_composite_decision_uncertainty(out)
    margin = _top2_margin(pk, pr, prem)
    critical = out["IsCritical"].fillna(0).astype(int).to_numpy(dtype=int) == 1
    isolated = out["Isolated_within_Ell"].fillna(False).astype(bool).to_numpy()
    base_dec = out["FinalDecision_preSafeguard"].astype(str).to_numpy()
    new_dec = base_dec.copy()
    decision_source = np.array(["none"] * len(out), dtype=object)
    calibrated = np.zeros(len(out), dtype=int)
    ambiguous = (margin <= DECISION_AMBIG_MARGIN) & (comp_unc >= DECISION_AMBIG_UNCERTAINTY)
    new_dec[ambiguous] = "REVIEW"
    decision_source[ambiguous] = "ambiguity_to_review"
    calibrated[ambiguous] = (base_dec[ambiguous] != "REVIEW").astype(int)
    for i in range(len(out)):
        if ambiguous[i]:
            continue
        if isolated[i]:
            continue
        if new_dec[i] != "REVIEW":
            continue
        if (
            pk[i] >= DECISION_KEEP_PROB_MIN
            and util[i] >= DECISION_KEEP_UTILITY_MIN
            and structural[i] >= DECISION_KEEP_STRUCTURAL_MIN
            and pk[i] >= prem[i]
        ):
            new_dec[i] = "KEEP"
            decision_source[i] = "review_resolved_to_keep"
            calibrated[i] = 1
            continue
        if (
            (not critical[i])
            and prem[i] >= DECISION_REMOVE_PROB_MIN
            and util[i] <= DECISION_REMOVE_UTILITY_MAX
            and structural[i] <= DECISION_REMOVE_STRUCTURAL_MAX
            and dist_keep[i] <= DECISION_REMOVE_DISTANCE_MAX
            and comp_unc[i] <= DECISION_REMOVE_UNCERTAINTY_MAX
            and prem[i] >= pk[i]
        ):
            new_dec[i] = "CANDIDATE_REMOVE"
            decision_source[i] = "review_resolved_to_remove"
            calibrated[i] = 1
            continue
    new_dec = np.where((critical) & (new_dec == "CANDIDATE_REMOVE"), "REVIEW", new_dec)
    out["DecisionProbMargin"] = margin
    out["CompositeDecisionUncertainty"] = comp_unc
    out["StructuralValueMean"] = structural
    out["DecisionCalibrationSource"] = decision_source
    out["DecisionCalibrated"] = calibrated
    out["FinalDecision_preSafeguard"] = new_dec
    return out
# ============================================================
# NEW: ACTIVE SENSING CANDIDATE INJECTION (B4.9)
# ============================================================
def inject_active_sensing_candidates(
    sub_comp: gpd.GeoDataFrame,
    domain_geom,
    ell_use: float,
    grid_spacing: float,
) -> gpd.GeoDataFrame:
    """Inject extra candidates from uncertainty hotspots and graph vulnerability.
    Only adds points that are inside domain and respect min distance."""
    if len(sub_comp) < 2 or domain_geom is None:
        return gpd.GeoDataFrame(columns=["geometry"], geometry="geometry", crs=sub_comp.crs)
    # 1. High-uncertainty wells
    unc_cols = [c for c in sub_comp.columns if c.endswith("_unc")]
    if unc_cols:
        mean_unc = sub_comp[unc_cols].mean(axis=1, numeric_only=True)
        high_unc = sub_comp[mean_unc >= mean_unc.quantile(0.8)].copy()
    else:
        high_unc = sub_comp.copy()
    # 2. High graph influence wells
    if "GraphInfluence_score" in sub_comp.columns:
        high_infl = sub_comp[sub_comp["GraphInfluence_score"] >= sub_comp["GraphInfluence_score"].quantile(0.8)].copy()
    else:
        high_infl = sub_comp.iloc[:0].copy()
    candidates = []
    # Midpoints between distant high-unc pairs
    if len(high_unc) >= 2:
        coords_unc = np.column_stack([high_unc.geometry.x.values, high_unc.geometry.y.values])
        tree = cKDTree(coords_unc)
        for i in range(len(high_unc)):
            dists, idxs = tree.query(coords_unc[i], k=min(4, len(high_unc)))
            for d, j in zip(dists[1:], idxs[1:]):
                if d > 0.8 * ell_use:
                    p1 = coords_unc[i]
                    p2 = coords_unc[j]
                    mid = Point(0.5 * (p1[0] + p2[0]), 0.5 * (p1[1] + p2[1]))
                    if domain_geom.contains(mid):
                        candidates.append(mid)
                    # slight perpendicular offset for diversity
                    dx = p2[0] - p1[0]
                    dy = p2[1] - p1[1]
                    offset = 0.15 * ell_use
                    perp_x = p1[0] + 0.5 * dx - offset * dy / (d + 1e-9)
                    perp_y = p1[1] + 0.5 * dy + offset * dx / (d + 1e-9)
                    perp_pt = Point(perp_x, perp_y)
                    if domain_geom.contains(perp_pt):
                        candidates.append(perp_pt)
    # Centroid offsets around high-influence wells
    for _, row in high_infl.iterrows():
        p = row.geometry
        for angle in [0, 90, 180, 270]:
            rad = math.radians(angle)
            off_x = p.x + 0.3 * ell_use * math.cos(rad)
            off_y = p.y + 0.3 * ell_use * math.sin(rad)
            off_pt = Point(off_x, off_y)
            if domain_geom.contains(off_pt):
                candidates.append(off_pt)
    if not candidates:
        return gpd.GeoDataFrame(columns=["geometry"], geometry="geometry", crs=sub_comp.crs)
    inj = gpd.GeoDataFrame({"geometry": candidates}, geometry="geometry", crs=sub_comp.crs)
    # min distance filter
    existing_coords = np.column_stack([sub_comp.geometry.x.values, sub_comp.geometry.y.values])
    tree = cKDTree(existing_coords)
    inj_coords = np.column_stack([inj.geometry.x.values, inj.geometry.y.values])
    dmin, _ = tree.query(inj_coords, k=1)
    inj = inj[dmin >= CAND_MIN_DIST_EXISTING_FACTOR * ell_use * 0.7].copy()
    return inj
# ============================================================
# CANDIDATE WELL SUGGESTION - DOMAIN GENERATION + INJECTION (B4.9)
# ============================================================
def _build_component_support_domain(
    sub_comp: gpd.GeoDataFrame, ell_use: float, grid_spacing: float,
):
    if len(sub_comp) == 0:
        return None
    coords = np.column_stack([sub_comp.geometry.x.values, sub_comp.geometry.y.values])
    network_geom = _build_network_corridor_geometry(sub_comp, ell_use)
    if network_geom is None or network_geom.is_empty:
        return None
    alpha_radius = max(CAND_ALPHA_RADIUS_FACTOR * ell_use, 1.25 * grid_spacing)
    alpha_geom = alpha_shape_polygon(coords, alpha_radius)
    if alpha_geom is None or alpha_geom.is_empty:
        alpha_geom = MultiPoint([Point(xy) for xy in coords]).convex_hull
    support_radius = max(CAND_BUFFER_FACTOR * ell_use, 0.75 * grid_spacing)
    expansion_extra = max((CAND_EXPANSION_FACTOR - 1.0) * ell_use, 0.0)
    smooth_r = max(CAND_DOMAIN_SMOOTHING_FRAC * grid_spacing, 0.0)
    try:
        alpha_support = alpha_geom.buffer(expansion_extra)
        domain_geom = network_geom.intersection(alpha_support)
        if domain_geom is None or domain_geom.is_empty:
            domain_geom = network_geom.union(alpha_support.buffer(0.25 * support_radius))
    except Exception:
        domain_geom = network_geom
    try:
        point_support = dissolve_geoms(sub_comp.geometry.buffer(support_radius))
        if point_support is not None and (not point_support.is_empty):
            domain_geom = domain_geom.union(point_support)
    except Exception:
        pass
    if smooth_r > 0:
        try:
            smoothed = domain_geom.buffer(smooth_r).buffer(-smooth_r)
            if smoothed is not None and (not smoothed.is_empty):
                domain_geom = smoothed
        except Exception:
            pass
    if domain_geom is None or domain_geom.is_empty or (not domain_geom.is_valid):
        minx, miny, maxx, maxy = sub_comp.total_bounds
        pad = max(support_radius, grid_spacing)
        domain_geom = box(minx - pad, miny - pad, maxx + pad, maxy + pad)
    return domain_geom
def create_candidate_points_for_aquifer(sub: gpd.GeoDataFrame, ell_aquifer: float) -> gpd.GeoDataFrame:
    if len(sub) == 0:
        return gpd.GeoDataFrame(columns=["geometry"], geometry="geometry", crs=sub.crs)
    ell_use = ell_aquifer if np.isfinite(ell_aquifer) and ell_aquifer > 0 else ELL_MIN_M
    grid_spacing = float(np.clip(CAND_GRID_FACTOR * ell_use, CAND_MIN_GRID_M, CAND_MAX_GRID_M))
    component_frames = []
    if CAND_DOMAIN_COMPONENT_AWARE and ("Component_id" in sub.columns):
        group_iter = sub.groupby("Component_id", dropna=False)
    else:
        group_iter = [("all", sub)]
    for comp_id, sub_comp in group_iter:
        sub_comp = sub_comp.copy()
        if len(sub_comp) < CAND_DOMAIN_SUPPORT_MIN_POINTS:
            continue
        domain_geom = _build_component_support_domain(sub_comp, ell_use, grid_spacing)
        if domain_geom is None or domain_geom.is_empty:
            continue
        minx, miny, maxx, maxy = domain_geom.bounds
        if CAND_HEX_GRID:
            dy = grid_spacing * math.sqrt(3.0) / 2.0
            ys = np.arange(miny, maxy + dy, dy)
            pts = []
            for row_id, y in enumerate(ys):
                x_offset = 0.5 * grid_spacing if (row_id % 2 == 1) else 0.0
                xs = np.arange(minx + x_offset, maxx + grid_spacing, grid_spacing)
                for x in xs:
                    p = Point(float(x), float(y))
                    if domain_geom.covers(p):
                        pts.append(p)
        else:
            xs = np.arange(minx, maxx + grid_spacing, grid_spacing)
            ys = np.arange(miny, maxy + grid_spacing, grid_spacing)
            pts = []
            for x in xs:
                for y in ys:
                    p = Point(float(x), float(y))
                    if domain_geom.covers(p):
                        pts.append(p)
        if len(pts) == 0:
            continue
        cand_comp = gpd.GeoDataFrame({"geometry": pts}, geometry="geometry", crs=sub.crs)
        existing_coords = np.column_stack([sub_comp.geometry.x.values, sub_comp.geometry.y.values])
        tree = cKDTree(existing_coords)
        cand_coords = np.column_stack([cand_comp.geometry.x.values, cand_comp.geometry.y.values])
        dmin, _ = tree.query(cand_coords, k=1)
        min_allowed = max(CAND_MIN_DIST_EXISTING_FACTOR * ell_use, 0.60 * grid_spacing)
        cand_comp["DistToNearestExisting_m"] = dmin
        cand_comp = cand_comp[cand_comp["DistToNearestExisting_m"] >= min_allowed].copy()
        if len(cand_comp) == 0:
            continue
        pre_min_spacing = max(CAND_MIN_SEPARATION_FACTOR * grid_spacing, 0.70 * ell_use)
        cand_comp["SeedScore"] = cand_comp["DistToNearestExisting_m"]
        cand_comp = thin_candidates_by_spacing(
            cand_comp, min_spacing=pre_min_spacing, score_col="SeedScore", max_keep=CAND_MAX_PER_COMPONENT * 4,
        )
        cand_comp = cand_comp.drop(columns=["SeedScore"], errors="ignore")
        if len(cand_comp) == 0:
            continue
        # B4.9: Active-sensing injection (uncertainty hotspots + graph vulnerability + midpoints)
        cand_injected = inject_active_sensing_candidates(
            sub_comp=sub_comp,
            domain_geom=domain_geom,
            ell_use=ell_use,
            grid_spacing=grid_spacing,
        )
        if len(cand_injected) > 0:
            cand_comp = pd.concat([cand_comp, cand_injected], ignore_index=True)
            cand_comp = gpd.GeoDataFrame(cand_comp, geometry="geometry", crs=sub.crs)
            # dedup again
            cand_comp["__x"] = cand_comp.geometry.x.round(6)
            cand_comp["__y"] = cand_comp.geometry.y.round(6)
            cand_comp = cand_comp.drop_duplicates(subset=["__x", "__y"]).drop(columns=["__x", "__y"]).reset_index(drop=True)
        cand_comp["SourceComponentID"] = comp_id
        component_frames.append(cand_comp)
    if len(component_frames) == 0:
        return gpd.GeoDataFrame(columns=["geometry"], geometry="geometry", crs=sub.crs)
    cand = pd.concat(component_frames, ignore_index=True)
    cand = gpd.GeoDataFrame(cand, geometry="geometry", crs=sub.crs)
    cand["__x"] = cand.geometry.x.round(6)
    cand["__y"] = cand.geometry.y.round(6)
    cand = cand.drop_duplicates(subset=["__x", "__y"]).drop(columns=["__x", "__y"]).reset_index(drop=True)
    return cand
# ============================================================
# NEW: ACTIVE SENSING CANDIDATE SCORING (B4.9)
# ============================================================
def score_candidate_points_active_sensing(
    cand: gpd.GeoDataFrame,
    sub: gpd.GeoDataFrame,
    ell_aquifer: float,
) -> gpd.GeoDataFrame:
    if len(cand) == 0 or len(sub) == 0:
        return cand
    cand = cand.copy()
    ell_use = ell_aquifer if np.isfinite(ell_aquifer) and ell_aquifer > 0 else ELL_MIN_M
    feat_cols = ["Feat_chl_norm", "Feat_trend_norm", "Feat_depth_norm", "Feat_status_norm"]
    if (
        CAND_COMPONENT_SCOPE_SCORING
        and ("SourceComponentID" in cand.columns)
        and ("Component_id" in sub.columns)
    ):
        cand_groups = cand.groupby("SourceComponentID", dropna=False).groups
    else:
        cand_groups = {"all": cand.index.to_numpy()}
    cand["AS_ExpectedUncertaintyReduction"] = np.nan
    cand["AS_ExpectedSupportImprovement"] = np.nan
    cand["AS_ExpectedGraphImprovement"] = np.nan
    cand["AS_ExpectedRepresentationGain"] = np.nan
    cand["AS_ExpectedDependencyGain"] = np.nan
    cand["AS_ActiveSensingScore"] = np.nan
    for comp_id, cand_idx in cand_groups.items():
        cand_idx = np.asarray(list(cand_idx), dtype=int)
        cand_sub = cand.loc[cand_idx].copy()
        if len(cand_sub) == 0:
            continue
        if (
            CAND_COMPONENT_SCOPE_SCORING
            and ("SourceComponentID" in cand.columns)
            and ("Component_id" in sub.columns)
            and (comp_id != "all")
        ):
            sub_scope = sub[sub["Component_id"].astype(str) == str(comp_id)].copy()
            if len(sub_scope) == 0:
                sub_scope = sub.copy()
        else:
            sub_scope = sub.copy()
        ex_coords = np.column_stack([sub_scope.geometry.x.values, sub_scope.geometry.y.values])
        cand_coords = np.column_stack([cand_sub.geometry.x.values, cand_sub.geometry.y.values])
        if len(ex_coords) == 0:
            continue
        dmat_ce = np.sqrt(((cand_coords[:, None, :] - ex_coords[None, :, :]) ** 2).sum(axis=2))
        support_w = np.exp(-dmat_ce / max(CAND_SUPPORT_DECAY_FACTOR * ell_use, 1e-6))
        den = support_w.sum(axis=1)
        wnorm = support_w / np.maximum(den[:, None], 1e-12)
        # --- 1) expected uncertainty reduction
        unc_cols = []
        for c in [
            "P_keep_chloride_adj_unc",
            "P_keep_trend_adj_unc",
            "P_keep_depth_adj_unc",
            "P_keep_status_adj_unc",
            "P_keep_joint_quality_unc",
            "P_keep_dependency_unc",
            "P_keep_graph_role_unc",
        ]:
            if c in sub_scope.columns:
                unc_cols.append(pd.to_numeric(sub_scope[c], errors="coerce").fillna(0.5).to_numpy(dtype=float))
        if len(unc_cols) > 0:
            ex_unc = np.nanmean(np.column_stack(unc_cols), axis=1)
        else:
            ex_unc = np.full(len(sub_scope), 0.5, dtype=float)
        expected_unc_reduction = np.sum(wnorm * ex_unc[None, :], axis=1)
        expected_unc_reduction = _minmax_norm_arr(expected_unc_reduction)
        # --- 2) expected support improvement
        tree = cKDTree(ex_coords)
        dmin, _ = tree.query(cand_coords, k=1)
        support_improvement = np.clip(dmin / max(ell_use, 1.0), 0, 1)
        support_improvement = _minmax_norm_arr(support_improvement)
        # --- 3) expected graph improvement
        if "GraphInfluence_score" in sub_scope.columns:
            ex_graph_infl = pd.to_numeric(
                sub_scope["GraphInfluence_score"], errors="coerce"
            ).fillna(0.5).to_numpy(dtype=float)
        elif "GraphRole_strength_norm" in sub_scope.columns:
            ex_graph_infl = pd.to_numeric(
                sub_scope["GraphRole_strength_norm"], errors="coerce"
            ).fillna(0.5).to_numpy(dtype=float)
        else:
            ex_graph_infl = np.full(len(sub_scope), 0.5, dtype=float)
        expected_graph_improvement = np.sum(wnorm * ex_graph_infl[None, :], axis=1)
        expected_graph_improvement = _minmax_norm_arr(expected_graph_improvement)
        # --- 4) expected representation gain
        ex_feat = (
            sub_scope[feat_cols]
            .apply(pd.to_numeric, errors="coerce")
            .fillna(0.5)
            .to_numpy(dtype=float)
        )
        local_feat_disp = _weighted_feature_dispersion(ex_feat, wnorm)
        expected_representation_gain = _minmax_norm_arr(local_feat_disp)
        # --- 5) expected dependency gain
        trend_feat = pd.to_numeric(sub_scope["Feat_trend_norm"], errors="coerce").fillna(0.5).to_numpy(dtype=float)
        chl_feat = pd.to_numeric(sub_scope["Feat_chl_norm"], errors="coerce").fillna(0.5).to_numpy(dtype=float)
        depth_feat = pd.to_numeric(sub_scope["Feat_depth_norm"], errors="coerce").fillna(0.5).to_numpy(dtype=float)
        status_feat = pd.to_numeric(sub_scope["Feat_status_norm"], errors="coerce").fillna(0.5).to_numpy(dtype=float)
        dep_feat = np.column_stack([chl_feat, trend_feat, depth_feat, status_feat])
        local_dep_disp = _weighted_feature_dispersion(dep_feat, wnorm)
        expected_dependency_gain = _minmax_norm_arr(local_dep_disp)
        if AS_USE_ADAPTIVE_WEIGHTS:
            w_unc,w_sup,w_gra,w_rep,w_dep=compute_adaptive_active_sensing_weights(
                ex_unc,
                ex_graph_infl,
                ex_feat,
                dep_feat,
                ex_coords,
                ell_use
            )
        else:
            w_unc=AS_W_UNCERTAINTY_REDUCTION
            w_sup=AS_W_SUPPORT_IMPROVEMENT
            w_gra=AS_W_GRAPH_IMPROVEMENT
            w_rep=AS_W_REPRESENTATION_GAIN
            w_dep=AS_W_DEPENDENCY_GAIN
        if R1["AS_ADAPTIVE"]:                         # R1 [C4]: Eq. 17 with Table S1 adaptive weights
            final_score = np.clip(
                w_unc * expected_unc_reduction + w_sup * support_improvement + w_gra * expected_graph_improvement
                + w_rep * expected_representation_gain + w_dep * expected_dependency_gain, 0, 1)
        else:
            final_score = np.clip(
                0.50 * expected_unc_reduction
                + 0.35 * support_improvement
                + 0.10 * expected_graph_improvement
                + 0.03 * expected_representation_gain
                + 0.02 * expected_dependency_gain,
                0, 1
            )
        cand.loc[cand_idx, "AS_w_unc"], cand.loc[cand_idx, "AS_w_sup"] = float(w_unc), float(w_sup)
        cand.loc[cand_idx, "AS_w_gra"], cand.loc[cand_idx, "AS_w_rep"], cand.loc[cand_idx, "AS_w_dep"] = float(w_gra), float(w_rep), float(w_dep)
        cand.loc[cand_idx, "AS_ExpectedUncertaintyReduction"] = expected_unc_reduction
        cand.loc[cand_idx, "AS_ExpectedSupportImprovement"] = support_improvement
        cand.loc[cand_idx, "AS_ExpectedGraphImprovement"] = expected_graph_improvement
        cand.loc[cand_idx, "AS_ExpectedRepresentationGain"] = expected_representation_gain
        cand.loc[cand_idx, "AS_ExpectedDependencyGain"] = expected_dependency_gain
        cand.loc[cand_idx, "AS_ActiveSensingScore"] = final_score
        cand.loc[cand_idx, "AS_BackboneScore"] = final_score
        # backward compatibility
        cand.loc[cand_idx, "CandidateScore"] = final_score
        cand.loc[cand_idx, "ExplorationGainScore"] = expected_unc_reduction
        cand.loc[cand_idx, "GraphCoverageGainScore"] = expected_graph_improvement
        cand.loc[cand_idx, "InformationGapScore"] = expected_representation_gain
        cand.loc[cand_idx, "DependencyGapScore"] = expected_dependency_gain
        cand.loc[cand_idx, "SpatialGapScore"] = support_improvement
    cand["CandidateScore"] = pd.to_numeric(cand["CandidateScore"], errors="coerce").fillna(0.0).clip(0, 1)
    return cand
# ============================================================
# NEW: HYDRO-LIMG CANDIDATE SCORING (B4.9 augmentation - multi-level deviation/ratio/inter-intra)
# ============================================================
def compute_candidate_validation_gain(
    cand_coords: np.ndarray,
    remove_coords: np.ndarray,
    remove_err: np.ndarray,
    radius: float,
) -> np.ndarray:
    if len(cand_coords) == 0:
        return np.array([], dtype=float)
    if len(remove_coords) == 0:
        return np.zeros(len(cand_coords), dtype=float)

    dmat = np.sqrt(((cand_coords[:, None, :] - remove_coords[None, :, :]) ** 2).sum(axis=2))
    w = np.exp(-dmat / max(radius, 1e-9))
    num = np.sum(w * remove_err[None, :], axis=1)
    den = np.sum(w, axis=1)

    out = np.zeros(len(cand_coords), dtype=float)
    ok = den > 0
    out[ok] = num[ok] / den[ok]
    return _minmax_norm_arr(out)


def build_local_graph_level(
    cand_xy: np.ndarray,
    ex_xy: np.ndarray,
    ex_feat: np.ndarray,
    ex_unc: np.ndarray,
    ex_graph: np.ndarray,
    k: int = 8,
):
    tree = cKDTree(ex_xy)
    d, idx = tree.query(cand_xy, k=min(k, len(ex_xy)))
    idx = np.atleast_2d(idx)
    d = np.atleast_2d(d)

    local_feat_mean = np.zeros((len(cand_xy), ex_feat.shape[1]), dtype=float)
    local_unc_mean = np.zeros(len(cand_xy), dtype=float)
    local_graph_mean = np.zeros(len(cand_xy), dtype=float)
    local_dist_mean = np.zeros(len(cand_xy), dtype=float)

    for i in range(len(cand_xy)):
        ii = np.atleast_1d(idx[i]).astype(int)
        dd = np.atleast_1d(d[i]).astype(float)
        w = np.exp(-dd / max(np.nanmean(dd) + 1e-9, 1.0))
        w = w / max(w.sum(), 1e-12)

        local_feat_mean[i, :] = np.sum(ex_feat[ii] * w[:, None], axis=0)
        local_unc_mean[i] = np.sum(ex_unc[ii] * w)
        local_graph_mean[i] = np.sum(ex_graph[ii] * w)
        local_dist_mean[i] = np.sum(dd * w)

    return local_feat_mean, local_unc_mean, local_graph_mean, local_dist_mean

# ============================================================
# PATCH E — HYDRO-LIMG CANDIDATE AUGMENTATION
# ============================================================
def score_candidate_points_hydro_limg(
    cand: gpd.GeoDataFrame,
    sub: gpd.GeoDataFrame,
    ell_aquifer: float,
    loo_remove_df: Optional[pd.DataFrame] = None,
) -> gpd.GeoDataFrame:
    if len(cand) == 0 or len(sub) == 0:
        return cand

    cand = cand.copy()
    ell_use = ell_aquifer if np.isfinite(ell_aquifer) and ell_aquifer > 0 else ELL_MIN_M

    feat_cols = ["Feat_chl_norm", "Feat_trend_norm", "Feat_depth_norm", "Feat_status_norm"]
    ex_xy = np.column_stack([sub.geometry.x.values, sub.geometry.y.values])
    ex_feat = sub[feat_cols].apply(pd.to_numeric, errors="coerce").fillna(0.5).to_numpy(dtype=float)

    unc_cols = [
        c for c in [
            "P_keep_chloride_adj_unc",
            "P_keep_trend_adj_unc",
            "P_keep_depth_adj_unc",
            "P_keep_status_adj_unc",
            "P_keep_joint_quality_unc",
            "P_keep_dependency_unc",
            "P_keep_graph_role_unc",
        ] if c in sub.columns
    ]

    if len(unc_cols) > 0:
        ex_unc = np.nanmean(
            np.column_stack([
                pd.to_numeric(sub[c], errors="coerce").fillna(0.5).to_numpy(dtype=float)
                for c in unc_cols
            ]),
            axis=1
        )
    else:
        ex_unc = np.full(len(sub), 0.5, dtype=float)

    if "GraphInfluence_score" in sub.columns:
        ex_graph = pd.to_numeric(sub["GraphInfluence_score"], errors="coerce").fillna(0.5).to_numpy(dtype=float)
    else:
        ex_graph = np.full(len(sub), 0.5, dtype=float)

    cand_xy = np.column_stack([cand.geometry.x.values, cand.geometry.y.values])

    # --------------------------------------------------
    # Global support weights
    # --------------------------------------------------
    dmat = np.sqrt(((cand_xy[:, None, :] - ex_xy[None, :, :]) ** 2).sum(axis=2))
    w_support = np.exp(-dmat / max(ell_use, 1e-9))
    w_support = w_support / np.maximum(w_support.sum(axis=1, keepdims=True), 1e-12)

    global_feat_mean = w_support @ ex_feat
    global_unc_mean = np.sum(w_support * ex_unc[None, :], axis=1)
    global_graph_mean = np.sum(w_support * ex_graph[None, :], axis=1)

    global_feat_ref = np.nanmean(ex_feat, axis=0)

    # --------------------------------------------------
    # Level 1: global/component-like
    # --------------------------------------------------
    inter_dev_global = np.mean(np.abs(global_feat_mean - global_feat_ref[None, :]), axis=1)
    inter_ratio_global = np.mean(
        np.abs(global_feat_mean / np.maximum(global_feat_ref[None, :], 1e-6) - 1.0),
        axis=1
    )
    intra_global = np.sum(w_support * np.linalg.norm(ex_feat[None, :, :] - global_feat_mean[:, None, :], axis=2), axis=1)
    score_global = _minmax_norm_arr(inter_dev_global + inter_ratio_global) - _minmax_norm_arr(intra_global)

    # --------------------------------------------------
    # Level 2: aquifer
    # --------------------------------------------------
    inter_dev_aq = np.mean(np.abs(global_feat_mean - global_feat_ref[None, :]), axis=1)
    inter_ratio_aq = np.mean(
        np.abs(global_feat_mean / np.maximum(global_feat_ref[None, :], 1e-6) - 1.0),
        axis=1
    )
    intra_aq = np.sum(
        w_support * np.linalg.norm(ex_feat[None, :, :] - global_feat_ref[None, None, :], axis=2),
        axis=1
    )
    score_aq = _minmax_norm_arr(inter_dev_aq + inter_ratio_aq) - _minmax_norm_arr(intra_aq)

    # --------------------------------------------------
    # Level 3: local graph neighborhood
    # --------------------------------------------------
    if USE_LOCAL_GRAPH_LEVEL:
        local_feat_mean, local_unc_mean, local_graph_mean, local_dist_mean = build_local_graph_level(
            cand_xy, ex_xy, ex_feat, ex_unc, ex_graph, k=LIMG_LOCAL_K
        )
        inter_dev_local = np.mean(np.abs(local_feat_mean - global_feat_ref[None, :]), axis=1)
        inter_ratio_local = np.mean(
            np.abs(local_feat_mean / np.maximum(global_feat_ref[None, :], 1e-6) - 1.0),
            axis=1
        )
        intra_local = _minmax_norm_arr(local_dist_mean) + (1.0 - _minmax_norm_arr(local_graph_mean))
        score_local = _minmax_norm_arr(inter_dev_local + inter_ratio_local) - _minmax_norm_arr(intra_local)
    else:
        score_local = np.zeros(len(cand), dtype=float)

    # --------------------------------------------------
    # Level 4: blended uncertainty-graph
    # --------------------------------------------------
    inter_blended = _minmax_norm_arr(global_unc_mean) + _minmax_norm_arr(global_graph_mean)
    intra_blended = 1.0 - _minmax_norm_arr(
        np.mean(np.abs(global_feat_mean - global_feat_ref[None, :]), axis=1)
    )
    score_blended = _minmax_norm_arr(inter_blended) - _minmax_norm_arr(intra_blended)

    # --------------------------------------------------
    # Adaptive level weights
    # --------------------------------------------------
    w_global, w_aq, w_local, w_blended = R1["LIMG_W"]   # R1 [C5]
    w_local = w_local if USE_LOCAL_GRAPH_LEVEL else 0.0
    w_sum = w_global + w_aq + w_local + w_blended

    hydro_limg_score = (
        w_global * score_global
        + w_aq * score_aq
        + w_local * score_local
        + w_blended * score_blended
    ) / max(w_sum, 1e-12)

    hydro_limg_score = _minmax_norm_arr(hydro_limg_score)

    # --------------------------------------------------
    # Validation gain
    # --------------------------------------------------
    if (
        USE_VALIDATION_GAIN
        and (loo_remove_df is not None)
        and (len(loo_remove_df) > 0)
        and ("X_m" in loo_remove_df.columns)
        and ("Y_m" in loo_remove_df.columns)
        and ("AbsError_without_well" in loo_remove_df.columns)
    ):
        loo_ok = loo_remove_df.copy()
        loo_ok = loo_ok[
            np.isfinite(pd.to_numeric(loo_ok["X_m"], errors="coerce"))
            & np.isfinite(pd.to_numeric(loo_ok["Y_m"], errors="coerce"))
            & np.isfinite(pd.to_numeric(loo_ok["AbsError_without_well"], errors="coerce"))
        ]
        if len(loo_ok) > 0:
            remove_xy = loo_ok[["X_m", "Y_m"]].to_numpy(dtype=float)
            remove_err = pd.to_numeric(loo_ok["AbsError_without_well"], errors="coerce").to_numpy(dtype=float)
            valid_gain = compute_candidate_validation_gain(
                cand_xy, remove_xy, remove_err, radius=VALID_GAIN_RADIUS_FACTOR * ell_use
            )
        else:
            valid_gain = np.zeros(len(cand), dtype=float)
    else:
        valid_gain = np.zeros(len(cand), dtype=float)

    # --------------------------------------------------
    # Final fusion
    # --------------------------------------------------
    as_score = pd.to_numeric(cand.get("AS_BackboneScore", 0.0), errors="coerce").fillna(0.0).to_numpy(dtype=float)

    final_score = np.clip(
        CAND_W_AS * as_score
        + CAND_W_LIMG * hydro_limg_score
        + CAND_W_VALID * valid_gain,
        0, 1
    )

    cand["HydroLIMGScore"] = hydro_limg_score
    cand["ValidationGainScore"] = valid_gain
    cand["HydroLIMG_GlobalLevel"] = score_global
    cand["HydroLIMG_AquiferLevel"] = score_aq
    cand["HydroLIMG_LocalLevel"] = score_local
    cand["HydroLIMG_BlendedLevel"] = score_blended
    cand["CandidateScore"] = final_score

    return cand

def select_candidates_sequentially(
    cand: gpd.GeoDataFrame,
    ell_use: float,
    min_spacing: float,
    max_keep: int,
) -> gpd.GeoDataFrame:
    if len(cand) == 0 or max_keep <= 0:
        return cand.copy()

    work = cand.copy().reset_index(drop=True)
    work["OriginalScore"] = pd.to_numeric(work["CandidateScore"], errors="coerce").fillna(0.0)

    xy = np.column_stack([work.geometry.x.values, work.geometry.y.values])
    kept = []
    remaining = list(range(len(work)))

    while len(kept) < max_keep and remaining:
        best_idx = max(remaining, key=lambda i: float(work.loc[i, "CandidateScore"]))
        kept.append(best_idx)
        remaining.remove(best_idx)

        if len(remaining) == 0:
            break

        best_xy = xy[best_idx]
        rem_xy = xy[remaining]
        d = np.sqrt(((rem_xy - best_xy[None, :]) ** 2).sum(axis=1))
        spatial_pen = np.exp(-d / max(0.7 * ell_use, 1.0))

        if USE_MULTI_OVERLAP_PENALTY:
            if "HydroLIMGScore" in work.columns:
                best_graph = float(work.loc[best_idx, "HydroLIMGScore"])
                graph_pen = np.array([
                    1.0 - abs(float(work.loc[i, "HydroLIMGScore"]) - best_graph)
                    for i in remaining
                ], dtype=float)
                graph_pen = np.clip(graph_pen, 0, 1)
            else:
                graph_pen = np.zeros(len(remaining), dtype=float)

            best_signal = np.array([
                float(work.loc[best_idx, c]) if c in work.columns else 0.0
                for c in ["GraphCoverageGainScore", "InformationGapScore", "DependencyGapScore", "ValidationGainScore"]
            ], dtype=float)

            signal_pen = []
            for i in remaining:
                sig_i = np.array([
                    float(work.loc[i, c]) if c in work.columns else 0.0
                    for c in ["GraphCoverageGainScore", "InformationGapScore", "DependencyGapScore", "ValidationGainScore"]
                ], dtype=float)
                sim = 1.0 - np.mean(np.abs(sig_i - best_signal))
                signal_pen.append(np.clip(sim, 0, 1))
            signal_pen = np.array(signal_pen, dtype=float)

            total_pen = (
                GREEDY_PEN_W_SPATIAL * spatial_pen
                + GREEDY_PEN_W_GRAPH * graph_pen
                + GREEDY_PEN_W_SIGNAL * signal_pen
            )
        else:
            total_pen = spatial_pen

        work.loc[remaining, "CandidateScore"] = (
            work.loc[remaining, "OriginalScore"].to_numpy(dtype=float) * (1.0 - total_pen)
        )

    out = work.iloc[kept].copy().reset_index(drop=True)
    out = thin_candidates_by_spacing(out, min_spacing=min_spacing, score_col="CandidateScore", max_keep=max_keep)
    return out

def build_candidate_reason(row: pd.Series) -> str:
    scores = {
        "active sensing": row.get("AS_BackboneScore", np.nan),
        "Hydro-LIMG": row.get("HydroLIMGScore", np.nan),
        "validation gain": row.get("ValidationGainScore", np.nan),
        "graph coverage": row.get("GraphCoverageGainScore", np.nan),
        "information gap": row.get("InformationGapScore", np.nan),
        "dependency gap": row.get("DependencyGapScore", np.nan),
    }
    top_good = top_n_reason_labels(scores, n=3, descending=True)
    if len(top_good) == 0:
        return "no dominant candidate explanation"
    return "suggested due to " + ", ".join(top_good)

# ============================================================
# POST-FINAL SAFEGUARD (unchanged)
# ============================================================
def apply_postfinal_cluster_keep_safeguard(
    df: pd.DataFrame, group_map: Dict[tuple, List[int]],
) -> pd.DataFrame:
    out = df.copy()
    out["PostFinalClusterSafeguard"] = False
    out["PolicyKeepReason"] = out.get("PolicyKeepReason", "none")
    out["ClusterSafeguardUnresolved"] = False
    out["SafeguardEvidenceScore"] = np.nan
    for (aq, rid), idxs in group_map.items():
        idxs_arr = np.array(idxs, dtype=int)
        if (rid == "NA") or (len(idxs_arr) <= 1):
            continue
        labels = out.iloc[idxs_arr]["FinalDecision"].astype(str).to_numpy()
        if np.any(labels == "KEEP"):
            continue
        sub = out.iloc[idxs_arr].copy()
        sub["SafeguardEvidenceScore_local"] = (
            0.55 * pd.to_numeric(sub["Prob_KEEP"], errors="coerce").fillna(0.0)
            + 0.25 * pd.to_numeric(sub["Prob_REVIEW"], errors="coerce").fillna(0.0)
            + 0.20 * pd.to_numeric(sub["UtilityScore_mean"], errors="coerce").fillna(0.0)
        )
        best_pos = sub.sort_values(
            by=[
                "SafeguardEvidenceScore_local",
                "Prob_KEEP",
                "UtilityScore_mean",
                "Prob_REVIEW",
                "P_keep_graph_role_base",
                "P_keep_information_base",
            ],
            ascending=[False, False, False, False, False, False]
        ).index[0]
        ev = float(sub.loc[best_pos, "SafeguardEvidenceScore_local"])
        pk = float(sub.loc[best_pos, "Prob_KEEP"])
        um = float(sub.loc[best_pos, "UtilityScore_mean"])
        out.loc[best_pos, "PostFinalClusterSafeguard"] = True
        out.loc[best_pos, "SafeguardEvidenceScore"] = ev
        if (pk >= SAFEGUARD_KEEP_MIN_PROB) or (um >= SAFEGUARD_KEEP_MIN_UTILITY) or (ev >= SAFEGUARD_KEEP_MIN_EVIDENCE):
            out.loc[best_pos, "FinalDecision"] = "KEEP"
            out.loc[best_pos, "PolicyKeepReason"] = "postfinal_cluster_safeguard_keep"
            out.loc[idxs_arr, "ClusterSafeguardUnresolved"] = False
        else:
            out.loc[best_pos, "FinalDecision"] = "REVIEW"
            out.loc[best_pos, "PolicyKeepReason"] = SAFEGUARD_REVIEW_LABEL
            out.loc[idxs_arr, "ClusterSafeguardUnresolved"] = True
    return out
# ============================================================
# HARD FINAL RESOLVER (REVISED - evidence consensus voting)
# ============================================================
def resolve_remaining_reviews(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    out["FinalDecision_beforeHardResolve"] = out["FinalDecision"].astype(str)
    out["HardReviewResolved"] = 0
    out["HardReviewResolutionSource"] = "none"
    out["HardResolveScore"] = np.nan
    out["HardResolveKeepVotes"] = 0
    out["HardResolveRemoveVotes"] = 0
    mask = out["FinalDecision"].astype(str).eq("REVIEW")
    if mask.sum() == 0:
        return out
    pk = pd.to_numeric(out.loc[mask, "Prob_KEEP"], errors="coerce").fillna(0.0).to_numpy(dtype=float)
    prem = pd.to_numeric(out.loc[mask, "Prob_CANDIDATE_REMOVE"], errors="coerce").fillna(0.0).to_numpy(dtype=float)
    util = pd.to_numeric(out.loc[mask, "UtilityScore_mean"], errors="coerce").fillna(0.5).to_numpy(dtype=float)
    info = pd.to_numeric(out.loc[mask, "P_keep_information_base"], errors="coerce").fillna(0.5).to_numpy(dtype=float)
    dep = pd.to_numeric(out.loc[mask, "P_keep_dependency_base"], errors="coerce").fillna(0.5).to_numpy(dtype=float)
    graph = pd.to_numeric(out.loc[mask, "P_keep_graph_role_base"], errors="coerce").fillna(0.5).to_numpy(dtype=float)
    graph_infl = pd.to_numeric(
        out.loc[mask, "GraphInfluence_score"], errors="coerce"
    ).fillna(0.5).to_numpy(dtype=float)
    structural = np.nanmean(np.column_stack([info, dep, graph, graph_infl]), axis=1)
    stability = pd.to_numeric(
        out.loc[mask, "InformationStabilityIndex"], errors="coerce"
    ).fillna(0.5).to_numpy(dtype=float)
    uncertainty = pd.to_numeric(
        out.loc[mask, "CompositeDecisionUncertainty"], errors="coerce"
    ).fillna(0.5).to_numpy(dtype=float)
    critical = out.loc[mask, "IsCritical"].fillna(0).astype(int).to_numpy(dtype=int) == 1
    keep_votes = (
        (pk >= HARD_RESOLVE_KEEP_PK_MIN).astype(int)
        + (util >= HARD_RESOLVE_KEEP_UTIL_MIN).astype(int)
        + (structural >= HARD_RESOLVE_KEEP_STRUCTURAL_MIN).astype(int)
        + (stability >= HARD_RESOLVE_KEEP_STABILITY_MIN).astype(int)
    )
    remove_votes = (
        (prem >= HARD_RESOLVE_REMOVE_PREM_MIN).astype(int)
        + (util <= HARD_RESOLVE_REMOVE_UTIL_MAX).astype(int)
        + (structural <= HARD_RESOLVE_REMOVE_STRUCTURAL_MAX).astype(int)
        + (stability <= HARD_RESOLVE_REMOVE_STABILITY_MAX).astype(int)
        + (uncertainty <= HARD_RESOLVE_REMOVE_UNCERTAINTY_MAX).astype(int)
    )
    score = (
        0.30 * pk - 0.25 * prem + 0.15 * util + 0.10 * structural + 0.10 * stability - 0.10 * uncertainty
    )
    idxs = out.index[mask].to_numpy()
    out.loc[idxs, "HardResolveScore"] = score
    out.loc[idxs, "HardResolveKeepVotes"] = keep_votes
    out.loc[idxs, "HardResolveRemoveVotes"] = remove_votes
    for j, idx in enumerate(idxs):
        if critical[j]:
            out.loc[idx, "FinalDecision"] = "KEEP"
            out.loc[idx, "HardReviewResolved"] = 1
            out.loc[idx, "HardReviewResolutionSource"] = "critical_force_keep"
            continue
        if (keep_votes[j] >= HARD_RESOLVE_MIN_KEEP_VOTES) and (keep_votes[j] > remove_votes[j]):
            out.loc[idx, "FinalDecision"] = "KEEP"
            out.loc[idx, "HardReviewResolved"] = 1
            out.loc[idx, "HardReviewResolutionSource"] = "hard_review_to_keep_consensus"
            continue
        if (remove_votes[j] >= HARD_RESOLVE_MIN_REMOVE_VOTES) and (remove_votes[j] > keep_votes[j]):
            out.loc[idx, "FinalDecision"] = "CANDIDATE_REMOVE"
            out.loc[idx, "HardReviewResolved"] = 1
            out.loc[idx, "HardReviewResolutionSource"] = "hard_review_to_remove_consensus"
            continue
        if HARD_RESOLVE_CONSERVATIVE_TIE_TO_KEEP:
            out.loc[idx, "FinalDecision"] = "KEEP"
            out.loc[idx, "HardReviewResolved"] = 1
            out.loc[idx, "HardReviewResolutionSource"] = "hard_review_to_keep_conservative_tie"
        else:
            out.loc[idx, "FinalDecision"] = "CANDIDATE_REMOVE"
            out.loc[idx, "HardReviewResolved"] = 1
            out.loc[idx, "HardReviewResolutionSource"] = "hard_review_to_remove_tie"
    return out
# ============================================================
# INFORMATION STABILITY INDEX (unchanged - before hard resolve)
# ============================================================
def add_information_stability_index(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    pk = pd.to_numeric(out["Prob_KEEP"], errors="coerce").fillna(0.0).to_numpy(dtype=float)
    pr = pd.to_numeric(out["Prob_REVIEW"], errors="coerce").fillna(0.0).to_numpy(dtype=float)
    prem = pd.to_numeric(out["Prob_CANDIDATE_REMOVE"], errors="coerce").fillna(0.0).to_numpy(dtype=float)
    util = pd.to_numeric(out["UtilityScore_mean"], errors="coerce").fillna(0.5).to_numpy(dtype=float)
    unc = pd.to_numeric(out["CompositeDecisionUncertainty"], errors="coerce").fillna(0.5).to_numpy(dtype=float)
    margin = pd.to_numeric(out["DecisionProbMargin"], errors="coerce").fillna(0.0).to_numpy(dtype=float)
    decision_stability = np.maximum.reduce([pk, pr, prem])
    utility_centered = np.clip(np.abs(util - 0.5) * 2.0, 0, 1)
    uncertainty_stability = 1.0 - np.clip(unc, 0, 1)
    margin_stability = np.clip(margin, 0, 1)
    isi = (
        0.40 * decision_stability
        + 0.25 * margin_stability
        + 0.20 * uncertainty_stability
        + 0.15 * utility_centered
    )
    isi = np.clip(isi, 0, 1)
    out["DecisionStability"] = decision_stability
    out["InformationStabilityIndex"] = isi
    out["StabilityClass"] = np.where(
        isi >= 0.80, "HIGH", np.where(isi >= 0.60, "MEDIUM", "LOW")
    )
    return out
# ============================================================
# LEAVE-ONE-OUT VALIDATION (unchanged)
# ============================================================
def inverse_distance_predict(xy_train, z_train, xy_pred, power=2.0, eps=1e-6):
    d = np.sqrt(((xy_train - xy_pred[None, :]) ** 2).sum(axis=1))
    w = 1.0 / np.maximum(d, eps) ** power
    return float(np.sum(w * z_train) / np.sum(w))
def leave_one_out_remove_validation(df: pd.DataFrame, value_col: str = "CHLORIDE") -> pd.DataFrame:
    work = df.copy()
    work["__val"] = pd.to_numeric(work[value_col], errors="coerce")
    work["__x"] = pd.to_numeric(work["X_m"], errors="coerce")
    work["__y"] = pd.to_numeric(work["Y_m"], errors="coerce")
    work = work[np.isfinite(work["__val"]) & np.isfinite(work["__x"]) & np.isfinite(work["__y"])].copy()
    rows = []
    for aq, sub in work.groupby("Aquifer_group"):
        sub = sub.copy()
        if len(sub) < 4:
            continue
        coords = np.column_stack([sub["__x"].values, sub["__y"].values])
        vals = sub["__val"].values
        idxs = sub.index.to_numpy()
        for i_local, idx in enumerate(idxs):
            if str(sub.loc[idx, "FinalDecision"]) != "CANDIDATE_REMOVE":
                continue
            train_mask = np.ones(len(sub), dtype=bool)
            train_mask[i_local] = False
            if train_mask.sum() < 3:
                continue
            pred = inverse_distance_predict(
                coords[train_mask], vals[train_mask], coords[i_local]
            )
            err = float(abs(pred - vals[i_local]))
            rows.append({
                SID_COL: sub.loc[idx, SID_COL],
                "Aquifer_group": aq,
                "ObservedValue": float(vals[i_local]),
                "PredictedWithoutWell": float(pred),
                "AbsError_without_well": err,
                "FinalDecision": str(sub.loc[idx, "FinalDecision"]),
                "InformationStabilityIndex": float(sub.loc[idx, "InformationStabilityIndex"]) if "InformationStabilityIndex" in sub.columns else np.nan,
            })
    return pd.DataFrame(rows)
# ============================================================
# SPATIAL COVERAGE VALIDATION (unchanged)
# ============================================================
def nearest_neighbor_summary(coords: np.ndarray) -> Dict[str, float]:
    if len(coords) <= 1:
        return {"mean_nn": np.nan, "median_nn": np.nan, "max_nn": np.nan}
    tree = cKDTree(coords)
    d, _ = tree.query(coords, k=2)
    nn = d[:, 1]
    return {
        "mean_nn": float(np.nanmean(nn)),
        "median_nn": float(np.nanmedian(nn)),
        "max_nn": float(np.nanmax(nn)),
    }
def build_spatial_coverage_validation(df: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for aq, sub in df.groupby("Aquifer_group"):
        sub = sub.copy()
        coords_all = np.column_stack([sub["X_m"].values, sub["Y_m"].values])
        sub_keep = sub[sub["FinalDecision"] == "KEEP"].copy()
        coords_keep = (
            np.column_stack([sub_keep["X_m"].values, sub_keep["Y_m"].values])
            if len(sub_keep) > 0 else np.empty((0, 2))
        )
        all_stats = nearest_neighbor_summary(coords_all)
        keep_stats = nearest_neighbor_summary(coords_keep)
        rows.append({
            "Aquifer_group": aq,
            "n_all": int(len(sub)),
            "n_keep": int(len(sub_keep)),
            "mean_nn_all": all_stats["mean_nn"],
            "mean_nn_keep": keep_stats["mean_nn"],
            "median_nn_all": all_stats["median_nn"],
            "median_nn_keep": keep_stats["median_nn"],
            "max_nn_all": all_stats["max_nn"],
            "max_nn_keep": keep_stats["max_nn"],
        })
    return pd.DataFrame(rows)
# ============================================================
# MAIN (B4.9 full upgrades + Hydro-LIMG candidate augmentation)
# ============================================================

def select_candidates_sequentially_bgas(
    cand: gpd.GeoDataFrame,
    sub: gpd.GeoDataFrame,
    ell_aquifer: float,
    max_keep: int,
    min_spacing: float,
) -> gpd.GeoDataFrame:
    """B-GAS sequential greedy selection (verbatim from Final5NEW): pick best, penalize nearby candidates, repeat."""
    if len(cand) == 0 or max_keep <= 0:
        return cand.copy()
    work = cand.copy().reset_index(drop=True)
    work["OriginalScore"] = work["CandidateScore"].copy()
    kept = []
    remaining = list(range(len(work)))
    ell_use = ell_aquifer if np.isfinite(ell_aquifer) and ell_aquifer > 0 else ELL_MIN_M
    penalty_dist = 0.7 * ell_use
    while len(kept) < max_keep and remaining:
        scores = work.loc[remaining, "CandidateScore"].values
        best_idx = remaining[np.argmax(scores)]
        kept.append(best_idx)
        kept_coords = np.array([work.geometry.iloc[kept[-1]].coords[0]])
        if len(remaining) > 1:
            rem_coords = np.column_stack([work.geometry.iloc[remaining].x, work.geometry.iloc[remaining].y])
            d = np.sqrt(((rem_coords - kept_coords) ** 2).sum(axis=1))
            distance_penalty = np.exp(-d / penalty_dist)
            overlap_penalty = np.clip(0.3 * (1.0 - d / (1.5 * ell_use)), 0, 0.3)
            work.loc[remaining, "CandidateScore"] = (
                work.loc[remaining, "OriginalScore"].values
                * (1.0 - 0.45 * distance_penalty)
                * (1.0 - overlap_penalty)
            )
        remaining = [i for i in remaining if i not in kept]
    out = work.iloc[kept].copy().reset_index(drop=True)
    out = thin_candidates_by_spacing(out, min_spacing=min_spacing, score_col="CandidateScore", max_keep=max_keep)
    return out


_LAND = {}


def _land_polygon(crs):
    """R1 [C10]: land polygon (Census 1:500,000 shoreline) in the CRS of the candidate points."""
    key = (R1["LAND_MASK"], str(crs))
    if key not in _LAND:
        g = gpd.read_file(R1["LAND_MASK"]).to_crs(crs)
        _LAND[key] = g.geometry.union_all() if hasattr(g.geometry, "union_all") else g.geometry.unary_union
    return _LAND[key]


def _finish_candidate_frame(cand, aq, ell_aquifer):
    cand["Aquifer_group"] = aq
    cand["Ell_aquifer_m"] = float(ell_aquifer)
    cand = cand.sort_values("CandidateScore", ascending=False).reset_index(drop=True)
    cand["CandidateRank_inAquifer"] = np.arange(1, len(cand) + 1)
    cand_ll = cand.to_crs(epsg=4326)
    cand["Lat"] = cand_ll.geometry.y.values
    cand["Lon"] = cand_ll.geometry.x.values
    cand["X_m"] = cand.geometry.x
    cand["Y_m"] = cand.geometry.y
    cand["CandidateReason"] = cand.apply(build_candidate_reason, axis=1)
    return cand


def generate_candidates_r1(g_out, loo_df):
    """R1 [S1]: one candidate pool per aquifer; B-GAS and E-GAS selections from the same pool."""
    frames_e, frames_b, frames_p = [], [], []
    if GENERATE_CANDIDATE_WELLS:
        for aq, sub in g_out.groupby("Aquifer_group"):
            aq = str(aq).strip().lower()
            sub = sub.copy()
            ell_vals = pd.to_numeric(sub["Ell_aquifer_m"], errors="coerce")
            ell_aquifer = float(np.nanmedian(ell_vals)) if ell_vals.notna().any() else ELL_MIN_M
            if not np.isfinite(ell_aquifer) or ell_aquifer <= 0:
                ell_aquifer = ELL_MIN_M
            pool0 = create_candidate_points_for_aquifer(sub, ell_aquifer)
            if R1["LAND_MASK"] and len(pool0) > 0:          # R1 [C10]: candidate sites on land only
                pool0 = pool0[pool0.within(_land_polygon(pool0.crs))].copy()
            if len(pool0) == 0:
                continue
            # B-GAS (Final5NEW) always used the adaptive Table S1 weights; FINAL6 (E-GAS) did not ([C4])
            flag = R1["AS_ADAPTIVE"]
            R1["AS_ADAPTIVE"] = True
            pool = score_candidate_points_active_sensing(pool0.copy(), sub, ell_aquifer)
            R1["AS_ADAPTIVE"] = flag
            pool_e = pool if flag else score_candidate_points_active_sensing(pool0.copy(), sub, ell_aquifer)
            post_min_spacing = max(
                CAND_POSTSCORE_MIN_SEPARATION_FACTOR * float(np.clip(CAND_GRID_FACTOR * ell_aquifer, CAND_MIN_GRID_M, CAND_MAX_GRID_M)),
                0.80 * ell_aquifer,
            )
            pp = pool.copy(); pp["Aquifer_group"] = aq; pp["Ell_aquifer_m"] = float(ell_aquifer); pp["PostMinSpacing_m"] = post_min_spacing
            frames_p.append(pp)
            cb = select_candidates_sequentially_bgas(pool.copy(), sub, ell_aquifer, TOP_CANDIDATES_PER_AQUIFER, post_min_spacing)
            frames_b.append(_finish_candidate_frame(cb, aq, ell_aquifer))
            ce = pool_e.copy()
            if USE_HYDRO_LIMG:
                loo_v = loo_df                                   # R1 [C8]: screened wells of the same aquifer group
                if R1["VGAIN_SAME_AQUIFER"] and loo_df is not None and "Aquifer_group" in loo_df.columns:
                    loo_v = loo_df[loo_df["Aquifer_group"].astype(str).str.strip().str.lower() == aq]
                ce = score_candidate_points_hydro_limg(cand=ce, sub=sub, ell_aquifer=ell_aquifer, loo_remove_df=loo_v)
            ce = select_candidates_sequentially(cand=ce, ell_use=ell_aquifer, min_spacing=post_min_spacing,
                                                max_keep=TOP_CANDIDATES_PER_AQUIFER)
            frames_e.append(_finish_candidate_frame(ce, aq, ell_aquifer))
    crs = g_out.crs
    def _cat(fr):
        if len(fr) == 0:
            return gpd.GeoDataFrame(columns=["geometry"], geometry="geometry", crs=crs)
        return gpd.GeoDataFrame(pd.concat(fr, ignore_index=True), geometry="geometry", crs=crs)
    global LAST_CANDIDATE_POOL
    LAST_CANDIDATE_POOL = _cat(frames_p)
    return _cat(frames_e), _cat(frames_b)


# --- R1 [C0]: restored verbatim from Final5NEW (missing in the FINAL6 file) ---
def compute_adaptive_active_sensing_weights(
    ex_unc, ex_graph_infl, ex_feat, dep_feat, ex_coords, ell_use
):
    p_unc=np.nanmean(ex_unc)
    p_graph=np.nanmean(ex_graph_infl)
    if len(ex_coords)>1:
        tree=cKDTree(ex_coords)
        d,_=tree.query(ex_coords,k=2)
        p_spatial=np.nanmedian(d[:,1])/max(ell_use,1)
    else:
        p_spatial=0.5
    p_repr=np.nanstd(ex_feat)
    p_dep=np.nanstd(dep_feat)
    w_unc=AS_W_UNCERTAINTY_REDUCTION*(1+0.3*(p_unc-0.5))
    w_sup=AS_W_SUPPORT_IMPROVEMENT*(1+0.3*(p_spatial-0.5))
    w_gra=AS_W_GRAPH_IMPROVEMENT*(1+0.3*(p_graph-0.5))
    w_rep=AS_W_REPRESENTATION_GAIN*(1+0.2*(p_repr-0.5))
    w_dep=AS_W_DEPENDENCY_GAIN*(1+0.2*(p_dep-0.5))
    ws=np.array([w_unc,w_sup,w_gra,w_rep,w_dep])
    ws=ws/ws.sum()
    return ws
def build_final_decision_reason(row: pd.Series) -> str:
    favorable = {
        "chloride": row.get("P_keep_chloride_adj", np.nan),
        "distance uniqueness": row.get("P_keep_distance_base", np.nan),
        "information uniqueness": row.get("P_keep_information_base", np.nan),
        "dependency uniqueness": row.get("P_keep_dependency_base", np.nan),
        "graph role": row.get("P_keep_graph_role_base", np.nan),
        "graph influence": row.get("GraphInfluence_score", np.nan),
        "depth representation": row.get("P_keep_depth_adj", np.nan),
        "trend desirability": row.get("P_keep_trend_adj", np.nan),
        "status desirability": row.get("P_keep_status_adj", np.nan),
        "joint quality": row.get("P_keep_joint_quality", np.nan),
    }
    unfavorable = {k: 1.0 - v for k, v in favorable.items() if np.isfinite(v)}
    top_good = top_n_reason_labels(favorable, n=3, descending=True)
    top_bad = top_n_reason_labels(unfavorable, n=3, descending=True)
    is_critical = int(row.get("IsCritical", 0)) == 1
    is_isolated = bool(row.get("Isolated_within_Ell", False))
    dec = str(row.get("FinalDecision", ""))
    parts = []
    if is_critical:
        parts.append("critical protection active")
    if is_isolated:
        parts.append("isolated within Ell")
    if dec == "KEEP":
        if str(row.get("DecisionSource", "")) == "policy_safeguard_keep":
            parts.append("promoted by evidence-aware final safeguard")
        if bool(row.get("IsDeterministicSecondKeepAnchor", False)):
            parts.append("retained as stabilized second cluster anchor")
        if top_good:
            parts.append("strong on " + ", ".join(top_good))
    elif dec == "REVIEW":
        if str(row.get("DecisionSource", "")) == "policy_safeguard_review":
            parts.append("no strong keep evidence in cluster; elevated to review by safeguard")
        if bool(row.get("IsDeterministicSecondKeepAnchor", False)):
            parts.append("stabilized second anchor but sampled utility remained mixed")
        if top_good and top_bad:
            parts.append("mixed evidence: good on " + ", ".join(top_good[:2]) + " but weaker on " + ", ".join(top_bad[:2]))
        elif top_bad:
            parts.append("uncertain / mixed structural role and redundancy")
    elif dec == "CANDIDATE_REMOVE":
        if top_bad:
            parts.append("high redundancy or weaker support on " + ", ".join(top_bad))
        if not is_critical:
            parts.append("not protected by critical rule")
    if len(parts) == 0:
        return "no dominant explanation"
    return "; ".join(parts)
def run(in_path=None, out_dir=None, verbose=True, wells_filter=None):
    """R1 [S2]: in_path/out_dir override the environment paths; wells_filter(g0_m) -> bool mask removes stations
    before the graph is built (used by the hold-out and pseudo-prospective tests); returns the results."""
    global IN_PATH, OUT_DIR
    if in_path is not None:
        IN_PATH = in_path
    if out_dir is not None:
        OUT_DIR = out_dir
    os.makedirs(OUT_DIR, exist_ok=True)
    configure()
    rng = np.random.default_rng(RNG_SEED)
    if verbose:
        print("Reading:", IN_PATH)
    gdf = gpd.read_file(IN_PATH)
    gdf = gdf[gdf.geometry.notnull()].copy()
    gdf = gdf[gdf.geometry.geom_type == "Point"].copy()
    if gdf.crs is None:
        raise ValueError("Input CRS is missing. Please define CRS for the shapefile.")
    for req in [SID_COL, WB_COL]:
        if req not in gdf.columns:
            raise ValueError(f"Missing required column: {req}")
    if COL_RANK in gdf.columns:
        gdf["Rank_final"] = gdf.groupby(SID_COL)[COL_RANK].transform(rank_aggregate_per_sid)
        rank_col_used = "Rank_final"
    else:
        gdf["Rank_final"] = "unknown"
        rank_col_used = "Rank_final"
    g0 = collapse_to_unique_sid_keep_all(gdf, SID_COL)
    if verbose: print("rows before collapse:", len(gdf))
    if verbose: print("unique SID before collapse:", gdf[SID_COL].astype(str).nunique())
    if verbose: print("rows after collapse:", len(g0))
    if verbose: print("unique SID after collapse:", g0[SID_COL].astype(str).nunique())
    assert len(g0) == g0[SID_COL].astype(str).nunique(), "Duplicate SID still exists after collapse"
    g0["Waterbod_1_raw"] = g0[WB_COL].apply(canon_text)
    g0["IsConfinement"] = g0["Waterbod_1_raw"].apply(is_confinement_label) if EXCLUDE_CONFINEMENT else False
    g0["Aquifer_group"] = g0["Waterbod_1_raw"].apply(aquifer_group_from_waterbod1)
    g0["Aquifer_group"] = g0["Aquifer_group"].astype(str).str.strip().str.lower()
    g0["IsCritical"] = g0[rank_col_used].astype(str).str.strip().str.upper().eq("CRITICAL")
    g0["IsCritical_dominant"] = g0[COL_RANK].astype(str).str.strip().str.upper().eq("CRITICAL") if COL_RANK in g0.columns else False
    if R1["CRITICAL_RULE"] == "dominant":           # sensitivity only
        g0["IsCritical"] = g0["IsCritical_dominant"]
    elif R1["CRITICAL_RULE"] == "none":
        g0["IsCritical"] = False
    g0_ll = g0.to_crs(epsg=4326)
    g0["Lat"] = g0_ll.geometry.y
    g0["Lon"] = g0_ll.geometry.x
    g0_m = g0.to_crs(epsg=METRIC_EPSG).copy()
    g0_m["X_m"] = g0_m.geometry.x
    g0_m["Y_m"] = g0_m.geometry.y
    for c in ["Lat", "Lon", "Waterbod_1_raw", "Aquifer_group", "IsConfinement", rank_col_used, "IsCritical"]:
        g0_m[c] = g0[c].values
    eligible = (~g0_m["IsConfinement"].to_numpy(bool)) if EXCLUDE_CONFINEMENT else np.ones(len(g0_m), bool)
    # R1 [D1]: spring vents are a separate station class (not part of the well graph)
    g0_m["IsSpring"] = g0_m["WATERBODY_"].astype(str).str.strip().str.lower().str.startswith("spring") if "WATERBODY_" in g0_m.columns else False
    if R1["SPRINGS_SEPARATE"]:
        g_spr = g0_m[eligible & g0_m["IsSpring"].to_numpy(bool)].copy()
        g_spr.drop(columns="geometry").to_csv(os.path.join(OUT_DIR, "Springs_separate_class.csv"), index=False)
        eligible = eligible & (~g0_m["IsSpring"].to_numpy(bool))
    if wells_filter is not None:
        eligible = eligible & np.asarray(wells_filter(g0_m), bool)
    g_elig = g0_m[eligible].copy()
    g_excl = g0_m[~eligible & g0_m["IsConfinement"].to_numpy(bool)].copy()
    g_excl.drop(columns="geometry").to_csv(
        os.path.join(OUT_DIR, "Excluded_Confinement_FULLINFO_withCoords.csv"),
        index=False
    )
    lookup = pd.DataFrame({
        SID_COL: g_elig[SID_COL].astype(str).values,
        "Aquifer_group": g_elig["Aquifer_group"].astype(str).str.strip().str.lower().values,
        "SID_Lat": g_elig["Lat"].values,
        "SID_Lon": g_elig["Lon"].values,
        "SID_X_m": g_elig["X_m"].values,
        "SID_Y_m": g_elig["Y_m"].values,
    }).drop_duplicates([SID_COL, "Aquifer_group"])
    sid2 = lookup.set_index([SID_COL, "Aquifer_group"])
    aquifer_summary = []
    comp_summary = []
    per_sid_rows = []
    edge_rows = []
    connectivity_rows = []
    g_elig["Component_id"] = -1
    g_elig["Ell_aquifer_m"] = np.nan
    for aq, sub in g_elig.groupby("Aquifer_group"):
        aq = str(aq).strip().lower()
        sub = sub.copy()
        idx_aq = sub.index.to_numpy()
        sids = sub[SID_COL].astype(str).tolist()
        coords = np.vstack([sub["X_m"].values, sub["Y_m"].values]).T
        n = coords.shape[0]
        if n <= 1:
            g_elig.loc[idx_aq, "Component_id"] = 0
            g_elig.loc[idx_aq, "Ell_aquifer_m"] = np.nan
            aquifer_summary.append({
                "Aquifer_group": aq,
                "N_WELLS": int(n),
                "Ell_aquifer_m": np.nan,
                "Ell_method": "too_small_n"
            })
            if n == 1:
                connectivity_rows.append({
                    SID_COL: sids[0],
                    "Aquifer_group": aq,
                    "Isolated_within_Ell": True,
                    "Component_id": 0,
                    "Redundancy_cluster_id": f"{aq}_C0_R0",
                    "Neighbors_n": 0,
                })
            continue
        mst_edges = mst_edges_from_points(coords)
        mst_dists = np.array([e[2] for e in mst_edges], dtype=float)
        cut_val, cut_info = mst_cut_threshold(mst_dists)
        if R1["EDGE_ZONE_FILTER"]:                    # sensitivity: no edge between incompatible hydrostratigraphic zones
            f = R1["EDGE_ZONE_FILTER"]
            zz = sub["Waterbod_1_raw"].astype(str).to_numpy()
            ok = (lambda a, b: a == b) if f == "strict" else f
            mst_edges = [(i, j, d) if ok(zz[i], zz[j]) else (i, j, np.inf) for (i, j, d) in mst_edges]
        uf = UnionFind(n)
        kept_edges = 0
        cut_edges = 0
        for (i, j, d) in mst_edges:
            if np.isfinite(cut_val) and d > cut_val:
                cut_edges += 1
            else:
                uf.union(i, j)
                kept_edges += 1
        comps = sorted(uf.components(), key=len, reverse=True)
        comp_id_arr = np.full(n, -1, dtype=int)
        for cid, members in enumerate(comps):
            for m in members:
                comp_id_arr[m] = cid
        g_elig.loc[idx_aq, "Component_id"] = comp_id_arr
        nn_pool = []
        for cid, members in enumerate(comps):
            members = np.array(members, dtype=int)
            if members.size < 2:
                comp_summary.append({
                    "Aquifer_group": aq,
                    "Component_id": int(cid),
                    "N_in_component": int(members.size),
                    "note": "singleton_component"
                })
                continue
            c_coords = coords[members, :]
            nn = nearest_neighbor_distances(c_coords)
            nn = nn[np.isfinite(nn) & (nn > 0)]
            if nn.size:
                nn_pool.extend(nn.tolist())
            comp_summary.append({
                "Aquifer_group": aq,
                "Component_id": int(cid),
                "N_in_component": int(members.size),
                "note": ""
            })
        if len(nn_pool) == 0:
            ell_aquifer = np.nan
            ell_method = "no_valid_nn_in_components"
        else:
            ell_aquifer = float(np.percentile(np.array(nn_pool, dtype=float), ELL_FROM_NN_PCTL))
            ell_aquifer = max(ELL_MIN_M, min(ell_aquifer, ELL_MAX_M))
            ell_aquifer = round_to(ell_aquifer, ELL_ROUND_TO_M)
            ell_method = f"Ell_aquifer = P{ELL_FROM_NN_PCTL}(NN within MST-cut components)"
        g_elig.loc[idx_aq, "Ell_aquifer_m"] = ell_aquifer
        aquifer_summary.append({
            "Aquifer_group": aq,
            "N_WELLS": int(n),
            "Ell_aquifer_m": float(ell_aquifer) if np.isfinite(ell_aquifer) else np.nan,
            "Ell_method": ell_method,
            "cut_rule": cut_info.get("cut_rule", ""),
            "cut_value": float(cut_info.get("cut_value", np.nan)),
            "mst_edges": int(len(mst_edges)),
            "kept_edges": int(kept_edges),
            "cut_edges": int(cut_edges),
            "N_components": int(len(comps)),
            "AquiferReliability": aquifer_reliability_from_n(n),
        })
        if (not np.isfinite(ell_aquifer)) or ell_aquifer <= 0:
            for i, sid in enumerate(sids):
                connectivity_rows.append({
                    SID_COL: sid,
                    "Aquifer_group": aq,
                    "Isolated_within_Ell": True,
                    "Component_id": int(comp_id_arr[i]),
                    "Redundancy_cluster_id": f"{aq}_C{int(comp_id_arr[i])}_R0",
                    "Neighbors_n": 0,
                })
            continue
        for cid, members in enumerate(comps):
            members = np.array(members, dtype=int)
            c_n = members.size
            c_sids = [sids[i] for i in members]
            c_coords = coords[members, :]
            if c_n < 2:
                connectivity_rows.append({
                    SID_COL: c_sids[0],
                    "Aquifer_group": aq,
                    "Isolated_within_Ell": True,
                    "Component_id": int(cid),
                    "Redundancy_cluster_id": f"{aq}_C{cid}_R0",
                    "Neighbors_n": 0,
                })
                per_sid_rows.append({
                    SID_COL: c_sids[0],
                    "Aquifer_group": aq,
                    "Component_id": int(cid),
                    "Ell_aquifer_m": float(ell_aquifer),
                    "Neighbors_SID_dist": "",
                    "Neighbors_Dist_m_dist": "",
                    "Neighbors_Wdist_dist": "",
                    "Neighbors_Wnorm_dist": "",
                    "Neighbors_n_used": 0,
                    "Neighbors_Wsum": 0.0,
                    "Neighbors_meanDist": np.nan,
                    "Weight_formula": WEIGHT_FORMULA,
                })
                continue
            tree = cKDTree(c_coords)
            pairs = list(tree.query_pairs(r=ell_aquifer))
            uf_red = UnionFind(c_n)
            for (a, b) in pairs:
                uf_red.union(a, b)
            red_comps = uf_red.components()
            red_id_map: Dict[int, int] = {}
            for rid, group in enumerate(sorted(red_comps, key=len, reverse=True)):
                for li in group:
                    red_id_map[li] = rid
            neigh_lists = tree.query_ball_point(c_coords, r=ell_aquifer)
            for ii, inds in enumerate(neigh_lists):
                sid_i = c_sids[ii]
                inds = [jj for jj in inds if jj != ii]
                neigh_sids = [c_sids[jj] for jj in inds]
                if not inds:
                    per_sid_rows.append({
                        SID_COL: sid_i,
                        "Aquifer_group": aq,
                        "Component_id": int(cid),
                        "Ell_aquifer_m": float(ell_aquifer),
                        "Neighbors_SID_dist": "",
                        "Neighbors_Dist_m_dist": "",
                        "Neighbors_Wdist_dist": "",
                        "Neighbors_Wnorm_dist": "",
                        "Neighbors_n_used": 0,
                        "Neighbors_Wsum": 0.0,
                        "Neighbors_meanDist": np.nan,
                        "Weight_formula": WEIGHT_FORMULA,
                    })
                else:
                    di = np.linalg.norm(c_coords[inds] - c_coords[ii], axis=1)
                    wdist = [math.exp(-float(d) / ell_aquifer) for d in di]
                    wsum = float(np.sum(wdist)) if len(wdist) else 0.0
                    wnorm = [(w / wsum) if wsum > 0 else np.nan for w in wdist]
                    order = np.argsort(-np.array(wdist))
                    neigh_sids2 = [neigh_sids[k] for k in order]
                    di2 = [float(di[k]) for k in order]
                    wdist2 = [float(wdist[k]) for k in order]
                    wnorm2 = [float(wnorm[k]) for k in order]
                    per_sid_rows.append({
                        SID_COL: sid_i,
                        "Aquifer_group": aq,
                        "Component_id": int(cid),
                        "Ell_aquifer_m": float(ell_aquifer),
                        "Neighbors_SID_dist": pipe_join(neigh_sids2),
                        "Neighbors_Dist_m_dist": pipe_join(di2, fmt=lambda x: f"{x:.3f}"),
                        "Neighbors_Wdist_dist": pipe_join(wdist2, fmt=lambda x: f"{x:.6f}"),
                        "Neighbors_Wnorm_dist": pipe_join(wnorm2, fmt=lambda x: f"{x:.6f}"),
                        "Neighbors_n_used": int(len(neigh_sids2)),
                        "Neighbors_Wsum": float(wsum),
                        "Neighbors_meanDist": float(np.mean(di2)) if len(di2) else np.nan,
                        "Weight_formula": WEIGHT_FORMULA,
                    })
                    for sid_j, d, w in zip(neigh_sids2, di2, wdist2):
                        key_i = (str(sid_i), aq)
                        key_j = (str(sid_j), aq)
                        if key_i in sid2.index and key_j in sid2.index:
                            edge_rows.append({
                                "Aquifer_group": aq,
                                "Component_id": int(cid),
                                "Ell_aquifer_m": float(ell_aquifer),
                                "Method": "MSTCut_components + singleEll_aquifer + neighbors_within_component",
                                SID_COL: sid_i,
                                "Neighbor_SID": sid_j,
                                "Distance_m": float(d),
                                "Weight_dist": float(w),
                                "SID_Lat": float(sid2.loc[key_i, "SID_Lat"]),
                                "SID_Lon": float(sid2.loc[key_i, "SID_Lon"]),
                                "SID_X_m": float(sid2.loc[key_i, "SID_X_m"]),
                                "SID_Y_m": float(sid2.loc[key_i, "SID_Y_m"]),
                                "Neighbor_Lat": float(sid2.loc[key_j, "SID_Lat"]),
                                "Neighbor_Lon": float(sid2.loc[key_j, "SID_Lon"]),
                                "Neighbor_X_m": float(sid2.loc[key_j, "SID_X_m"]),
                                "Neighbor_Y_m": float(sid2.loc[key_j, "SID_Y_m"]),
                            })
                connectivity_rows.append({
                    SID_COL: sid_i,
                    "Aquifer_group": aq,
                    "Isolated_within_Ell": (len(inds) == 0),
                    "Component_id": int(cid),
                    "Redundancy_cluster_id": f"{aq}_C{cid}_R{int(red_id_map.get(ii, 0))}",
                    "Neighbors_n": int(len(inds)),
                })
    pd.DataFrame(aquifer_summary).to_csv(os.path.join(OUT_DIR, "Aquifer_Ell_single_summary.csv"), index=False)
    pd.DataFrame(comp_summary).to_csv(os.path.join(OUT_DIR, "Components_summary.csv"), index=False)
    per_sid_df = pd.DataFrame(per_sid_rows)
    per_sid_df.to_csv(os.path.join(OUT_DIR, "Neighbors_perSID_singleEll_withCoords.csv"), index=False)
    edges_df = pd.DataFrame(edge_rows)
    edges_df.to_csv(os.path.join(OUT_DIR, "Edges_singleEll_withCoords.csv"), index=False)
    conn_df = pd.DataFrame(connectivity_rows)
    conn_df.to_csv(os.path.join(OUT_DIR, "Connectivity_only_perSID.csv"), index=False)
    g_out = g_elig.copy()
    g_out[SID_COL] = g_out[SID_COL].astype(str)
    g_out["Aquifer_group"] = g_out["Aquifer_group"].astype(str).str.strip().str.lower()
    g_out["Aquifer_N"] = g_out.groupby("Aquifer_group")[SID_COL].transform("count")
    g_out["AquiferReliability"] = g_out["Aquifer_N"].apply(aquifer_reliability_from_n)

    if not conn_df.empty:
        conn_df[SID_COL] = conn_df[SID_COL].astype(str)
        conn_df["Aquifer_group"] = conn_df["Aquifer_group"].astype(str).str.strip().str.lower()
        g_out = g_out.merge(
            conn_df[[SID_COL, "Aquifer_group", "Isolated_within_Ell", "Redundancy_cluster_id", "Neighbors_n"]],
            on=[SID_COL, "Aquifer_group"],
            how="left"
        )

    # --- NON-AI MERGE FIX: avoid duplicate Component_id / Ell_aquifer_m before second merge ---
    g_out = g_out.drop(columns=["Component_id", "Ell_aquifer_m"], errors="ignore")

    if not per_sid_df.empty:
        per_sid_df[SID_COL] = per_sid_df[SID_COL].astype(str)
        per_sid_df["Aquifer_group"] = per_sid_df["Aquifer_group"].astype(str).str.strip().str.lower()

        keep_cols = [
            SID_COL, "Aquifer_group",
            "Component_id", "Ell_aquifer_m",
            "Neighbors_n_used", "Neighbors_Wsum", "Neighbors_meanDist"
        ]
        keep_cols = [c for c in keep_cols if c in per_sid_df.columns]

        g_out = g_out.merge(
            per_sid_df[keep_cols],
            on=[SID_COL, "Aquifer_group"],
            how="left"
        )

    g_out["Aquifer_group"] = g_out["Aquifer_group"].astype(str).str.strip().str.lower()
    g_out["Isolated_within_Ell"] = g_out["Isolated_within_Ell"].fillna(False).astype(bool)
    g_out["Redundancy_cluster_id"] = g_out["Redundancy_cluster_id"].fillna("NA").astype(str)

    if "Component_id" in g_out.columns:
        g_out["Component_id"] = pd.to_numeric(g_out["Component_id"], errors="coerce").fillna(-1).astype(int)

    if "Ell_aquifer_m" in g_out.columns:
        g_out["Ell_aquifer_m"] = pd.to_numeric(g_out["Ell_aquifer_m"], errors="coerce")

    g_out["Neighbors_n_used"] = pd.to_numeric(g_out.get("Neighbors_n_used", 0), errors="coerce").fillna(0).astype(int)
    g_out["Neighbors_Wsum"] = pd.to_numeric(g_out.get("Neighbors_Wsum", 0), errors="coerce").fillna(0.0).astype(float)
    g_out["Neighbors_meanDist"] = pd.to_numeric(g_out.get("Neighbors_meanDist", np.nan), errors="coerce")

    g_out["Neighbors_n"] = pd.to_numeric(
        g_out.get("Neighbors_n", 0),
        errors="coerce"
    ).fillna(0).astype(int)

    if "Ell_aquifer_m" not in g_out.columns:
        raise ValueError("Ell_aquifer_m was not built correctly.")

    g_out = g_out.reset_index(drop=True)
    p_chl_base, p_chl_unc = compute_chloride_keep(g_out[COL_CHL], g_out["Aquifer_group"], threshold=CHL_THRESHOLD) if COL_CHL in g_out.columns else (np.full(len(g_out), 0.5), np.full(len(g_out), 0.45))
    p_status_base, p_status_unc = compute_status_keep(g_out[COL_STATUS]) if COL_STATUS in g_out.columns else (np.full(len(g_out), 0.55), np.full(len(g_out), 0.35))
    p_trend_base, p_trend_unc = compute_trend_keep(g_out[COL_TREND], g_out["Aquifer_group"]) if COL_TREND in g_out.columns else (np.full(len(g_out), 0.55), np.full(len(g_out), 0.40))
    p_depth_base, p_depth_unc, depth_missing_flag = compute_depth_keep(g_out[COL_DEPTH], g_out["Aquifer_group"]) if COL_DEPTH in g_out.columns else (np.full(len(g_out), 0.5), np.full(len(g_out), 0.45), np.ones(len(g_out), dtype=int))
    p_dist_base, p_dist_unc = score_distance_keep_clusterwise(g_out)
    p_dist_base, p_dist_unc = apply_aquifer_reliability_adjustment(g_out, p_dist_base, p_dist_unc, "distance", unc_extra=0.12)
    g_out["P_keep_chloride_base"] = p_chl_base
    g_out["P_keep_chloride_unc"] = p_chl_unc
    g_out["P_keep_status_base"] = p_status_base
    g_out["P_keep_status_unc"] = p_status_unc
    g_out["P_keep_trend_base"] = p_trend_base
    g_out["P_keep_trend_unc"] = p_trend_unc
    g_out["P_keep_depth_base"] = p_depth_base
    g_out["P_keep_depth_unc"] = p_depth_unc
    g_out["Depth_missing_imputed"] = depth_missing_flag.astype(int)
    g_out["P_keep_distance_base"] = p_dist_base
    g_out["P_keep_distance_unc"] = p_dist_unc
    g_out = build_feature_columns(
        g_out, p_chl_base=p_chl_base, p_trend_base=p_trend_base, p_status_base=p_status_base,
    )
    p_info_base_raw, p_info_unc = compute_information_keep_clusterwise(g_out)
    p_info_base_raw, p_info_unc = apply_aquifer_reliability_adjustment(g_out, p_info_base_raw, p_info_unc, "information", unc_extra=0.15)
    p_info_base = deovercount_score_against_reference(
        p_info_base_raw, p_dist_base, strength=INFO_VS_DISTANCE_DEOVERCOUNT_STRENGTH
    )
    p_info_unc = boost_uncertainty_from_overlap(
        p_info_base_raw, p_dist_base, p_info_unc, max_boost=INFO_OVERLAP_UNC_BOOST
    )
    g_out["P_keep_information_raw"] = p_info_base_raw
    g_out["P_keep_information_base"] = p_info_base
    g_out["P_keep_information_unc"] = p_info_unc
    p_dep_base_raw, p_dep_unc, dep_edges_df = compute_dependency_keep_clusterwise(g_out)
    p_dep_base_raw, p_dep_unc = apply_aquifer_reliability_adjustment(g_out, p_dep_base_raw, p_dep_unc, "dependency", unc_extra=0.15)
    dep_reference = 0.60 * p_info_base + 0.40 * p_dist_base
    p_dep_base = deovercount_score_against_reference(
        p_dep_base_raw, dep_reference, strength=DEP_VS_BACKBONE_DEOVERCOUNT_STRENGTH
    )
    p_dep_unc = boost_uncertainty_from_overlap(
        p_dep_base_raw, dep_reference, p_dep_unc, max_boost=DEP_OVERLAP_UNC_BOOST
    )
    g_out["P_keep_dependency_raw"] = p_dep_base_raw
    g_out["P_keep_dependency_base"] = p_dep_base
    g_out["P_keep_dependency_unc"] = p_dep_unc
    p_graph_base_raw, p_graph_unc, graph_diag_df = compute_graph_role_keep_clusterwise(g_out)
    p_graph_base_raw, p_graph_unc = apply_aquifer_reliability_adjustment(g_out, p_graph_base_raw, p_graph_unc, "graph_role", unc_extra=0.15)
    graph_reference = 0.45 * p_dep_base + 0.35 * p_info_base + 0.20 * p_dist_base
    p_graph_base = deovercount_score_against_reference(
        p_graph_base_raw, graph_reference, strength=GRAPH_VS_BACKBONE_DEOVERCOUNT_STRENGTH
    )
    p_graph_unc = boost_uncertainty_from_overlap(
        p_graph_base_raw, graph_reference, p_graph_unc, max_boost=GRAPH_OVERLAP_UNC_BOOST
    )
    for c in graph_diag_df.columns:
        g_out[c] = graph_diag_df[c].to_numpy()
    g_out["P_keep_graph_role_raw"] = p_graph_base_raw
    g_out["P_keep_graph_role_base"] = p_graph_base
    g_out["P_keep_graph_role_unc"] = p_graph_unc
    # B4.9: Graph Influence Analysis (diagnostic)
    graph_infl_df = compute_graph_influence_analysis(g_out)
    for c in graph_infl_df.columns:
        g_out[c] = graph_infl_df[c].to_numpy()
    g_out["NetworkOverlap_info_vs_distance"] = np.clip(1.0 - np.abs(p_info_base_raw - p_dist_base), 0, 1)
    g_out["NetworkOverlap_dep_vs_backbone"] = np.clip(1.0 - np.abs(p_dep_base_raw - dep_reference), 0, 1)
    g_out["NetworkOverlap_graph_vs_backbone"] = np.clip(1.0 - np.abs(p_graph_base_raw - graph_reference), 0, 1)
    dep = apply_bayesian_dependency_layer(
        p_chl=p_chl_base, u_chl=p_chl_unc,
        p_trend=p_trend_base, u_trend=p_trend_unc,
        p_status=p_status_base, u_status=p_status_unc,
        p_depth=p_depth_base, u_depth=p_depth_unc,
    )
    for k, v in dep.items():
        g_out[k] = v
    entropy_w = entropy_weights_from_components(g_out)
    if verbose: print("Entropy-derived weights (B4.9-GRAPH-AWARE-ACTIVE-SENSING):")
    if verbose: print(entropy_w)
    for k, v in entropy_w.items():
        g_out[f"W_{k}"] = float(v)
    g_out["UtilityDeterministic_keep"] = weighted_keep_utility(
        g_out["P_keep_chloride_adj"].to_numpy(),
        g_out["P_keep_distance_base"].to_numpy(),
        g_out["P_keep_information_base"].to_numpy(),
        g_out["P_keep_dependency_base"].to_numpy(),
        g_out["P_keep_graph_role_base"].to_numpy(),
        g_out["P_keep_depth_adj"].to_numpy(),
        g_out["P_keep_trend_adj"].to_numpy(),
        g_out["P_keep_status_adj"].to_numpy(),
        g_out["P_keep_joint_quality"].to_numpy(),
        entropy_w,
    )
    n = len(g_out)
    iso_mask = g_out["Isolated_within_Ell"].to_numpy(bool)
    aq_arr = g_out["Aquifer_group"].astype(str).to_numpy()
    rid_arr = g_out["Redundancy_cluster_id"].astype(str).to_numpy()
    critical_mask = g_out["IsCritical"].to_numpy(dtype=bool)
    group_map = {}
    for i in range(n):
        if iso_mask[i]:
            continue
        key = (aq_arr[i], rid_arr[i])
        group_map.setdefault(key, []).append(i)
    x_all = pd.to_numeric(g_out["X_m"], errors="coerce").to_numpy(dtype=float)
    y_all = pd.to_numeric(g_out["Y_m"], errors="coerce").to_numpy(dtype=float)
    ell_all = pd.to_numeric(g_out["Ell_aquifer_m"], errors="coerce").to_numpy(dtype=float)
    cluster_meta = {}
    g_out["IsDeterministicSecondKeepAnchor"] = False
    g_out["SecondKeepAnchorSoftPolicy"] = ""
    g_out["SecondAnchorStabilityScore"] = np.nan
    for (aq, rid), idxs in group_map.items():
        idxs_arr = np.array(idxs, dtype=int)
        if (rid == "NA") or (len(idxs_arr) <= 1):
            cluster_meta[(aq, rid)] = {
                "allow_second_keep": False,
                "cluster_n": len(idxs_arr),
                "extent_ratio": 0.0,
                "heterogeneity": 0.0,
                "second_anchor_idx": None,
            }
            continue
        coords = np.column_stack([x_all[idxs_arr], y_all[idxs_arr]])
        ell_grp = np.nanmedian(ell_all[idxs_arr])
        if not np.isfinite(ell_grp) or ell_grp <= 0:
            ell_grp = ELL_MIN_M
        extent_ratio = cluster_pairwise_max_distance(coords) / max(ell_grp, 1e-9)
        heterogeneity = float(np.nanmean([
            np.nanstd(pd.to_numeric(g_out.loc[idxs_arr, "P_keep_information_base"], errors="coerce").to_numpy(dtype=float)),
            np.nanstd(pd.to_numeric(g_out.loc[idxs_arr, "P_keep_dependency_base"], errors="coerce").to_numpy(dtype=float)),
            np.nanstd(pd.to_numeric(g_out.loc[idxs_arr, "P_keep_graph_role_base"], errors="coerce").to_numpy(dtype=float)),
            np.nanstd(pd.to_numeric(g_out.loc[idxs_arr, "P_keep_depth_adj"], errors="coerce").to_numpy(dtype=float)),
            np.nanstd(pd.to_numeric(g_out.loc[idxs_arr, "P_keep_chloride_adj"], errors="coerce").to_numpy(dtype=float)),
        ]))
        allow_second_keep = (
            (len(idxs_arr) >= SECOND_KEEP_MIN_CLUSTER_N)
            and (
                (extent_ratio >= SECOND_KEEP_MIN_EXTENT_RATIO)
                or (heterogeneity >= SECOND_KEEP_MIN_HETEROGENEITY)
            )
        )
        second_anchor_idx: Optional[int] = None
        if allow_second_keep:
            local_util_mean = g_out.loc[idxs_arr, "UtilityDeterministic_keep"].to_numpy(dtype=float)
            order = idxs_arr[np.argsort(-local_util_mean)]
            best_local = int(order[0])
            best_util = float(g_out.loc[best_local, "UtilityDeterministic_keep"])
            det_candidates = []
            for i_idx in order[1:]:
                close_to_best = float(g_out.loc[i_idx, "UtilityDeterministic_keep"]) >= (best_util - SECOND_KEEP_UTILITY_GAP)
                high_enough = float(g_out.loc[i_idx, "UtilityDeterministic_keep"]) >= SECOND_KEEP_MIN_UTILITY
                structural_value = (
                    (float(g_out.loc[i_idx, "P_keep_information_base"]) >= SECOND_KEEP_MIN_INFO)
                    or (float(g_out.loc[i_idx, "P_keep_graph_role_base"]) >= SECOND_KEEP_MIN_GRAPH)
                )
                if close_to_best and high_enough and structural_value:
                    det_candidates.append(int(i_idx))
            if len(det_candidates) > 0:
                for ii in det_candidates:
                    g_out.loc[ii, "SecondAnchorStabilityScore"] = second_anchor_stability_score(g_out, ii)
                second_anchor_idx = max(
                    det_candidates,
                    key=lambda ii: (
                        second_anchor_stability_score(g_out, ii),
                        float(g_out.loc[ii, "UtilityDeterministic_keep"]),
                        float(g_out.loc[ii, "P_keep_graph_role_base"]),
                        float(g_out.loc[ii, "P_keep_information_base"]),
                        -mean_component_uncertainty_for_idx(g_out, ii),
                    )
                )
                g_out.loc[second_anchor_idx, "IsDeterministicSecondKeepAnchor"] = True
                g_out.loc[second_anchor_idx, "SecondKeepAnchorSoftPolicy"] = "soft_keep_or_review"
        cluster_meta[(aq, rid)] = {
            "allow_second_keep": bool(allow_second_keep),
            "cluster_n": int(len(idxs_arr)),
            "extent_ratio": float(extent_ratio),
            "heterogeneity": float(heterogeneity),
            "second_anchor_idx": second_anchor_idx,
        }
    keep_ct = np.zeros(n, dtype=int)
    review_ct = np.zeros(n, dtype=int)
    remove_ct = np.zeros(n, dtype=int)
    util_sum = np.zeros(n, dtype=float)
    g_out["SecondAnchor_keep_count"] = 0
    g_out["SecondAnchor_review_count"] = 0
    for _ in range(N_MC):
        s_chl = sample_beta_from_mean_uncertainty(g_out["P_keep_chloride_adj"].to_numpy(), g_out["P_keep_chloride_adj_unc"].to_numpy(), rng)
        s_dist = sample_beta_from_mean_uncertainty(g_out["P_keep_distance_base"].to_numpy(), g_out["P_keep_distance_unc"].to_numpy(), rng)
        s_info = sample_beta_from_mean_uncertainty(g_out["P_keep_information_base"].to_numpy(), g_out["P_keep_information_unc"].to_numpy(), rng)
        s_dep = sample_beta_from_mean_uncertainty(g_out["P_keep_dependency_base"].to_numpy(), g_out["P_keep_dependency_unc"].to_numpy(), rng)
        s_graph = sample_beta_from_mean_uncertainty(g_out["P_keep_graph_role_base"].to_numpy(), g_out["P_keep_graph_role_unc"].to_numpy(), rng)
        s_depth = sample_beta_from_mean_uncertainty(g_out["P_keep_depth_adj"].to_numpy(), g_out["P_keep_depth_adj_unc"].to_numpy(), rng)
        s_trend = sample_beta_from_mean_uncertainty(g_out["P_keep_trend_adj"].to_numpy(), g_out["P_keep_trend_adj_unc"].to_numpy(), rng)
        s_status = sample_beta_from_mean_uncertainty(g_out["P_keep_status_adj"].to_numpy(), g_out["P_keep_status_adj_unc"].to_numpy(), rng)
        s_joint = sample_beta_from_mean_uncertainty(g_out["P_keep_joint_quality"].to_numpy(), g_out["P_keep_joint_quality_unc"].to_numpy(), rng)
        util = weighted_keep_utility(
            s_chl, s_dist, s_info, s_dep, s_graph, s_depth, s_trend, s_status, s_joint, entropy_w
        )
        util_sum += util
        dec_keep = np.zeros(n, dtype=bool)
        dec_review = np.zeros(n, dtype=bool)
        dec_remove = np.zeros(n, dtype=bool)
        for i in np.where(iso_mask)[0]:
            if float(util[i]) < ISO_REVIEW_THRESHOLD:
                dec_review[i] = True
            else:
                dec_keep[i] = True
        for (aq, rid), idxs in group_map.items():
            if (rid == "NA") or (len(idxs) <= 1):
                for i in idxs:
                    dec_keep[i] = True
                continue
            idxs_arr = np.array(idxs, dtype=int)
            local_util = util[idxs_arr]
            best_local = idxs_arr[np.argmax(local_util)]
            keep_set = {int(best_local)}
            review_set = set()
            meta = cluster_meta.get((aq, rid), {})
            second_anchor_idx = meta.get("second_anchor_idx", None)
            if second_anchor_idx is not None and int(second_anchor_idx) != int(best_local):
                u2 = float(util[second_anchor_idx])
                if u2 >= SECOND_KEEP_SOFT_KEEP_FLOOR:
                    keep_set.add(int(second_anchor_idx))
                elif u2 >= SECOND_KEEP_SOFT_REVIEW_FLOOR:
                    review_set.add(int(second_anchor_idx))
            for i in idxs_arr:
                if i in keep_set:
                    dec_keep[i] = True
                    continue
                if i in review_set:
                    dec_review[i] = True
                    continue
                if float(util[i]) >= REVIEW_THRESHOLD:
                    dec_review[i] = True
                else:
                    if critical_mask[i]:
                        dec_review[i] = True
                    else:
                        dec_remove[i] = True
            if second_anchor_idx is not None and int(second_anchor_idx) != int(best_local):
                if dec_keep[int(second_anchor_idx)]:
                    g_out.loc[int(second_anchor_idx), "SecondAnchor_keep_count"] += 1
                elif dec_review[int(second_anchor_idx)]:
                    g_out.loc[int(second_anchor_idx), "SecondAnchor_review_count"] += 1
        keep_ct += dec_keep.astype(int)
        review_ct += dec_review.astype(int)
        remove_ct += dec_remove.astype(int)
    g_out["UtilityScore_mean"] = util_sum / float(N_MC)
    g_out["Prob_KEEP"] = keep_ct / float(N_MC)
    g_out["Prob_REVIEW"] = review_ct / float(N_MC)
    g_out["Prob_CANDIDATE_REMOVE"] = remove_ct / float(N_MC)
    g_out["SecondAnchor_keep_prob"] = g_out["SecondAnchor_keep_count"] / float(N_MC)
    g_out["SecondAnchor_review_prob"] = g_out["SecondAnchor_review_count"] / float(N_MC)
    g_out["FinalDecision_preSafeguard"] = [
        final_label_from_probs(pk, pr, prem)
        for pk, pr, prem in zip(
            g_out["Prob_KEEP"], g_out["Prob_REVIEW"], g_out["Prob_CANDIDATE_REMOVE"]
        )
    ]
    g_out = calibrate_pre_safeguard_decisions(g_out)
    g_out["FinalDecision"] = g_out["FinalDecision_preSafeguard"].copy()
    g_out["PolicyKeepReason"] = "none"
    g_out["DecisionConfidence"] = [
        confidence_class(pk, pr, prem)
        for pk, pr, prem in zip(
            g_out["Prob_KEEP"], g_out["Prob_REVIEW"], g_out["Prob_CANDIDATE_REMOVE"]
        )
    ]
    cluster_df_pre = g_out.loc[
        ~g_out["Isolated_within_Ell"],
        ["Aquifer_group", "Redundancy_cluster_id", "FinalDecision_preSafeguard"]
    ].copy()
    if len(cluster_df_pre) > 0:
        cluster_keep_counts_pre = (
            cluster_df_pre.assign(is_keep=cluster_df_pre["FinalDecision_preSafeguard"].eq("KEEP").astype(int))
            .groupby(["Aquifer_group", "Redundancy_cluster_id"], dropna=False)["is_keep"]
            .sum()
            .reset_index()
        )
        n_clusters_total_pre = int(len(cluster_keep_counts_pre))
        n_clusters_with_keep_pre = int((cluster_keep_counts_pre["is_keep"] >= 1).sum())
        n_clusters_without_keep_pre = int((cluster_keep_counts_pre["is_keep"] == 0).sum())
    else:
        n_clusters_total_pre = 0
        n_clusters_with_keep_pre = 0
        n_clusters_without_keep_pre = 0
    g_out = apply_postfinal_cluster_keep_safeguard(g_out, group_map)
    # === INFORMATION STABILITY INDEX (must run BEFORE hard resolve) ===
    g_out = add_information_stability_index(g_out)
    # === HARD FINAL RESOLVER (REVISED - evidence consensus voting) ===
    g_out = resolve_remaining_reviews(g_out)
    g_out["DecisionSource"] = "probabilistic_evidence"
    g_out.loc[g_out["PolicyKeepReason"].eq("postfinal_cluster_safeguard_keep"), "DecisionSource"] = "policy_safeguard_keep"
    g_out.loc[g_out["PolicyKeepReason"].eq(SAFEGUARD_REVIEW_LABEL), "DecisionSource"] = "policy_safeguard_review"
    g_out["FinalDecisionEvidence"] = g_out["FinalDecision_preSafeguard"]
    g_out["Rank_final"] = g_out[rank_col_used].astype(str)
    g_out["IsCritical"] = g_out["IsCritical"].astype(int)
    g_out["ClusterAllowSecondKeep"] = False
    g_out["ClusterExtentRatio"] = np.nan
    g_out["ClusterHeterogeneity"] = np.nan
    g_out["ClusterSecondKeepAnchor"] = ""
    for (aq, rid), idxs in group_map.items():
        meta = cluster_meta.get((aq, rid), {})
        idxs_arr = np.array(idxs, dtype=int)
        g_out.loc[idxs_arr, "ClusterAllowSecondKeep"] = bool(meta.get("allow_second_keep", False))
        g_out.loc[idxs_arr, "ClusterExtentRatio"] = float(meta.get("extent_ratio", np.nan))
        g_out.loc[idxs_arr, "ClusterHeterogeneity"] = float(meta.get("heterogeneity", np.nan))
        second_anchor_idx = meta.get("second_anchor_idx", None)
        if second_anchor_idx is not None:
            g_out.loc[idxs_arr, "ClusterSecondKeepAnchor"] = str(g_out.loc[second_anchor_idx, SID_COL])
    g_out["FinalDecisionReason"] = g_out.apply(build_final_decision_reason, axis=1)

    # validation table used both for reporting and candidate augmentation
    loo_df = leave_one_out_remove_validation(g_out, value_col=COL_CHL)

    # attach coordinates for validation-aware candidate scoring
    if (SID_COL in loo_df.columns) and (SID_COL in g_out.columns) and ("X_m" in g_out.columns) and ("Y_m" in g_out.columns):
        loo_df = loo_df.merge(
            g_out[[SID_COL, "X_m", "Y_m"]].drop_duplicates(subset=[SID_COL]),
            on=SID_COL,
            how="left"
        )
    else:
        loo_df["X_m"] = np.nan
        loo_df["Y_m"] = np.nan

    g_out["FinalDecision_BGAS"] = g_out["FinalDecision"].astype(str)      # R1: B-GAS screening outcome
    if USE_REMOVE_RISK_SAFEGUARD and len(loo_df) > 0:
        loo_map = loo_df[[SID_COL, "AbsError_without_well"]].drop_duplicates(subset=[SID_COL]).copy()
        g_out = g_out.merge(loo_map, on=SID_COL, how="left")

        loo_thr = float(loo_df["AbsError_without_well"].quantile(REMOVE_RISK_LOO_Q)) if loo_df["AbsError_without_well"].notna().any() else np.inf

        mask_rescue = (
            g_out["FinalDecision"].eq("CANDIDATE_REMOVE")
            & (
                (pd.to_numeric(g_out["AbsError_without_well"], errors="coerce") >= loo_thr)
                | (pd.to_numeric(g_out["GraphInfluence_score"], errors="coerce") >= REMOVE_RISK_GRAPH_THR)
                | (pd.to_numeric(g_out["P_keep_chloride_adj"], errors="coerce") >= REMOVE_RISK_CHL_THR)
            )
        )

        g_out.loc[mask_rescue, "FinalDecision"] = "REVIEW"
        g_out.loc[mask_rescue, "DecisionSource"] = "remove_risk_safeguard"
        g_out["Safeguard_LOO_threshold"] = loo_thr                       # R1: criterion-level record
        g_out["Safeguard_trig_LOO"] = g_out["FinalDecision_BGAS"].eq("CANDIDATE_REMOVE") & (pd.to_numeric(g_out["AbsError_without_well"], errors="coerce") >= loo_thr)
        g_out["Safeguard_trig_SGI"] = g_out["FinalDecision_BGAS"].eq("CANDIDATE_REMOVE") & (pd.to_numeric(g_out["GraphInfluence_score"], errors="coerce") >= REMOVE_RISK_GRAPH_THR)
        g_out["Safeguard_trig_CHL"] = g_out["FinalDecision_BGAS"].eq("CANDIDATE_REMOVE") & (pd.to_numeric(g_out["P_keep_chloride_adj"], errors="coerce") >= REMOVE_RISK_CHL_THR)

    cand_gdf, cand_gdf_b = generate_candidates_r1(g_out, loo_df)   # R1 [S1]
    if verbose: print("final rows entering summary:", len(g_out))
    if verbose: print("final unique SID entering summary:", g_out[SID_COL].astype(str).nunique())
    assert len(g_out) == g_out[SID_COL].astype(str).nunique(), "Duplicate SID reintroduced before final summary"
    val_rows = []
    keep_mask = g_out["FinalDecision"] == "KEEP"
    review_mask = g_out["FinalDecision"] == "REVIEW"
    remove_mask = g_out["FinalDecision"] == "CANDIDATE_REMOVE"
    n_critical_remove = int(((g_out["IsCritical"] == 1) & remove_mask).sum())
    cluster_df_val = g_out.loc[~g_out["Isolated_within_Ell"], ["Aquifer_group", "Redundancy_cluster_id", "FinalDecision"]].copy()
    if len(cluster_df_val) > 0:
        cluster_keep_counts = (
            cluster_df_val.assign(is_keep=cluster_df_val["FinalDecision"].eq("KEEP").astype(int))
            .groupby(["Aquifer_group", "Redundancy_cluster_id"], dropna=False)["is_keep"]
            .sum()
            .reset_index()
        )
        n_clusters_total = int(len(cluster_keep_counts))
        n_clusters_with_keep = int((cluster_keep_counts["is_keep"] >= 1).sum())
        n_clusters_with_two_keep = int((cluster_keep_counts["is_keep"] >= 2).sum())
        n_clusters_without_keep = int((cluster_keep_counts["is_keep"] == 0).sum())
    else:
        n_clusters_total = 0
        n_clusters_with_keep = 0
        n_clusters_with_two_keep = 0
        n_clusters_without_keep = 0
    aq_before = g_out.groupby("Aquifer_group").size().rename("n_before")
    aq_keep = g_out.loc[keep_mask].groupby("Aquifer_group").size().rename("n_keep")
    aq_review = g_out.loc[review_mask].groupby("Aquifer_group").size().rename("n_review")
    aq_remove = g_out.loc[remove_mask].groupby("Aquifer_group").size().rename("n_remove")
    aq_val = pd.concat([aq_before, aq_keep, aq_review, aq_remove], axis=1).fillna(0).reset_index()
    aq_val.to_csv(os.path.join(OUT_DIR, "Validation_Aquifer_BeforeAfter.csv"), index=False)
    depth_cov_rows = []
    if COL_DEPTH in g_out.columns:
        for aq in sorted(g_out["Aquifer_group"].dropna().astype(str).unique()):
            sub_all = g_out[g_out["Aquifer_group"].astype(str) == aq].copy()
            sub_keep = sub_all[sub_all["FinalDecision"] == "KEEP"].copy()
            d_all = pd.to_numeric(sub_all[COL_DEPTH], errors="coerce").mask(pd.to_numeric(sub_all[COL_DEPTH], errors="coerce") <= 0, np.nan)
            d_keep = pd.to_numeric(sub_keep[COL_DEPTH], errors="coerce").mask(pd.to_numeric(sub_keep[COL_DEPTH], errors="coerce") <= 0, np.nan)
            depth_cov_rows.append({
                "Aquifer_group": aq,
                "n_depth_nonmissing_before": int(d_all.notna().sum()),
                "n_depth_nonmissing_keep": int(d_keep.notna().sum()),
                "AquiferReliability": float(aquifer_reliability_from_n(len(sub_all))),
                "n_imputed_or_zero_before": int((pd.to_numeric(sub_all[COL_DEPTH], errors="coerce") <= 0).fillna(False).sum()) if len(sub_all) > 0 else 0,
            })
    pd.DataFrame(depth_cov_rows).to_csv(os.path.join(OUT_DIR, "Validation_DepthCoverage_BeforeAfter.csv"), index=False)
    if len(cand_gdf) > 0:
        cand_summary = (
            cand_gdf.groupby("Aquifer_group")["CandidateScore"]
            .agg(["count", "max", "mean"])
            .reset_index()
            .rename(columns={"count": "n_candidates", "max": "top_candidate_score", "mean": "mean_candidate_score"})
        )
        cand_summary.to_csv(os.path.join(OUT_DIR, "CandidateWell_Summary_byAquifer.csv"), index=False)
    else:
        pd.DataFrame(columns=["Aquifer_group", "n_candidates", "top_candidate_score", "mean_candidate_score"]).to_csv(
            os.path.join(OUT_DIR, "CandidateWell_Summary_byAquifer.csv"), index=False
        )
    cluster_consistency_rows = [{
        "n_clusters_total_pre_safeguard": n_clusters_total_pre,
        "n_clusters_with_keep_pre_safeguard": n_clusters_with_keep_pre,
        "n_clusters_without_keep_pre_safeguard": n_clusters_without_keep_pre,
        "n_clusters_total_final": n_clusters_total,
        "n_clusters_with_keep_final": n_clusters_with_keep,
        "n_clusters_without_keep_final": n_clusters_without_keep,
        "n_postfinal_cluster_promotions": int(g_out["PostFinalClusterSafeguard"].sum()),
        "n_policy_safeguard_review_only": int(g_out["PolicyKeepReason"].eq(SAFEGUARD_REVIEW_LABEL).sum()),
        "n_unresolved_policy_clusters": int(g_out.groupby(["Aquifer_group", "Redundancy_cluster_id"], dropna=False)["ClusterSafeguardUnresolved"].max().sum()),
        "n_deterministic_second_keep_anchors": int(g_out["IsDeterministicSecondKeepAnchor"].sum()),
        "mean_second_anchor_keep_prob": float(g_out.loc[g_out["IsDeterministicSecondKeepAnchor"], "SecondAnchor_keep_prob"].mean()) if g_out["IsDeterministicSecondKeepAnchor"].any() else np.nan,
        "mean_second_anchor_review_prob": float(g_out.loc[g_out["IsDeterministicSecondKeepAnchor"], "SecondAnchor_review_prob"].mean()) if g_out["IsDeterministicSecondKeepAnchor"].any() else np.nan,
        "mean_second_anchor_stability_score": float(g_out.loc[g_out["IsDeterministicSecondKeepAnchor"], "SecondAnchorStabilityScore"].mean()) if g_out["IsDeterministicSecondKeepAnchor"].any() else np.nan,
        "each_mc_iteration_assigns_at_least_one_primary_keep_anchor_per_cluster": True,
    }]
    pd.DataFrame(cluster_consistency_rows).to_csv(
        os.path.join(OUT_DIR, "Validation_ClusterConsistency.csv"), index=False
    )
    # === LOO VALIDATION (unchanged) ===
    loo_df.to_csv(os.path.join(OUT_DIR, "Validation_Remove_LOO_IDW.csv"), index=False)
    # === SPATIAL COVERAGE VALIDATION (unchanged) ===
    coverage_df = build_spatial_coverage_validation(g_out)
    coverage_df.to_csv(os.path.join(OUT_DIR, "Validation_SpatialCoverage.csv"), index=False)
    val_rows.append({
        "method_name": "B4_9_GRAPH_AWARE_ACTIVE_SENSING",
        "n_total": int(len(g_out)),
        "n_keep": int(keep_mask.sum()),
        "n_review": int(review_mask.sum()),
        "n_candidate_remove": int(remove_mask.sum()),
        "critical_removed_should_be_zero": n_critical_remove,
        "n_clusters_total_pre_safeguard": n_clusters_total_pre,
        "n_clusters_with_keep_pre_safeguard": n_clusters_with_keep_pre,
        "n_clusters_without_keep_pre_safeguard": n_clusters_without_keep_pre,
        "n_clusters_total_final": n_clusters_total,
        "n_clusters_with_keep_final": n_clusters_with_keep,
        "n_clusters_with_two_keep_or_more_final": n_clusters_with_two_keep,
        "n_clusters_without_keep_final": n_clusters_without_keep,
        "mean_prob_keep": float(g_out["Prob_KEEP"].mean()),
        "mean_prob_review": float(g_out["Prob_REVIEW"].mean()),
        "mean_prob_remove": float(g_out["Prob_CANDIDATE_REMOVE"].mean()),
        "mean_neighbors_keep": float(g_out.loc[keep_mask, "Neighbors_n_used"].mean()) if keep_mask.any() else np.nan,
        "mean_neighbors_remove": float(g_out.loc[remove_mask, "Neighbors_n_used"].mean()) if remove_mask.any() else np.nan,
        "mean_p_keep_distance": float(g_out["P_keep_distance_base"].mean()),
        "mean_p_keep_information_raw": float(g_out["P_keep_information_raw"].mean()),
        "mean_p_keep_information_final": float(g_out["P_keep_information_base"].mean()),
        "mean_p_keep_dependency_raw": float(g_out["P_keep_dependency_raw"].mean()),
        "mean_p_keep_dependency_final": float(g_out["P_keep_dependency_base"].mean()),
        "mean_p_keep_graph_role_raw": float(g_out["P_keep_graph_role_raw"].mean()),
        "mean_p_keep_graph_role_final": float(g_out["P_keep_graph_role_base"].mean()),
        "mean_p_keep_chloride": float(g_out["P_keep_chloride_adj"].mean()),
        "mean_network_overlap_info_vs_distance": float(g_out["NetworkOverlap_info_vs_distance"].mean()),
        "mean_network_overlap_dep_vs_backbone": float(g_out["NetworkOverlap_dep_vs_backbone"].mean()),
        "mean_network_overlap_graph_vs_backbone": float(g_out["NetworkOverlap_graph_vs_backbone"].mean()),
        "mean_aquifer_reliability": float(g_out["AquiferReliability"].mean()),
        "weight_chloride": float(entropy_w["chloride"]),
        "weight_distance": float(entropy_w["distance"]),
        "weight_information": float(entropy_w["information"]),
        "weight_dependency": float(entropy_w["dependency"]),
        "weight_graph_role": float(entropy_w["graph_role"]),
        "weight_depth": float(entropy_w["depth"]),
        "weight_trend": float(entropy_w["trend"]),
        "weight_status": float(entropy_w["status"]),
        "weight_joint_quality": float(entropy_w["joint_quality"]),
        "network_family_weight_total": float(entropy_w["information"] + entropy_w["dependency"] + entropy_w["graph_role"]),
        "n_candidate_points_exported": int(len(cand_gdf)),
        "n_postfinal_cluster_promotions": int(g_out["PostFinalClusterSafeguard"].sum()),
        "n_policy_safeguard_keep": int(g_out["PolicyKeepReason"].eq("postfinal_cluster_safeguard_keep").sum()),
        "n_policy_safeguard_review_only": int(g_out["PolicyKeepReason"].eq(SAFEGUARD_REVIEW_LABEL).sum()),
        "n_deterministic_second_keep_anchors": int(g_out["IsDeterministicSecondKeepAnchor"].sum()),
        "mean_second_anchor_keep_prob": float(g_out.loc[g_out["IsDeterministicSecondKeepAnchor"], "SecondAnchor_keep_prob"].mean()) if g_out["IsDeterministicSecondKeepAnchor"].any() else np.nan,
        "mean_second_anchor_review_prob": float(g_out.loc[g_out["IsDeterministicSecondKeepAnchor"], "SecondAnchor_review_prob"].mean()) if g_out["IsDeterministicSecondKeepAnchor"].any() else np.nan,
        "mean_second_anchor_stability_score": float(g_out.loc[g_out["IsDeterministicSecondKeepAnchor"], "SecondAnchorStabilityScore"].mean()) if g_out["IsDeterministicSecondKeepAnchor"].any() else np.nan,
        "mean_candidate_exploration_gain": float(cand_gdf["ExplorationGainScore"].mean()) if len(cand_gdf) > 0 and "ExplorationGainScore" in cand_gdf.columns else np.nan,
        "n_decisions_calibrated_total": int(g_out.get("DecisionCalibrated", 0).sum()),
        "n_calibrated_ambiguity_to_review": int((g_out.get("DecisionCalibrationSource", "") == "ambiguity_to_review").sum()),
        "n_calibrated_review_to_keep": int((g_out.get("DecisionCalibrationSource", "") == "review_resolved_to_keep").sum()),
        "n_calibrated_review_to_remove": int((g_out.get("DecisionCalibrationSource", "") == "review_resolved_to_remove").sum()),
        "n_final_reviews_after_hard_resolution": int((g_out["FinalDecision"] == "REVIEW").sum()),
        "n_hard_review_resolved": int(g_out["HardReviewResolved"].sum()) if "HardReviewResolved" in g_out.columns else 0,
        "mean_information_stability_index": float(g_out["InformationStabilityIndex"].mean()) if "InformationStabilityIndex" in g_out.columns else np.nan,
        "n_high_stability": int((g_out["StabilityClass"] == "HIGH").sum()) if "StabilityClass" in g_out.columns else 0,
        "n_medium_stability": int((g_out["StabilityClass"] == "MEDIUM").sum()) if "StabilityClass" in g_out.columns else 0,
        "n_low_stability": int((g_out["StabilityClass"] == "LOW").sum()) if "StabilityClass" in g_out.columns else 0,
        # Hydro-LIMG summary metrics
        "mean_candidate_limg_score": float(cand_gdf["LIMG_ScoreRaw"].mean()) if len(cand_gdf) > 0 and "LIMG_ScoreRaw" in cand_gdf.columns else np.nan,
        "top_candidate_limg_score": float(cand_gdf["LIMG_ScoreRaw"].max()) if len(cand_gdf) > 0 and "LIMG_ScoreRaw" in cand_gdf.columns else np.nan,
    })
    pd.DataFrame(val_rows).to_csv(os.path.join(OUT_DIR, "Validation_Summary.csv"), index=False)
    selection_cols = [
        SID_COL, "Aquifer_group", "Component_id", "Ell_aquifer_m", "Redundancy_cluster_id",
        "Isolated_within_Ell", rank_col_used, "IsCritical", "Aquifer_N", "AquiferReliability",
        COL_CHL if COL_CHL in g_out.columns else None,
        COL_TREND if COL_TREND in g_out.columns else None,
        COL_STATUS if COL_STATUS in g_out.columns else None,
        COL_DEPTH if COL_DEPTH in g_out.columns else None,
        "Neighbors_n_used", "Neighbors_Wsum", "Neighbors_meanDist",
        "Feat_chl_norm", "Feat_trend_norm", "Feat_depth_norm", "Feat_status_norm", "Feat_quality_norm",
        "P_keep_chloride_base", "P_keep_chloride_unc",
        "P_keep_distance_base", "P_keep_distance_unc",
        "P_keep_information_raw", "P_keep_information_base", "P_keep_information_unc",
        "P_keep_dependency_raw", "P_keep_dependency_base", "P_keep_dependency_unc",
        "P_keep_graph_role_raw", "P_keep_graph_role_base", "P_keep_graph_role_unc",
        "P_keep_depth_base", "P_keep_depth_unc",
        "P_keep_trend_base", "P_keep_trend_unc",
        "P_keep_status_base", "P_keep_status_unc",
        "Depth_missing_imputed",
        "NetworkOverlap_info_vs_distance",
        "NetworkOverlap_dep_vs_backbone",
        "NetworkOverlap_graph_vs_backbone",
        "GraphRole_strength", "GraphRole_strength_norm",
        "GraphRole_neighbor_cohesion", "GraphRole_neighbor_spread", "GraphRole_bridge_proxy",
        # B4.9 Graph Influence
        "GraphInfluence_component_delta",
        "GraphInfluence_strength_loss",
        "GraphInfluence_mst_delta",
        "GraphInfluence_score",
        "P_keep_chloride_adj", "P_keep_chloride_adj_unc",
        "P_keep_depth_adj", "P_keep_depth_adj_unc",
        "P_keep_trend_adj", "P_keep_trend_adj_unc",
        "P_keep_status_adj", "P_keep_status_adj_unc",
        "P_keep_joint_quality", "P_keep_joint_quality_unc",
        "BadJoint_chl_trend", "GoodJoint_chl_trend", "BadStatusBadQuality",
        "W_chloride", "W_distance", "W_information", "W_dependency", "W_graph_role",
        "W_depth", "W_trend", "W_status", "W_joint_quality",
        "ClusterAllowSecondKeep", "ClusterExtentRatio", "ClusterHeterogeneity", "ClusterSecondKeepAnchor",
        "IsDeterministicSecondKeepAnchor", "SecondKeepAnchorSoftPolicy", "SecondAnchorStabilityScore",
        "SecondAnchor_keep_prob", "SecondAnchor_review_prob",
        "PostFinalClusterSafeguard", "PolicyKeepReason", "DecisionSource", "SafeguardEvidenceScore",
        "ClusterSafeguardUnresolved",
        "UtilityDeterministic_keep", "UtilityScore_mean",
        "Prob_KEEP", "Prob_REVIEW", "Prob_CANDIDATE_REMOVE",
        "FinalDecision_preSafeguard", "FinalDecisionEvidence", "FinalDecision", "DecisionConfidence", "FinalDecisionReason",
        "DecisionCalibrated", "DecisionProbMargin", "CompositeDecisionUncertainty", "StructuralValueMean", "DecisionCalibrationSource",
        "AbsError_without_well",
        "Lat", "Lon", "X_m", "Y_m",
        # === NEW COLUMNS (hard resolve + stability) ===
        "FinalDecision_beforeHardResolve",
        "HardReviewResolved",
        "HardReviewResolutionSource",
        "HardResolveScore",
        "HardResolveKeepVotes",
        "HardResolveRemoveVotes",
        "DecisionStability",
        "InformationStabilityIndex",
        "StabilityClass",
    ]
    selection_cols = [c for c in selection_cols if c is not None and c in g_out.columns]
    g_out[selection_cols].to_csv(
        os.path.join(OUT_DIR, "Selection_sets_b4_9_graph_aware_active_sensing.csv"), index=False
    )
    g_out.drop(columns="geometry").to_csv(
        os.path.join(OUT_DIR, "Retention_probabilities_perSID_B4_9_GRAPH_AWARE_ACTIVE_SENSING.csv"), index=False
    )
    if R1["WRITE_GEO"]: write_points_output(g_out, name="wells_uniqueSID_prob_retention_b4_9_graph_aware_active_sensing", layer_name="wells")
    if not edges_df.empty:
        geoms = [
            LineString([(r["SID_X_m"], r["SID_Y_m"]), (r["Neighbor_X_m"], r["Neighbor_Y_m"])])
            for _, r in edges_df.iterrows()
        ]
        e_gdf = gpd.GeoDataFrame(edges_df.copy(), geometry=geoms, crs=g_elig.crs)
        if R1["WRITE_GEO"]: write_edges_output(e_gdf, name="edges_singleEll_b4_9_graph_aware_active_sensing", layer_name="edges")
    if len(dep_edges_df) > 0:
        dep_geoms = [
            LineString([(r["X1_m"], r["Y1_m"]), (r["X2_m"], r["Y2_m"])])
            for _, r in dep_edges_df.iterrows()
        ]
        dep_gdf = gpd.GeoDataFrame(dep_edges_df.copy(), geometry=dep_geoms, crs=g_elig.crs)
        dep_edges_df.to_csv(os.path.join(OUT_DIR, "DependencyGraph_edges_B4_9.csv"), index=False)
        if R1["WRITE_GEO"]: write_edges_output(dep_gdf, name="dependency_graph_edges_b4_9_graph_aware_active_sensing", layer_name="dependency_edges")
    else:
        pd.DataFrame().to_csv(os.path.join(OUT_DIR, "DependencyGraph_edges_B4_9.csv"), index=False)
    if len(cand_gdf) > 0:
        cand_cols = [
            "Aquifer_group", "Ell_aquifer_m", "SourceComponentID", "CandidateRank_inAquifer", "CandidateScore",
            "SpatialGapScore", "InformationGapScore", "DependencyGapScore", "GraphCoverageGainScore",
            "ExplorationGainScore",
            # B4.9 Active Sensing columns
            "AS_ExpectedUncertaintyReduction",
            "AS_ExpectedSupportImprovement",
            "AS_ExpectedGraphImprovement",
            "AS_ExpectedRepresentationGain",
            "AS_ExpectedDependencyGain",
            "AS_ActiveSensingScore",
            # FINAL6 extension diagnostics
            "AS_BackboneScore",
            "HydroLIMGScore",
            "ValidationGainScore",
            "HydroLIMG_GlobalLevel",
            "HydroLIMG_AquiferLevel",
            "HydroLIMG_LocalLevel",
            "HydroLIMG_BlendedLevel",
            "CandidateReason",
            "Lat", "Lon", "X_m", "Y_m"
        ]
        cand_cols = [c for c in cand_cols if c in cand_gdf.columns]
        cand_gdf[cand_cols].to_csv(os.path.join(OUT_DIR, "Candidate_new_wells_B4_9.csv"), index=False)
        if R1["WRITE_GEO"]: write_points_output(cand_gdf[cand_cols + ["geometry"]], name="candidate_new_wells_b4_9_graph_aware_active_sensing", layer_name="candidates")
        if len(cand_gdf_b) > 0:
            cand_gdf_b[[c for c in cand_cols if c in cand_gdf_b.columns]].to_csv(os.path.join(OUT_DIR, "Candidate_new_wells_BGAS.csv"), index=False)
    else:
        pd.DataFrame().to_csv(os.path.join(OUT_DIR, "Candidate_new_wells_B4_9.csv"), index=False)
    if R1["WRITE_GEO"]:
        zip_name = "b4_9_graph_aware_active_sensing_outputs.zip"
        zip_path = os.path.join(OUT_DIR, zip_name)
        with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as z:
            for root, _, files in os.walk(OUT_DIR):
                for f in files:
                    if f.lower() == zip_name.lower():
                        continue
                    fp = os.path.join(root, f)
                    z.write(fp, arcname=os.path.relpath(fp, OUT_DIR))
    if verbose:
        print("DONE - GAS engine (R1). Outputs written to:", OUT_DIR)
    return dict(wells=g_out, cand_egas=cand_gdf, cand_bgas=cand_gdf_b, cand_pool=LAST_CANDIDATE_POOL if GENERATE_CANDIDATE_WELLS else None,
                loo=loo_df, weights=entropy_w,
                aquifers=pd.DataFrame(aquifer_summary), components=pd.DataFrame(comp_summary),
                edges=edges_df, dep_edges=dep_edges_df, excluded=g_excl)
if __name__ == "__main__":
    run()

# R1 [S2]: snapshot of every module constant, so that repeated runs in one process (sensitivity analyses) start
# from the documented configuration
import copy as _copy
_CONST_SNAPSHOT = {k: _copy.deepcopy(v) for k, v in list(globals().items())
                   if k.isupper() and not k.startswith("_") and not callable(v) and not isinstance(v, type(os))}


def reset():
    """Restore all module constants and the R1 switches to the revised (reference) configuration."""
    globals().update(_copy.deepcopy(_CONST_SNAPSHOT))
    R1.clear(); R1.update(_copy.deepcopy(R1_DEFAULT))
    configure()
