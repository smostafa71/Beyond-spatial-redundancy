# ESM 2 – Code

Biazar SM, Smith S, Patterson J. *Beyond spatial redundancy: a graph-based and uncertainty-aware
framework for groundwater monitoring network optimization.* Hydrogeology Journal, HYJO-D-26-00546 (revision 1).

This archive contains the code that reproduces every number, table and figure of the revised manuscript and of
ESM 1 from the District station inventory and the EDP chloride record. The data are not included; they are
available from the corresponding author on request (see *Data* below). The code is also available at
[repository link].

## Quick start

```bash
pip install numpy pandas geopandas pyogrio shapely scipy matplotlib python-docx pillow pyproj
# place the data in data/ (see data/README.txt), then
bash run_all.sh               # inputs, framework, all analyses, numbers, figures and documents
bash run_all.sh --reference   # inputs and the reference run only (about 20 s), outputs in analysis_r1/reference/
```

Pandoc (≥ 3.1) is needed for the Word documents and LibreOffice for the PDFs. `get_basemap.sh` downloads the base maps.
The complete run takes several hours on two cores, most of it for the 400 joint (LHS) perturbations and the
withholding tests; the reference run takes about 20 s.

## Contents

| Path | Role |
|---|---|
| `gas_engine.py` | The framework used in the revision (graph construction, retention scores, entropy weights, Monte Carlo resolution, calibration, hard resolver, E-GAS safeguard, candidate generation and scoring). `run(...)` runs one analysis; `configure(...)` changes switches and parameters; `reset()` restores the defaults. |
| `tools/build_engine.py` | Builds `gas_engine.py` from `final6_patched.py` by explicit, commented replacements. Every change to the submitted code is listed there with its ledger code (C0–C10 and D1, see ESM S3). `FINAL6_to_gas_engine.diff` shows the full difference to the submitted code. |
| `final6_patched.py` | The submitted FINAL6 code with the two functions it called but did not contain (`build_final_decision_reason`, `compute_adaptive_active_sensing_weights`) restored from the submitted Final5NEW code (change C0). |
| `original_code/` | The submitted code (`FINAL6_original.py`, `Final5NEW_original.py`), unchanged. |
| `build_input_r1.py` | Builds the analysis input from the station inventory (`data/GW_Stations_Final.*`; chloride concentration and trend class as in the original analysis) and processes the EDP export (`data/edp/`; dissolved chloride WQ_139, exact duplicates removed, same-day median) for the 2021–2026 tests and the concentration check of ESM Table S4. Writes `inputs/GW_input_attr.gpkg` (analysis input), `inputs/GW_input_edpC.gpkg` (sensitivity variant with EDP 2013–2020 medians) and `analysis_r1/edp_*`. |
| `ledger.py` | Step-by-step reconciliation from the submitted code and data (L0) to the revised analysis (L5); ESM Table S5. |
| `analyses_r1.py` | Reference run and all evaluations: `reference`, `structure`, `baselines` (equal-budget comparison), `temporal` (2021–2026), `prospective` and `blocks` (withholding tests), `oat` and `lhs` (sensitivity). |
| `r1common.py` | Shared functions (IDW, leave-one-out, ΔNN, Jaccard, variogram, kriging variance). |
| `collect_numbers_r1.py` | Every number quoted in the manuscript → `analysis_r1/numbers.json`. |
| `figs_r1/` | Figure scripts (Figs. 1–6, ESM Figs. S1–S3); `figstyle.py` holds the common style. Base maps (US Census cartographic boundaries 2023; Natural Earth 10 m) are downloaded to `basemap/` by `get_basemap.sh`. |
| `ms/` | Manuscript and ESM 1 text (`ms_r1_part1.md`, `ms_r1_part2.md`, `build_esm_r1.py`) and Word builders; numbers are filled in from `numbers.json`. |
| `inputs/` | `florida_land.gpkg` (Census 1:500,000 shoreline of Florida; candidate sites must lie on land). `build_input_r1.py` writes `GW_input_attr.gpkg` (analysis input: inventory chloride and trend class) and `GW_input_edpC.gpkg` (EDP 2013–2020 median chloride, inventory trend class) here. |
| `analysis_r1/` | All outputs are written here; `numbers_text.json` holds the two interpretive sentences and the repository link that `collect_numbers_r1.py` inserts into the text. `reference/` receives the per-well and per-site outputs of the revised analysis. |
| `data/` | Empty; see `data/README.txt`. |

## Main outputs (written to `analysis_r1/reference/`)

* `Retention_probabilities_perSID_B4_9_GRAPH_AWARE_ACTIVE_SENSING.csv` – one row per well: aquifer group,
  component, neighbours, the nine retention scores with uncertainties and weights, Monte Carlo class
  probabilities, ISI, `FinalDecision_BGAS` (detection), `FinalDecision` (after the E-GAS safeguard) and the
  safeguard criteria (`Safeguard_trig_LOO`, `Safeguard_trig_SGI`, `Safeguard_trig_CHL`).
* `Candidate_new_wells_BGAS.csv`, `Candidate_new_wells_B4_9.csv` – candidate sites selected by B-GAS and E-GAS.
* `Candidate_pool_scored.csv` – the full candidate pool with all scores.
* `Springs_separate_class.csv` – the 53 spring vents, listed as a separate station class.
* `entropy_weights.json`, `Aquifer_summary.csv`, `Components_summary.csv` – weights and network structure.

## Switches

The defaults of the revision are in `R1_DEFAULT` at the top of `gas_engine.py`. `R1_ORIGINAL_CODE` reproduces
the submitted code; with the safeguard thresholds of the submitted Table S1 it reproduces the published result
(23 screened, 2 confirmed; step L1 of ESM Table S5). For example:

```python
import gas_engine as G
G.configure(SPRINGS_SEPARATE=False)          # spring vents back in the well graph (Sect. 3.7)
G.configure(CRITICAL_RULE="dominant")        # critical designation of the dominant record
res = G.run("inputs/GW_input_attr.gpkg", "out_test")
G.reset()
```

## Data

The chloride record is public (Southwest Florida Water Management District, Environmental Data Portal, parameter
WQ_139). The station inventory (District groundwater-quality station table) and the EDP export used in the study
are available from the corresponding author on request. Place them as described in `data/README.txt`:

```
data/GW_Stations_Final.shp (.shx, .dbf, .prj, .cpg)   station inventory
data/edp/                                            EDP export (chloride time series by station)
```
