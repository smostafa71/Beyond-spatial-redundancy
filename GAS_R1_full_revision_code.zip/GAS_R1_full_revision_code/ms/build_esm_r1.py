"""Builds the electronic supplementary material (ESM 1) of the revised submission as a Word document via pandoc."""
import json, os, re, subprocess, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(1, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import numpy as np, pandas as pd
from docx import Document
from docx.shared import Pt, Cm
from docx.enum.text import WD_LINE_SPACING
from docx.oxml.ns import qn
from docx.oxml import OxmlElement
from esm_params import PARAMS

HERE = os.path.dirname(os.path.abspath(__file__))
A = "analysis_r1/"; R = A + "reference/"
N = json.load(open(A + "numbers.json"))


def mdtable(hdr, rows, align=None, widths=None):
    """pipe table; widths (relative) set the number of dashes, which pandoc uses as relative column widths"""
    align = align or ([":--"] * len(hdr))
    widths = widths or [max(4, min(30, len(str(h)))) for h in hdr]
    sep = []
    for a, w in zip(align, widths):
        d = "-" * max(3, int(w))
        sep.append((":" if a.startswith(":") else "") + d + (":" if a.endswith(":") else ""))
    s = "| " + " | ".join(hdr) + " |\n|" + "|".join(sep) + "|\n"
    for r in rows:
        s += "| " + " | ".join(str(x) for x in r) + " |\n"
    return s


def s1_params():
    rows = [[g, p, v, e, src, rng] for g, p, v, e, src, rng in PARAMS]
    return mdtable(["Group", "Parameter", "Value", "Eq.", "Source", "Sensitivity range"], rows, widths=[9, 12, 36, 4, 16, 14])


def s2_funnel():
    S = json.load(open(A + "summary.json"))
    rows = [["Inventory records", "2,069"], ["Unique stations (SIDs)", N["n_sids"]],
            ["Wells open to confining units (excluded)", S["n_excluded_confining"]],
            ["Spring vents (separate class; 52 at vent, 1 not at vent)", S["n_springs"]],
            ["Wells analysed", S["n_wells"]],
            ["  Upper Floridan aquifer (incl. 16 Avon Park high-permeability zone, 1 Ocala low-permeability zone, 1 Floridan aquifer system)", S["n_by_aquifer"]["upper floridan"]],
            ["  Hawthorn aquifer system (Peace River 2, upper Arcadia 15, lower Arcadia 24, not assigned 47)", S["n_by_aquifer"]["hawthorn"]],
            ["  Surficial aquifer", S["n_by_aquifer"]["surficial"]],
            ["Wells with a critical designation (any record / dominant record)", f"{S['n_critical']} / {S['n_critical_dominant']}"],
            ["Wells with imputed depth (aquifer median)", N["n_depth_missing"]]]
    return mdtable(["Step", "n"], rows, [":--", "--:"], widths=[60, 10])


def s2_edp():
    L = json.load(open(A + "edp_build_log.json"))
    rows = [["EDP records returned (354 stations)", f"{L['raw_records']:,}"], ["Dissolved chloride (WQ_139)", f"{L['wq139_records']:,}"],
            ["Total chloride (WQ_140), excluded", L["wq140_records_excluded"]],
            ["After removal of exact duplicates (SID, timestamp, value)", f"{L['after_exact_duplicate_removal']:,}"],
            ["Non-numeric / non-positive values removed", f"{L['non_numeric_removed']} / {L['non_positive_removed']}"],
            ["Valid records", f"{L['valid_records']:,}"], ["Days with several records (with differing values)", f"{L['days_with_several_records']} ({L['days_with_differing_values']})"],
            ["Sampling days (station-days)", f"{L['sampling_days']:,}"], ["Period of record", f"{L['first_date']} to {L['last_date']}"]]
    return mdtable(["Processing step", "Records"], rows, [":--", "--:"], widths=[55, 20])


def s2_conc_check():
    W = pd.read_csv(R + "Retention_probabilities_perSID_B4_9_GRAPH_AWARE_ACTIVE_SENSING.csv", dtype={"SID": str}, low_memory=False)
    AV = pd.read_csv(A + "attribute_vs_edp.csv", dtype={"SID": str})
    a = AV.merge(W[["SID", "Aquifer_group"]], on="SID")
    a = a[np.isfinite(a.ratio_attr_edp)]
    rows = []
    for aq, lab in [("upper floridan", "Upper Floridan aquifer"), ("hawthorn", "Hawthorn aquifer system"), ("surficial", "Surficial aquifer"), (None, "All wells")]:
        g = a if aq is None else a[a.Aquifer_group == aq]
        rows.append([lab, len(g), f"{g.ratio_attr_edp.median():.2f}", int(((g.ratio_attr_edp > 1.25) | (g.ratio_attr_edp < 0.8)).sum()),
                     f"{g.CHLORIDE_ATTR.corr(g.dev_median, method='spearman'):.2f}"])
    return mdtable(["Aquifer group", "Wells", "Median ratio", "Ratio outside 0.8–1.25", "Spearman ρ"], rows, [":--", "--:", "--:", "--:", "--:"])


def s3_ledger():
    Lg = pd.read_csv(A + "ledger.csv")
    rows = []
    for _, r in Lg.iterrows():
        rows.append([r.step, r.change, int(r.n_stations), int(r.n_isolated), int(r.n_components), f"{r.ell_ufa:,.0f}", int(r.n_screened_BGAS),
                     int(r.n_confirmed_EGAS), (r.confirmed.replace(";", ", ") if isinstance(r.confirmed, str) else "–"),
                     ("–" if pd.isna(r.get("jaccard_screened_vs_prev")) else f"{r.jaccard_screened_vs_prev:.2f}")])
    return mdtable(["Step", "Change (cumulative)", "Stations", "Isolated", "Comp.", "ℓ Upper Floridan (m)", "Screened", "Confirmed", "Confirmed SIDs", "Jaccard vs previous"],
                   rows, [":--", ":--"] + ["--:"] * 6 + [":--", "--:"], widths=[4, 34, 6, 6, 5, 7, 6, 6, 10, 6])


def s4_screened():
    T = pd.read_csv(A + "temporal_screened_wells.csv", dtype={"SID": str})
    W = pd.read_csv(R + "Retention_probabilities_perSID_B4_9_GRAPH_AWARE_ACTIVE_SENSING.csv", dtype={"SID": str}).set_index("SID")
    rows = []
    for _, r in T.iterrows():
        w = W.loc[r.SID]
        trig = ",".join(k for k, c in [("i", "Safeguard_trig_LOO"), ("ii", "Safeguard_trig_SGI"), ("iii", "Safeguard_trig_CHL")] if bool(w[c]))
        rows.append([r.SID, r.STATION, w.COUNTY, ("–" if bool(w.get("Depth_missing_imputed", False)) else f"{w.Well_Depth * 0.3048:.0f}"), f"{r.CHLORIDE:.1f}", str(w.CHLORIDE_T).lower(), f"{w.Prob_CANDIDATE_REMOVE:.2f}",
                     f"{w.InformationStabilityIndex:.2f}", f"{w.GraphInfluence_score:.2f}", f"{w.AbsError_without_well:.1f}", f"{w.P_keep_chloride_adj:.3f}", trig,
                     f"{r.Cl_val:.1f}", r.val_dir.lower(), f"{r.later_loo_factor:.1f}"])
    return mdtable(["SID", "Station", "County", "Depth (m)", "Cl 2013–20 (mg/L)", "Trend class", "P(CR)", "ISI", "S~GI~", "LOO (mg/L)", "P~chl,adj~",
                    "Safeguard", "Cl 2021–26 (mg/L)", "Trend 2021–26", "LOO factor 2021–26"], rows,
                   widths=[5, 13, 7, 5, 6, 8, 4, 4, 4, 5, 5, 6, 6, 6, 5])


def s5_variograms():
    V = json.load(open(A + "baselines_variograms.json"))
    NAME = {"upper floridan": "Upper Floridan aquifer", "hawthorn": "Hawthorn aquifer system", "surficial": "Surficial aquifer"}
    NOTE = {"upper floridan": "range at the upper bound of the fit", "surficial": "too few lag classes; default model", "hawthorn": ""}
    rows = [[NAME[k], f"{v['nugget']:.3f}", f"{v['sill']:.3f}", f"{v['range']:,.0f}", NOTE[k]] for k in ["upper floridan", "hawthorn", "surficial"] for v in [V[k]]]
    return mdtable(["Aquifer group", "Nugget", "Partial sill", "Range (m)", "Note"], rows, [":--", "--:", "--:", "--:", ":--"], widths=[22, 8, 8, 9, 30])


def s6_labels():
    W = pd.read_csv(R + "Retention_probabilities_perSID_B4_9_GRAPH_AWARE_ACTIVE_SENSING.csv", dtype={"SID": str})
    h = W[(W.Aquifer_group == "hawthorn") & W.STATION.str.contains("Fldn|Floridan", case=False, regex=True)]
    rows = [[r.SID, r.STATION, r.Waterbod_1.replace(" (former Intermediate)", "").replace(" (former zone 3)", ""), r.COUNTY,
             f"{r.Well_Depth * 0.3048:.0f}", f"{r.CHLORIDE:.0f}"] for _, r in h.iterrows()]
    return mdtable(["SID", "Station", "Assigned unit", "County", "Depth (m)", "Cl 2013–20 (mg/L)"], rows, widths=[6, 24, 22, 10, 6, 8])


def s7_prospective():
    AQN = {"upper floridan": "Upper Floridan", "hawthorn": "Hawthorn", "surficial": "Surficial"}
    MN = {"GAS-B": "B-GAS", "GAS-E": "E-GAS", "Random (pool)": "Random (same pool)", "Space-filling": "Space-filling"}
    P = pd.read_csv(A + "prospective_by_aquifer.csv")
    P = P[P.radius == 1.0]
    rows = [[AQN.get(r.aquifer, r.aquifer), MN.get(r.method, r.method), f"{r.k:.1f}", f"{r.n_held:.0f}", f"{r.n_high:.1f}", f"{r.hit_high:.3f}", f"{r.hit_low:.3f}"]
            for _, r in P.iterrows()]
    out = mdtable(["Aquifer group", "Method", "Sites (k)", "Withheld", "Informative", "Recovered, informative", "Recovered, other"], rows,
                  [":--", ":--"] + ["--:"] * 5, widths=[14, 16, 8, 8, 9, 12, 12])
    if os.path.exists(A + "prospective_blocks_summary.csv"):
        B = pd.read_csv(A + "prospective_blocks_summary.csv")
        rows = [[MN.get(r.method, r.method), f"{r.k:.1f}", f"{r.n_held:.1f}", f"{r.any_in_hole:.2f}", f"{r.frac_in_hole:.3f}", f"{r.best_rank:.1f}",
                 f"{r.hit_all:.3f}", f"{r.hit_high:.3f}"] for _, r in B.iterrows()]
        out2 = mdtable(["Method", "Sites (k)", "Withheld", "≥ 1 site in gap", "Share of sites in gap", "Best rank in gap", "Withheld recovered",
                        "Informative recovered"], rows, [":--"] + ["--:"] * 7, widths=[16, 8, 8, 9, 10, 9, 10, 11])
    else:
        out2 = "(pending)"
    return out, out2


def s8_oat():
    O = pd.read_csv(A + "oat.csv")
    rows = [[r.variant, int(r.n_wells), int(r.n_components), int(r.n_isolated), int(r.n_screened), int(r.n_confirmed), f"{r.jaccard_screened_vs_ref:.2f}",
             (r.confirmed if isinstance(r.confirmed, str) and r.confirmed else "–") if r.n_confirmed <= 2 else f"{int(r.n_confirmed)} wells (Sect. 3.7)",
             int(r.n_cand_B), int(r.n_cand_E)] for _, r in O.iterrows()]
    return mdtable(["Variant", "Wells", "Comp.", "Isolated", "Screened", "Confirmed", "Jaccard", "Confirmed SIDs", "Sites B", "Sites E"], rows,
                   [":--"] + ["--:"] * 6 + [":--", "--:", "--:"], widths=[30, 5, 5, 6, 6, 6, 6, 14, 5, 5])


LHS_NAMES = {
    "MAD_MULT": ("MST cut, MAD multiplier", "3"), "ELL_FROM_NN_PCTL": ("Percentile of NN distance defining ℓ", "4"),
    "CHL_THRESHOLD": ("Chloride midpoint (mg/L)", "6"), "CHL_SIGMOID_SCALE": ("Chloride transition width (mg/L)", "6"),
    "INFO_SIM_DECAY": ("Information similarity decay", "11"), "PROX_W_WSUM": ("Proximity intensity, weight of W*", "9"),
    "BETA_KAPPA_SPAN": ("Beta concentration span", "18"), "NETWORK_FAMILY_MAX_WEIGHT": ("Network-family weight cap", "16"),
    "MAX_JOINT_QUALITY_WEIGHT": ("Joint-quality weight cap", "16"), "MIN_COMPONENT_WEIGHT": ("Minimum score weight", "16"),
    "ENTROPY_GLOBAL_BLEND": ("Global share of entropy weights", "16"), "REVIEW_THRESHOLD": ("Cluster review threshold", "19"),
    "ISO_REVIEW_THRESHOLD": ("Isolated-well review threshold", "19"), "SECOND_KEEP_MIN_UTILITY": ("Second-anchor minimum utility", "19"),
    "AQUIFER_RELIABILITY_MIN": ("Minimum aquifer reliability", "15"),
    "HARD_RESOLVE_KEEP_PK_MIN": ("Keep vote: P(KEEP)", "20"), "HARD_RESOLVE_KEEP_UTIL_MIN": ("Keep vote: utility", "20"),
    "HARD_RESOLVE_KEEP_STRUCTURAL_MIN": ("Keep vote: structural value", "20"), "HARD_RESOLVE_KEEP_STABILITY_MIN": ("Keep vote: ISI", "20"),
    "HARD_RESOLVE_REMOVE_PREM_MIN": ("Remove vote: P(CR)", "20"), "HARD_RESOLVE_REMOVE_UTIL_MAX": ("Remove vote: utility", "20"),
    "HARD_RESOLVE_REMOVE_STRUCTURAL_MAX": ("Remove vote: structural value", "20"), "HARD_RESOLVE_REMOVE_STABILITY_MAX": ("Remove vote: ISI", "20"),
    "HARD_RESOLVE_REMOVE_UNCERTAINTY_MAX": ("Remove vote: uncertainty", "20"),
    "SG_LOO_Q": ("Safeguard (i): LOO quantile", "22"), "SG_SGI": ("Safeguard (ii): S_GI", "22"), "SG_PCHL": ("Safeguard (iii): P_chl,adj", "22"),
    "f_DEP": ("Dependency weights (factor on trend weight)", "12"), "f_GRAPHROLE": ("Graph-role weights (factor on bridge weight)", "13"),
    "f_DISTRED": ("Redundancy weights (factor on proximity weight)", "10"), "f_GI": ("Graph-influence weights (factor on Δcomp weight)", "14"),
}


def s8_prcc():
    import analyses_r1 as AN
    rng = {n: (lo, hi) for n, lo, hi in AN.LHS_PARAMS}
    P = pd.read_csv(A + "lhs_prcc.csv")
    P = P[P.output == "n_screened"].copy()
    P["a"] = P.prcc.abs(); P = P.sort_values("a", ascending=False)
    fmt = lambda v: f"{v:,.0f}" if abs(v) >= 100 else (f"{v:.2f}" if abs(v) >= 1 else f"{v:.3g}")
    rows = [[LHS_NAMES.get(r.parameter, (r.parameter, ""))[0], LHS_NAMES.get(r.parameter, ("", "–"))[1],
             f"{fmt(rng[r.parameter][0])}–{fmt(rng[r.parameter][1])}" if r.parameter in rng else "–",
             f"{r.prcc:+.2f}", f"{r.p:.3f}" if r.p >= 0.001 else "<0.001", f"{r.eta2:.2f}"] for _, r in P.iterrows()]
    return mdtable(["Parameter", "Eq.", "Range sampled", "PRCC", "p", "η²"], rows, [":--", "--:", ":--", "--:", "--:", "--:"])



LIMG_TXT = r"""*Hydro-LIMG levels (Eq. 28).* For a candidate site *c* of aquifer group *a*, let **x**~*j*~ be the feature vectors of the existing wells of the group (Eq. 11), $\bar{\mathbf{x}}$ their mean, *d*~*cj*~ the distances from *c*, $\omega_{cj}=e^{-d_{cj}/\ell_a}/\sum_l e^{-d_{cl}/\ell_a}$ the support weights and $\mathbf{m}_c=\sum_j\omega_{cj}\mathbf{x}_j$ the support-weighted feature mean around *c*. Its deviation from the aquifer mean is

$$\delta(\mathbf{m})=\frac{1}{4}\sum_f\left|m_f-\bar{x}_f\right|+\frac{1}{4}\sum_f\left|\frac{m_f}{\bar{x}_f}-1\right| \qquad (\mathrm{S}1)$$

where *f* runs over the four features. Each level contrasts a between-term with a within-term, both min–max scaled over the candidate sites of the group (operator 𝒩):

$$L_\mathrm{glob}=\mathcal{N}\!\left[\delta(\mathbf{m}_c)\right]-\mathcal{N}\!\left[\sum_j\omega_{cj}\lVert\mathbf{x}_j-\mathbf{m}_c\rVert\right],\qquad L_\mathrm{aq}=\mathcal{N}\!\left[\delta(\mathbf{m}_c)\right]-\mathcal{N}\!\left[\sum_j\omega_{cj}\lVert\mathbf{x}_j-\bar{\mathbf{x}}\rVert\right] \qquad (\mathrm{S}2)$$

$$L_\mathrm{loc}=\mathcal{N}\!\left[\delta(\mathbf{m}_c^{k})\right]-\mathcal{N}\!\left[\mathcal{N}(\bar d_c^{k})+1-\mathcal{N}(\bar S_{\mathrm{GI},c}^{k})\right] \qquad (\mathrm{S}3)$$

$$L_\mathrm{bl}=\mathcal{N}\!\left[\mathcal{N}\Big(\sum_j\omega_{cj}\bar u_j\Big)+\mathcal{N}\Big(\sum_j\omega_{cj}S_{\mathrm{GI},j}\Big)\right]-\mathcal{N}\!\left[1-\mathcal{N}\Big(\frac{1}{4}\sum_f\left|m_{c,f}-\bar{x}_f\right|\Big)\right] \qquad (\mathrm{S}4)$$

where $\mathbf{m}_c^{k}$, $\bar d_c^{k}$ and $\bar S_{\mathrm{GI},c}^{k}$ are the feature mean, distance and graph influence (Eq. 14) of the *k* = 8 wells nearest to *c*, weighted by $e^{-d/\bar d}$ with $\bar d$ their mean distance, and $\bar u_j$ is the mean uncertainty of the retention scores of well *j*. The weighted sum of the four levels (Eq. 28) is min–max scaled over the candidate sites."""

def build():
    LS = json.load(open(A + "lhs_summary.json"))
    pp1, pp2 = s7_prospective()
    md = f"""**Electronic supplementary material (ESM 1)**

**Beyond spatial redundancy: a graph-based and uncertainty-aware framework for groundwater monitoring network optimization**

Seyed Mostafa Biazar, Samantha Smith, Jason Patterson

Hydrogeology Journal, HYJO-D-26-00546.R1

Contents: S1 Parameters and definitions; S2 Data preparation and chloride record; S3 Reconciliation with the original submission; S4 Screened wells; S5 Equal-budget comparison; S6 Pseudo-prospective tests; S7 Sensitivity; S8 Code

# S1 Parameters and definitions

Table S1 lists every fixed parameter of the framework with the equation in which it is used and the place where it was documented. "Ms" values were stated in the text of the original submission, "S1" values in its Table S1, and "Code" values were present only in its code and are documented here for the first time. Where the code and the manuscript differed, the code now uses the manuscript value (Sect. S3); "R1" marks additions of the revision. Adaptive quantities (ℓ~a~, entropy weights, aquifer reliability, LOO percentile) are not listed. The last column gives the values tested in the one-at-a-time analysis and the ranges of the joint Latin hypercube sampling (LHS; Table S11). Abbreviations as in the main text; P90 etc., percentiles.

Table: **Table S1** Fixed parameters of the GAS framework

{s1_params()}

*Candidate generation (Sect. 2.8, Eq. 23).* Fig. S1 shows the steps for two Upper Floridan components: the support domain (point buffers, MST corridors and alpha-shape envelope), the hexagonal grid, the exclusion of grid points close to existing wells, the points injected between high-uncertainty wells and around high-influence wells, the thinning and land mask that give the candidate pool, and the sites selected by B-GAS.

![**Fig. S1** Generation of candidate sites (Sect. 2.8) for two components of the Upper Floridan aquifer (component numbers of the reference run in the panel titles; ℓ~a~ = {N['ell_ufa']} m, grid spacing *g* = 0.75ℓ~a~). Grey dots: hexagonal grid points inside the support domain (shaded); crosses: grid points closer than 0.60ℓ~a~ to an existing well (black dots, MST edges in grey); triangles: injected points; open circles: candidate pool after thinning (spacing ≥ max(0.90*g*, 0.70ℓ~a~)) and removal of points in open water; diamonds: sites selected by B-GAS (Eqs. 24–26). Diamonds are drawn over the pool sites they were selected from](figures_r1/FigS1_candidate_generation.png){{width=16cm}}

{LIMG_TXT}

# S2 Data and chloride record

The station inventory was consolidated by SID; the funnel from the 2,069 inventory records to the analysed wells is given in Table S2. Chloride concentration (median of the 2013–2020 record) and trend class (attribute CHLORIDE_T: decreasing, stable or increasing) are attributes of the District inventory and are used as in the original analysis. The EDP record of dissolved chloride, retrieved through the KiWIS web service of the EDP and processed as in Table S3, is used for the tests of Sect. 2.9 (January 2021 to July 2026). As a check of the concentration input, Table S4 compares the inventory concentration with the median of the 2013–2020 EDP record (median ratio of inventory to EDP value {N['attr_ratio_median']}; {N['attr_gt25']} wells differ by more than a factor of 1.25); the analysis with the EDP medians is reported in Table S10. The EDP station medians agree with an independent extraction of the same record made for the revision (identical medians for all 353 stations contained in both).

Table: **Table S2** From the station inventory to the analysed wells

{s2_funnel()}

Table: **Table S3** Processing of the EDP chloride record

{s2_edp()}

Table: **Table S4** Inventory chloride concentration compared with the median of the 2013–2020 EDP record, by aquifer group

{s2_conc_check()}

# S3 Reconciliation with the original submission

The code of the original submission (FINAL6, with the B-GAS candidate selection of Final5NEW) was run on the original inventory. As received, it uses safeguard thresholds that differ from those stated in the original Supporting Information and confirms one station (step L0 in Table S5); with the stated thresholds it reproduces the published result exactly (23 screened, 2 confirmed: SIDs 20056 and 21106, LOO 85th percentile 2,166 mg/L; step L1). The changes of the revision were then added one at a time (Table S5).

*Code corrections.* C1: the MST was built on a Delaunay triangulation, which ignores points that share coordinates with another point; wells at multi-depth sites with identical coordinates received no edge and were classified as isolated. The MST is now built on the complete distance graph. C2–C7 and C9: where the code and the manuscript differed, the manuscript value is now used—trend scores (Eq. 7; code 0.80/0.65/0.25), graph-role shrinkage for clusters of fewer than three wells (Eq. 13; code three or fewer, C9), structural value of the calibration step (Eq. 20; code without *S*~GI~), active-sensing weights in E-GAS (Eqs. 24–25; the E-GAS code computed the adaptive weights but applied fixed weights 0.50/0.35/0.10/0.03/0.02, whereas the B-GAS code applied the adaptive weights), Hydro-LIMG level weights (Eq. 28; code 0.30/0.20/0.30/0.20), fusion weights (Eq. 27; code 0.40/0.40/0.20) and safeguard thresholds (Eq. 22; code Q75/0.75/0.80). C8: the validation gain (Eq. 29) used the leave-one-out errors of the screened wells of all aquifer groups, so that Hawthorn and surficial candidate sites were ranked by distant Upper Floridan wells; it now uses the screened wells of the candidate's own aquifer group, because the aquifer groups are processed independently and the manuscript defined the gain from nearby screened wells. C10: the candidate domain was not clipped to the shoreline, so that some sites fell in Tampa Bay or the Gulf of Mexico; points in open water are now removed before scoring. Two functions missing from the FINAL6 file were restored from the B-GAS script of the same version (C0). Three descriptions in the original text could not be implemented as written and are now stated as coded: the cluster rule (Eq. 19), described with three classes (utility below, near or above 0.66), assigns REVIEW (*U* ≥ 0.66) or CANDIDATE_REMOVE; the small-cluster shrinkage, described as towards 0.55, multiplies the deviation from 0.5 by 0.55; and the adaptive active-sensing weights, described as ±30 % and ±20 %, use the factors 1 + 0.30(ρ − 0.5) and 1 + 0.20(ρ − 0.5) (Eq. 25). The complete differences between the original and the revised code are given in the file FINAL6_to_gas_engine.diff of the code package.

*Station classes.* D1: spring vents form a separate class. The two stations confirmed in the original analysis were spring vents (Halls River Head Main Spring and Crystal Beach Spring); once spring vents are separated, no well is confirmed (step L5, the revised analysis). Chloride concentration and trend class are the inventory attributes in all steps.

Table: **Table S5** Step-by-step reconciliation from the original code and data (L0) to the revised analysis (L5); each step adds one change to the previous one

{s3_ledger()}

# S4 Screened wells

Table: **Table S6** The {N['n_screened']} wells screened by B-GAS (all returned to REVIEW by E-GAS). P(CR) probability of the CANDIDATE_REMOVE class; LOO leave-one-out chloride error (Eq. 32; criterion (i) threshold, the 85th percentile of the screened set: {float(pd.read_csv(R + 'Retention_probabilities_perSID_B4_9_GRAPH_AWARE_ACTIVE_SENSING.csv', usecols=['Safeguard_LOO_threshold']).Safeguard_LOO_threshold.dropna().iloc[0]):,.0f} mg/L); safeguard criteria triggered (Eq. 22); trend class: District inventory (Eq. 7); trend 2021–26: Mann–Kendall test on the EDP record; depth –: not reported; LOO factor 2021–26: error factor of the 2021–2026 median predicted from all other wells (the median over the wells in Sect. 3.6 is computed on the log errors)

{s4_screened()}

# S5 Equal-budget comparison

The kriging-variance baseline used an exponential variogram of log~10~ chloride fitted for each aquifer group by weighted least squares on 12 lag classes up to 4ℓ~a~ (Table S7), and the ordinary-kriging variance was averaged over a grid of spacing ℓ~a~/2 within ℓ~a~ of the wells; co-located wells were separated by 1 m. In the Upper Floridan aquifer the nugget exceeds the structured variance and the fitted range reached the upper bound of the fit (three times the largest lag), so that chloride has little spatial continuity at the spacing of the network; for the five surficial wells fewer than three lag classes were available, and the sample variance was used as sill, with zero nugget and a range of one third of the largest lag. The reconstructability baseline predicts each well's chloride as the dependency-weighted (*s*~dep~ *w*) mean of its neighbours and removes the wells with the smallest absolute error.

Table: **Table S7** Variograms of log~10~ chloride used for the kriging-variance baseline

{s5_variograms()}

![**Fig. S2** GAS (B-GAS screening) compared with established reduction methods at an equal budget of {N['n_screened']} removals (values in Table 3 of the main text). **a** Mean leave-one-out chloride error of the removed wells (log scale). **b** Aquifer-weighted change in mean nearest-neighbour distance (Eq. 31). **c** Removed wells with a critical designation. **d** Removed wells with an increasing trend class (District inventory; Eq. 7). **e** Median factor of error with which the 2021–2026 median chloride of the removed wells is reconstructed from the retained wells. Filled symbols: methods applied to all wells; open symbols: methods applied to the wells without a critical designation; grey bars: 5th–95th percentile of 1,000 random removal sets from each pool, with their mean](figures_r1/FigS2_equal_budget.png){{width=16cm}}

# S6 Pseudo-prospective tests

In the random design, 15 % of the Upper Floridan and Hawthorn wells were withheld in each of {N['pp_reps']} replicates; in the gap design, all wells of one aquifer group within 1.5ℓ~a~ of a randomly chosen well were withheld ({N['ppb_reps']} replicates; 3 wells at least, 25 % of the aquifer group at most). The framework was rerun on the remaining wells (Monte Carlo *N* = 1,000), and the candidate sites were compared with the withheld wells. Random sites were drawn from the same candidate pool (200 draws per replicate) in the number selected by E-GAS; space-filling sites were chosen from the same pool as the sites farthest from existing wells and previously chosen sites, with the same minimum spacing.

Table: **Table S8** Random withholding: recovery within ℓ~a~ by aquifer group (means over replicates)

{pp1}

Table: **Table S9** Spatial-gap withholding: means over replicates

{pp2}

# S7 Sensitivity

Table S10 lists the one-at-a-time and structural variants. In the joint perturbation, {LS['n']} parameter sets were drawn by Latin hypercube sampling over {N['lhs_k']} parameters (ranges in Table S11) and run with Monte Carlo *N* = 1,000. An additive linear model on ranks explained {100 * LS['r2_rank_additive_n_screened']:.0f} % of the variance of the number of screened wells and {100 * LS['r2_rank_additive_jaccard_vs_ref']:.0f} % of the variance of the Jaccard overlap with the reference set; the remainder reflects interactions and non-linear effects of the sequential thresholds (Table S11; Fig. S3).

Table: **Table S10** One-at-a-time and structural sensitivity (Monte Carlo *N* = 3,000 unless stated). Jaccard: overlap of the screened set with the reference; Sites B/E: candidate sites of B-GAS and E-GAS

{s8_oat()}

Table: **Table S11** Parameters of the joint (Latin hypercube) perturbation, with the sampled range and the partial rank correlation coefficient (PRCC) with the number of screened wells; η² is the share of variance explained by each parameter alone (binned). Weight groups are perturbed by a factor on their dominant weight, the other weights of the group being rescaled to keep the group total

{s8_prcc()}

![**Fig. S3** Sensitivity of the screening. **a** One-at-a-time and structural variants: wells screened (blue) and confirmed (red), with the Jaccard overlap (J) of the screened set with the reference. **b** Number of wells screened in 400 joint (Latin-hypercube) perturbations of the fixed parameters; the dashed line marks the reference. **c** Share of the joint perturbations in which each well was screened; red bars are the wells of the reference screened set. The most influential parameters were the percentile defining ℓ (PRCC {LS['top_prcc_n_screened'][0][1]:+.2f}), the cluster review threshold ({LS['top_prcc_n_screened'][1][1]:+.2f}) and the network-family weight cap ({LS['top_prcc_n_screened'][2][1]:+.2f})](figures_r1/FigS3_sensitivity.png){{width=16.5cm}}

# S8 Code

The code (ESM 2 and the repository given under Code availability) contains: gas_engine.py (framework; built from the original FINAL6 code by tools/build_engine.py, which lists every change and produces FINAL6_to_gas_engine.diff), build_input_r1.py (analysis input from the station inventory; EDP chloride record for the tests), ledger.py (Table S5), analyses_r1.py (all analyses), collect_numbers_r1.py (all numbers quoted in the paper), the figure scripts and document builders, and run_all.sh, which reproduces every number, table and figure from the station inventory and the EDP export. The data are available on request.
"""
    return md


def _landscape(d, first_caption, last_caption):
    """Put the block from the caption paragraph starting with first_caption to the table after last_caption in a landscape section."""
    import copy as _c
    body = d.element.body
    paras = [p for p in d.paragraphs]
    start = next(p for p in paras if p.text.strip().startswith(first_caption))
    lastcap = next(p for p in paras if p.text.strip().startswith(last_caption))
    el = lastcap._p.getnext()
    while el is not None and el.tag != qn("w:tbl"):
        el = el.getnext()
    body_sect = body.find(qn("w:sectPr"))
    # end of the preceding portrait section
    prev = start._p.getprevious()
    pp = OxmlElement("w:p"); ppr = OxmlElement("w:pPr"); ppr.append(_c.deepcopy(body_sect)); pp.append(ppr)
    start._p.addprevious(pp)
    # end of the landscape section, right after the table
    land = _c.deepcopy(body_sect)
    pg = land.find(qn("w:pgSz"))
    w, h = pg.get(qn("w:w")), pg.get(qn("w:h"))
    pg.set(qn("w:w"), h); pg.set(qn("w:h"), w); pg.set(qn("w:orient"), "landscape")
    for ref in land.findall(qn("w:headerReference")) + land.findall(qn("w:footerReference")):
        land.remove(ref)
    lp = OxmlElement("w:p"); lpr = OxmlElement("w:pPr"); lpr.append(land); lp.append(lpr)
    el.addnext(lp)


def main(out):
    md = build()
    src = os.path.join(HERE, "esm_r1_filled.md"); open(src, "w").write(md)
    ref = os.path.join(HERE, "reference.docx")
    tmp = out + ".tmp.docx"
    subprocess.run(["pandoc", src, "-f", "markdown+tex_math_dollars+subscript+superscript+pipe_tables+table_captions", "-o", tmp,
                    "--reference-doc", ref, "--resource-path", "."], check=True)
    d = Document(tmp)
    for st in d.styles:
        if st.name in ("Body Text", "First Paragraph", "Compact", "Normal"):
            st.paragraph_format.line_spacing_rule = WD_LINE_SPACING.ONE_POINT_FIVE
    sec = d.sections[0]
    p = sec.footer.paragraphs[0]
    r = p.add_run()
    for t, txt in [("begin", None), (None, "PAGE"), ("end", None)]:
        if t:
            f = OxmlElement("w:fldChar"); f.set(qn("w:fldCharType"), t); r._r.append(f)
        else:
            it = OxmlElement("w:instrText"); it.set(qn("xml:space"), "preserve"); it.text = txt; r._r.append(it)
    for t in d.tables:
        tblPr = t._tbl.tblPr
        b = OxmlElement("w:tblBorders")
        for edge in ("top", "bottom", "insideH"):
            e = OxmlElement(f"w:{edge}"); e.set(qn("w:val"), "single"); e.set(qn("w:sz"), "4"); e.set(qn("w:color"), "000000"); b.append(e)
        old = tblPr.find(qn("w:tblBorders"))
        if old is not None:
            tblPr.remove(old)
        tblPr.append(b)
        tw = tblPr.find(qn("w:tblW"))
        if tw is None:
            tw = OxmlElement("w:tblW"); tblPr.append(tw)
        tw.set(qn("w:type"), "pct"); tw.set(qn("w:w"), "5000")
        for row in t.rows:
            for c in row.cells:
                for pp in c.paragraphs:
                    pp.paragraph_format.line_spacing_rule = WD_LINE_SPACING.SINGLE
                    for rr in pp.runs:
                        rr.font.size = Pt(8)
    _landscape(d, "Table S5", "Table S6")
    _landscape(d, "Table S10", "Table S10")
    d.save(out); os.remove(tmp)
    print("written", out)


if __name__ == "__main__":
    main(sys.argv[1] if len(sys.argv) > 1 else "deliverables/ESM1_Supporting_Information_R1.docx")
