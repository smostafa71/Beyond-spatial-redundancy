"""Builds the revised manuscript (Word) from the markdown text, the analysis numbers and the figures.

  python ms/build_ms_r1.py [out.docx]

Steps: fill [[key]] placeholders from analysis_r1/numbers.json (error if any is missing); insert tables and figures;
convert with pandoc (equations become native Word equations); post-process with python-docx (line numbers,
page numbers, table layout)."""
import json, os, re, subprocess, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from docx import Document
from docx.shared import Pt, Cm
from docx.enum.text import WD_LINE_SPACING, WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.oxml.ns import qn
from docx.oxml import OxmlElement
from tables_figs import TABLE1, table2, table3, FIGS
from references import REFERENCES

HERE = os.path.dirname(os.path.abspath(__file__))
N = json.load(open("analysis_r1/numbers.json"))

FRONT = """**Beyond spatial redundancy: a graph-based and uncertainty-aware framework for groundwater monitoring network optimization**

Seyed Mostafa Biazar^1\\*^, Samantha Smith^1^, Jason Patterson^1^

^1^ Southwest Florida Water Management District, Environmental Flows & Levels, Natural Systems & Restoration Bureau, 2379 Broad Street, Brooksville, FL 34604, USA

\\* Corresponding author: Seyed Mostafa Biazar, Seyedmostafa.b@gmail.com; Seyed.Biazar@swfwmd.state.fl.us

Samantha Smith: SamanthaSmith@swfwmd.state.fl.us; Jason Patterson: JasonPatterson@swfwmd.state.fl.us

"""


def fill(text):
    miss = sorted(set(k for k in re.findall(r"\[\[([A-Za-z0-9_]+)\]\]", text) if k not in N))
    if miss:
        raise KeyError(f"missing numbers: {miss}")
    return re.sub(r"\[\[([A-Za-z0-9_]+)\]\]", lambda m: str(N[m.group(1)]), text)


def figure_md(key):
    path, w, cap = FIGS[key]
    return f"![{fill(cap)}]({path}){{width={w}cm}}"


def build_markdown():
    md = FRONT + open(os.path.join(HERE, "ms_r1_part1.md")).read() + "\n\n" + open(os.path.join(HERE, "ms_r1_part2.md")).read()
    md = md.replace("<<Table1>>", TABLE1).replace("<<Table2>>", table2()).replace("<<Table3>>", table3())
    for k in FIGS:
        md = md.replace(f"<<{k}>>", figure_md(k))
    md = fill(md)
    md += "\n\n# References\n\n" + "\n\n".join(REFERENCES) + "\n"
    return md


def _line_numbers(d):
    sec = d.sections[0]
    ln = OxmlElement("w:lnNumType")
    ln.set(qn("w:countBy"), "1"); ln.set(qn("w:restart"), "continuous"); ln.set(qn("w:distance"), "283")
    sp = sec._sectPr
    # lnNumType must precede pgNumType/cols/docGrid etc.; insert after pgMar if present
    pgmar = sp.find(qn("w:pgMar"))
    if pgmar is not None:
        pgmar.addnext(ln)
    else:
        sp.append(ln)
    p = sec.footer.paragraphs[0]; p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p._p.get_or_add_pPr().append(OxmlElement("w:suppressLineNumbers"))   # no line number on the footer line
    r = p.add_run()
    for t, txt in [("begin", None), (None, "PAGE"), ("end", None)]:
        if t:
            f = OxmlElement("w:fldChar"); f.set(qn("w:fldCharType"), t); r._r.append(f)
        else:
            it = OxmlElement("w:instrText"); it.set(qn("xml:space"), "preserve"); it.text = txt; r._r.append(it)


def _tables(d):
    for t in d.tables:
        t.alignment = WD_TABLE_ALIGNMENT.CENTER
        tblPr = t._tbl.tblPr
        b = OxmlElement("w:tblBorders")
        for edge in ("top", "bottom", "insideH"):
            e = OxmlElement(f"w:{edge}"); e.set(qn("w:val"), "single"); e.set(qn("w:sz"), "4"); e.set(qn("w:color"), "000000")
            b.append(e)
        old = tblPr.find(qn("w:tblBorders"))
        if old is not None:
            tblPr.remove(old)
        tblPr.append(b)
        tw = tblPr.find(qn("w:tblW"))
        if tw is None:
            tw = OxmlElement("w:tblW"); tblPr.append(tw)
        tw.set(qn("w:type"), "pct"); tw.set(qn("w:w"), "5000")
        for row in t.rows:
            for c in row.cells:
                for p in c.paragraphs:
                    p.paragraph_format.line_spacing_rule = WD_LINE_SPACING.SINGLE
                    p.paragraph_format.first_line_indent = Cm(0)
                    for r in p.runs:
                        r.font.size = Pt(9)
                    for m in p._p.iter(qn("m:r")):
                        pass


def _body(d):
    for p in d.paragraphs:
        st = p.style.name
        if st in ("Body Text", "First Paragraph"):
            p.paragraph_format.first_line_indent = Cm(0.6) if st == "Body Text" else Cm(0)
        if st in ("Image Caption", "Table Caption", "Caption"):
            p.paragraph_format.keep_with_next = (st == "Table Caption")


def main(out):
    md = build_markdown()
    src = os.path.join(HERE, "ms_r1_filled.md")
    open(src, "w").write(md)
    ref = os.path.join(HERE, "reference.docx")
    if not os.path.exists(ref):
        subprocess.run(["pandoc", "-o", os.path.join(HERE, "pandoc_default_reference.docx"), "--print-default-data-file", "reference.docx"], check=True)
        subprocess.run([sys.executable, os.path.join(HERE, "make_reference_docx.py"), os.path.join(HERE, "pandoc_default_reference.docx"), ref], check=True)
    tmp = out + ".tmp.docx"
    subprocess.run(["pandoc", src, "-f", "markdown+tex_math_dollars+subscript+superscript+pipe_tables+table_captions",
                    "-o", tmp, "--reference-doc", ref, "--resource-path", "."], check=True)
    d = Document(tmp)
    _line_numbers(d); _tables(d); _body(d)
    d.core_properties.author = "Seyed Mostafa Biazar"; d.core_properties.title = "Beyond spatial redundancy (HYJO-D-26-00546.R1)"
    d.save(out); os.remove(tmp)
    words = len(re.sub(r"\$\$.*?\$\$", " ", md, flags=re.S).split())
    print("written", out, "approx. words incl. references:", words)


if __name__ == "__main__":
    main(sys.argv[1] if len(sys.argv) > 1 else "deliverables/Biazar_Manuscript_R1_clean.docx")
