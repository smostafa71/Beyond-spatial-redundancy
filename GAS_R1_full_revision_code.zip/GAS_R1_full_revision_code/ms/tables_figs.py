"""Tables (markdown) and figure captions of the revised manuscript. Values come from analysis_r1/ outputs."""
import json
import pandas as pd

A = "analysis_r1/"
REF = A + "reference/"

TABLE1 = """Table: **Table 1** Steps of the GAS framework: inputs, operations and outputs. Steps 1–3 and 5 (B-GAS part) are shared by both configurations; step 4 and the E-GAS part of step 5 form the enhanced configuration

| Step | Inputs | Operation (equations) | Outputs |
|:------------|:--------------|:--------------------------|:--------------|
| 0 Data preparation (Sect. 2.2) | District station inventory (2,069 records) | SID consolidation; exclusion of confining-unit wells; separation of spring vents | 301 wells with aquifer group, chloride (2013–2020 median), trend class, depth, status, designation |
| 1 Graph construction (Sect. 2.4) | well coordinates by aquifer group | MST, long-edge cut, neighbourhood length, distance weights (Eqs. 3–5) | components, ℓ~a~, neighbours and *w*~*ij*~, isolated wells, redundancy clusters |
| 2 Evidence (Sect. 2.5) | well attributes, neighbours | nine retention scores with uncertainties; adjacency, strength and cohesion within clusters (Eqs. 6–15) | *P*~*ij*~, *u*~*ij*~, *A*~*ij*~, Strength, Cohesion, *S*~GI~ |
| 3 Resolution (Sect. 2.6) | scores, uncertainties, clusters, designation | entropy weights, utility, Beta Monte Carlo, cluster rule, calibration and votes, stability (Eqs. 16–21) | class probabilities, ISI; KEEP or CANDIDATE_REMOVE (B-GAS screening) |
| 4 Confirmation, E-GAS (Sect. 2.7) | screened wells; LOO error, *S*~GI~, *P*~chl,adj~ | removal-risk safeguard (Eq. 22) | confirmed CANDIDATE_REMOVE or REVIEW |
| 5 Candidate sites (Sect. 2.8) | wells with uncertainty, *S*~GI~, features; LOO of screened wells of the same aquifer group | domain and grid on land (Eq. 23); active sensing (Eqs. 24–25); B-GAS greedy (Eq. 26); E-GAS fusion, Hydro-LIMG, validation gain, greedy (Eqs. 27–30) | ≤ 20 ranked plan-view sites per aquifer group |
| 6 Evaluation (Sect. 2.9) | decisions; 2021–2026 record | equal-budget baselines (Eqs. 31–32); out-of-period and pseudo-prospective tests; sensitivity | Table 3; Fig. 6; ESM S5–S7 |
"""


def table2():
    W = pd.read_csv(REF + "Retention_probabilities_perSID_B4_9_GRAPH_AWARE_ACTIVE_SENSING.csv", dtype={"SID": str})
    T = pd.read_csv(A + "structure_aquifers.csv").set_index("aquifer")
    CB = pd.read_csv(REF + "Candidate_new_wells_BGAS.csv"); CE = pd.read_csv(REF + "Candidate_new_wells_B4_9.csv")
    rows = []
    for a, lab in [("upper floridan", "Upper Floridan aquifer"), ("hawthorn", "Hawthorn aquifer system"), ("surficial", "Surficial aquifer")]:
        g = W[W.Aquifer_group == a]; r = T.loc[a]
        rows.append([lab, len(g), f"{r.ell_m:,.0f}", f"{int(r.n_components)} ({int(r.dominant_size)})", int(r.n_isolated),
                     int(g.IsCritical.astype(int).sum()), int((g.FinalDecision_BGAS == "CANDIDATE_REMOVE").sum()),
                     int((g.FinalDecision == "CANDIDATE_REMOVE").sum()), int((g.FinalDecision == "REVIEW").sum()),
                     int((CB.Aquifer_group == a).sum()), int((CE.Aquifer_group == a).sum())])
    tot = ["Total", sum(r[1] for r in rows), "–", f"{sum(int(r[3].split()[0]) for r in rows)}", sum(r[4] for r in rows)] + [sum(r[i] for r in rows) for i in range(5, 11)]
    rows.append(tot)
    hdr = ["Aquifer group", "Wells", "ℓ~a~ (m)", "Components (largest)", "Isolated", "Critical", "Screened (B-GAS)", "Confirmed (E-GAS)",
           "REVIEW (E-GAS)", "Sites B-GAS", "Sites E-GAS"]
    md = "Table: **Table 2** Network structure and decisions by aquifer group. Screened: CANDIDATE_REMOVE after detection (B-GAS); confirmed: screened wells without a removal-risk signal (Eq. 22); REVIEW: screened wells returned to the active network by the safeguard. Critical: wells with a District critical designation (excluded from removal by Eq. 2). Sites: candidate sites for new wells\n\n"
    md += "| " + " | ".join(hdr) + " |\n|" + "|".join([":" + "-" * 22] + ["-" * 8 + ":"] * (len(hdr) - 1)) + "|\n"
    for r in rows:
        md += "| " + " | ".join(str(x) for x in r) + " |\n"
    return md


def table3():
    B = pd.read_csv(A + "baselines_equal_budget.csv")
    md = ("Table: **Table 3** GAS (B-GAS screening) compared with established reduction methods at an equal budget of [[n_screened]] removals, applied to all wells and to "
          "the wells without a critical designation (the pool available to GAS). LOO: mean leave-one-out chloride error of the removed wells (Eq. 32, mg/L); "
          "ΔNN: aquifer-weighted change in mean nearest-neighbour distance (Eq. 31); Comp.: components touched; Jaccard: overlap with B-GAS; Critical and "
          "Incr.: removed wells with a critical designation and with an increasing trend class (District inventory); 2021–2026: removed wells with "
          "significantly rising chloride in 2021–2026 and median factor of error with which their 2021–2026 chloride is reconstructed from the retained wells. Random: mean "
          "(5th–95th percentile) of 1,000 random sets\n\n")
    hdr = ["Pool", "Method", "LOO (mg/L)", "ΔNN (m)", "Comp.", "Jaccard", "Critical", "Incr.", "Rising Cl 2021–2026", "Error factor 2021–2026"]
    md += "| " + " | ".join(hdr) + " |\n|:" + "-" * 10 + "|:" + "-" * 18 + "|" + "|".join(["-" * 9 + ":"] * (len(hdr) - 2)) + "|\n"
    for pool, plab in [("all wells", "All wells"), ("policy-eligible (not critical)", "Not critical")]:
        q = B[B.pool == pool].set_index("method")
        for i, (m, ml) in enumerate([("GAS (B-GAS screening)", "GAS (B-GAS)"), ("Distance thinning", "Distance thinning"),
                                     ("Reconstructability", "Reconstructability"), ("Kriging variance", "Kriging variance")]):
            r = q.loc[m]
            md += f"| {plab if i == 0 else ''} | {ml} | {r.loo_mean_mgL:,.0f} | {r.dNN_m:.0f} | {int(r.n_components)} | {r.jaccard_vs_GAS:.2f} | {int(r.n_critical)} | {int(r.n_dev_rising)} | {int(r.n_val_rising)} | {r.later_rec_median_factor:.1f} |\n"
        rm = q.loc["Random (mean of 1000)"]; r5 = q.loc["Random 5th pct"]; r95 = q.loc["Random 95th pct"]
        f = lambda c, fmt: f"{fmt.format(rm[c])} ({fmt.format(r5[c])}–{fmt.format(r95[c])})"
        md += (f"| | Random | {f('loo_mean_mgL', '{:,.0f}')} | {f('dNN_m', '{:.0f}')} | {f('n_components', '{:.1f}')} | {f('jaccard_vs_GAS', '{:.2f}')} | "
               f"{f('n_critical', '{:.1f}')} | {f('n_dev_rising', '{:.1f}')} | {f('n_val_rising', '{:.1f}')} | {f('later_rec_median_factor', '{:.1f}')} |\n")
    return md


FIGS = {
    "Fig1": ("figures_r1/Fig1_study_area.png", 14.0,
             "**Fig. 1** Study area. **a** Location of the study area (red box) in Florida, USA. **b** Monitoring stations analysed: wells of the Upper "
             "Floridan aquifer (n = 208), the Hawthorn aquifer system (n = 88) and the surficial aquifer (n = 5); spring vents (open triangles, n = 53), "
             "which form a separate station class and are not part of the well graphs; and wells open to confining units (crosses, n = 3), which were "
             "excluded. Grey lines are county boundaries. **c** Schematic north–south hydrostratigraphic section along the Gulf coast, after LaRoche and "
             "Horstman (2023); not to scale and not a single transect. The Hawthorn aquifer system pinches out north of central Hillsborough County; the "
             "Avon Park high-permeability zone is part of the Upper Floridan aquifer north of central Polk County and part of the Lower Floridan aquifer, "
             "below middle confining unit I, south of it. Blue symbols mark springs of the karstic, unconfined to thinly confined Upper Floridan aquifer in the north. Base maps: US Census Bureau (2023) and Natural Earth (www.naturalearthdata.com)"),
    "Fig2": ("figures_r1/Fig2_framework.png", 14.5,
             "**Fig. 2** Architecture of the graph-aware active-sensing (GAS) framework, with the equations used in each step. The baseline configuration "
             "(B-GAS, blue) ends after detection; the enhanced configuration (E-GAS, orange) adds the confirmation stage and the Hydro-LIMG and "
             "validation-gain scores for candidate sites. The evaluation (grey) uses information that does not feed back into the decisions. "
             "KEEP: retained; CANDIDATE_REMOVE: screened as potentially redundant (detection); REVIEW: undecided class of the probabilistic resolution, or "
             "screened well with a removal-risk signal (REVIEW wells remain active); confirmed CANDIDATE_REMOVE: screened well without a removal-risk signal. *u* uncertainty of a score; *S*~GI~ graph-influence "
             "score; LOO leave-one-out chloride error"),
    "Fig3": ("figures_r1/Fig3_network_topology.png", 16.0,
             "**Fig. 3** Monitoring-network topology. **a** Minimum spanning tree (MST) of each aquifer group after the long-edge cut (Eq. 3): coloured "
             "lines are kept edges and dashed grey lines cut edges; filled circles are wells of the largest component of each aquifer group, open circles "
             "wells of smaller components and open squares isolated wells (no neighbour within ℓ~a~, Eq. 4). The red box marks panel b. **b** Dominant "
             "Upper Floridan component in Citrus, Hernando and Pasco counties: light-blue lines connect neighbours within ℓ~a~; grey circles are wells with a "
             "District critical designation and open circles wells without it; red diamonds (with SIDs) are the wells screened by B-GAS, all of which "
             "were returned to REVIEW by the E-GAS safeguard (Eq. 22)"),
    "Fig4": ("figures_r1/Fig4_detection_confirmation.png", 15.0,
             "**Fig. 4** Detection and confirmation. **a** Probability of the CANDIDATE_REMOVE class in the Monte Carlo realizations versus mean utility "
             "(Eq. 17) for all wells; symbols distinguish isolated wells, wells with and without a critical designation, and the [[n_screened]] screened wells. **b** "
             "Mean retention scores of the screened wells and of retained wells with neighbours, with 95 % bootstrap intervals. **c** Removal-risk "
             "safeguard (Eq. 22) for the screened wells: leave-one-out chloride error versus chloride keep score. The blue band marks criterion (iii) "
             "and the red band criterion (i); removal can be confirmed only outside both bands and with *S*~GI~ < 0.80. Labels identify the Hawthorn "
             "well and the wells that triggered criterion (i). **d** Entropy-derived weights of the nine retention scores (Eq. 16); blue bars form "
             "the network family, whose total is capped at 0.36"),
    "Fig5": ("figures_r1/Fig5_candidates.png", 14.5,
             "**Fig. 5** Candidate sites for new wells ranked by **a** B-GAS (active-sensing score, Eqs. 24–26) and **b** E-GAS (fusion of active "
             "sensing, Hydro-LIMG and validation gain, Eqs. 27–30). Colour gives the aquifer group and marker area the final score after sequential "
             "greedy selection; numbers give the rank of the three highest-scoring sites in each aquifer group; grey dots are existing wells. Sites are "
             "plan-view locations; depth and screened interval are left to site design"),
    "Fig6": ("figures_r1/Fig6_validation.png", 15.0,
             "**Fig. 6** Independent tests. **a** Error factor with which the 2021–2026 median chloride of each well is predicted from all other wells "
             "of its aquifer group (leave-one-out, Eq. 32 on log~10~ chloride) for the [[n_screened]] screened wells, the other wells with neighbours and the "
             "isolated wells; boxes show quartiles and medians. **b** Pseudo-prospective test with 15 % of the Upper Floridan and Hawthorn wells withheld "
             "at random ([[pp_reps]] replicates): share of withheld wells with a candidate site within ℓ~a~, for informative withheld wells (chloride "
             "mispredicted by at least a factor of 2 from the remaining wells; filled bars) and other withheld wells (hatched). **c** Pseudo-prospective "
             "test with spatial gaps (all wells within 1.5ℓ~a~ of a random well withheld; [[ppb_reps]] replicates): share of replicates with at least one "
             "site in the gap (filled) and share of withheld wells with a site within ℓ~a~ (dotted). Random sites are drawn from the GAS candidate pool in "
             "the number selected by E-GAS; space-filling sites are the pool sites farthest from existing wells"),
}
