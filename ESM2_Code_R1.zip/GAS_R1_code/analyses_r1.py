"""Analyses for the revised submission (HYJO-D-26-00546.R1).

  reference   GAS reference run (B-GAS screening, E-GAS confirmation, candidates)    -> analysis_r1/reference/
  structure   network structure, screening and confirmation statistics             -> structure_*.csv, summary.json
  baselines   equal-budget comparison with external baselines (Reviewer 2, comment 2)-> baselines_*.csv
  temporal    2021-2026 out-of-period validation (Reviewer 2, comment 5)            -> temporal_*.csv
  prospective pseudo-prospective test of candidate placement (Reviewer 2, comment 5) -> prospective_*.csv
  oat         one-at-a-time and structural sensitivity, seeds, hydrostratigraphic edges -> oat.csv
  lhs         joint (Latin-hypercube) perturbation of the fixed parameters (Reviewer 2, comment 4) -> lhs_*.csv

Usage: python analyses_r1.py [sections ...] [--reps 50] [--n-lhs 400] [--procs 2]
Decisions are always produced by gas_engine.py; nothing computed here feeds back into them.
"""
import os, re, sys, json, argparse, time
import numpy as np, pandas as pd
from scipy import stats
from scipy.spatial import cKDTree
from r1common import (INPUT, AQ_ORDER, load_edp, idw, loo_single, joint_reconstruction, mean_nn, delta_nn, jaccard,
                      fit_exponential_variogram, ok_variance, domain_grid)

OUT = "analysis_r1"
REF = OUT + "/reference"
WELLS_CSV = REF + "/Retention_probabilities_perSID_B4_9_GRAPH_AWARE_ACTIVE_SENSING.csv"


# ============================================================ reference
def run_reference():
    import gas_engine as G
    G.reset()
    res = G.run(INPUT, REF, verbose=False)
    pool = res["cand_pool"].drop(columns="geometry").copy()
    pool["X_m"], pool["Y_m"] = res["cand_pool"].geometry.x.values, res["cand_pool"].geometry.y.values
    pool.to_csv(REF + "/Candidate_pool_scored.csv", index=False)
    res["aquifers"].to_csv(REF + "/Aquifer_summary.csv", index=False)
    json.dump({k: float(v) for k, v in res["weights"].items()}, open(REF + "/entropy_weights.json", "w"), indent=1)
    print("reference:", res["wells"].FinalDecision_BGAS.value_counts().to_dict(), res["wells"].FinalDecision.value_counts().to_dict())


def load_ref():
    w = pd.read_csv(WELLS_CSV, dtype={"SID": str})
    S = load_edp()
    for c, s in [("Cl_val", "val_median"), ("val_dir", "val_dir"), ("dev_dir", "dev_dir"), ("val_n", "val_n"),
                 ("dev_n", "dev_n"), ("dev_sen_pct_yr", "dev_sen_pct_yr"), ("val_sen_pct_yr", "val_sen_pct_yr")]:
        w[c] = w.SID.map(S[s])
    w = w.copy()
    w["IsCritical"] = w.IsCritical.astype(int).astype(bool)
    w["Isolated_within_Ell"] = w.Isolated_within_Ell.astype(bool)
    return w


def screened(w):
    return sorted(w.loc[w.FinalDecision_BGAS == "CANDIDATE_REMOVE", "SID"])


def confirmed(w):
    return sorted(w.loc[w.FinalDecision == "CANDIDATE_REMOVE", "SID"])


# ============================================================ structure
def structure():
    w = load_ref()
    aq = pd.read_csv(REF + "/Aquifer_summary.csv")
    comp = pd.read_csv(REF + "/Components_summary.csv")
    rows = []
    scr = set(screened(w))
    for a in AQ_ORDER:
        g = w[w.Aquifer_group == a]
        sizes = g.groupby("Component_id").size().sort_values(ascending=False)
        dom = int(sizes.index[0])
        r = aq.set_index("Aquifer_group").loc[a]
        nn_all = mean_nn(g[["X_m", "Y_m"]].to_numpy(float))
        keepB = g[~g.SID.isin(scr)]
        rows.append(dict(aquifer=a, n=len(g), ell_m=r.Ell_aquifer_m, n_components=int(r.N_components),
                         n_singleton_components=int((sizes == 1).sum()), dominant_size=int(sizes.iloc[0]),
                         dominant_share=sizes.iloc[0] / len(g), n_isolated=int(g.Isolated_within_Ell.sum()),
                         n_redundancy_clusters=int(g.loc[~g.Isolated_within_Ell, "Redundancy_cluster_id"].nunique()),
                         n_critical=int(g.IsCritical.sum()), n_noncritical_nonisolated=int((~g.IsCritical & ~g.Isolated_within_Ell).sum()),
                         mean_nn_m=nn_all, median_nn_m=float(np.median(cKDTree(g[["X_m", "Y_m"]]).query(g[["X_m", "Y_m"]], k=2)[0][:, 1])) if len(g) > 1 else np.nan,
                         mean_nn_after_BGAS_m=mean_nn(keepB[["X_m", "Y_m"]].to_numpy(float)),
                         n_screened=int(g.SID.isin(scr).sum()),
                         n_screened_in_dominant=int((g.SID.isin(scr) & (g.Component_id == dom)).sum()),
                         reliability=float(r.AquiferReliability), cut_value_m=float(r.cut_value)))
    T = pd.DataFrame(rows)
    T.to_csv(OUT + "/structure_aquifers.csv", index=False)

    # screened vs retained structural contrasts (original Sect. 3.1.2)
    cols = ["GraphRole_bridge_proxy", "GraphInfluence_score", "P_keep_graph_role_base", "P_keep_information_base",
            "P_keep_dependency_base", "P_keep_distance_base", "Neighbors_n_used", "UtilityScore_mean", "InformationStabilityIndex",
            "P_keep_chloride_adj", "P_keep_trend_adj"]
    sc = w.SID.isin(scr)
    ret = ~sc
    C = []
    for c in cols:
        a, b = w.loc[sc, c].astype(float), w.loc[ret, c].astype(float)
        bb = w.loc[ret & ~w.Isolated_within_Ell, c].astype(float)
        p = stats.mannwhitneyu(a, bb, alternative="two-sided").pvalue if len(a) > 1 else np.nan
        C.append(dict(metric=c, screened_mean=a.mean(), retained_mean=b.mean(), retained_nonisolated_mean=bb.mean(), mw_p_vs_nonisolated=p))
    pd.DataFrame(C).to_csv(OUT + "/structure_contrasts.csv", index=False)

    # decision statistics
    wt = json.load(open(REF + "/entropy_weights.json"))
    pre = w.FinalDecision_beforeHardResolve.value_counts().to_dict()
    S = {}
    S["n_wells"] = len(w); S["n_by_aquifer"] = w.Aquifer_group.value_counts().to_dict()
    S["n_excluded_confining"] = int(len(pd.read_csv(REF + "/Excluded_Confinement_FULLINFO_withCoords.csv")))
    S["n_critical"] = int(w.IsCritical.sum()); S["n_critical_dominant"] = int(w.IsCritical_dominant.astype(bool).sum())
    S["n_isolated"] = int(w.Isolated_within_Ell.sum())
    S["n_components"] = int(T.n_components.sum())
    S["pre_hard_resolve"] = {k: int(v) for k, v in pre.items()}
    S["mean_P_keep"], S["mean_P_review"], S["mean_P_remove"] = (float(w.Prob_KEEP.mean()), float(w.Prob_REVIEW.mean()), float(w.Prob_CANDIDATE_REMOVE.mean()))
    S["weights"] = wt
    S["network_family_weight"] = wt["information"] + wt["dependency"] + wt["graph_role"]
    S["ISI_mean"] = float(w.InformationStabilityIndex.mean())
    S["ISI_classes"] = w.StabilityClass.value_counts().to_dict()
    S["ISI_screened_mean"] = float(w.loc[sc, "InformationStabilityIndex"].mean()); S["ISI_retained_mean"] = float(w.loc[ret, "InformationStabilityIndex"].mean())
    S["screened"] = sorted(scr); S["n_screened"] = len(scr); S["confirmed"] = confirmed(w); S["n_confirmed"] = len(confirmed(w))
    S["screened_P_remove_mean"] = float(w.loc[sc, "Prob_CANDIDATE_REMOVE"].mean()); S["screened_P_keep_mean"] = float(w.loc[sc, "Prob_KEEP"].mean())
    S["hard_resolve_sources"] = w.HardReviewResolutionSource.value_counts().to_dict()
    S["calibration_sources"] = w.DecisionCalibrationSource.value_counts().to_dict()
    S["n_second_anchor"] = int(w.IsDeterministicSecondKeepAnchor.astype(bool).sum())
    S["loo_screened_mean"] = float(w.loc[sc, "AbsError_without_well"].mean()); S["loo_screened_median"] = float(w.loc[sc, "AbsError_without_well"].median())
    S["loo_screened_max"] = float(w.loc[sc, "AbsError_without_well"].max()); S["loo_q85"] = float(w.Safeguard_LOO_threshold.iloc[0])
    S["safeguard_triggers"] = {k: int(w.loc[sc, c].astype(bool).sum()) for k, c in
                               [("loo", "Safeguard_trig_LOO"), ("sgi", "Safeguard_trig_SGI"), ("chl", "Safeguard_trig_CHL")]}
    S["screened_Pchl_min"] = float(w.loc[sc, "P_keep_chloride_adj"].min()); S["screened_SGI_max"] = float(w.loc[sc, "GraphInfluence_score"].max())
    S["screened_SGI_min"] = float(w.loc[sc, "GraphInfluence_score"].min())
    S["screened_Cl_max"] = float(w.loc[sc, "CHLORIDE"].max()); S["screened_Cl_min"] = float(w.loc[sc, "CHLORIDE"].min())
    S["dNN_BGAS"] = delta_nn(w, scr); S["dNN_EGAS"] = delta_nn(w, confirmed(w))
    S["dev_dir_counts"] = w.dev_dir.value_counts().to_dict()
    # candidates
    for tag, f in [("BGAS", REF + "/Candidate_new_wells_BGAS.csv"), ("EGAS", REF + "/Candidate_new_wells_B4_9.csv")]:
        c = pd.read_csv(f)
        S[f"cand_{tag}_n"] = len(c); S[f"cand_{tag}_by_aquifer"] = c.Aquifer_group.value_counts().to_dict()
        S[f"cand_{tag}_score_mean"] = float(c.CandidateScore.mean()); S[f"cand_{tag}_score_max"] = float(c.CandidateScore.max())
        S[f"cand_{tag}_score_min"] = float(c.CandidateScore.min())
        S[f"cand_{tag}_components"] = int(c.groupby("Aquifer_group").SourceComponentID.nunique().sum())
        S[f"cand_{tag}_components_by_aquifer"] = c.groupby("Aquifer_group").SourceComponentID.nunique().to_dict()
        # distance to nearest existing well
        d = []
        for a, g in c.groupby("Aquifer_group"):
            ex = w[w.Aquifer_group == a][["X_m", "Y_m"]].to_numpy(float)
            d += list(cKDTree(ex).query(g[["X_m", "Y_m"]].to_numpy(float), k=1)[0])
        S[f"cand_{tag}_dist_mean_m"] = float(np.mean(d))
        S[f"cand_{tag}_score_by_aquifer"] = c.groupby("Aquifer_group").CandidateScore.agg(["mean", "max"]).round(3).to_dict()
    ce = pd.read_csv(REF + "/Candidate_new_wells_B4_9.csv")
    for c in ["AS_BackboneScore", "HydroLIMGScore", "ValidationGainScore"]:
        S[f"cand_EGAS_{c}_mean"] = float(ce[c].mean())
    pool = pd.read_csv(REF + "/Candidate_pool_scored.csv")
    S["cand_pool_n"] = len(pool); S["cand_pool_by_aquifer"] = pool.Aquifer_group.value_counts().to_dict()
    S["AS_weights_by_aquifer"] = pool.groupby("Aquifer_group")[["AS_w_unc", "AS_w_sup", "AS_w_gra", "AS_w_rep", "AS_w_dep"]].mean().round(3).to_dict("index")
    json.dump(S, open(OUT + "/summary.json", "w"), indent=1, default=lambda o: o.item() if hasattr(o, "item") else str(o))
    print("structure:", T[["aquifer", "n", "ell_m", "n_components", "dominant_size", "n_isolated", "n_screened", "n_screened_in_dominant"]].to_string(index=False))


# ============================================================ baselines
def _dep_reconstruction_error(w):
    e = pd.read_csv(REF + "/DependencyGraph_edges_B4_9.csv", dtype={"SID": str, "Neighbor_SID": str})
    e2 = e.rename(columns={"SID": "Neighbor_SID", "Neighbor_SID": "SID"})
    E = pd.concat([e, e2], ignore_index=True)
    E["A"] = E.DependencyWeight * E.SpatialWeight
    cl = w.set_index("SID").CHLORIDE
    E["Cj"] = E.Neighbor_SID.map(cl)
    pred = E.groupby("SID").apply(lambda g: (g.A * g.Cj).sum() / g.A.sum() if g.A.sum() > 0 else np.nan)
    err = (pred - cl.reindex(pred.index)).abs()
    return err.reindex(w.SID).fillna(np.inf)


def _distance_thinning(w, pool, k):
    removed = []
    for _ in range(k):
        best = None
        for a, g in w.groupby("Aquifer_group"):
            keep = g[~g.SID.isin(removed)]
            if len(keep) < 3:
                continue
            xy = keep[["X_m", "Y_m"]].to_numpy(float)
            d, _ = cKDTree(xy).query(xy, k=3)
            for i, sid in enumerate(keep.SID):
                if sid not in pool:
                    continue
                key = (d[i, 1], d[i, 2], sid)
                if best is None or key < best[0]:
                    best = (key, sid)
        removed.append(best[1])
    return removed


def _kriging_greedy(w, pool, k):
    """Remove, one at a time, the well whose deletion least increases the mean ordinary-kriging variance of
    log10 chloride over the aquifer domain (variance normalised by the fitted sill so aquifers are comparable)."""
    setup = {}
    w = w.copy()
    # co-located wells (multi-depth sites) make the kriging system singular; separate them by 1 m
    dup = w.duplicated(["X_m", "Y_m"], keep=False)
    if dup.any():
        rank = w[dup].groupby(["X_m", "Y_m"]).cumcount()
        w.loc[rank.index, "X_m"] = w.loc[rank.index, "X_m"] + rank.to_numpy(float)
    for a, g in w.groupby("Aquifer_group"):
        xy = g[["X_m", "Y_m"]].to_numpy(float); z = np.log10(g.CHLORIDE.to_numpy(float))
        ell = float(g.Ell_aquifer_m.iloc[0])
        vg = fit_exponential_variogram(xy, z, maxlag=4 * ell)
        grid = domain_grid(xy, ell, ell / 2)
        setup[a] = (vg, grid)
    removed = []
    cur = {a: ok_variance(g[["X_m", "Y_m"]].to_numpy(float), setup[a][1], setup[a][0]).mean() for a, g in w.groupby("Aquifer_group")}
    for _ in range(k):
        best = None
        for a, g in w.groupby("Aquifer_group"):
            keep = g[~g.SID.isin(removed)]
            if len(keep) < 4:
                continue
            vg, grid = setup[a]
            xy = keep[["X_m", "Y_m"]].to_numpy(float)
            for i, sid in enumerate(keep.SID):
                if sid not in pool:
                    continue
                m = np.ones(len(keep), bool); m[i] = False
                try:
                    v = ok_variance(xy[m], grid, vg).mean()
                except np.linalg.LinAlgError:
                    continue
                inc = (v - cur[a]) / (vg["sill"] + vg["nugget"])
                if best is None or (inc, sid) < best[0]:
                    best = ((inc, sid), sid, a, v)
        removed.append(best[1]); cur[best[2]] = best[3]
    return removed, {a: s[0] for a, s in setup.items()}


def _set_metrics(w, removed, ref_set, loo_lin, later_err_log, later_err_lin):
    r = w[w.SID.isin(removed)]
    idx = r.index
    return dict(k=len(removed),
                loo_mean_mgL=float(loo_lin[idx].mean()), loo_median_mgL=float(loo_lin[idx].median()),
                dNN_m=delta_nn(w, removed), n_components=int(r.groupby(["Aquifer_group", "Component_id"]).ngroups),
                jaccard_vs_GAS=jaccard(removed, ref_set), n_critical=int(r.IsCritical.sum()),
                n_isolated=int(r.Isolated_within_Ell.sum()), n_hawthorn=int((r.Aquifer_group == "hawthorn").sum()),
                n_dev_rising=int((r.CHLORIDE_T.astype(str).str.upper() == "INCREASING").sum()),   # inventory trend class
                n_val_rising=int((r.val_dir == "RISING").sum()),
                later_rec_median_factor=float(10 ** later_err_log.reindex(idx).median()),
                later_rec_mean_mgL=float(later_err_lin.reindex(idx).mean()),
                median_Cl_dev=float(r.CHLORIDE.median()))


def baselines(n_random=1000):
    w = load_ref()
    ref = screened(w); k = len(ref)
    loo_lin = loo_single(w, "CHLORIDE")
    rec = _dep_reconstruction_error(w)
    rows, sets = [], {}
    for pool_name, pool in [("all wells", set(w.SID)), ("policy-eligible (not critical)", set(w.loc[~w.IsCritical, "SID"]))]:
        methods = {"GAS (B-GAS screening)": ref,
                   "Distance thinning": _distance_thinning(w, pool, k),
                   "Reconstructability": [x for x in w.SID.iloc[np.argsort(rec.to_numpy(), kind="stable")] if x in pool][:k]}
        kr, vgs = _kriging_greedy(w, pool, k)
        methods["Kriging variance"] = kr
        for m, s in methods.items():
            later_log = joint_reconstruction(w.assign(V=w.Cl_val), s, "V", log=True)
            later_lin = joint_reconstruction(w.assign(V=w.Cl_val), s, "V", log=False)
            rows.append(dict(pool=pool_name, method=m, **_set_metrics(w, s, ref, loo_lin, later_log, later_lin)))
            sets[f"{pool_name}|{m}"] = sorted(s)
        rng = np.random.default_rng(12345)
        plist = sorted(pool)
        R = []
        for _ in range(n_random):
            s = list(rng.choice(plist, size=k, replace=False))
            later_log = joint_reconstruction(w.assign(V=w.Cl_val), s, "V", log=True)
            later_lin = joint_reconstruction(w.assign(V=w.Cl_val), s, "V", log=False)
            R.append(_set_metrics(w, s, ref, loo_lin, later_log, later_lin))
        R = pd.DataFrame(R)
        R.to_csv(OUT + f"/baselines_random_{'all' if pool_name == 'all wells' else 'policy'}.csv", index=False)
        rr = {c: float(R[c].mean()) for c in R.columns}
        rows.append(dict(pool=pool_name, method=f"Random (mean of {n_random})", **rr))
        rows.append(dict(pool=pool_name, method="Random 5th pct", **{c: float(R[c].quantile(0.05)) for c in R.columns}))
        rows.append(dict(pool=pool_name, method="Random 95th pct", **{c: float(R[c].quantile(0.95)) for c in R.columns}))
    B = pd.DataFrame(rows)
    B.to_csv(OUT + "/baselines_equal_budget.csv", index=False)
    json.dump(sets, open(OUT + "/baselines_sets.json", "w"), indent=1)
    json.dump({a: v for a, v in vgs.items()}, open(OUT + "/baselines_variograms.json", "w"), indent=1)
    pd.set_option("display.width", 250)
    print(B[["pool", "method", "loo_mean_mgL", "dNN_m", "n_components", "jaccard_vs_GAS", "n_critical", "n_dev_rising", "n_val_rising", "later_rec_median_factor"]].round(3).to_string(index=False))


# ============================================================ temporal validation
def temporal():
    w = load_ref()
    scr = set(screened(w))
    has = w.Cl_val.notna()
    # 1) persistence of the 2013-2020 trend class
    P = pd.crosstab(w.dev_dir, w.val_dir)
    P.to_csv(OUT + "/temporal_trend_persistence.csv")
    # 2) later-period single-well reconstruction (log10 IDW from all other wells with later data)
    wl = w[has].copy()
    wl["later_loo_log"] = loo_single(wl.assign(V=wl.Cl_val), "V", log=True)
    wl["design_loo_log"] = loo_single(wl, "CHLORIDE", log=True)
    grp = np.where(wl.SID.isin(scr), "screened", np.where(wl.Isolated_within_Ell, "isolated", "other non-isolated"))
    wl["group"] = grp
    G = wl.groupby("group").agg(n=("SID", "size"), later_loo_median_factor=("later_loo_log", lambda x: 10 ** x.median()),
                                design_loo_median_factor=("design_loo_log", lambda x: 10 ** x.median()),
                                val_rising=("val_dir", lambda x: int((x == "RISING").sum())),
                                dev_rising=("dev_dir", lambda x: int((x == "RISING").sum())),
                                median_ratio_val_dev=("Cl_val", lambda x: np.nan))
    a = wl.loc[wl.group == "screened", "later_loo_log"]; b = wl.loc[wl.group == "other non-isolated", "later_loo_log"]
    mw = stats.mannwhitneyu(a, b, alternative="less")
    G["mw_p_screened_lt_other"] = mw.pvalue
    G.to_csv(OUT + "/temporal_groups.csv")
    # 3) per-well table for the screened set
    T = wl[wl.SID.isin(scr)][["SID", "STATION", "Aquifer_group", "Waterbod_1", "CHLORIDE", "Cl_val", "dev_dir", "val_dir",
                               "dev_n", "val_n", "later_loo_log", "design_loo_log", "FinalDecision", "Safeguard_trig_LOO",
                               "Safeguard_trig_SGI", "Safeguard_trig_CHL", "P_keep_chloride_adj", "GraphInfluence_score",
                               "AbsError_without_well", "Prob_CANDIDATE_REMOVE", "InformationStabilityIndex"]].copy()
    T["ratio_val_dev"] = T.Cl_val / T.CHLORIDE
    T["later_loo_factor"] = 10 ** T.later_loo_log
    T["joint_rec_factor"] = 10 ** joint_reconstruction(wl.assign(V=wl.Cl_val), sorted(scr), "V", log=True).reindex(T.index)
    T.to_csv(OUT + "/temporal_screened_wells.csv", index=False)
    ratio = (wl.Cl_val / wl.CHLORIDE)
    S = dict(n_with_later=int(has.sum()), persistence=P.to_dict(),
             screened_later_loo_median_factor=float(10 ** a.median()), other_later_loo_median_factor=float(10 ** b.median()),
             mw_p=float(mw.pvalue), screened_ratio_min=float(T.ratio_val_dev.min()), screened_ratio_max=float(T.ratio_val_dev.max()),
             screened_val_rising=int((T.val_dir == "RISING").sum()), screened_val_falling=int((T.val_dir == "FALLING").sum()),
             all_ratio_median=float(ratio.median()), dev_rising_to_val_rising=int(((wl.dev_dir == "RISING") & (wl.val_dir == "RISING")).sum()),
             dev_rising_n=int((wl.dev_dir == "RISING").sum()), dev_rising_with_val_dir=int(((wl.dev_dir == "RISING") & (wl.val_dir != "NOT DETERMINED")).sum()),
             val_rising_total=int((wl.val_dir == "RISING").sum()))
    json.dump(S, open(OUT + "/temporal_summary.json", "w"), indent=1)
    print("temporal:", json.dumps(S, indent=0)[:1500])


# ============================================================ independent check of the E-GAS safeguard (2021-2026 record)
def safeguard_check():
    """Is the reconstruction difficulty used by the safeguard (Eq. 22, criterion i) a persistent property of the network?
    Design period: LOO error of Eq. (32) on the inventory chloride (the framework's AbsError_without_well).
    Check period: the same protocol applied to the 2021-2026 EDP medians (data not used by the framework)."""
    w = load_ref()
    wl = w[w.Cl_val.notna() & (w.Cl_val > 0)].copy()
    wl["later_err"] = loo_single(wl.assign(V=wl.Cl_val), "V", log=False)
    wl["later_log"] = loo_single(wl.assign(V=wl.Cl_val), "V", log=True)
    wl["design_err"] = loo_single(w, "CHLORIDE", log=False).reindex(wl.index)   # Eq. (32) on all wells, as in the framework
    wl["design_log"] = loo_single(w, "CHLORIDE", log=True).reindex(wl.index)
    _sc = wl.FinalDecision_BGAS.eq("CANDIDATE_REMOVE")
    assert np.allclose(wl.loc[_sc, "design_err"], wl.loc[_sc, "AbsError_without_well"].astype(float), rtol=1e-6), "LOO protocol differs from the framework"
    tr = lambda c: wl[c].astype(str).str.lower().isin(["true", "1", "1.0"])
    scr = wl.FinalDecision_BGAS.eq("CANDIDATE_REMOVE")
    grp = np.select([scr & tr("Safeguard_trig_LOO"), scr & tr("Safeguard_trig_CHL"), wl.FinalDecision.eq("CANDIDATE_REMOVE"),
                     ~scr & ~wl.Isolated_within_Ell, ~scr & wl.Isolated_within_Ell],
                    ["criterion (i)", "criterion (iii)", "confirmed", "other, with neighbours", "isolated"], "other")
    wl["sg_group"] = grp
    r_lin = stats.spearmanr(wl.design_err, wl.later_err); r_log = stats.spearmanr(wl.design_log, wl.later_log)
    thr = float(w.Safeguard_LOO_threshold.iloc[0])                       # Q85 of the screened set (Eq. 22)
    above = wl.design_err >= thr
    a1 = wl.loc[wl.sg_group == "criterion (i)", "later_log"]; b1 = wl.loc[wl.sg_group == "other, with neighbours", "later_log"]
    a2 = wl.loc[above, "later_log"]; b2 = wl.loc[~above, "later_log"]
    G = wl.groupby("sg_group").agg(n=("SID", "size"), later_factor_median=("later_log", lambda x: 10 ** x.median()),
                                    later_err_median=("later_err", "median"), design_err_median=("design_err", "median"))
    G.to_csv(OUT + "/safeguard_check_groups.csv")
    wl[["SID", "Aquifer_group", "sg_group", "CHLORIDE", "Cl_val", "design_err", "later_err", "design_log", "later_log"]].to_csv(
        OUT + "/safeguard_check_wells.csv", index=False)
    S = dict(n=int(len(wl)), spearman_err=float(r_lin.statistic), spearman_err_p=float(r_lin.pvalue),
             spearman_log=float(r_log.statistic), spearman_log_p=float(r_log.pvalue), q85=thr,
             n_above_q85=int(above.sum()), later_factor_above_q85=float(10 ** a2.median()), later_factor_below_q85=float(10 ** b2.median()),
             mw_p_above_q85=float(stats.mannwhitneyu(a2, b2, alternative="greater").pvalue),
             crit_i_n=int(len(a1)), crit_i_later_factor=float(10 ** a1.median()), other_later_factor=float(10 ** b1.median()),
             crit_i_later_err_median=float(wl.loc[wl.sg_group == "criterion (i)", "later_err"].median()),
             other_later_err_median=float(wl.loc[wl.sg_group == "other, with neighbours", "later_err"].median()),
             mw_p_crit_i=float(stats.mannwhitneyu(a1, b1, alternative="greater").pvalue),
             crit_i_min_later_factor=float(10 ** a1.min()), other_q90_later_factor=float(10 ** b1.quantile(0.9)))
    # design check of the two withholding tests: does withholding open a gap (no remaining neighbour within ell)?
    w0 = pd.read_csv(WELLS_CSV, dtype={"SID": str})
    rnd, gap = [], []
    for rep in range(50):
        rng = np.random.default_rng(1000 + rep); held = []
        for a in ["upper floridan", "hawthorn"]:
            s_ = sorted(w0.loc[w0.Aquifer_group == a, "SID"]); held += list(rng.choice(s_, size=int(round(0.15 * len(s_))), replace=False))
        held = set(held)
        for a in ["upper floridan", "hawthorn"]:
            g = w0[w0.Aquifer_group == a]; ell = float(g.Ell_aquifer_m.iloc[0])
            H = g[g.SID.isin(held)]; Rm = g[~g.SID.isin(held)]
            d = cKDTree(Rm[["X_m", "Y_m"]].to_numpy(float)).query(H[["X_m", "Y_m"]].to_numpy(float), k=1)[0]
            rnd += list(d / ell)
    for rep in range(60):
        rng = np.random.default_rng(5000 + rep)
        cand = w0[w0.Aquifer_group.isin(["upper floridan", "hawthorn"])].reset_index(drop=True)
        while True:
            c = cand.iloc[rng.integers(len(cand))]; a = c.Aquifer_group; g = w0[w0.Aquifer_group == a]; ell = float(g.Ell_aquifer_m.iloc[0])
            dd = np.hypot(g.X_m - c.X_m, g.Y_m - c.Y_m); held = set(g.SID[dd <= 1.5 * ell])
            if 3 <= len(held) <= 0.25 * len(g):
                break
        H = g[g.SID.isin(held)]; Rm = g[~g.SID.isin(held)]
        gap += list(cKDTree(Rm[["X_m", "Y_m"]].to_numpy(float)).query(H[["X_m", "Y_m"]].to_numpy(float), k=1)[0] / ell)
    rnd, gap = np.array(rnd), np.array(gap)
    S.update(random_design_frac_neighbour_within_ell=float((rnd <= 1).mean()), random_design_median_dist_ell=float(np.median(rnd)),
             gap_design_frac_neighbour_within_ell=float((gap <= 1).mean()), gap_design_median_dist_ell=float(np.median(gap)))
    json.dump(S, open(OUT + "/safeguard_check.json", "w"), indent=1)
    print(G.round(2).to_string()); print(json.dumps(S, indent=0))


# ============================================================ pseudo-prospective
def _pp_worker(args):
    rep, frac, nmc = args
    import gas_engine as G
    G.reset(); G.configure(N_MC=nmc)
    w0 = pd.read_csv(WELLS_CSV, dtype={"SID": str})
    rng = np.random.default_rng(1000 + rep)
    held = []
    for a in ["upper floridan", "hawthorn"]:
        s = sorted(w0.loc[w0.Aquifer_group == a, "SID"])
        held += list(rng.choice(s, size=int(round(frac * len(s))), replace=False))
    held = set(held)
    res = G.run(INPUT, f"runs/pp/rep{rep:03d}", verbose=False, wells_filter=lambda g: ~g["SID"].astype(str).isin(held))
    wr = res["wells"]; wr["SID"] = wr.SID.astype(str)
    out = []
    pool = res["cand_pool"]
    for a in ["upper floridan", "hawthorn"]:
        rem = wr[wr.Aquifer_group == a]
        ell = float(rem.Ell_aquifer_m.iloc[0])
        H = w0[(w0.Aquifer_group == a) & w0.SID.isin(held)]
        xy_rem = rem[["X_m", "Y_m"]].to_numpy(float)
        pred = idw(xy_rem, np.log10(rem.CHLORIDE.to_numpy(float)), H[["X_m", "Y_m"]].to_numpy(float))
        err = np.abs(pred - np.log10(H.CHLORIDE.to_numpy(float)))
        hi = err >= np.log10(2.0)
        xy_h = H[["X_m", "Y_m"]].to_numpy(float)
        P = pool[pool.Aquifer_group == a]
        xy_p = np.column_stack([P.geometry.x.values, P.geometry.y.values])
        def hits(xy_c, r):
            if len(xy_c) == 0:
                return np.zeros(len(xy_h), bool)
            return cKDTree(xy_c).query(xy_h, k=1)[0] <= r
        sets = {}
        for tag, c in [("GAS-B", res["cand_bgas"]), ("GAS-E", res["cand_egas"])]:
            cc = c[c.Aquifer_group == a]
            sets[tag] = np.column_stack([cc.geometry.x.values, cc.geometry.y.values])
        kE = len(sets["GAS-E"]); kB = len(sets["GAS-B"])
        # space-filling (farthest-point from existing wells and already chosen sites), same pool, same k as GAS-E
        def farthest(k):
            chosen = []
            base = cKDTree(xy_rem).query(xy_p, k=1)[0]
            dmin = base.copy()
            spacing = float(P.PostMinSpacing_m.iloc[0]) if len(P) else 0
            for _ in range(min(k, len(xy_p))):
                i = int(np.argmax(dmin))
                if dmin[i] <= 0:
                    break
                chosen.append(i)
                dd = np.sqrt(((xy_p - xy_p[i]) ** 2).sum(1))
                dmin = np.minimum(dmin, dd)
                dmin[dd < spacing] = 0
            return xy_p[chosen]
        sets["Space-filling"] = farthest(kE)
        for r_fac in (0.5, 1.0):
            r = r_fac * ell
            for tag, xy_c in sets.items():
                h = hits(xy_c, r)
                out.append(dict(rep=rep, aquifer=a, radius=r_fac, method=tag, k=len(xy_c), n_held=len(H), n_high=int(hi.sum()),
                                hit_high=float(h[hi].mean()) if hi.any() else np.nan, hit_low=float(h[~hi].mean()) if (~hi).any() else np.nan))
            # random draws from the same pool, k = GAS-E
            rh, rl = [], []
            for _ in range(200):
                if len(xy_p) == 0:
                    break
                idx = rng.choice(len(xy_p), size=min(kE, len(xy_p)), replace=False)
                h = hits(xy_p[idx], r)
                rh.append(h[hi].mean() if hi.any() else np.nan); rl.append(h[~hi].mean() if (~hi).any() else np.nan)
            out.append(dict(rep=rep, aquifer=a, radius=r_fac, method="Random (pool)", k=kE, n_held=len(H), n_high=int(hi.sum()),
                            hit_high=float(np.nanmean(rh)) if rh else np.nan, hit_low=float(np.nanmean(rl)) if rl else np.nan))
    return out


def prospective(reps=50, frac=0.15, procs=2, nmc=1000):
    from multiprocessing import Pool
    t = time.time()
    with Pool(procs, maxtasksperchild=1) as p:
        res = p.map(_pp_worker, [(r, frac, nmc) for r in range(reps)])
    D = pd.DataFrame([x for r in res for x in r])
    D.to_csv(OUT + "/prospective_reps.csv", index=False)
    S = (D.groupby(["radius", "aquifer", "method"])[["hit_high", "hit_low", "k", "n_high", "n_held"]].mean().round(3))
    # pooled over aquifers (weighted by number of high/low wells)
    D["w_hi"] = D.n_high; D["w_lo"] = D.n_held - D.n_high
    pooled = D.groupby(["radius", "method"]).apply(lambda g: pd.Series(dict(
        hit_high=np.nansum(g.hit_high * g.w_hi) / g.w_hi[g.hit_high.notna()].sum(),
        hit_low=np.nansum(g.hit_low * g.w_lo) / g.w_lo[g.hit_low.notna()].sum()))).round(3)
    pooled["discrimination"] = pooled.hit_high - pooled.hit_low
    # replicate-level paired difference GAS-E minus random (high-information wells, radius = ell)
    S.to_csv(OUT + "/prospective_by_aquifer.csv"); pooled.to_csv(OUT + "/prospective_pooled.csv")
    pv = {}
    for m in ["GAS-B", "GAS-E", "Space-filling"]:
        a = D[(D.radius == 1.0) & (D.method == m)].groupby("rep").apply(lambda g: np.nansum(g.hit_high * g.w_hi) / g.w_hi.sum())
        b = D[(D.radius == 1.0) & (D.method == "Random (pool)")].groupby("rep").apply(lambda g: np.nansum(g.hit_high * g.w_hi) / g.w_hi.sum())
        dd = (a - b).dropna()
        pv[m] = dict(mean_diff=float(dd.mean()), frac_reps_better=float((dd > 0).mean()),
                     wilcoxon_p=float(stats.wilcoxon(dd).pvalue) if (dd != 0).any() else np.nan)
    json.dump(pv, open(OUT + "/prospective_tests.json", "w"), indent=1)
    print(pooled.to_string()); print(pv); print("prospective time", round(time.time() - t), "s")


# ============================================================ pseudo-prospective, spatial blocks
def _ppb_worker(args):
    rep, rho_fac, nmc = args
    import gas_engine as G
    G.reset(); G.configure(N_MC=nmc)
    w0 = pd.read_csv(WELLS_CSV, dtype={"SID": str})
    rng = np.random.default_rng(5000 + rep)
    cand = w0[w0.Aquifer_group.isin(["upper floridan", "hawthorn"])].reset_index(drop=True)
    while True:
        c = cand.iloc[rng.integers(len(cand))]
        a = c.Aquifer_group
        g = w0[w0.Aquifer_group == a]
        ell = float(g.Ell_aquifer_m.iloc[0])
        d = np.hypot(g.X_m - c.X_m, g.Y_m - c.Y_m)
        held = set(g.SID[d <= rho_fac * ell])
        if 3 <= len(held) <= 0.25 * len(g):
            break
    res = G.run(INPUT, f"runs/ppb/rep{rep:03d}", verbose=False, wells_filter=lambda gg: ~gg["SID"].astype(str).isin(held))
    wr = res["wells"]; wr["SID"] = wr.SID.astype(str)
    rem = wr[wr.Aquifer_group == a]
    ell_r = float(rem.Ell_aquifer_m.iloc[0])
    H = w0[w0.SID.isin(held)]
    xy_h = H[["X_m", "Y_m"]].to_numpy(float)
    pred = idw(rem[["X_m", "Y_m"]].to_numpy(float), np.log10(rem.CHLORIDE.to_numpy(float)), xy_h)
    hi = np.abs(pred - np.log10(H.CHLORIDE.to_numpy(float))) >= np.log10(2.0)
    P = res["cand_pool"]; P = P[P.Aquifer_group == a]
    xy_p = np.column_stack([P.geometry.x.values, P.geometry.y.values])
    tree_h = cKDTree(xy_h)
    in_hole_pool = tree_h.query(xy_p, k=1)[0] <= ell_r if len(xy_p) else np.zeros(0, bool)
    out = []

    def metrics(xy_c, ranks=None):
        if len(xy_c) == 0:
            return dict(any_in_hole=0.0, frac_in_hole=0.0, best_rank=np.nan, hit_high=np.nan, hit_all=0.0)
        dh = tree_h.query(xy_c, k=1)[0]
        inh = dh <= ell_r
        near = cKDTree(xy_c).query(xy_h, k=1)[0] <= ell_r
        br = float(np.min(np.asarray(ranks)[inh])) if (ranks is not None and inh.any()) else np.nan
        return dict(any_in_hole=float(inh.any()), frac_in_hole=float(inh.mean()), best_rank=br,
                    hit_high=float(near[hi].mean()) if hi.any() else np.nan, hit_all=float(near.mean()))
    kE = 0
    for tag, C in [("GAS-B", res["cand_bgas"]), ("GAS-E", res["cand_egas"])]:
        cc = C[C.Aquifer_group == a].sort_values("CandidateRank_inAquifer")
        xy_c = np.column_stack([cc.geometry.x.values, cc.geometry.y.values])
        if tag == "GAS-E":
            kE = len(xy_c)
        out.append(dict(rep=rep, aquifer=a, n_held=len(held), n_high=int(hi.sum()), method=tag, k=len(xy_c),
                        pool_frac_in_hole=float(in_hole_pool.mean()) if len(in_hole_pool) else np.nan,
                        **metrics(xy_c, cc.CandidateRank_inAquifer.to_numpy())))
    # space-filling, same pool and k
    base = cKDTree(rem[["X_m", "Y_m"]].to_numpy(float)).query(xy_p, k=1)[0] if len(xy_p) else np.zeros(0)
    dmin = base.copy(); chosen = []
    spacing = float(P.PostMinSpacing_m.iloc[0]) if len(P) else 0.0
    for _ in range(min(kE, len(xy_p))):
        i = int(np.argmax(dmin))
        if dmin[i] <= 0:
            break
        chosen.append(i)
        dd = np.sqrt(((xy_p - xy_p[i]) ** 2).sum(1)); dmin = np.minimum(dmin, dd); dmin[dd < spacing] = 0
    out.append(dict(rep=rep, aquifer=a, n_held=len(held), n_high=int(hi.sum()), method="Space-filling", k=len(chosen),
                    pool_frac_in_hole=float(in_hole_pool.mean()) if len(in_hole_pool) else np.nan,
                    **metrics(xy_p[chosen], np.arange(1, len(chosen) + 1))))
    M = []
    for _ in range(200):
        if len(xy_p) == 0:
            break
        idx = rng.choice(len(xy_p), size=min(kE, len(xy_p)), replace=False)
        M.append(metrics(xy_p[idx], np.arange(1, len(idx) + 1)))
    M = pd.DataFrame(M)
    out.append(dict(rep=rep, aquifer=a, n_held=len(held), n_high=int(hi.sum()), method="Random (pool)", k=kE,
                    pool_frac_in_hole=float(in_hole_pool.mean()) if len(in_hole_pool) else np.nan, **M.mean().to_dict()))
    return out


def prospective_blocks(reps=60, rho=1.5, procs=2, nmc=1000):
    from multiprocessing import Pool
    t = time.time()
    with Pool(procs) as p:
        res = p.map(_ppb_worker, [(r, rho, nmc) for r in range(reps)], chunksize=1)
    D = pd.DataFrame([x for r in res for x in r])
    D.to_csv(OUT + "/prospective_blocks_reps.csv", index=False)
    S = D.groupby("method")[["any_in_hole", "frac_in_hole", "best_rank", "hit_high", "hit_all", "k", "n_held", "n_high", "pool_frac_in_hole"]].mean().round(3)
    S.to_csv(OUT + "/prospective_blocks_summary.csv")
    tests = {}
    for m in ["GAS-B", "GAS-E", "Space-filling"]:
        a = D[D.method == m].set_index("rep").hit_all; b = D[D.method == "Random (pool)"].set_index("rep").hit_all
        dd = (a - b).dropna()
        tests[m] = dict(mean_diff_hit_all=float(dd.mean()), frac_reps_better=float((dd > 0).mean()),
                        wilcoxon_p=float(stats.wilcoxon(dd).pvalue) if (dd != 0).any() else np.nan)
    json.dump(tests, open(OUT + "/prospective_blocks_tests.json", "w"), indent=1)
    print(S.to_string()); print(tests); print("blocks time", round(time.time() - t), "s")


# ============================================================ one-at-a-time / structural sensitivity
def _variant_worker(args):
    name, inp, cfg = args
    import gas_engine as G
    G.reset(); G.configure(**cfg)
    res = G.run(inp, "runs/oat/" + re.sub(r"[^A-Za-z0-9.,-]+", "_", name), verbose=False)
    w = res["wells"]; w["SID"] = w.SID.astype(str)
    scr = sorted(w.loc[w.FinalDecision_BGAS == "CANDIDATE_REMOVE", "SID"]); conf = sorted(w.loc[w.FinalDecision == "CANDIDATE_REMOVE", "SID"])
    aq = res["aquifers"].set_index("Aquifer_group")
    return dict(variant=name, n_wells=len(w), n_screened=len(scr), n_confirmed=len(conf), screened=";".join(scr), confirmed=";".join(conf),
                n_components=int(aq.N_components.sum()), ell_ufa=float(aq.loc["upper floridan", "Ell_aquifer_m"]),
                n_isolated=int(w.Isolated_within_Ell.sum()), n_cand_E=len(res["cand_egas"]), n_cand_B=len(res["cand_bgas"]))


def lenient_zone(a, b):
    und = {"Hawthorn aquifer system (former Intermediate)", "Floridan aquifer system", "Upper Floridan aquifer"}
    return (a == b) or (a in und) or (b in und)


def oat(procs=2):
    V = [("Reference", INPUT, {})]
    V += [(f"Seed {s}", INPUT, dict(RNG_SEED=s)) for s in (1, 2, 3, 4)]
    V += [("N_MC 1000", INPUT, dict(N_MC=1000)), ("N_MC 10000", INPUT, dict(N_MC=10000))]
    V += [("MAD multiplier 2.5", INPUT, dict(MAD_MULT=2.5)), ("MAD multiplier 3.5", INPUT, dict(MAD_MULT=3.5)),
          ("ell = P80", INPUT, dict(ELL_FROM_NN_PCTL=80)), ("ell = P95", INPUT, dict(ELL_FROM_NN_PCTL=95)),
          ("Review threshold 0.60", INPUT, dict(REVIEW_THRESHOLD=0.60)), ("Review threshold 0.72", INPUT, dict(REVIEW_THRESHOLD=0.72)),
          ("Chloride midpoint 1,500 mg/L", INPUT, dict(CHL_THRESHOLD=1500.0)), ("Chloride midpoint 2,500 mg/L", INPUT, dict(CHL_THRESHOLD=2500.0)),
          ("Chloride scale 300 mg/L", INPUT, dict(CHL_SIGMOID_SCALE=300.0)), ("Chloride scale 500 mg/L", INPUT, dict(CHL_SIGMOID_SCALE=500.0)),
          ("Safeguard Q75/0.75/0.80", INPUT, dict(SAFEGUARD=(0.75, 0.75, 0.80))),
          ("Safeguard Q95/0.90/0.95", INPUT, dict(SAFEGUARD=(0.95, 0.90, 0.95))),
          ("Network-family cap 0.30", INPUT, dict(NETWORK_FAMILY_MAX_WEIGHT=0.30)), ("Network-family cap 0.42", INPUT, dict(NETWORK_FAMILY_MAX_WEIGHT=0.42)),
          ("Trend scores 0.80/0.65/0.25 (code)", INPUT, dict(TREND_SCORES={"DECREASING": 0.80, "STABLE": 0.65, "INCREASING": 0.25})),
          ("Critical rule: dominant record", INPUT, dict(CRITICAL_RULE="dominant")),
          ("Critical rule: none", INPUT, dict(CRITICAL_RULE="none")),
          ("EDP 2013-2020 median chloride", "inputs/GW_input_edpC.gpkg", {}),
          ("Hydrostratigraphic edges (lenient)", INPUT, dict(EDGE_ZONE_FILTER=lenient_zone)),
          ("Hydrostratigraphic edges (strict)", INPUT, dict(EDGE_ZONE_FILTER="strict")),
          ("Original MST (no co-location fix)", INPUT, dict(FIX_MST=False))]
    from multiprocessing import Pool
    with Pool(procs, maxtasksperchild=1) as p:
        rows = p.map(_variant_worker, V)
    D = pd.DataFrame(rows)
    ref = set(D.loc[D.variant == "Reference", "screened"].iloc[0].split(";"))
    D["jaccard_screened_vs_ref"] = [jaccard(ref, set(s.split(";")) - {""}) for s in D.screened]
    D.to_csv(OUT + "/oat.csv", index=False)
    print(D[["variant", "n_wells", "n_screened", "n_confirmed", "jaccard_screened_vs_ref", "n_cand_E"]].to_string(index=False))


# ============================================================ joint (Latin-hypercube) perturbation
LHS_PARAMS = [  # name, low, high (absolute values); weight groups are perturbed by factor and renormalised
    ("MAD_MULT", 2.25, 3.75), ("ELL_FROM_NN_PCTL", 80, 95), ("CHL_THRESHOLD", 1500, 2500), ("CHL_SIGMOID_SCALE", 300, 500),
    ("INFO_SIM_DECAY", 0.94, 1.56), ("PROX_W_WSUM", 0.45, 0.75), ("BETA_KAPPA_SPAN", 36, 60),
    ("NETWORK_FAMILY_MAX_WEIGHT", 0.27, 0.45), ("MAX_JOINT_QUALITY_WEIGHT", 0.135, 0.225), ("MIN_COMPONENT_WEIGHT", 0.0225, 0.0375),
    ("ENTROPY_GLOBAL_BLEND", 0.375, 0.625), ("REVIEW_THRESHOLD", 0.594, 0.726), ("ISO_REVIEW_THRESHOLD", 0.2625, 0.4375),
    ("SECOND_KEEP_MIN_UTILITY", 0.576, 0.704), ("AQUIFER_RELIABILITY_MIN", 0.2625, 0.4375),
    ("HARD_RESOLVE_KEEP_PK_MIN", 0.45, 0.55), ("HARD_RESOLVE_KEEP_UTIL_MIN", 0.468, 0.572), ("HARD_RESOLVE_KEEP_STRUCTURAL_MIN", 0.486, 0.594),
    ("HARD_RESOLVE_KEEP_STABILITY_MIN", 0.522, 0.638), ("HARD_RESOLVE_REMOVE_PREM_MIN", 0.468, 0.572), ("HARD_RESOLVE_REMOVE_UTIL_MAX", 0.432, 0.528),
    ("HARD_RESOLVE_REMOVE_STRUCTURAL_MAX", 0.414, 0.506), ("HARD_RESOLVE_REMOVE_STABILITY_MAX", 0.45, 0.55),
    ("HARD_RESOLVE_REMOVE_UNCERTAINTY_MAX", 0.396, 0.484),
    ("SG_LOO_Q", 0.75, 0.95), ("SG_SGI", 0.70, 0.90), ("SG_PCHL", 0.75, 0.95),
    ("f_DEP", 0.75, 1.25), ("f_GRAPHROLE", 0.75, 1.25), ("f_DISTRED", 0.75, 1.25), ("f_GI", 0.75, 1.25),
]


def _lhs_cfg(x, seed=None):
    cfg = {}
    for (n, lo, hi), u in zip(LHS_PARAMS, x):
        v = lo + u * (hi - lo)
        cfg[n] = v
    out = {k: v for k, v in cfg.items() if not k.startswith(("SG_", "f_"))}
    out["ELL_FROM_NN_PCTL"] = int(round(out["ELL_FROM_NN_PCTL"]))
    out["SAFEGUARD"] = (cfg["SG_LOO_Q"], cfg["SG_SGI"], cfg["SG_PCHL"])

    def grp(base, f, dom=0):
        """factor f on the dominant weight, the others rescaled so that the group keeps its total"""
        b = np.array(base, float); tot = b.sum(); nd = b[dom] * f
        r = b * (tot - nd) / (tot - b[dom]); r[dom] = nd
        return r
    d = grp([0.35, 0.30, 0.20, 0.15], cfg["f_DEP"])                       # Eq. 12, trend weight
    out.update(DEP_GRAPH_W_TREND=d[0], DEP_GRAPH_W_CHL=d[1], DEP_GRAPH_W_DEPTH=d[2], DEP_GRAPH_W_STATUS=d[3])
    g = grp([0.65, 0.20, 0.15], cfg["f_GRAPHROLE"])                       # Eq. 13, bridge weight
    out.update(GRAPH_ROLE_W_BRIDGE=g[0], GRAPH_ROLE_W_LOW_COHESION=g[1], GRAPH_ROLE_W_NEIGHBOR_SPREAD=g[2])
    r = grp([0.40, 0.42, 0.18], cfg["f_DISTRED"], dom=1)                  # Eq. 10, proximity weight
    out.update(DIST_REDUNDANCY_W_NEIGH=r[0], DIST_REDUNDANCY_W_PROX=r[1], DIST_REDUNDANCY_W_COMPACT=r[2])
    gi = grp([0.45, 0.35, 0.20], cfg["f_GI"])                             # Eq. 14, component-change weight
    out["GI_W"] = tuple(gi)
    return out, cfg


def _lhs_worker(args):
    i, x, nmc = args
    import gas_engine as G
    G.reset(); G.configure(N_MC=nmc, GENERATE_CANDIDATE_WELLS=False)
    cfg, raw = _lhs_cfg(x, 777 + i)
    G.configure(**cfg)
    res = G.run(INPUT, f"runs/lhs/run{i:04d}", verbose=False)
    w = res["wells"]; w["SID"] = w.SID.astype(str)
    scr = sorted(w.loc[w.FinalDecision_BGAS == "CANDIDATE_REMOVE", "SID"]); conf = sorted(w.loc[w.FinalDecision == "CANDIDATE_REMOVE", "SID"])
    return dict(run=i, **raw, n_screened=len(scr), n_confirmed=len(conf), screened=";".join(scr), confirmed=";".join(conf),
                n_isolated=int(w.Isolated_within_Ell.sum()))


def lhs(n=400, procs=2, nmc=1000):
    from scipy.stats import qmc
    X = qmc.LatinHypercube(d=len(LHS_PARAMS), seed=2026).random(n)
    from multiprocessing import Pool
    t = time.time()
    with Pool(procs, maxtasksperchild=1) as p:
        rows = p.map(_lhs_worker, [(i, X[i], nmc) for i in range(n)])
    D = pd.DataFrame(rows)
    w = load_ref(); ref = set(screened(w))
    D["jaccard_vs_ref"] = [jaccard(ref, set(s.split(";")) - {""}) for s in D.screened]
    D.to_csv(OUT + "/lhs_runs.csv", index=False)
    # per-well screening frequency
    allsid = w.SID.tolist()
    F = pd.Series({s: np.mean([s in r.split(";") for r in D.screened]) for s in allsid}, name="screen_freq")
    Fc = pd.Series({s: np.mean([s in r.split(";") for r in D.confirmed]) for s in allsid}, name="confirm_freq")
    pd.concat([F, Fc], axis=1).to_csv(OUT + "/lhs_well_frequency.csv")
    # PRCC (partial rank correlation) for each output
    names = [p[0] for p in LHS_PARAMS]
    R = D[names].rank().to_numpy(float)
    res = []
    for y in ["n_screened", "n_confirmed", "jaccard_vs_ref"]:
        yr = D[y].rank().to_numpy(float)
        if np.std(yr) == 0:
            continue
        Z = np.column_stack([np.ones(len(D)), R])
        beta, *_ = np.linalg.lstsq(Z, yr, rcond=None)
        r2_rank = 1 - ((yr - Z @ beta) ** 2).sum() / ((yr - yr.mean()) ** 2).sum()
        for j, nme in enumerate(names):
            others = np.delete(R, j, axis=1)
            Zo = np.column_stack([np.ones(len(D)), others])
            rx = R[:, j] - Zo @ np.linalg.lstsq(Zo, R[:, j], rcond=None)[0]
            ry = yr - Zo @ np.linalg.lstsq(Zo, yr, rcond=None)[0]
            prcc = np.corrcoef(rx, ry)[0, 1]
            tstat = prcc * np.sqrt((len(D) - 2 - (len(names) - 1)) / max(1 - prcc ** 2, 1e-12))
            p = 2 * (1 - stats.t.cdf(abs(tstat), len(D) - 2 - (len(names) - 1)))
            # first-order (main-effect) share by binning (correlation ratio)
            bins = pd.qcut(D[nme], 10, labels=False, duplicates="drop")
            eta2 = D.groupby(bins)[y].mean().var(ddof=0) / D[y].var(ddof=0) if D[y].var() > 0 else np.nan
            res.append(dict(output=y, parameter=nme, prcc=prcc, p=p, eta2=eta2, r2_rank_additive=r2_rank))
    P = pd.DataFrame(res)
    P.to_csv(OUT + "/lhs_prcc.csv", index=False)
    S = dict(n=n, n_mc=nmc, n_screened_median=float(D.n_screened.median()), n_screened_p05=float(D.n_screened.quantile(.05)),
             n_screened_p95=float(D.n_screened.quantile(.95)), n_screened_min=int(D.n_screened.min()), n_screened_max=int(D.n_screened.max()),
             n_confirmed_counts=D.n_confirmed.value_counts().sort_index().to_dict(),
             jaccard_median=float(D.jaccard_vs_ref.median()), jaccard_p05=float(D.jaccard_vs_ref.quantile(.05)),
             frac_runs_confirmed_zero=float((D.n_confirmed == 0).mean()),
             wells_ever_screened=int((F > 0).sum()), wells_screened_ge50=int((F >= 0.5).sum()), ref_screened_freq_min=float(F[list(ref)].min()),
             wells_ever_confirmed=int((Fc > 0).sum()), confirm_freq_max=float(Fc.max()),
             critical_ever_screened=int(((F > 0) & w.set_index("SID").IsCritical.reindex(F.index)).sum()))
    if len(P):
        for y in P.output.unique():
            q = P[P.output == y]
            S[f"r2_rank_additive_{y}"] = float(q.r2_rank_additive.iloc[0]); S[f"sum_eta2_{y}"] = float(q.eta2.sum())
            S[f"top_prcc_{y}"] = q.reindex(q.prcc.abs().sort_values(ascending=False).index).head(5)[["parameter", "prcc", "p"]].round(3).values.tolist()
    json.dump(S, open(OUT + "/lhs_summary.json", "w"), indent=1, default=float)
    print(json.dumps(S, indent=1, default=float)); print("lhs time", round(time.time() - t), "s")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("sections", nargs="*", default=["reference", "structure", "baselines", "temporal", "oat", "prospective", "lhs"])
    ap.add_argument("--reps", type=int, default=50)
    ap.add_argument("--n-lhs", type=int, default=400)
    ap.add_argument("--procs", type=int, default=2)
    a = ap.parse_args()
    os.makedirs(OUT, exist_ok=True)
    for s in a.sections:
        t = time.time()
        {"reference": run_reference, "structure": structure, "baselines": baselines, "temporal": temporal,
         "oat": lambda: oat(a.procs), "prospective": lambda: prospective(a.reps, procs=a.procs),
         "lhs": lambda: lhs(a.n_lhs, a.procs), "blocks": lambda: prospective_blocks(a.reps, procs=a.procs),
         "safeguard": safeguard_check}[s]()
        print(f"[{s}] {time.time() - t:.0f} s", flush=True)
