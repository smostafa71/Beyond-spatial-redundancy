"""Collects every number quoted in the revised manuscript into analysis_r1/numbers.json (single source of truth)."""
import json, re, os
import numpy as np, pandas as pd
import geopandas as gpd

A = "analysis_r1/"; R = A + "reference/"
N = {}
WORDS = {0: "no", 1: "one", 2: "two", 3: "three", 4: "four", 5: "five", 6: "six", 7: "seven", 8: "eight", 9: "nine", 10: "ten",
         11: "eleven", 12: "twelve", 13: "thirteen", 14: "fourteen", 15: "fifteen", 16: "sixteen", 17: "seventeen", 18: "eighteen",
         19: "nineteen", 20: "twenty", 21: "twenty-one", 22: "twenty-two", 23: "twenty-three", 24: "twenty-four", 25: "twenty-five",
         26: "twenty-six", 27: "twenty-seven", 28: "twenty-eight", 29: "twenty-nine", 30: "thirty"}


def f(x, d=0):
    """number with thousands separator; d decimals; halves rounded up (160.5 -> 161)"""
    from decimal import Decimal, ROUND_HALF_UP
    q = Decimal(1).scaleb(-d)
    return f"{float(Decimal(str(float(x))).quantize(q, rounding=ROUND_HALF_UP)):,.{d}f}"


S = json.load(open(A + "summary.json"))
L = json.load(open(A + "edp_build_log.json"))
T = pd.read_csv(A + "structure_aquifers.csv").set_index("aquifer")
C = pd.read_csv(A + "structure_contrasts.csv").set_index("metric")
W = pd.read_csv(R + "Retention_probabilities_perSID_B4_9_GRAPH_AWARE_ACTIVE_SENSING.csv", dtype={"SID": str})
ST = pd.read_csv(A + "edp_station_chloride.csv", dtype={"SID": str}).set_index("SID")
AV = pd.read_csv(A + "attribute_vs_edp.csv", dtype={"SID": str})
inv_sids = AV.SID.nunique()

# ---- data
N["n_sids"] = f(inv_sids); N["n_confining"] = S["n_excluded_confining"]; N["n_confining_w"] = WORDS[S["n_excluded_confining"]].capitalize()
N["n_wells"] = S["n_wells"]; N["n_ufa"] = S["n_by_aquifer"]["upper floridan"]; N["n_haw"] = S["n_by_aquifer"]["hawthorn"]; N["n_sur"] = S["n_by_aquifer"]["surficial"]
N["edp_records"] = f(L["wq139_records"]); N["edp_wq140"] = L["wq140_records_excluded"]
N["edp_dups"] = f(L["wq139_records"] - L["after_exact_duplicate_removal"]); N["edp_invalid"] = L["non_numeric_removed"] + L["non_positive_removed"]
wells = W.SID
N["dev_n_median"] = int(ST.loc[wells, "dev_n"].median()); N["val_n_median"] = int(ST.loc[wells, "val_n"].median())
dd = ST.loc[wells, "dev_dir"].value_counts()
N["n_trend_nd"] = int(dd.get("NOT DETERMINED", 0)); N["n_rising"] = int(dd.get("RISING", 0)); N["n_falling"] = int(dd.get("FALLING", 0))
N["edp_notrend_n"] = int(dd.get("NO TREND", 0))
aw = AV[AV.SID.isin(wells)]
N["attr_ratio_median"] = f"{aw.ratio_attr_edp.median():.2f}"
N["attr_gt25"] = int(((aw.ratio_attr_edp > 1.25) | (aw.ratio_attr_edp < 0.8)).sum())
N["attr_stable_n"] = int((aw.CHLORIDE_T_ATTR == "STABLE").sum())
_tc = W.CHLORIDE_T.astype(str).str.strip().str.upper().value_counts()     # inventory trend class (analysis input)
N["n_trend_dec"] = int(_tc.get("DECREASING", 0)); N["n_trend_sta"] = int(_tc.get("STABLE", 0)); N["n_trend_inc"] = int(_tc.get("INCREASING", 0))
assert N["n_trend_dec"] + N["n_trend_sta"] + N["n_trend_inc"] == len(W), _tc.to_dict()
N["n_depth_missing"] = int(W.Depth_missing_imputed.sum())
N["n_critical"] = S["n_critical"]; N["n_critical_dom"] = S["n_critical_dominant"]
N["crit_pct"] = f"{100 * S['n_critical'] / S['n_wells']:.0f}"
noncrit = W[W.IsCritical.astype(int) == 0]
N["n_noncrit"] = len(noncrit); N["n_noncrit_noniso"] = int((~noncrit.Isolated_within_Ell.astype(bool)).sum())
N["n_noncrit_noniso_ufa"] = int(((noncrit.Aquifer_group == "upper floridan") & ~noncrit.Isolated_within_Ell.astype(bool)).sum())
N["n_noncrit_noniso_ch"] = int(((noncrit.Aquifer_group == "upper floridan") & ~noncrit.Isolated_within_Ell.astype(bool) & noncrit.COUNTY.isin(["Citrus", "Hernando", "Pasco"])).sum())

# ---- structure
N["n_components"] = S["n_components"]; N["n_isolated"] = S["n_isolated"]
for a, k in [("upper floridan", "ufa"), ("hawthorn", "haw"), ("surficial", "sur")]:
    N[f"ell_{k}"] = f(T.loc[a, "ell_m"]); N[f"nn_{k}"] = f(T.loc[a, "mean_nn_m"]); N[f"iso_{k}"] = int(T.loc[a, "n_isolated"])
N["dom_ufa"] = int(T.loc["upper floridan", "dominant_size"]); N["dom_ufa_pct"] = f"{100 * T.loc['upper floridan', 'dominant_share']:.0f}"
_CS = pd.read_csv(R + "Components_summary.csv"); _cu = _CS[_CS.Aquifer_group == "upper floridan"].N_in_component.sort_values()
N["comp_ufa_other_min"] = int(_cu.iloc[0]); N["comp_ufa_other_max"] = int(_cu.iloc[-2])
N["n_comp_ufa_minus1"] = int(T.loc["upper floridan", "n_components"]) - 1; N["n_single_ufa"] = int(T.loc["upper floridan", "n_singleton_components"])
N["n_comp_haw"] = int(T.loc["hawthorn", "n_components"]); N["dom_haw"] = int(T.loc["hawthorn", "dominant_size"])
N["dom_haw_pct"] = f"{100 * T.loc['hawthorn', 'dominant_share']:.0f}"

# ---- weights and detection
w = S["weights"]
for k in ["information", "joint_quality", "distance", "trend", "dependency", "chloride", "graph_role", "depth", "status"]:
    N[f"w_{k}"] = f"{w[k]:.3f}"
N["w_family"] = f"{S['network_family_weight']:.2f}"
N["w_trend_r0"] = "0.098"      # original submission (Validation_Summary of FINAL6)
_LG = pd.read_csv(A + "ledger.csv").set_index("step")
N["w_trend_l1"] = f"{_LG.loc['L1', 'w_trend']:.3f}"; N["w_trend_l2"] = f"{_LG.loc['L2', 'w_trend']:.3f}"
pre = S["pre_hard_resolve"]
N["pre_keep"] = pre.get("KEEP", 0); N["pre_review"] = pre.get("REVIEW", 0); N["pre_cr"] = pre.get("CANDIDATE_REMOVE", 0)
N["mean_pk"] = f"{S['mean_P_keep']:.3f}"; N["mean_pr"] = f"{S['mean_P_review']:.3f}"; N["mean_pcr"] = f"{S['mean_P_remove']:.3f}"
hr = S["hard_resolve_sources"]
N["hr_crit"] = hr.get("critical_force_keep", 0); N["hr_votes"] = hr.get("hard_review_to_keep_consensus", 0); N["hr_tie"] = hr.get("hard_review_to_keep_conservative_tie", 0)
N["hr_remove"] = hr.get("hard_review_to_remove_consensus", 0)
_k = [(N["hr_crit"], "by the critical rule"), (N["hr_votes"], "by votes"), (N["hr_tie"], "by the tie rule")]
_k = [f"{n} {t}" for n, t in _k if n]
_nk = N['hr_crit'] + N['hr_votes'] + N['hr_tie']
N["hr_text"] = ((f"all {_nk} were resolved to KEEP (" if _nk == N["pre_review"] else f"{_nk} of them were resolved to KEEP (") + (", ".join(_k[:-1]) + " and " + _k[-1] if len(_k) > 1 else _k[0]) + ")"
                + (f" and {WORDS[N['hr_remove']]} to CANDIDATE_REMOVE by votes (Eq. 20)" if N["hr_remove"] else ""))
assert N["hr_crit"] + N["hr_votes"] + N["hr_tie"] + N["hr_remove"] == N["pre_review"], hr
N["n_screened"] = S["n_screened"]; N["n_screened_w"] = WORDS[S["n_screened"]]; N["n_screened_W"] = WORDS[S["n_screened"]].capitalize()
N["scr_pct"] = f"{100 * S['n_screened'] / S['n_wells']:.1f}"
N["scr_ufa"] = int((W.FinalDecision_BGAS.eq("CANDIDATE_REMOVE") & W.Aquifer_group.eq("upper floridan")).sum())
N["scr_pcr_pct"] = f"{100 * S['screened_P_remove_mean']:.0f}"
N["isi_scr"] = f"{S['ISI_screened_mean']:.2f}"; N["isi_ret"] = f"{S['ISI_retained_mean']:.2f}"; N["isi_mean"] = f"{S['ISI_mean']:.2f}"
N["isi_high"] = S["ISI_classes"].get("HIGH", 0); N["isi_med"] = S["ISI_classes"].get("MEDIUM", 0); N["isi_low"] = S["ISI_classes"].get("LOW", 0)
for key, m in [("sgi", "GraphInfluence_score"), ("graph", "P_keep_graph_role_base"), ("bridge", "GraphRole_bridge_proxy"),
               ("info", "P_keep_information_base"), ("dep", "P_keep_dependency_base"), ("dist", "P_keep_distance_base")]:
    N[f"c_{key}_s"] = f"{C.loc[m, 'screened_mean']:.2f}"; N[f"c_{key}_r"] = f"{C.loc[m, 'retained_nonisolated_mean']:.2f}"
    _pv = C.loc[m, 'mw_p_vs_nonisolated']
    N[f"c_{key}_p"] = f"{_pv:.2f}" if _pv >= 0.1 else (f"{_pv:.3f}" if _pv >= 0.001 else "< 0.001")

# ---- confirmation
N["scr_cl_min"] = f"{S['screened_Cl_min']:.0f}"; N["scr_cl_max"] = f"{S['screened_Cl_max']:.0f}"
N["scr_pchl_min"] = f"{np.floor(S['screened_Pchl_min'] * 100) / 100:.2f}"
_sids = lambda L: " and ".join([", ".join(L[:-1]), L[-1]]) if len(L) > 1 else "".join(L)
_scr = W[W.FinalDecision_BGAS == "CANDIDATE_REMOVE"]
_ci = sorted(_scr.SID[_scr.Safeguard_trig_LOO.astype(str).str.lower() == "true"])
N["crit_i_n"] = WORDS[len(_ci)].capitalize(); N["crit_i_sids"] = _sids(_ci)
_tr = lambda c: _scr[c].astype(str).str.lower() == "true"
_conf = _scr[_scr.FinalDecision == "CANDIDATE_REMOVE"].sort_values("SID"); _rev = _scr[_scr.FinalDecision == "REVIEW"]
N["n_confirmed"] = len(_conf); N["n_confirmed_w"] = WORDS[len(_conf)]; N["n_confirmed_W"] = WORDS[len(_conf)].capitalize()
N["conf_sids"] = _sids(list(_conf.SID)); N["conf_cl"] = " and ".join(f(x) for x in _conf.CHLORIDE)
N["conf_pchl"] = " and ".join(f"{x:.2f}" for x in _conf.P_keep_chloride_adj)
N["conf_counties"] = _sids(list(_conf.COUNTY)) + (" counties" if _conf.COUNTY.nunique() > 1 else " County")
N["n_review_scr"] = len(_rev)
_iii = _rev[_tr("Safeguard_trig_CHL").reindex(_rev.index)]
N["crit_iii_n"] = len(_iii); N["scr_iii_cl_min"] = f(_iii.CHLORIDE.min()); N["scr_iii_cl_max"] = f(_iii.CHLORIDE.max())
N["scr_iii_pchl_min"] = f"{np.floor(_iii.P_keep_chloride_adj.min() * 100) / 100:.2f}"
_io = _rev[_tr("Safeguard_trig_LOO").reindex(_rev.index) & ~_tr("Safeguard_trig_CHL").reindex(_rev.index)]
N["crit_i_only_n"] = WORDS[len(_io)]; N["crit_i_only_cl_min"] = f(_io.CHLORIDE.min()) if len(_io) else "–"
N["crit_i_only_cl_max"] = f(_io.CHLORIDE.max()) if len(_io) else "–"
# Sect. 4.2: the wells kept by criterion (i) alone are the most saline screened wells and have a lower chloride keep score
# than the confirmed wells, so that the decision is not a chloride threshold
assert len(_io) and _io.CHLORIDE.min() > _scr.drop(_io.index).CHLORIDE.max(), "criterion-(i)-only wells = most saline screened wells"
assert _io.P_keep_chloride_adj.max() < _conf.P_keep_chloride_adj.min(), "their chloride keep score is below that of the confirmed wells"
N["crit_i_count"] = WORDS[len(_ci)]; N["crit_ii_n"] = int(_tr("Safeguard_trig_SGI").sum())
import r1common as _rc
N["dnn_e"] = f"{_rc.delta_nn(W, list(_conf.SID)):.0f}"
_u = W[W.Aquifer_group == "upper floridan"]; _dom = _u.Component_id.value_counts().idxmax()
_su = _scr[_scr.Aquifer_group == "upper floridan"]
N["scr_ufa_dom"] = int((_su.Component_id == _dom).sum())
N["scr_dom_counties"] = _sids(sorted(_su[_su.Component_id == _dom].COUNTY.unique())) + " counties"
_out = _su[_su.Component_id != _dom]
N["scr_ufa_out"] = ("" if len(_out) == 0 else
                    f", and {WORDS[len(_out)]} (SID{'s' if len(_out) > 1 else ''} {_sids(sorted(_out.SID))}) to {'smaller components' if len(_out) > 1 else 'a smaller component'} in "
                    + _sids(sorted(_out.COUNTY.unique())) + (" counties" if _out.COUNTY.nunique() > 1 else " County"))
_ndom = 0
for _aq, _g in _scr.groupby("Aquifer_group"):                          # screened wells in the dominant component of their aquifer
    _ndom += int((_g.Component_id == W[W.Aquifer_group == _aq].Component_id.value_counts().idxmax()).sum())
N["scr_dom_n"] = _ndom
_nc = W[W.IsCritical.astype(int) == 0]
N["noncrit_brackish_n"] = WORDS[int((_nc.CHLORIDE > 1000).sum())]
_cty = sorted(_scr[_scr.Aquifer_group == "upper floridan"].COUNTY.dropna().unique())
N["scr_ufa_counties"] = _sids(_cty) + (" counties" if len(_cty) > 1 else " County")
N["loo_q85"] = f(S["loo_q85"]); N["scr_sgi_min"] = f"{S['screened_SGI_min']:.2f}"; N["scr_sgi_max"] = f"{S['screened_SGI_max']:.2f}"
N["dnn_b"] = f"{S['dNN_BGAS']:.0f}"

# ---- candidates
for tag, k in [("BGAS", "cb"), ("EGAS", "ce")]:
    ba = S[f"cand_{tag}_by_aquifer"]
    N[f"{k}_n"] = S[f"cand_{tag}_n"]; N[f"{k}_ufa"] = ba.get("upper floridan", 0); N[f"{k}_haw"] = ba.get("hawthorn", 0); N[f"{k}_sur"] = ba.get("surficial", 0)
    N[f"{k}_comp"] = S[f"cand_{tag}_components"]; N[f"{k}_min"] = f"{S[f'cand_{tag}_score_min']:.2f}"; N[f"{k}_max"] = f"{S[f'cand_{tag}_score_max']:.2f}"
    N[f"{k}_mean"] = f"{S[f'cand_{tag}_score_mean']:.2f}"; N[f"{k}_dist"] = f"{S[f'cand_{tag}_dist_mean_m'] / 1000:.1f}"
_cty = gpd.read_file("basemap/cb_2023_us_county_500k/cb_2023_us_county_500k.shp")
_cty = _cty[_cty.STATEFP == "12"].to_crs(4326)[["NAME", "geometry"]]
for _f, k in [("Candidate_new_wells_BGAS.csv", "cb"), ("Candidate_new_wells_B4_9.csv", "ce")]:
    _C = pd.read_csv(A + "reference/" + _f)
    _g = gpd.sjoin(gpd.GeoDataFrame(_C, geometry=gpd.points_from_xy(_C.Lon, _C.Lat), crs=4326), _cty, how="left")
    _nh = int(((_g.Aquifer_group == "hawthorn") & _g.NAME.isin(["Pinellas"])).sum())
    N[f"{k}_haw_north"] = "none" if _nh == 0 else WORDS[_nh]
    N[f"{k}_water"] = int(_g.NAME.isna().sum())
    N[f"{k}_south"] = int(_g.NAME.isin(["DeSoto", "Charlotte", "Manatee", "Sarasota"]).sum())
    N[f"{k}_hil"] = int(((_g.Aquifer_group == "upper floridan") & _g.NAME.eq("Hillsborough")).sum())
assert N["cb_south"] > N["cb_n"] / 2 and N["ce_hil"] >= 0.25 * N["ce_n"], "Sect. 3.4 wording"
aw_ = S["AS_weights_by_aquifer"]["upper floridan"]
N["as_w_ufa"] = ", ".join(f"{aw_[k]:.2f}" for k in ["AS_w_unc", "AS_w_sup", "AS_w_gra", "AS_w_rep", "AS_w_dep"])

# ---- baselines
B = pd.read_csv(A + "baselines_equal_budget.csv")
ba = B[B.pool == "all wells"].set_index("method"); bp = B[B.pool != "all wells"].set_index("method")
M = {"dist": "Distance thinning", "rec": "Reconstructability", "krig": "Kriging variance", "gas": "GAS (B-GAS screening)"}
for k, m in M.items():
    N[f"j_{k}"] = f"{ba.loc[m, 'jaccard_vs_GAS']:.2f}"; N[f"crit_{k}"] = int(ba.loc[m, "n_critical"])
    N[f"dnn_{k}"] = f"{ba.loc[m, 'dNN_m']:.0f}"; N[f"loo_{k}"] = f(ba.loc[m, "loo_mean_mgL"])
    N[f"dnnr_{k}"] = f"{bp.loc[m, 'dNN_m']:.0f}"; N[f"riser_{k}"] = int(bp.loc[m, "n_dev_rising"])
N["crit_rand"] = f"{ba.loc['Random (mean of 1000)', 'n_critical']:.1f}"
N["dnnr_rand"] = f"{bp.loc['Random (mean of 1000)', 'dNN_m']:.0f}".replace("-", "−")
jr = [bp.loc[M[k], "jaccard_vs_GAS"] for k in ("dist", "rec", "krig")]
N["jr_min"] = f"{min(jr):.2f}"; N["jr_max"] = f"{max(jr):.2f}"; N["jr_rand"] = f"{bp.loc['Random (mean of 1000)', 'jaccard_vs_GAS']:.2f}"
N["rise_gas"] = int(bp.loc[M["gas"], "n_dev_rising"])
N["riser_rand"] = f"{bp.loc['Random (mean of 1000)', 'n_dev_rising']:.1f}"; N["riser_rand05"] = f"{bp.loc['Random 5th pct', 'n_dev_rising']:.0f}"
N["later_gas"] = f"{bp.loc[M['gas'], 'later_rec_median_factor']:.1f}"
N["later_rand05"] = f"{bp.loc['Random 5th pct', 'later_rec_median_factor']:.1f}"; N["later_rand95"] = f"{bp.loc['Random 95th pct', 'later_rec_median_factor']:.1f}"
N["later_rise_max"] = int(max(B[B.method.isin(M.values())].n_val_rising))
vg = json.load(open(A + "baselines_variograms.json"))["upper floridan"]
N["vg_ufa"] = f"nugget {vg['nugget']:.2f} and partial sill {vg['sill']:.2f} (log~10~ mg/L)^2^"
_nnu = float(T.loc["upper floridan", "mean_nn_m"])
N["vg_ufa_frac"] = f"{100 * (vg['nugget'] + vg['sill'] * (1 - np.exp(-_nnu / vg['range']))) / (vg['nugget'] + vg['sill']):.0f}"
N["vg_ufa_range"] = f(vg["range"]); N["vg_ufa_nugpct"] = f"{100 * vg['nugget'] / (vg['nugget'] + vg['sill']):.0f}"

# ---- eligible (non-critical) wells and Avon Park wells
_W = pd.read_csv(A + "reference/Retention_probabilities_perSID_B4_9_GRAPH_AWARE_ACTIVE_SENSING.csv", low_memory=False)
_nc = _W[_W.IsCritical.astype(int) == 0]
N["noncrit_cl_max"] = f(_nc.CHLORIDE.max()); N["noncrit_pchl_min"] = f"{np.floor(_nc.P_keep_chloride_adj.min() * 100) / 100:.2f}"
N["pchl85_n"] = int((_W.P_keep_chloride_adj >= 0.85).sum()); N["pchl85_clmax"] = f(_W.loc[_W.P_keep_chloride_adj >= 0.85, "CHLORIDE"].max())
_ap = _W[_W.Waterbod_1_raw.astype(str).str.contains("Avon Park")]
N["n_appz"] = len(_ap); N["n_appz_south"] = int((_ap.Lat < 27.95).sum())     # south of central Polk County

# ---- co-located wells (sites with two or more wells < 150 m apart)
from scipy.spatial import cKDTree
from scipy.sparse import coo_matrix
from scipy.sparse.csgraph import connected_components
from pyproj import Transformer
_R = pd.read_csv(A + "reference/Retention_probabilities_perSID_B4_9_GRAPH_AWARE_ACTIVE_SENSING.csv", low_memory=False)
_x, _y = Transformer.from_crs(4326, 3087, always_xy=True).transform(_R.LONGITUDE.values, _R.LATITUDE.values)
_pr = np.array(sorted(cKDTree(np.c_[_x, _y]).query_pairs(150.0)))
_G = coo_matrix((np.ones(len(_pr)), (_pr[:, 0], _pr[:, 1])), shape=(len(_R), len(_R)))
_R = _R.assign(site=connected_components(_G, directed=False)[1], cl=_R.CHLORIDE.clip(lower=0.1))
_sz = _R.groupby("site").size(); _multi = _R[_R.site.isin(_sz[_sz >= 2].index)]
_rat = lambda g: g.cl.max() / g.cl.min() > 10
N["coloc_sites"] = int(_multi.site.nunique()); N["coloc_wells"] = int(len(_multi))
N["coloc_contrast"] = int(_multi.groupby("site").apply(_rat).sum())
N["coloc_contrast_same"] = int(_multi.groupby("site").apply(lambda g: any(len(h) > 1 and _rat(h) for _, h in g.groupby("Aquifer_group"))).sum())
N["coloc_diffaq"] = int((_multi.groupby("site").Aquifer_group.nunique() > 1).sum())

# ---- temporal
TV = json.load(open(A + "temporal_summary.json"))
TS = pd.read_csv(A + "temporal_screened_wells.csv", dtype={"SID": str}).set_index("SID")
TG = pd.read_csv(A + "temporal_groups.csv").set_index("group")
N["scr_ratio_min"] = f"{TV['screened_ratio_min']:.2f}"; N["scr_ratio_max"] = f"{TV['screened_ratio_max']:.2f}"
N["cl_20181_dev"] = f"{TS.loc['20181', 'CHLORIDE']:.1f}"; N["cl_20181_val"] = f"{TS.loc['20181', 'Cl_val']:.1f}"
N["tv_scr"] = f"{TG.loc['screened', 'later_loo_median_factor']:.1f}"; N["tv_oth"] = f"{TG.loc['other non-isolated', 'later_loo_median_factor']:.1f}"
N["tv_iso"] = f"{TG.loc['isolated', 'later_loo_median_factor']:.1f}"; N["tv_p"] = f"{TV['mw_p']:.2f}"
_mx = TS.ratio_val_dev.idxmax()                                       # screened well with the largest change after 2020
N["scr_max_sid"] = _mx; N["scr_max_dev"] = f(TS.loc[_mx, "CHLORIDE"]); N["scr_max_val"] = f(TS.loc[_mx, "Cl_val"])
_vr = sorted(TS.index[TS.val_dir == "RISING"])                     # screened wells with significantly rising 2021-2026 chloride
N["scr_val_rising_n"] = WORDS[len(_vr)]; N["scr_val_rising_sids"] = " and ".join([", ".join(_vr[:-1]), _vr[-1]]) if len(_vr) > 1 else "".join(_vr)

# ---- independent check of the confirmation stage with the 2021-2026 record (analyses_r1.py safeguard)
SG = json.load(open(A + "safeguard_check.json"))
_p3 = lambda v: "< 0.001" if v < 0.001 else f"= {v:.3f}"
N["sg_n"] = SG["n"]; N["sg_rho"] = f"{SG['spearman_err']:.2f}"; N["sg_rho_log"] = f"{SG['spearman_log']:.2f}"
N["sg_n_above"] = SG["n_above_q85"]; N["sg_above_f"] = f"{SG['later_factor_above_q85']:.0f}"; N["sg_below_f"] = f"{SG['later_factor_below_q85']:.1f}"
N["sg_above_p"] = _p3(SG["mw_p_above_q85"])
N["sg_ci_n"] = WORDS[SG["crit_i_n"]]; N["sg_ci_f"] = f"{SG['crit_i_later_factor']:.0f}"; N["sg_oth_f"] = f"{SG['other_later_factor']:.1f}"
N["sg_ci_p"] = _p3(SG["mw_p_crit_i"]); N["sg_ci_min"] = f"{SG['crit_i_min_later_factor']:.0f}"
N["sg_ci_err"] = f(SG["crit_i_later_err_median"]); N["sg_oth_err"] = f(SG["other_later_err_median"])
N["sg_ratio"] = f"{SG['crit_i_later_factor'] / SG['other_later_factor']:.0f}"
assert SG["mw_p_crit_i"] < 0.05 and SG["mw_p_above_q85"] < 0.05 and SG["spearman_err"] > 0.9, "text: the safeguard check is described as significant"
N["rd_neigh_pct"] = f"{100 * SG['random_design_frac_neighbour_within_ell']:.0f}"; N["rd_med"] = f"{SG['random_design_median_dist_ell']:.1f}"
N["gd_neigh_pct"] = f"{100 * SG['gap_design_frac_neighbour_within_ell']:.0f}"; N["gd_med"] = f"{SG['gap_design_median_dist_ell']:.1f}"

# ---- eligibility of the screened wells; LOO without the four wells of criterion (i); later error of the confirmed wells
_el = W[(W.IsCritical.astype(int) == 0) & ~W.Isolated_within_Ell.astype(bool)]
N["elig_scr"] = int(_el.FinalDecision_BGAS.eq("CANDIDATE_REMOVE").sum())
_rt = W[~W.FinalDecision_BGAS.eq("CANDIDATE_REMOVE") & ~W.Isolated_within_Ell.astype(bool)]
N["ret_n"] = len(_rt); N["ret_crit"] = int(_rt.IsCritical.astype(int).sum())
_x = _scr[~_tr("Safeguard_trig_LOO")]
N["loo_gas_wo"] = f(_x.AbsError_without_well.mean()); N["loo_gas_wo_med"] = f(_x.AbsError_without_well.median())
N["crit_i_saline"] = WORDS[int((_scr[_tr("Safeguard_trig_LOO")].CHLORIDE >= 5000).sum())]
_SW = pd.read_csv(A + "safeguard_check_wells.csv", dtype={"SID": str}).set_index("SID")
_up = _conf.sort_values("SID").iloc[0]           # the confirmed well whose chloride rose most
_cr = sorted(_conf.SID, key=lambda x: -_SW.loc[x, "Cl_val"] / _SW.loc[x, "CHLORIDE"])
N["conf_up_sid"] = _cr[0]; N["conf_st_sid"] = _cr[1]
N["conf_up_dev"] = f(_SW.loc[_cr[0], "CHLORIDE"]); N["conf_up_val"] = f(_SW.loc[_cr[0], "Cl_val"]); N["conf_st_val"] = f(_SW.loc[_cr[1], "Cl_val"])
N["conf_up_err"] = f(_SW.loc[_cr[0], "later_err"])
assert str(W.set_index("SID").loc[_cr[0], "CHLORIDE_T"]).upper() == "INCREASING", "text: the confirmed well that rose has an increasing trend class"
assert _SW.loc[_cr[0], "later_err"] > float(SG["q85"]), "text: its later error exceeds the criterion-(i) threshold"
N["n_crit_both"] = WORDS[int((_tr("Safeguard_trig_LOO") & _tr("Safeguard_trig_CHL")).sum())]
_bp2 = B[B.pool != "all wells"].set_index("method")
_dr = [float(_bp2.loc[M[k], "dNN_m"]) for k in ("dist", "rec", "krig")]
N["dnnr_min"] = f"{min(_dr):.0f}"; N["dnnr_max"] = f"{max(_dr):.0f}"

# ---- comparison of the two configurations (B-GAS and E-GAS)
_dnb, _dne = float(S["dNN_BGAS"]), float(_rc.delta_nn(W, list(_conf.SID)))
N["cfg_rem_red"] = f"{100 * (1 - len(_conf) / len(_scr)):.0f}"; N["cfg_dnn_red"] = f"{100 * (1 - _dne / _dnb):.0f}"
_CB = pd.read_csv(A + "reference/Candidate_new_wells_BGAS.csv"); _CE = pd.read_csv(A + "reference/Candidate_new_wells_B4_9.csv")
_ncomp = lambda D: int(D.groupby(["Aquifer_group", "SourceComponentID"]).ngroups)
_cnt = _CB.Aquifer_group.value_counts()
_CEq = pd.concat([_CE[_CE.Aquifer_group == a].sort_values("CandidateRank_inAquifer").head(n) for a, n in _cnt.items()])
N["cfg_comp_b"] = _ncomp(_CB); N["cfg_comp_e"] = _ncomp(_CE); N["cfg_comp_eq"] = _ncomp(_CEq)
_nh = lambda D: int(D[D.Aquifer_group == "hawthorn"].SourceComponentID.nunique())
N["cfg_haw_b"] = WORDS[_nh(_CB)]; N["cfg_haw_e"] = WORDS[_nh(_CE)]; N["cfg_haw_eq"] = WORDS[_nh(_CEq)]
N["n_comp_haw_w"] = WORDS[int(W[W.Aquifer_group == "hawthorn"].Component_id.nunique())]
assert N["cfg_comp_eq"] > N["cfg_comp_b"], "text: E-GAS covers more components at the B-GAS number of sites"
_TS2 = pd.read_csv(A + "temporal_screened_wells.csv", dtype={"SID": str}).set_index("SID")
N["conf_cl_val"] = " and ".join(f(_TS2.loc[x, "Cl_val"]) for x in _conf.SID)
_rs = int(_tr("Safeguard_trig_LOO").sum())
N["cfg_risk_i"] = WORDS[_rs]
_r3 = int(_tr("Safeguard_trig_CHL").sum())
N["cfg_risk_iii"] = _r3
_RA = pd.read_csv(A + "baselines_random_all.csv")
N["crit_rand_min"] = int(_RA.n_critical.min()); N["dnn_gas_pct"] = f"{100 * (_RA.dNN_m <= _dnb).mean():.0f}"
_dn = [float(ba.loc[M[k], "dNN_m"]) for k in ("dist", "rec", "krig")]
N["ext_ratio_min"] = f"{min(_dn) / _dnb:.1f}"; N["ext_ratio_max"] = f"{max(_dn) / _dnb:.0f}"
N["loo_med_gas"] = f(ba.loc[M["gas"], "loo_median_mgL"])

# ---- pseudo-prospective (random withholding)
_D = pd.read_csv(A + "prospective_reps.csv")          # pooled recovery recomputed from the replicates (no intermediate rounding)
_D = _D[_D.radius == 1.0].assign(w_hi=lambda d: d.n_high, w_lo=lambda d: d.n_held - d.n_high)
PP = _D.groupby("method").apply(lambda g: pd.Series(dict(
    hit_high=np.nansum(g.hit_high * g.w_hi) / g.w_hi[g.hit_high.notna()].sum(),
    hit_low=np.nansum(g.hit_low * g.w_lo) / g.w_lo[g.hit_low.notna()].sum())))
PR = pd.read_csv(A + "prospective_reps.csv")
N["pp_reps"] = int(PR.rep.nunique())
q = PR[(PR.radius == 1.0) & (PR.method == "GAS-E")]
N["pp_high_pct"] = f"{100 * q.n_high.sum() / q.n_held.sum():.0f}"
for k, m in [("e", "GAS-E"), ("b", "GAS-B"), ("r", "Random (pool)"), ("s", "Space-filling")]:
    N[f"pp_{k}_hi"] = f"{PP.loc[m, 'hit_high']:.2f}"; N[f"pp_{k}_lo"] = f"{PP.loc[m, 'hit_low']:.2f}"
fp = lambda v: "< 0.001" if v < 0.001 else f"= {v:.3f}"
tp = json.load(open(A + "prospective_tests.json"))
for k, m in [("e", "GAS-E"), ("b", "GAS-B"), ("s", "Space-filling")]:
    N[f"pp_p_{k}"] = fp(tp[m]["wilcoxon_p"])
_lb = {"GAS-B": "B-GAS", "GAS-E": "E-GAS", "Space-filling": "space-filling"}
_M3 = ["GAS-E", "GAS-B", "Space-filling"]
assert not any(tp[m]["wilcoxon_p"] < 0.05 and tp[m]["mean_diff"] > 0 for m in _M3), "text: no method recovered informative wells better than random"
_worse = [m for m in _M3 if tp[m]["wilcoxon_p"] < 0.05]; _ns3 = [m for m in _M3 if m not in _worse]
_and = lambda L: " and ".join([", ".join(L[:-1]), L[-1]]) if len(L) > 1 else "".join(L)
_t = ""
if _worse:
    _t = (f"Random sites recovered informative wells more often than {_and([_lb[m] + ' sites' for m in _worse])} (paired Wilcoxon *p* "
          + _and([fp(tp[m]['wilcoxon_p']) for m in _worse]) + ")")
if _ns3:
    _t += ("; " if _t else "") + (_and([_lb[m] for m in _ns3]) + " sites did not differ significantly from random sites (*p* = "
          + _and([f"{tp[m]['wilcoxon_p']:.2f}" for m in _ns3]) + ")")
N["pp_sig_text"] = _t[0].upper() + _t[1:] + "."
N["pp_sig_text_short"] = f"paired Wilcoxon *p* {fp(tp['GAS-E']['wilcoxon_p'])}"
_disc = PP.hit_high - PP.hit_low
assert _disc["GAS-B"] >= 0 and all(_disc[m] < 0 for m in ["GAS-E", "Random (pool)", "Space-filling"]), "ESM S6: only B-GAS discriminates"

# ---- pseudo-prospective (spatial gaps)
if os.path.exists(A + "prospective_blocks_summary.csv"):
    PB = pd.read_csv(A + "prospective_blocks_summary.csv").set_index("method")
    PBr = pd.read_csv(A + "prospective_blocks_reps.csv")
    tb = json.load(open(A + "prospective_blocks_tests.json"))
    N["ppb_reps"] = int(PBr.rep.nunique()); N["ppb_held"] = f"{PB.loc['GAS-E', 'n_held']:.0f}"
    PB = PBr.groupby("method")[["any_in_hole", "hit_all", "n_held"]].mean()          # from the replicates, no intermediate rounding
    g = lambda m, c: PB.loc[m, c]
    _lab = {"GAS-B": "B-GAS", "GAS-E": "E-GAS", "Space-filling": "space-filling"}
    _sig = [m for m in ["GAS-B", "GAS-E", "Space-filling"] if tb[m]["wilcoxon_p"] < 0.05]
    _ns = [m for m in ["GAS-B", "GAS-E", "Space-filling"] if m not in _sig]
    _pf = lambda v: "< 0.001" if v < 0.001 else f"= {v:.3f}" if v < 0.1 else f"= {v:.2f}"
    _ss = "; ".join(f"{_lab[m]} sites were within ℓ~a~ of {'more' if tb[m]['mean_diff_hit_all'] > 0 else 'fewer'} withheld wells than random "
                    f"sites (paired Wilcoxon *p* {_pf(tb[m]['wilcoxon_p'])})" for m in _sig)
    _and2 = lambda L: " and ".join([", ".join(L[:-1]), L[-1]]) if len(L) > 1 else "".join(L)
    _nn = (_and2([_lab[m] for m in _ns]) + " sites did not differ significantly from random sites (*p* = "
           + _and2([f"{tb[m]['wilcoxon_p']:.2f}" for m in _ns]) + ")") if _ns else ""
    assert not any(tb[m]["wilcoxon_p"] < 0.05 for m in ["GAS-B", "GAS-E", "Space-filling"]), "letter R2.5/annotation 5: gap design not significant"
    _kb, _ke = PBr[PBr.method == "GAS-B"].k.mean(), PBr[PBr.method == "GAS-E"].k.mean()
    from scipy import stats as _st
    _rr = PBr[PBr.method == "Random (pool)"].set_index("rep")
    _pt = {(m, c): float(_st.wilcoxon((PBr[PBr.method == m].set_index("rep")[c] - _rr[c]).dropna()).pvalue)
           for m in ["GAS-B", "GAS-E", "Space-filling"] for c in ["any_in_hole", "hit_all"]}
    assert all(v >= 0.05 for (m, c), v in _pt.items() if m != "Space-filling"), "text: GAS not significantly different from random in the gap test"
    assert _pt[("Space-filling", "any_in_hole")] < 0.05 and _pt[("Space-filling", "hit_all")] >= 0.05, "text: space-filling significant on the gap measure only"
    N["ppb_p_sf_any"] = _pf(_pt[("Space-filling", "any_in_hole")]); N["ppb_p_sf_hit"] = f"{_pt[('Space-filling', 'hit_all')]:.2f}"
    N["ppb_p_gas_min"] = f"{min(v for (m, c), v in _pt.items() if m != 'Space-filling'):.2f}"
    N["ppb_text"] = (f"at least one site fell into the gap in {100 * g('GAS-B', 'any_in_hole'):.0f} % of the replicates for B-GAS, "
                     f"{100 * g('GAS-E', 'any_in_hole'):.0f} % for E-GAS, {100 * g('Space-filling', 'any_in_hole'):.0f} % for space-filling and "
                     f"{100 * g('Random (pool)', 'any_in_hole'):.0f} % for random sites, and the sites were within ℓ~a~ of "
                     f"{100 * g('GAS-B', 'hit_all'):.0f} %, {100 * g('GAS-E', 'hit_all'):.0f} %, {100 * g('Space-filling', 'hit_all'):.0f} % and "
                     f"{100 * g('Random (pool)', 'hit_all'):.0f} % of the withheld wells. Space-filling sites fell into the gap significantly more "
                     f"often than random sites (paired Wilcoxon *p* {N['ppb_p_sf_any']}; *p* = {N['ppb_p_sf_hit']} for the withheld wells); for B-GAS "
                     f"and E-GAS neither measure differed significantly from random sites (*p* ≥ {N['ppb_p_gas_min']}).")
    N["ppb_kb"] = f"{_kb:.1f}"; N["ppb_ke"] = f"{_ke:.1f}"
    for _k, _m in [("b", "GAS-B"), ("e", "GAS-E"), ("r", "Random (pool)"), ("s", "Space-filling")]:
        N[f"ppb_{_k}_any"] = f"{100 * g(_m, 'any_in_hole'):.0f}"; N[f"ppb_{_k}_hit"] = f"{100 * g(_m, 'hit_all'):.0f}"
    N["ppb_p_b"] = _pf(tb["GAS-B"]["wilcoxon_p"]); N["ppb_p_e"] = _pf(tb["GAS-E"]["wilcoxon_p"])
else:
    N["ppb_reps"] = "–"; N["ppb_held"] = "–"; N["ppb_text"] = "(pending)"

# ---- one-at-a-time
O = pd.read_csv(A + "oat.csv").set_index("variant")
base = O.loc[[v for v in O.index if not v.startswith("Critical rule")]]
N["oat_min"] = int(base.n_screened.min()); N["oat_max"] = int(base.n_screened.max()); N["oat_jmin"] = f"{base.jaccard_screened_vs_ref.min():.2f}"
_ref = set(str(O.loc["Reference", "screened"]).split(";"))
_ch = lambda v: (len(set(str(O.loc[v, "screened"]).split(";")) - _ref), len(_ref - set(str(O.loc[v, "screened"]).split(";"))))
_mc = [max(_ch(v)) for v in ["Seed 1", "Seed 2", "Seed 3", "Seed 4", "N_MC 1000", "N_MC 10000"]]
N["oat_mc_text"] = "did not change the screened set" if max(_mc) == 0 else f"exchanged at most {max(_mc)} well" + ("s" if max(_mc) > 1 else "")
_a, _r = _ch("Trend scores 0.80/0.65/0.25 (code)")
_w = {0: "no", 1: "one", 2: "two", 3: "three", 4: "four"}
N["oat_trend_text"] = ("did not change the screened set" if _a == 0 and _r == 0 else
                      f"added {_w[_a]} well{'s' if _a > 1 else ''} and removed {_w[_r]}" if _r else f"added {_w[_a]} well{'s' if _a > 1 else ''}")
_hs = [sum(_ch(v)) for v in ["Hydrostratigraphic edges (strict)", "Hydrostratigraphic edges (lenient)"]]
N["oat_hs_text"] = "changed one well" if max(_hs) == 1 else f"changed up to {_w.get(max(_hs), max(_hs))} wells"
N["oat_hs_strict"] = int(O.loc["Hydrostratigraphic edges (strict)", "n_screened"]); N["oat_hs_len"] = int(O.loc["Hydrostratigraphic edges (lenient)", "n_screened"])
_ref_c = set(str(O.loc["Reference", "confirmed"]).split(";")) - {"nan", ""}
_cset = lambda v: set(str(O.loc[v, "confirmed"]).split(";")) - {"nan", ""}
_sl = lambda L: ("SID" + ("s" if len(L) > 1 else "") + " " + (" and ".join([", ".join(L[:-1]), L[-1]]) if len(L) > 1 else "".join(L)))
_ww = lambda L: "were" if len(L) > 1 else "was"
def _cdesc(v):
    c = _cset(v); add, rem = sorted(c - _ref_c), sorted(_ref_c - c)
    if not add and not rem:
        return "the same wells were confirmed"
    if not add:
        return f"only {_sl(sorted(c))} {_ww(sorted(c))} confirmed" if c else "no well was confirmed"
    if not rem:
        return f"{_sl(add)} {_ww(add)} also confirmed"
    return f"{_sl(add)} {_ww(add)} confirmed instead of {_sl(rem)}"
_same = lambda v: sum(_ch(v)) == 0 and _cset(v) == _ref_c
_GR = [("the Monte Carlo seed or *N*", ["Seed 1", "Seed 2", "Seed 3", "Seed 4", "N_MC 1000", "N_MC 10000"]),
       ("the chloride transition width", ["Chloride scale 300 mg/L", "Chloride scale 500 mg/L"]),
       ("the uncorrected MST", ["Original MST (no co-location fix)"])]
assert all(_same(v) for _, vs in _GR for v in vs), "Sect. 3.7: these variants are described as unchanged"
N["oat_same_text"] = ", ".join(g for g, _ in _GR[:-1]) + " or " + _GR[-1][0]
_LB = [("Chloride midpoint 1,500 mg/L", "with the chloride midpoint at 1,500 mg/L,"), ("Chloride midpoint 2,500 mg/L", "at 2,500 mg/L,"),
       ("Safeguard Q75/0.75/0.80", "with the stricter safeguard thresholds (Q75, 0.75, 0.80),"),
       ("Safeguard Q95/0.90/0.95", "with the looser thresholds (Q95, 0.90, 0.95),"),
       ("EDP 2013-2020 median chloride", "with the 2013–2020 EDP medians instead of the inventory chloride,")]
assert all(sum(_ch(v)) == 0 for v, _ in _LB), "Sect. 3.7: these variants keep the screened set"
N["oat_conf_text"] = "; ".join(f"{lab} {_cdesc(v)}" for v, lab in _LB)
N["oat_conf_text"] = N["oat_conf_text"][0].upper() + N["oat_conf_text"][1:] + "."
_ns = O.loc[[v for v in O.index if not v.startswith("Critical rule")], "n_confirmed"]
N["oat_cmin"] = int(_ns.min()); N["oat_cmax"] = int(_ns.max())
assert all(_cset(v) == _ref_c for v in ["Hydrostratigraphic edges (strict)", "Hydrostratigraphic edges (lenient)"])
_tc = _cset("Trend scores 0.80/0.65/0.25 (code)") == _ref_c
N["oat_trend_conf"] = "the same wells confirmed" if _tc else _cdesc("Trend scores 0.80/0.65/0.25 (code)")
N["oat_ell80"] = int(O.loc["ell = P80", "n_screened"]); N["oat_rev60"] = int(O.loc["Review threshold 0.60", "n_screened"])
_mst = sum(_ch("Original MST (no co-location fix)"))
N["oat_mst_text"] = "did not change the screened set" if _mst == 0 else f"changed {_w.get(_mst, _mst)} screened well" + ("s" if _mst > 1 else "")
N["oat_none_s"] = int(O.loc["Critical rule: none", "n_screened"]); N["oat_none_c"] = int(O.loc["Critical rule: none", "n_confirmed"])
N["oat_dom_s"] = int(O.loc["Critical rule: dominant record", "n_screened"]); N["oat_dom_c"] = int(O.loc["Critical rule: dominant record", "n_confirmed"])
_nsids = str(O.loc["Critical rule: none", "confirmed"]).split(";")          # wells confirmed without the designation
_dsids = str(O.loc["Critical rule: dominant record", "confirmed"]).split(";")
_com = sorted(set(_nsids) & set(_dsids))
assert set(_dsids) <= set(_nsids) and set(N["conf_sids"].replace(" and ", ", ").split(", ")) <= set(_dsids), "Sect. 3.7: including all confirmed with the dominant-record designation"
N["dom_none_common"] = f"the same {WORDS[len(_com)]} well{'s' if len(_com) > 1 else ''} (SID{'s' if len(_com) > 1 else ''} {_sids(_com)})"
_Wc = pd.read_csv(A + "reference/Retention_probabilities_perSID_B4_9_GRAPH_AWARE_ACTIVE_SENSING.csv", low_memory=False, dtype={"SID": str})
cc = _Wc[_Wc.SID.isin(_nsids)]
N["none_cl_min"] = f(cc.CHLORIDE.min()); N["none_cl_max"] = f(cc.CHLORIDE.max())

# ---- wells above the chloride midpoint (letter, R2.2): the midpoint centres a continuous score, it is not a removal rule
_hi = _Wc[_Wc.CHLORIDE > 2000]
_hf = _hi[_hi.IsCritical == 0]
assert (_hf.FinalDecision_BGAS == "CANDIDATE_REMOVE").all(), "every non-critical well above 2,000 mg/L is screened by B-GAS"
_hci = _hf[(_hf.FinalDecision == "REVIEW") & _hf.Safeguard_trig_LOO.astype(bool)]
_hrel = _hf[_hf.FinalDecision == "CANDIDATE_REMOVE"]
assert len(_hci) + len(_hrel) == len(_hf), "non-critical wells above 2,000 mg/L: kept by criterion (i) or released"
N["hi_n"] = len(_hi); N["hi_crit"] = int((_hi.IsCritical == 1).sum()); N["hi_free"] = WORDS[len(_hf)]; N["hi_ci"] = WORDS[len(_hci)]
N["hi_rel"] = "; ".join(f"SID {r.SID} ({f(r.CHLORIDE)} mg/L)" for r in _hrel.itertuples())
_m15, _m25 = O.loc["Chloride midpoint 1,500 mg/L"], O.loc["Chloride midpoint 2,500 mg/L"]
_cref = set(N["conf_sids"].replace(" and ", ", ").split(", "))
_dc = [len(set(str(m.confirmed).split(";")) ^ _cref) for m in (_m15, _m25)]
assert _m15.jaccard_screened_vs_ref == 1 and _m25.jaccard_screened_vs_ref == 1 and _dc == [1, 1], "midpoint 1,500/2,500: same screened set, confirmed set +/- one well"
N["mid_oat_text"] = "changes the confirmed set by one well and leaves the screened set unchanged"

# ---- joint (LHS) perturbation
if os.path.exists(A + "lhs_summary.json"):
    LS = json.load(open(A + "lhs_summary.json"))
    N["lhs_n"] = LS["n"]; N["lhs_k"] = 31
    zero = 100 * LS["frac_runs_confirmed_zero"]
    top = LS.get("top_prcc_n_screened", []); topc = LS.get("top_prcc_n_confirmed", [])
    N["lhs_top"] = "; ".join(f"{p} {v:+.2f}" for p, v, _ in top[:3])
    _D = pd.read_csv(A + "lhs_runs.csv"); _F = pd.read_csv(A + "lhs_well_frequency.csv", index_col=0); _F.index = _F.index.astype(str)
    _Wr = pd.read_csv(A + "reference/Retention_probabilities_perSID_B4_9_GRAPH_AWARE_ACTIVE_SENSING.csv", low_memory=False, dtype={"SID": str}).set_index("SID")
    _cc = {int(k): v for k, v in LS["n_confirmed_counts"].items()}
    _cmin, _cmax = min(_cc), max(_cc)
    N["lhs_scr_range"] = (f"the number of screened wells ranged from {LS['n_screened_min']} to {LS['n_screened_max']} (median {LS['n_screened_median']:.0f}; "
                          f"5th–95th percentile {LS['n_screened_p05']:.0f}–{LS['n_screened_p95']:.0f})")
    N["lhs_conf_short"] = (f"{_cmin}–{_cmax} wells were confirmed (median {_D.n_confirmed.median():.0f}"
                           + (f"; none in {f(zero, 1)} % of the runs)" if zero > 0 else ")"))
    _ref = sorted(N["conf_sids"].replace(" and ", ", ").split(", "), key=lambda x: -_F.loc[x, "confirm_freq"])
    _pc = lambda x: f"{100 * _F.loc[x, 'confirm_freq']:.0f} %"
    N["lhs_conf_ref"] = (f"SID{'s' if len(_ref) > 1 else ''} {_sids(_ref)}, confirmed in the reference analysis, "
                         f"{'were' if len(_ref) > 1 else 'was'} confirmed in {_sids([_pc(x)[:-2] for x in _ref])} % of the runs")
    _oth = _F[(_F.confirm_freq > 0) & ~_F.index.isin(_ref)].sort_values("confirm_freq", ascending=False)
    _nr = lambda x: int(round(_F.loc[x, "confirm_freq"] * LS["n"]))
    _fq = lambda x: (f"{WORDS[_nr(x)]} run{'s' if _nr(x) > 1 else ''}" if _nr(x) <= 4 else _pc(x))
    _fresh = [x for x in _oth.index if _Wr.loc[x, "CHLORIDE"] < 250]
    _sal = [x for x in _oth.index if _Wr.loc[x, "CHLORIDE"] >= 5000]
    _mid = [x for x in _oth.index if x not in _fresh and x not in _sal]
    _pcs = lambda L: _sids([_pc(x)[:-2] for x in L]) + " %" if all(_nr(x) > 4 for x in L) else _sids([_fq(x) for x in L])
    _parts = []
    if _sal:
        _parts.append(f"the saline SID{'s' if len(_sal) > 1 else ''} {_sids(_sal)} ({_pcs(_sal)}{' of the runs' if not _parts else ''})")
    _parts += [f"SID {x} ({f(_Wr.loc[x, 'CHLORIDE'])} mg/L; {_fq(x)})" for x in _mid]
    oth_txt = ""
    if _fresh:
        _r = _D[_D.confirmed.fillna("").apply(lambda c: any(x in c.split(";") for x in _fresh))]
        _parts.append(f"the fresh SID{'s' if len(_fresh) > 1 else ''} {_sids(_fresh)} ({_pcs(_fresh)}), for which a chloride midpoint near "
                      f"{f(round(_r.CHL_THRESHOLD.mean(), -1))} mg/L, a transition width near {f(round(_r.CHL_SIGMOID_SCALE.mean(), -1))} mg/L and a "
                      f"criterion-(iii) threshold of {_r.SG_PCHL.min():.2f}" + (f"–{_r.SG_PCHL.max():.2f}" if len(_r) > 1 and f"{_r.SG_PCHL.min():.2f}" != f"{_r.SG_PCHL.max():.2f}" else "")
                      + " removed the protection of criterion (iii)")
    if _parts:
        oth_txt = " The other wells ever confirmed were " + _sids(_parts) + "."
    _PL = {"ELL_FROM_NN_PCTL": "the percentile that defines ℓ~a~", "REVIEW_THRESHOLD": "the cluster review threshold",
           "NETWORK_FAMILY_MAX_WEIGHT": "the network-family cap", "SECOND_KEEP_MIN_UTILITY": "the second-anchor threshold",
           "MAD_MULT": "the MAD multiplier of the edge cut", "CHL_THRESHOLD": "the chloride midpoint", "SG_LOO_Q": "the criterion-(i) quantile",
           "SG_PCHL": "the criterion-(iii) threshold", "SG_SGI": "the criterion-(ii) threshold", "CHL_SIGMOID_SCALE": "the chloride transition width"}
    _p = top[:3]; _q = topc[:3]
    _sg = lambda v: f"{v:+.2f}".replace("-", "\u2212")
    _nev = int((_F.screen_freq > 0).sum())
    assert LS["critical_ever_screened"] == 0, "text: no well ever screened has a critical designation"
    N["lhs_interp"] = (f"{WORDS[int((_F.screen_freq == 1).sum())].capitalize()} wells were screened in every run, and none of the {_nev} wells ever "
                       f"screened has a critical designation. {N['lhs_conf_ref']}.{oth_txt} "
                       f"{_PL[_q[0][0]].capitalize()}, {_PL[_q[1][0]]} and {_PL[_q[2][0]]} had the largest effects on the number confirmed "
                       f"(PRCC {_sg(_q[0][1])}, {_sg(_q[1][1])} and {_sg(_q[2][1])}), and {_PL[_p[0][0]]}, {_PL[_p[1][0]]} and {_PL[_p[2][0]]} "
                       f"on the number screened ({_sg(_p[0][1])}, {_sg(_p[1][1])} and {_sg(_p[2][1])}; ESM Table S11). "
                       f"An additive rank model explained {100 * LS['r2_rank_additive_n_screened']:.0f} % of the variance of the number screened "
                       f"and {100 * LS['r2_rank_additive_jaccard_vs_ref']:.0f} % of that of the overlap with the reference set; the remainder reflects "
                       f"interactions among the sequential thresholds.")
    N["lhs_text"] = (f"{N['lhs_scr_range']}, the median Jaccard overlap with the reference screened set was {LS['jaccard_median']:.2f}, and "
                     f"{N['lhs_conf_short']}. {N['lhs_interp']}")
    N["lhs_r2n"] = f"{100 * LS['r2_rank_additive_n_screened']:.0f}"; N["lhs_r2j"] = f"{100 * LS['r2_rank_additive_jaccard_vs_ref']:.0f}"
    N["lhs_conf_pct"] = f(zero, 1)
    N["lhs_any_conf_n"] = int((_D.n_confirmed > 0).sum()); N["lhs_every_n"] = WORDS[int((_F.screen_freq == 1).sum())]
    N["lhs_jacc"] = f"{LS['jaccard_median']:.2f}"; N["lhs_r2c"] = f"{100 * LS['r2_rank_additive_n_confirmed']:.0f}"
    N["lhs_pc"] = {k: _pc(k) for k in _ref}
else:
    N["lhs_n"] = "–"; N["lhs_k"] = 31; N["lhs_text"] = "(pending)"

# second-pass placeholders (interpretation sentences written after inspection) are kept in numbers_text.json
if os.path.exists(A + "numbers_text.json"):
    extra = json.load(open(A + "numbers_text.json"))
    for k, v in list(N.items()):
        if isinstance(v, str):
            for kk, vv in extra.items():
                v = v.replace(f"[[{kk}]]", vv)
            N[k] = v
    N.update({k: v for k, v in extra.items() if k not in N})
for k, v in list(N.items()):                           # numbers inside the interpretation sentences
    if isinstance(v, str):
        N[k] = re.sub(r"\[\[([A-Za-z0-9_]+)\]\]", lambda m: str(N.get(m.group(1), m.group(0))), v)
json.dump({k: (v.item() if hasattr(v, "item") else v) for k, v in N.items()}, open(A + "numbers.json", "w"), indent=1, ensure_ascii=False)
print(len(N), "numbers written")
