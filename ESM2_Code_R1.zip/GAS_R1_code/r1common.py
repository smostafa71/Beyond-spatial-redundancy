"""Shared helpers for the R1 analyses (no decision logic here: all decisions come from gas_engine.py)."""
import numpy as np
import pandas as pd
from scipy.spatial import cKDTree
from scipy.optimize import least_squares

INPUT = "inputs/GW_input_attr.gpkg"     # District inventory: chloride concentration and trend class as in the original analysis
EDP_STATIONS = "analysis_r1/edp_station_chloride.csv"
AQ_ORDER = ["upper floridan", "hawthorn", "surficial"]
AQ_LABEL = {"upper floridan": "Upper Floridan aquifer", "hawthorn": "Hawthorn aquifer system", "surficial": "Surficial aquifer"}


def load_edp():
    S = pd.read_csv(EDP_STATIONS, dtype={"SID": str})
    return S.set_index("SID")


def idw(xy_train, z_train, xy_pred, power=2.0, eps=1e-6):
    """Inverse-distance weighting (the original LOO protocol: power 2)."""
    d = np.sqrt(((xy_pred[:, None, :] - xy_train[None, :, :]) ** 2).sum(-1))
    w = 1.0 / np.maximum(d, eps) ** power
    return (w * z_train[None, :]).sum(1) / w.sum(1)


def loo_single(w, value_col="CHLORIDE", log=False):
    """Original protocol: each well predicted from all other wells of its aquifer (IDW, power 2)."""
    out = pd.Series(np.nan, index=w.index)
    for aq, g in w.groupby("Aquifer_group"):
        g = g[np.isfinite(g[value_col])]
        if len(g) < 4:
            continue
        xy = g[["X_m", "Y_m"]].to_numpy(float)
        z = g[value_col].to_numpy(float)
        z = np.log10(z) if log else z
        for k, idx in enumerate(g.index):
            m = np.ones(len(g), bool); m[k] = False
            p = idw(xy[m], z[m], xy[k:k + 1])[0]
            out[idx] = abs(p - z[k])
    return out


def joint_reconstruction(w, removed, value_col, log=True):
    """Predict every removed well from the RETAINED wells of its aquifer (simultaneous removal)."""
    rem = w.index[w.SID.isin(removed)]
    err = pd.Series(np.nan, index=rem)
    for aq, g in w.groupby("Aquifer_group"):
        g = g[np.isfinite(g[value_col])]
        keep = g[~g.SID.isin(removed)]
        tgt = g[g.SID.isin(removed)]
        if len(tgt) == 0 or len(keep) < 3:
            continue
        zk = keep[value_col].to_numpy(float); zt = tgt[value_col].to_numpy(float)
        if log:
            zk, zt = np.log10(zk), np.log10(zt)
        p = idw(keep[["X_m", "Y_m"]].to_numpy(float), zk, tgt[["X_m", "Y_m"]].to_numpy(float))
        err[tgt.index] = np.abs(p - zt)
    return err


def mean_nn(xy):
    if len(xy) < 2:
        return np.nan
    d, _ = cKDTree(xy).query(xy, k=2)
    return float(d[:, 1].mean())


def delta_nn(w, removed, retained_mask=None):
    """Aquifer-weighted change in mean nearest-neighbour spacing (weights = retained well counts), original Table 1."""
    num = den = 0.0
    for aq, g in w.groupby("Aquifer_group"):
        xy_all = g[["X_m", "Y_m"]].to_numpy(float)
        keep = g[~g.SID.isin(removed)]
        n = len(keep)
        if n < 2:
            continue
        dnn = mean_nn(keep[["X_m", "Y_m"]].to_numpy(float)) - mean_nn(xy_all)
        num += n * dnn; den += n
    return num / den if den else np.nan


def jaccard(a, b):
    a, b = set(a), set(b)
    return len(a & b) / len(a | b) if (a | b) else np.nan


# ---------------- ordinary-kriging variance (geostatistical baseline) ----------------
def fit_exponential_variogram(xy, z, maxlag, nbins=12):
    from scipy.spatial.distance import pdist
    d = pdist(xy); g = 0.5 * pdist(z[:, None]) ** 2
    m = (d > 0) & (d <= maxlag)
    d, g = d[m], g[m]
    edges = np.linspace(0, maxlag, nbins + 1)
    lag, gam, cnt = [], [], []
    for a, b in zip(edges[:-1], edges[1:]):
        s = (d > a) & (d <= b)
        if s.sum() >= 5:
            lag.append(d[s].mean()); gam.append(g[s].mean()); cnt.append(s.sum())
    lag, gam, cnt = map(np.asarray, (lag, gam, cnt))
    var = float(np.var(z))
    if len(lag) < 3:
        return dict(nugget=0.0, sill=max(var, 1e-6), range=maxlag / 3)

    def model(p, h):
        return p[0] + p[1] * (1 - np.exp(-h / p[2]))

    def res(p):
        return np.sqrt(cnt) * (model(p, lag) - gam)
    p0 = [0.1 * var, var, maxlag / 3]
    r = least_squares(res, p0, bounds=([0, 1e-9, maxlag / 50], [2 * var + 1e-9, 4 * var + 1e-9, 3 * maxlag]))
    return dict(nugget=float(r.x[0]), sill=float(r.x[1]), range=float(r.x[2]))


def gamma_exp(h, vg):
    return np.where(h > 0, vg["nugget"] + vg["sill"] * (1 - np.exp(-h / vg["range"])), 0.0)


def ok_variance(xy, grid, vg):
    n = len(xy)
    D = np.sqrt(((xy[:, None, :] - xy[None, :, :]) ** 2).sum(-1))
    A = np.ones((n + 1, n + 1)); A[:n, :n] = gamma_exp(D, vg); A[n, n] = 0.0
    G0 = np.sqrt(((xy[:, None, :] - grid[None, :, :]) ** 2).sum(-1))
    B = np.ones((n + 1, len(grid))); B[:n] = gamma_exp(G0, vg)
    sol = np.linalg.solve(A, B)
    return (sol * B).sum(0)        # lambda'gamma0 + mu


def domain_grid(xy, ell, spacing):
    from shapely.geometry import Point
    from shapely.ops import unary_union
    dom = unary_union([Point(p).buffer(ell) for p in xy])
    minx, miny, maxx, maxy = dom.bounds
    gx, gy = np.meshgrid(np.arange(minx, maxx, spacing), np.arange(miny, maxy, spacing))
    pts = np.column_stack([gx.ravel(), gy.ravel()])
    from shapely import contains_xy
    return pts[contains_xy(dom, pts[:, 0], pts[:, 1])]
