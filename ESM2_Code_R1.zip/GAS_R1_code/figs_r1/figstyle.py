import matplotlib as mpl
import matplotlib.pyplot as plt
import numpy as np, os

FIGDIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "figures_r1")
os.makedirs(FIGDIR, exist_ok=True)
BASE = os.environ.get("GAS_BASEMAP", os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "basemap"))

MM = 1 / 25.4
DOUBLE = 174 * MM      # Springer double-column width
SINGLE = 84 * MM

# categorical slots (validated all-pairs for three series)
C_UFA = "#2a78d6"
C_HAW = "#eb6834"
C_SUR = "#1baf7a"
AQ_COL = {"upper floridan": C_UFA, "hawthorn": C_HAW, "surficial": C_SUR}
AQ_LAB = {"upper floridan": "Upper Floridan aquifer", "hawthorn": "Hawthorn aquifer system", "surficial": "Surficial aquifer"}
INK = "#1a1a1a"; INK2 = "#52514e"; MUTED = "#8a8985"; GRID = "#e4e3df"
LAND = "#f4f3ef"; WATER = "#dfeaf4"; COUNTY = "#b9b7b0"; STATE = "#7d7b75"
C_REVIEW = "#d03b3b"; C_CAND = "#1c5cab"; C_KEEP = "#c9c7c0"


def setup():
    mpl.rcParams.update({
        "font.family": "Liberation Sans", "font.size": 8, "axes.titlesize": 8.5, "axes.labelsize": 8,
        "xtick.labelsize": 7, "ytick.labelsize": 7, "legend.fontsize": 7, "axes.linewidth": 0.6,
        "xtick.major.width": 0.6, "ytick.major.width": 0.6, "xtick.major.size": 2.5, "ytick.major.size": 2.5,
        "axes.edgecolor": INK2, "axes.labelcolor": INK, "xtick.color": INK2, "ytick.color": INK2,
        "text.color": INK, "legend.frameon": False, "pdf.fonttype": 42, "ps.fonttype": 42,
        "savefig.dpi": 600, "figure.dpi": 150, "axes.spines.top": False, "axes.spines.right": False,
    })


def panel(ax, letter, x=-0.02, y=1.02):
    ax.text(x, y, f"({letter})", transform=ax.transAxes, fontsize=9, fontweight="bold", va="bottom", ha="right")


def save(fig, name):
    for ext in ["pdf", "png"]:
        fig.savefig(os.path.join(FIGDIR, f"{name}.{ext}"), bbox_inches="tight", pad_inches=0.03, dpi=600)
    tif = os.path.join(FIGDIR, f"{name}.tif")
    fig.savefig(tif, bbox_inches="tight", pad_inches=0.03, dpi=600, pil_kwargs={"compression": "tiff_lzw"})
    from PIL import Image  # RGB without alpha channel, as preferred by the journal's figure checks
    im = Image.open(tif); im.load()
    im.convert("RGB").save(tif, compression="tiff_lzw", dpi=(600, 600))
    plt.close(fig)


def geo_aspect(ax, lat0):
    ax.set_aspect(1 / np.cos(np.radians(lat0)))


def lonlat_ticks(ax, xt, yt):
    ax.set_xticks(xt); ax.set_yticks(yt)
    ax.set_xticklabels([f"{abs(v):.1f}°W" if v % 1 else f"{abs(int(v))}°W" for v in xt])
    ax.set_yticklabels([f"{v:.1f}°N" if v % 1 else f"{int(v)}°N" for v in yt])


def scalebar(ax, lon0, lat0, km, lat_ref, label=None, h=0.012):
    dlon = km / (111.32 * np.cos(np.radians(lat_ref)))
    for i in range(2):
        ax.add_patch(mpl.patches.Rectangle((lon0 + i * dlon / 2, lat0), dlon / 2, h * 2, facecolor=INK if i == 0 else "white",
                                           edgecolor=INK, lw=0.5, zorder=20))
    ax.text(lon0, lat0 + h * 3.2, "0", ha="center", va="bottom", fontsize=6.5, zorder=20)
    ax.text(lon0 + dlon, lat0 + h * 3.2, label or f"{km} km", ha="center", va="bottom", fontsize=6.5, zorder=20)


def north_arrow(ax, x, y, size=0.06):
    ax.annotate("N", xy=(x, y), xytext=(x, y - size), xycoords="axes fraction", textcoords="axes fraction",
                ha="center", va="center", fontsize=8, fontweight="bold",
                arrowprops=dict(arrowstyle="-|>", lw=0.8, color=INK, shrinkA=6, shrinkB=0), zorder=30)

# equation numbers used in the revised manuscript (single source for figure labels)
EQ = dict(problem=1, constraints=2, cut=3, ell=4, w=5, chl=6, trend=7, joint=8, prox=9, dist=10, info=11, dep=12, graph=13,
          sgi=14, reliab=15, entropy=16, utility=17, beta=18, cluster=19, resolve=20, isi=21, safeguard=22, grid=23, AS=24,
          adapt=25, greedyB=26, fusion=27, limg=28, valgain=29, greedyE=30, dnn=31, idw=32)
