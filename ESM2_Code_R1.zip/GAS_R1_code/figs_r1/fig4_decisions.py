"""Fig. 4 Detection and confirmation: (a) Monte Carlo removal probability vs mean utility; (b) structural evidence of
screened vs retained non-isolated wells; (c) removal-risk safeguard space of the screened wells; (d) entropy weights."""
import json, numpy as np, pandas as pd, matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from figstyle import *

setup()
R = "analysis_r1/reference/"
W = pd.read_csv(R + "Retention_probabilities_perSID_B4_9_GRAPH_AWARE_ACTIVE_SENSING.csv", dtype={"SID": str})
wt = json.load(open(R + "entropy_weights.json"))
W = W.copy()
W["crit"] = W.IsCritical.astype(int).astype(bool); W["iso"] = W.Isolated_within_Ell.astype(bool)
scr = W.FinalDecision_BGAS.eq("CANDIDATE_REMOVE")

fig, axs = plt.subplots(2, 2, figsize=(DOUBLE, 6.0), gridspec_kw=dict(hspace=0.45, wspace=0.95, width_ratios=[1, 0.9]))
ax = axs[0, 0]
grp = [("KEEP, isolated", W.iso & ~scr, dict(marker="s", s=12, facecolor="white", edgecolor=MUTED, lw=0.6)),
       ("KEEP, critical designation", ~W.iso & W.crit & ~scr, dict(marker="o", s=10, color=C_KEEP, edgecolor="none")),
       ("KEEP, not critical", ~W.iso & ~W.crit & ~scr, dict(marker="o", s=16, facecolor="white", edgecolor=INK, lw=0.7)),
       ("screened, returned to REVIEW", scr & W.FinalDecision.eq("REVIEW"), dict(marker="D", s=20, color=C_REVIEW, edgecolor="white", lw=0.4)),
       ("screened, confirmed by E-GAS", scr & W.FinalDecision.eq("CANDIDATE_REMOVE"), dict(marker="D", s=28, color=INK, edgecolor="white", lw=0.4))]
for lab, m, kw in grp:
    ax.scatter(W.UtilityScore_mean[m], W.Prob_CANDIDATE_REMOVE[m] + np.random.default_rng(3).uniform(-0.012, 0.012, m.sum()),
               label=lab, zorder=4 if "screened" in lab else 3, **kw)
ax.set_xlabel(f"Mean Monte Carlo utility, Eq. {EQ['utility']}")
ax.set_ylabel("P(CANDIDATE_REMOVE)")
ax.set_ylim(-0.05, 1.05); ax.grid(color=GRID, lw=0.5); ax.set_axisbelow(True)
ax.legend(loc="lower right", bbox_to_anchor=(1.0, 0.17), fontsize=6.0, frameon=True, framealpha=0.9, edgecolor="none", handletextpad=0.2, borderpad=0.3)
panel(ax, "a")

# (b) structural contrasts
ax = axs[0, 1]
cols = [("P_keep_distance_base", f"Distance keep score, Eq. {EQ['dist']}"), ("P_keep_information_base", f"Information uniqueness, Eq. {EQ['info']}"),
        ("P_keep_dependency_base", f"Dependency uniqueness, Eq. {EQ['dep']}"), ("P_keep_graph_role_base", f"Graph-role keep score, Eq. {EQ['graph']}"),
        ("GraphInfluence_score", f"Graph influence $S_{{GI}}$, Eq. {EQ['sgi']}"), ("GraphRole_bridge_proxy", f"Bridge proxy, Eq. {EQ['graph']}")]
ret = ~scr & ~W.iso
rng = np.random.default_rng(7)
for i, (c, lab) in enumerate(cols):
    y = len(cols) - 1 - i
    for m, col, off, mk in [(ret, C_KEEP, 0.14, "o"), (scr, C_REVIEW, -0.14, "D")]:
        v = W.loc[m, c].astype(float).to_numpy()
        bs = [rng.choice(v, len(v)).mean() for _ in range(2000)]
        lo, hi = np.percentile(bs, [2.5, 97.5])
        ax.plot([lo, hi], [y + off] * 2, color=INK2 if col == C_KEEP else C_REVIEW, lw=1.0)
        ax.scatter([v.mean()], [y + off], marker=mk, s=22, color=col, edgecolor=INK2 if col == C_KEEP else "white", lw=0.5, zorder=4)
ax.set_yticks(range(len(cols))); ax.set_yticklabels([l for _, l in cols][::-1], fontsize=6.6)
ax.set_xlim(0, 1); ax.set_ylim(-1.5, len(cols) - 0.5); ax.set_xlabel("Mean score (95 % bootstrap interval)")
ax.grid(axis="x", color=GRID, lw=0.5); ax.set_axisbelow(True)
ax.legend(handles=[Line2D([], [], marker="o", ls="", mfc=C_KEEP, mec=INK2, label=f"retained, non-isolated (n = {int(ret.sum())})"),
                   Line2D([], [], marker="D", ls="", mfc=C_REVIEW, mec="white", label=f"screened (n = {int(scr.sum())})")],
          loc="lower right", fontsize=6.0, frameon=True, framealpha=0.9, edgecolor="none")
panel(ax, "b")

# (c) safeguard space
ax = axs[1, 0]
s = W[scr]
q85 = float(W.Safeguard_LOO_threshold.iloc[0])
ax.axvspan(q85, 1e5, color="#f6e3e3", lw=0, zorder=0)
ax.axhspan(0.85, 1.05, color="#e8eef7", lw=0, zorder=0)
ax.axvline(q85, color=C_REVIEW, lw=0.8, ls=(0, (3, 2)))
ax.axhline(0.85, color=C_UFA, lw=0.8, ls=(0, (3, 2)))
_c = s.FinalDecision.eq("CANDIDATE_REMOVE")
ax.scatter(s.AbsError_without_well[~_c], s.P_keep_chloride_adj[~_c], s=26, marker="D", color=C_REVIEW, edgecolor="white", lw=0.5, zorder=4)
ax.scatter(s.AbsError_without_well[_c], s.P_keep_chloride_adj[_c], s=34, marker="D", color=INK, edgecolor="white", lw=0.5, zorder=5)
for _, r in s[_c].iterrows():
    ax.annotate(r.SID, (r.AbsError_without_well, r.P_keep_chloride_adj), xytext=(-2, -12), textcoords="offset points", fontsize=5.6, color=INK)
_n = 0
for _, r in s.sort_values("AbsError_without_well").iterrows():          # staggered labels for wells close together
    if r.Aquifer_group == "hawthorn" or bool(r.Safeguard_trig_LOO):
        if not bool(r.Safeguard_trig_LOO):
            dx, dy = (-9, -11)
        elif r.P_keep_chloride_adj >= 0.5:
            dx, dy = (-30, -11)
        else:                                                           # saline wells at the bottom: labels above
            dx, dy = [(-4, 10), (-2, 21), (-4, 32)][_n % 3]; _n += 1
        ax.annotate(r.SID, (r.AbsError_without_well, r.P_keep_chloride_adj), xytext=(dx, dy), textcoords="offset points", fontsize=5.6, color=INK2,
                    arrowprops=dict(arrowstyle="-", color=MUTED, lw=0.4, shrinkA=0, shrinkB=2) if bool(r.Safeguard_trig_LOO) else None)
ax.set_xscale("log"); ax.set_xlim(20, 20000); ax.set_ylim(-0.03, 1.05)
ax.set_xlabel("LOO absolute chloride error (mg/L, log scale)")
ax.set_ylabel(f"Chloride keep score $P_{{chl,adj}}$ (Eqs. {EQ['chl']}, {EQ['joint']})")
ax.text(q85 * 1.12, 0.80, f"criterion (i):\nLOO ≥ Q85 of\nscreened set\n= {q85:,.0f} mg/L", fontsize=5.8, color=C_REVIEW, va="top", ha="left")
ax.text(22, 0.80, "criterion (iii): $P_{chl,adj}$ ≥ 0.85", fontsize=5.8, color=C_UFA, va="top")
ax.text(22, 0.20, "confirmation possible only in the\nwhite area (and $S_{GI}$ < 0.80)", fontsize=5.8, color=INK2, va="center")
panel(ax, "c")

# (d) entropy weights
ax = axs[1, 1]
names = {"distance": "Distance redundancy", "information": "Information uniqueness", "dependency": "Dependency uniqueness",
         "graph_role": "Graph role", "joint_quality": "Joint quality", "trend": "Chloride trend", "chloride": "Chloride concentration",
         "depth": "Depth representativeness", "status": "Operational status"}
order = sorted(wt, key=lambda k: wt[k])
fam = {"information", "dependency", "graph_role"}
ax.barh(range(len(order)), [wt[k] for k in order], color=[C_UFA if k in fam else "#a9a7a0" for k in order], height=0.62, edgecolor="none")
for i, k in enumerate(order):
    ax.text(wt[k] + 0.004, i, f"{wt[k]:.3f}", va="center", fontsize=6.2, color=INK2)
ax.set_yticks(range(len(order))); ax.set_yticklabels([names[k] for k in order], fontsize=6.6)
ax.set_xlim(0, 0.24); ax.set_xlabel(f"Entropy-derived weight, Eq. {EQ['entropy']}")
fs = sum(wt[k] for k in fam)
ax.text(0.235, 0.3, f"network family\n(blue) = {fs:.3f} ≤ 0.36", fontsize=6.2, color=C_UFA, ha="right", va="bottom")
ax.grid(axis="x", color=GRID, lw=0.5); ax.set_axisbelow(True)
panel(ax, "d")
save(fig, "Fig4_detection_confirmation")
print("ok")
