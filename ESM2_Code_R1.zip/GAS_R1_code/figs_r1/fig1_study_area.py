"""Fig. 1 Study area: (a) location, (b) monitoring stations by aquifer group, (c) schematic hydrostratigraphic section."""
import numpy as np, pandas as pd, geopandas as gpd, matplotlib.pyplot as plt
from matplotlib.patches import Rectangle
from figstyle import *

setup()
R = "analysis_r1/reference/"
W = pd.read_csv(R + "Retention_probabilities_perSID_B4_9_GRAPH_AWARE_ACTIVE_SENSING.csv")
X = pd.read_csv(R + "Excluded_Confinement_FULLINFO_withCoords.csv")
cty = gpd.read_file(f"{BASE}/cb_2023_us_county_500k/cb_2023_us_county_500k.shp").to_crs(4326)
st = gpd.read_file(f"{BASE}/cb_2023_us_state_500k/cb_2023_us_state_500k.shp").to_crs(4326)
cn = gpd.read_file(f"{BASE}/ne_10m_admin_0_countries/ne_10m_admin_0_countries.shp").to_crs(4326)
lakes = gpd.read_file(f"{BASE}/ne_10m_lakes/ne_10m_lakes.shp").to_crs(4326)
fl = cty[cty.STATEFP == "12"]

fig = plt.figure(figsize=(DOUBLE, 8.9))
gs = fig.add_gridspec(2, 2, width_ratios=[0.86, 1.0], height_ratios=[1.0, 0.62], wspace=0.08, hspace=0.12)
gsl = gs[0, 0].subgridspec(2, 1, height_ratios=[0.95, 1.0], hspace=0.10)
axl = fig.add_subplot(gsl[0]); axk = fig.add_subplot(gsl[1]); axk.axis("off")
axm = fig.add_subplot(gs[0, 1]); axs = fig.add_subplot(gs[1, :])

# (a) location
axl.set_facecolor(WATER)
ext = (-90.5, -78.5, 23.0, 33.2)
cn[cn.ADM0_A3.isin(["CUB", "BHS", "MEX"])].plot(ax=axl, color="#ebeae5", edgecolor=STATE, lw=0.3)
st.plot(ax=axl, color=LAND, edgecolor=STATE, lw=0.35)
fl.dissolve().plot(ax=axl, color="#ecebe6", edgecolor=STATE, lw=0.4)
lakes.plot(ax=axl, color=WATER, edgecolor="none")
bx = (-82.95, -81.45, 26.70, 29.20)
axl.add_patch(Rectangle((bx[0], bx[2]), bx[1] - bx[0], bx[3] - bx[2], fill=False, ec="#b03030", lw=1.1, zorder=10))
for name, x, y in [("Florida", -81.3, 28.4), ("Georgia", -83.5, 32.3), ("Alabama", -86.7, 32.3)]:
    axl.text(x, y, name, fontsize=6.5, color=INK2, ha="center", va="center")
axl.text(-86.7, 26.0, "Gulf of\nMexico", fontsize=7, style="italic", color="#3d6a8f", ha="center")
axl.text(-79.6, 30.4, "Atlantic\nOcean", fontsize=7, style="italic", color="#3d6a8f", ha="center")
axl.set_xlim(ext[0], ext[1]); axl.set_ylim(ext[2], ext[3]); geo_aspect(axl, 28)
lonlat_ticks(axl, [-88, -84, -80], [24, 28, 32])
for s_ in ["top", "right"]:
    axl.spines[s_].set_visible(True)
panel(axl, "a")

# (b) stations
axm.set_facecolor(WATER)
st.plot(ax=axm, color=LAND, edgecolor="none")
fl.plot(ax=axm, color=LAND, edgecolor=COUNTY, lw=0.35)
lakes.plot(ax=axm, color=WATER, edgecolor="none")
labels = {"Levy": (-82.55, 29.13), "Citrus": (-82.38, 28.86), "Hernando": (-82.33, 28.56), "Pasco": (-82.30, 28.33),
          "Pinellas": (-82.73, 27.86), "Hillsborough": (-82.18, 27.92), "Manatee": (-82.18, 27.47), "Sarasota": (-82.25, 27.18),
          "DeSoto": (-81.84, 27.17), "Charlotte": (-81.98, 26.87), "Hardee": (-81.80, 27.50), "Polk": (-81.70, 28.00),
          "Sumter": (-82.06, 28.70), "Marion": (-82.0, 29.08)}
for k, (x, y) in labels.items():
    axm.text(x, y, k, fontsize=6, color=MUTED, ha="center", va="center", zorder=3)
axm.text(-82.93, 27.55, "Gulf of\nMexico", fontsize=7, style="italic", color="#3d6a8f", ha="left")
axm.text(-82.58, 27.68, "Tampa\nBay", fontsize=5.5, style="italic", color="#3d6a8f", ha="center")
for aq in ["upper floridan", "hawthorn", "surficial"]:
    d = W[W.Aquifer_group == aq]
    axm.scatter(d.Lon, d.Lat, s=10 if aq != "surficial" else 18, color=AQ_COL[aq], edgecolor="white", lw=0.35, zorder=6,
                label=f"{AQ_LAB[aq]} well (n = {len(d)})")
axm.scatter(X.Lon, X.Lat, s=16, marker="x", color=INK2, lw=0.7, zorder=7, label=f"Well open to a confining unit, excluded (n = {len(X)})")
axm.set_xlim(bx[0], bx[1]); axm.set_ylim(bx[2], bx[3]); geo_aspect(axm, 28)
lonlat_ticks(axm, [-82.8, -82.4, -82.0, -81.6], [27.0, 27.5, 28.0, 28.5, 29.0])
for s_ in ["top", "right"]:
    axm.spines[s_].set_visible(True)
scalebar(axm, -82.90, 26.76, 50, 27.0)
north_arrow(axm, 0.92, 0.96)
panel(axm, "b")
h, l = axm.get_legend_handles_labels()
axk.legend(h, l, loc="upper left", fontsize=7, handletextpad=0.4, borderaxespad=0, labelspacing=0.7,
           title="Monitoring stations in panel b", title_fontsize=7.5, alignment="left")

# (c) schematic section (north -> south along the Gulf coast), after LaRoche and Horstman (2023)
x = np.linspace(0, 10, 600)
top = 0.10 * np.sin(x / 1.9)                       # land surface (schematic relief)
pinch = 4.6          # Hawthorn aquifer system pinches out north of central Hillsborough County
polk = 5.3           # latitude of central Polk County: APPZ in the UFA to the north, in the LFA (below MCU I) to the south
s_on = 3.4
sm = lambda x0, w=0.25: 0.5 * (1 + np.tanh((x - x0) / w))          # smooth step
sur = sm(s_on, 0.2) * (0.16 + 0.06 * np.clip(x - s_on, 0, None) / (10 - s_on))
hcl = 0.08 * sm(2.6) * (1 - sm(pinch))
has = sm(pinch, 0.15) * (0.04 + 1.05 * (np.clip(x - pinch, 0, None) / (10 - pinch)) ** 0.8)
ufa_top = top - sur - hcl - has
ufa_bot = ufa_top - (1.25 - 0.30 * sm(polk, 0.35))
mcu1_bot = ufa_bot - 0.18 * sm(polk, 0.35)
appz_bot = mcu1_bot - 0.70
mcu2_bot = appz_bot - 0.32
bottom = np.full_like(x, mcu2_bot.min() - 0.40)
C = dict(sur="#f2e6b6", hcl="#cfc8b8", has="#e9c9a3", conf="#c4baa9", ufa="#bcd6ec", appz="#97bde2", mcu="#d3cec6", lfa="#dbe6f1")


def band(y1, y2, col, hatch=None):
    axs.fill_between(x, y2, y1, facecolor=col, edgecolor="#8f887d" if hatch else "none", lw=0, hatch=hatch)


band(top, top - sur, C["sur"])
band(top - sur, top - sur - hcl, C["hcl"], hatch="....")
hs = top - sur
for f0, f1, col, hh in [(0.00, 0.08, C["conf"], "---"), (0.08, 0.28, C["has"], None), (0.28, 0.36, C["conf"], "---"),
                        (0.36, 0.62, C["has"], None), (0.62, 0.70, C["conf"], "---"), (0.70, 0.93, C["has"], None), (0.93, 1.0, C["conf"], "---")]:
    band(hs - f0 * has, hs - f1 * has, col, hh)
band(ufa_top, ufa_bot, C["ufa"])
band(ufa_bot, mcu1_bot, C["mcu"], "////")
band(mcu1_bot, appz_bot, C["appz"])
band(appz_bot, mcu2_bot, C["mcu"], "xxx")
band(mcu2_bot, bottom, C["lfa"])
for y in [top - sur, ufa_top, ufa_bot, mcu1_bot, appz_bot, mcu2_bot]:
    axs.plot(x, y, color=INK2, lw=0.45)
axs.plot(x, top, color=INK, lw=0.9)
ymax = top.max() + 1.00
axs.plot([pinch, pinch], [np.interp(pinch, x, ufa_top) - 0.05, top.max() + 0.55], color=INK2, lw=0.6, ls=(0, (3, 2)))
axs.plot([polk, polk], [bottom.min(), np.interp(polk, x, ufa_bot) + 0.10], color="#3d6a8f", lw=0.6, ls=(0, (1, 1.5)))


def lab(xx, yy, t, **kw):
    kw.setdefault("fontsize", 6.6)
    if kw.pop("box", False):
        kw["bbox"] = dict(fc="#f3f1ed", ec="none", pad=0.8, alpha=0.9)
    axs.text(xx, yy, t, ha="center", va="center", **kw)


lab(2.0, np.interp(2.0, x, ufa_top) - 0.55, "Upper Floridan aquifer\n(unconfined or thinly confined; karst)")
lab(7.6, np.interp(7.6, x, ufa_top) - 0.45, "Upper Floridan aquifer (confined)")
lab(2.0, np.interp(2.0, x, mcu1_bot) - 0.38, "Avon Park high-permeability zone\n(part of the Upper Floridan aquifer)", color=INK2, fontsize=6.3)
lab(7.6, np.interp(7.6, x, mcu1_bot) - 0.38, "Avon Park high-permeability zone\n(part of the Lower Floridan aquifer)", color=INK2, fontsize=6.3)
lab(7.6, np.interp(7.6, x, ufa_bot) - 0.09, "middle confining unit I", fontsize=6.0, box=True)
lab(2.6, np.interp(2.6, x, appz_bot) - 0.16, "middle confining unit II (evaporites)", fontsize=6.2, box=True)
lab(3.0, mcu2_bot.min() - 0.20, "Lower Floridan aquifer (brackish to saline)")
lab(8.9, np.interp(8.9, x, top) - 0.09, "Surficial aquifer", fontsize=6.2)
yh = np.interp(8.4, x, hs); th = np.interp(8.4, x, has)
for f, t in [(0.18, "Peace River aquifer"), (0.49, "upper Arcadia aquifer"), (0.815, "lower Arcadia aquifer")]:
    lab(8.4, yh - f * th, t, fontsize=6.2)
axs.text(5.3, np.interp(5.3, x, hs) - 0.05, "Hawthorn aquifer system", fontsize=6.6, ha="left", va="top", fontweight="bold", color="#7a4b1c")
axs.text(pinch, top.max() + 0.58, "Hawthorn aquifer system pinches out\nnorth of central Hillsborough County",
         fontsize=6, ha="center", va="bottom", color=INK2)
axs.text(polk + 0.08, bottom.min() + 0.05, "latitude of central Polk County", fontsize=5.8, ha="left", va="bottom", color="#3d6a8f")
axs.text(3.3, np.interp(3.3, x, top) - 0.17, "thin Hawthorn-age clays", fontsize=5.6, ha="center", va="top", color=INK2)
for nm, xx in [("Levy", 0.3), ("Citrus", 1.2), ("Hernando", 2.1), ("Pasco", 3.0), ("Hillsborough", 4.3), ("Manatee", 6.0), ("Sarasota", 7.6), ("Charlotte", 9.3)]:
    axs.text(xx, top.max() + 0.16, nm, fontsize=6, ha="center", va="bottom", color=MUTED)
axs.text(0.0, ymax, "North", fontsize=7, fontweight="bold", ha="left", va="top")
axs.text(10.0, ymax, "South", fontsize=7, fontweight="bold", ha="right", va="top")
axs.set_xlim(0, 10); axs.set_ylim(bottom.min() - 0.18, ymax + 0.02)
axs.axis("off")
axs.text(10.0, bottom.min() - 0.06, "Schematic, not to scale and not a single transect. The Floridan aquifer system is ≈550 m thick in the north and"
         " >760 m in the south; the Hawthorn aquifer system ≈15–90 m.", fontsize=5.8, color=INK2, ha="right", va="top")
panel(axs, "c", x=0.0, y=1.0)
for a_ in (axl, axm):
    a_.set_xlabel(""); a_.set_ylabel("")
save(fig, "Fig1_study_area")
print("ok")
