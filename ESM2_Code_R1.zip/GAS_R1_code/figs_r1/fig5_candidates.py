"""Fig. 5 Candidate new-well sites: (a) B-GAS (active-sensing score, Eq. 24), (b) E-GAS (fusion score, Eq. 27).
Marker size is proportional to the final post-greedy candidate score; existing wells in grey."""
import numpy as np, pandas as pd, geopandas as gpd, matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from figstyle import *

setup()
R = "analysis_r1/reference/"
W = pd.read_csv(R + "Retention_probabilities_perSID_B4_9_GRAPH_AWARE_ACTIVE_SENSING.csv")
CB = pd.read_csv(R + "Candidate_new_wells_BGAS.csv")
CE = pd.read_csv(R + "Candidate_new_wells_B4_9.csv")
cty = gpd.read_file(f"{BASE}/cb_2023_us_county_500k/cb_2023_us_county_500k.shp").to_crs(4326)
lakes = gpd.read_file(f"{BASE}/ne_10m_lakes/ne_10m_lakes.shp").to_crs(4326)
fl = cty[cty.STATEFP == "12"]
ext = (-82.95, -81.45, 26.70, 29.12)

fig, axs = plt.subplots(1, 2, figsize=(DOUBLE, 5.3), gridspec_kw=dict(wspace=0.06))
smax = max(CB.CandidateScore.max(), CE.CandidateScore.max())
for ax, C, lab, eq, letter in [(axs[0], CB, "B-GAS", EQ["AS"], "a"), (axs[1], CE, "E-GAS", EQ["fusion"], "b")]:
    ax.set_facecolor(WATER)
    fl.plot(ax=ax, color=LAND, edgecolor=COUNTY, lw=0.35)
    lakes.plot(ax=ax, color=WATER, edgecolor="none")
    ax.scatter(W.Lon, W.Lat, s=4, color="#9d9b95", edgecolor="none", zorder=4)
    for aq in ["upper floridan", "hawthorn", "surficial"]:
        d = C[C.Aquifer_group == aq]
        ax.scatter(d.Lon, d.Lat, s=12 + 110 * (d.CandidateScore / smax) ** 1.5, marker="o", facecolor=AQ_COL[aq], alpha=0.85,
                   edgecolor="white", lw=0.5, zorder=6)
        top = d.nsmallest(3, "CandidateRank_inAquifer")
        for _, r in top.iterrows():
            dx, dy = {"upper floridan": (0.025, 0.012), "hawthorn": (0.025, -0.045), "surficial": (-0.06, 0.012)}[aq]
            ax.text(r.Lon + dx, r.Lat + dy, str(int(r.CandidateRank_inAquifer)), fontsize=6, color=INK, zorder=8, fontweight="bold")
    ncomp = int(C.groupby("Aquifer_group").SourceComponentID.nunique().sum())
    n = C.Aquifer_group.value_counts()
    ax.set_title(f"({letter}) {lab}: {len(C)} sites in {ncomp} components\n{n.get('upper floridan', 0)} Upper Floridan, {n.get('hawthorn', 0)} Hawthorn, "
                 f"{n.get('surficial', 0)} surficial\nscore (Eq. {eq}) {C.CandidateScore.min():.2f}–{C.CandidateScore.max():.2f}",
                 fontsize=6.6, loc="left")
    ax.set_xlim(ext[0], ext[1]); ax.set_ylim(ext[2], ext[3]); geo_aspect(ax, 28)
    ax.set_xlabel(""); ax.set_ylabel("")
    for s_ in ["top", "right"]:
        ax.spines[s_].set_visible(True)
    lonlat_ticks(ax, [-82.8, -82.4, -82.0, -81.6], [27.0, 27.5, 28.0, 28.5, 29.0])
axs[1].set_yticklabels([])
scalebar(axs[0], -82.90, 26.76, 50, 27.0)
h = [Line2D([], [], marker="o", ls="", mfc=AQ_COL[a], mec="white", ms=6, label=f"candidate site, {AQ_LAB[a]}") for a in ["upper floridan", "hawthorn", "surficial"]]
h += [Line2D([], [], marker="o", ls="", mfc="#9d9b95", mec="none", ms=3, label="existing well")]
h += [Line2D([], [], marker="o", ls="", mfc="#c9c7c0", mec="white", ms=np.sqrt(12 + 110 * (v / smax) ** 1.5), label=f"score {v:.2f}") for v in (0.2, 0.5, 0.8) if v <= smax * 1.05]
fig.legend(handles=h, loc="lower center", ncol=4, fontsize=6.4, bbox_to_anchor=(0.5, -0.04), handletextpad=0.3, columnspacing=1.0)
fig.text(0.5, -0.075, "Numbers: rank of the three highest-scoring sites in each aquifer group after sequential greedy selection.", ha="center", fontsize=6.4, color=INK2)
save(fig, "Fig5_candidates")
print("ok")
