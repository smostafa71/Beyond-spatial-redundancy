"""ESM Fig. S3 Sensitivity: (a) one-at-a-time and structural variants; (b) joint LHS perturbation; (c) per-well screening
and confirmation frequency."""
import json, numpy as np, pandas as pd, matplotlib.pyplot as plt
from figstyle import *

setup()
A = "analysis_r1/"
O = pd.read_csv(A + "oat.csv")
D = pd.read_csv(A + "lhs_runs.csv")
F = pd.read_csv(A + "lhs_well_frequency.csv", index_col=0)
P = pd.read_csv(A + "lhs_prcc.csv")
ref = set(json.load(open(A + "summary.json"))["screened"])

fig = plt.figure(figsize=(DOUBLE, 8.2))
gs = fig.add_gridspec(2, 2, width_ratios=[1.25, 1], height_ratios=[1.35, 1], hspace=0.38, wspace=0.55)
ax = fig.add_subplot(gs[:, 0])
y = np.arange(len(O))[::-1]
ax.barh(y, O.n_screened, color=[C_UFA if v != "Reference" else INK2 for v in O.variant], height=0.62, edgecolor="none")
ax.barh(y, O.n_confirmed, color=C_REVIEW, height=0.62, edgecolor="none")
for yy, (_, r) in zip(y, O.iterrows()):
    ax.text(r.n_screened + 2, yy, f"{int(r.n_screened)} / {int(r.n_confirmed)}  (J = {r.jaccard_screened_vs_ref:.2f})", va="center", fontsize=5.8, color=INK2)
ax.set_yticks(y); ax.set_yticklabels(O.variant, fontsize=6.0)
ax.set_xscale("symlog", linthresh=20); ax.set_xlim(0, 900)
ax.set_xticks([0, 5, 10, 15, 20, 100, 200]); ax.set_xticklabels(["0", "5", "10", "15", "20", "100", "200"])
ax.set_xlabel("Wells screened (blue) / confirmed (red)")
ax.grid(axis="x", color=GRID, lw=0.5); ax.set_axisbelow(True)
panel(ax, "a")

ax = fig.add_subplot(gs[0, 1])
bins = np.arange(D.n_screened.min() - 0.5, D.n_screened.max() + 1.5)
ax.hist(D.n_screened, bins=bins, color=C_UFA, edgecolor="white", lw=0.5)
ax.axvline(len(ref), color=INK, lw=0.9, ls=(0, (3, 2)))
ax.text(len(ref) + 0.3, ax.get_ylim()[1] * 0.92, "reference", fontsize=6.2)
ax.set_xlabel("Wells screened (400 joint perturbations)"); ax.set_ylabel("Runs")
ax.set_xticks(range(int(D.n_screened.min()), int(D.n_screened.max()) + 1, 2))
ax.text(len(ref) + 0.3, ax.get_ylim()[1] * 0.72, f"confirmed per run:\n{D.n_confirmed.min()}–{D.n_confirmed.max()} wells (median {D.n_confirmed.median():.0f})\nmedian Jaccard {D.jaccard_vs_ref.median():.2f}",
        ha="left", va="top", fontsize=6.2, color=INK2)
panel(ax, "b")

ax = fig.add_subplot(gs[1, 1])
f = F[F.screen_freq > 0].sort_values("screen_freq", ascending=True)
ax.barh(range(len(f)), f.screen_freq, color=[C_REVIEW if s in ref else "#9d9b95" for s in f.index.astype(str)], height=0.65)
ax.barh(range(len(f)), f.confirm_freq, color=INK, height=0.32)
ax.set_yticks(range(len(f))); ax.set_yticklabels(f.index.astype(str), fontsize=5.8)
ax.set_xlabel("Share of runs in which the well is screened / confirmed"); ax.set_xlim(0, 1)
ax.text(0.98, 0.09, "red: reference screened set", transform=ax.transAxes, ha="right", fontsize=6.0, color=C_REVIEW)
ax.text(0.98, 0.03, "black: confirmed", transform=ax.transAxes, ha="right", fontsize=6.0, color=INK)
panel(ax, "c")
save(fig, "FigS3_sensitivity")
print("ok")
