"""Fig. 6 Independent tests with data not used by the framework: (a) persistence of the reconstruction difficulty between the
design period (inventory chloride, 2013-2020) and the 2021-2026 record; (b) 2021-2026 reconstruction error of the screened wells,
of the wells kept by safeguard criterion (i) and of the other wells; (c) spatial-gap withholding test."""
import json
import numpy as np, pandas as pd, matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from figstyle import *

setup()
A = "analysis_r1/"
D = pd.read_csv(A + "safeguard_check_wells.csv", dtype={"SID": str})
SG = json.load(open(A + "safeguard_check.json"))
W = pd.read_csv(A + "reference/Retention_probabilities_perSID_B4_9_GRAPH_AWARE_ACTIVE_SENSING.csv", dtype={"SID": str})
scr_ids = set(W.SID[W.FinalDecision_BGAS == "CANDIDATE_REMOVE"])
D["scr"] = D.SID.isin(scr_ids)

fig = plt.figure(figsize=(DOUBLE, 2.95))
gs = fig.add_gridspec(1, 3, wspace=0.48, width_ratios=[1.15, 1.0, 1.05])

# (a) persistence of the reconstruction difficulty (Eq. 32, mg/L)
ax = fig.add_subplot(gs[0, 0])
lo = 0.3
x = D.design_err.clip(lower=lo); y = D.later_err.clip(lower=lo)
oth = ~D.scr
ax.scatter(x[oth], y[oth], s=6, color=C_KEEP, edgecolor="none", zorder=2, label="other wells")
m3 = D.sg_group.eq("criterion (iii)")
ax.scatter(x[m3], y[m3], s=16, marker="D", color="white", edgecolor=C_REVIEW, lw=0.7, zorder=4, label="kept under REVIEW, criterion (iii)")
m1 = D.sg_group.eq("criterion (i)")
ax.scatter(x[m1], y[m1], s=22, marker="D", color=C_REVIEW, edgecolor="white", lw=0.4, zorder=5, label="kept under REVIEW, criterion (i)")
mc = D.sg_group.eq("confirmed")
ax.scatter(x[mc], y[mc], s=24, marker="D", color=INK, edgecolor="white", lw=0.4, zorder=5, label="confirmed by E-GAS")
ax.plot([lo, 3e4], [lo, 3e4], color=MUTED, lw=0.6, ls=(0, (3, 2)), zorder=1)
ax.axvline(SG["q85"], color=C_REVIEW, lw=0.7, ls=(0, (2, 2)))
ax.text(SG["q85"] / 1.15, 2.2e4, "criterion (i)\nthreshold", fontsize=5.6, color=C_REVIEW, va="top", ha="right")
ax.set_xscale("log"); ax.set_yscale("log"); ax.set_xlim(lo, 3e4); ax.set_ylim(lo, 3e4)
ax.set_xlabel("LOO error, design period (mg/L)"); ax.set_ylabel("LOO error, 2021–2026 (mg/L)")
ax.text(0.04, 0.80, f"Spearman ρ = {SG['spearman_err']:.2f}\nn = {SG['n']}", transform=ax.transAxes, fontsize=6.2, va="top", color=INK2)
ax.legend(loc="lower right", fontsize=5.4, frameon=True, framealpha=0.95, edgecolor="none",
          handletextpad=0.2, borderpad=0.3, markerscale=0.9)
ax.grid(color=GRID, lw=0.4); ax.set_axisbelow(True)
panel(ax, "a")

# (b) 2021-2026 reconstruction error by group
ax = fig.add_subplot(gs[0, 1])
f = 10 ** D.later_log
groups = [("Other\nwells", f[D.sg_group.eq("other, with neighbours")], C_KEEP),
          ("Screened\n(B-GAS)", f[D.scr], C_REVIEW),
          ("Kept by\ncriterion (i)", f[m1], C_REVIEW)]
rng = np.random.default_rng(4)
for i, (lab, v, col) in enumerate(groups):
    v = v.to_numpy()
    ax.boxplot([v], positions=[i], widths=0.5, showfliers=False, medianprops=dict(color=INK, lw=1.2),
               boxprops=dict(color=INK2, lw=0.7), whiskerprops=dict(color=INK2, lw=0.7), capprops=dict(color=INK2, lw=0.7))
    ax.scatter(i + rng.uniform(-0.16, 0.16, len(v)), v, s=6 if len(v) > 50 else 16, color=col, alpha=0.6 if len(v) > 50 else 0.95,
               edgecolor="none" if len(v) > 50 else "white", lw=0.4, zorder=3, marker="o" if i == 0 else "D")
    ax.text(i, 700, f"n = {len(v)}\n×{10 ** np.median(np.log10(v)):.1f}", ha="center", va="top", fontsize=5.8, color=INK2)
ax.set_yscale("log"); ax.set_ylim(1, 1000)
ax.set_yticks([1, 2, 5, 10, 30, 100]); ax.set_yticklabels(["1", "2", "5", "10", "30", "100"]); ax.minorticks_off()
ax.set_xticks(range(len(groups))); ax.set_xticklabels([g[0] for g in groups], fontsize=6.0)
ax.set_ylabel("LOO error of 2021–2026 chloride\n(factor, log scale)")
ax.grid(axis="y", color=GRID, lw=0.5); ax.set_axisbelow(True)
panel(ax, "b")

# (c) spatial-gap withholding test
ax = fig.add_subplot(gs[0, 2])
PBr = pd.read_csv(A + "prospective_blocks_reps.csv")
PB = PBr.groupby("method")[["any_in_hole", "hit_all"]].mean()
meth = ["GAS-E", "GAS-B", "Random (pool)", "Space-filling"]
mlab = ["E-GAS", "B-GAS", "Random\n(pool)", "Space-\nfilling"]
mcol = [C_HAW, C_UFA, MUTED, "#4a3aa7"]
xx = np.arange(len(meth))
ax.bar(xx - 0.18, [PB.loc[m, "any_in_hole"] for m in meth], width=0.34, color=mcol, edgecolor="white", lw=0.5)
ax.bar(xx + 0.18, [PB.loc[m, "hit_all"] for m in meth], width=0.34, color="white", edgecolor=mcol, lw=1.0, hatch="....")
ax.legend(handles=[plt.Rectangle((0, 0), 1, 1, fc=INK2, ec="white"), plt.Rectangle((0, 0), 1, 1, fc="white", ec=INK2, hatch="....")],
          labels=["replicates with ≥ 1 site in the gap", "withheld wells with a site within ℓ$_a$"], fontsize=5.8, loc="upper left", frameon=False)
ax.set_ylim(0, 0.62); ax.set_yticks(np.arange(0, 0.51, 0.1))
ax.set_xticks(xx); ax.set_xticklabels(mlab, fontsize=6.4)
ax.set_ylabel("Share"); ax.grid(axis="y", color=GRID, lw=0.5); ax.set_axisbelow(True)
panel(ax, "c")
save(fig, "Fig6_validation")
print("ok")
