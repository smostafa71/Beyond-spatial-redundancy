"""ESM Fig. S1 Generation of candidate sites (Sect. 2.8, Eq. 23) for two Upper Floridan components.

Re-creates the steps of gas_engine.create_candidate_points_for_aquifer for the wells of one component of the
reference run (support domain, hexagonal grid, exclusion near wells, thinning, injected points, land mask) and
overlays the candidate pool and the B-GAS sites actually produced by the reference run."""
import math, os, sys
import numpy as np, pandas as pd, geopandas as gpd, matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import Patch
from shapely.geometry import Point
from scipy.spatial import cKDTree
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from figstyle import *                     # figs_r1/figstyle.py
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import gas_engine as G

setup()
REF = "analysis_r1/reference/"
W = pd.read_csv(REF + "Retention_probabilities_perSID_B4_9_GRAPH_AWARE_ACTIVE_SENSING.csv", low_memory=False, dtype={"SID": str})
POOL = pd.read_csv(REF + "Candidate_pool_scored.csv")
BG = pd.read_csv(REF + "Candidate_new_wells_BGAS.csv")
AQ = "upper floridan"
CRS = "EPSG:3087"
LANDP = gpd.read_file("inputs/florida_land.gpkg").to_crs(CRS)

sub = W[W.Aquifer_group.str.strip().str.lower() == AQ].copy()
sub = gpd.GeoDataFrame(sub, geometry=gpd.points_from_xy(sub.X_m, sub.Y_m), crs=CRS)
ell = float(np.nanmedian(pd.to_numeric(sub["Ell_aquifer_m"], errors="coerce")))
g = float(np.clip(G.CAND_GRID_FACTOR * ell, G.CAND_MIN_GRID_M, G.CAND_MAX_GRID_M))


def steps(comp):
    sc = sub[sub.Component_id == comp].copy()
    dom = G._build_component_support_domain(sc, ell, g)
    minx, miny, maxx, maxy = dom.bounds
    dy = g * math.sqrt(3.0) / 2.0
    grid = []
    for k, y in enumerate(np.arange(miny, maxy + dy, dy)):
        for x in np.arange(minx + (0.5 * g if k % 2 else 0.0), maxx + g, g):
            p = Point(float(x), float(y))
            if dom.covers(p):
                grid.append(p)
    grid = gpd.GeoDataFrame({"geometry": grid}, geometry="geometry", crs=CRS)
    tree = cKDTree(np.column_stack([sc.geometry.x, sc.geometry.y]))
    dmin, _ = tree.query(np.column_stack([grid.geometry.x, grid.geometry.y]), k=1)
    near = grid[dmin < max(G.CAND_MIN_DIST_EXISTING_FACTOR * ell, 0.60 * g)]
    inj = G.inject_active_sensing_candidates(sc, dom, ell, g)
    return sc, dom, grid, near, inj


fig, axes = plt.subplots(1, 2, figsize=(DOUBLE, DOUBLE * 0.52))
_nb = BG[BG.Aquifer_group == AQ].groupby("SourceComponentID").size()
_nw = sub.groupby("Component_id").size()
_cand = [c for c in _nb.sort_values(ascending=False).index if 5 <= _nw.get(c, 0) <= 40]   # readable components with selected sites
_ninj = {c: len(steps(c)[4]) for c in _nw.index if 5 <= _nw.get(c, 0) <= 40}
COMPS = [_cand[0], max((c for c in _ninj if c != _cand[0]), key=lambda c: (_ninj[c], _nb.get(c, 0)))]   # b: a component with injected points
for ax, comp, letter in zip(axes, COMPS, "ab"):
    sc, dom, grid, near, inj = steps(comp)
    pool = POOL[(POOL.Aquifer_group == AQ) & (POOL.SourceComponentID == comp)]
    sel = BG[(BG.Aquifer_group == AQ) & (BG.SourceComponentID == comp)]
    x0, y0, x1, y1 = dom.bounds
    pad = 0.12 * max(x1 - x0, y1 - y0)
    ax.set_facecolor(WATER)
    LANDP.plot(ax=ax, color=LAND, edgecolor=STATE, linewidth=0.4, zorder=0)
    gpd.GeoSeries([dom], crs=CRS).plot(ax=ax, color=C_UFA, alpha=0.13, edgecolor=C_UFA, linewidth=0.6, zorder=1)
    cxy = np.column_stack([sc.geometry.x, sc.geometry.y])
    for i, j, _ in G.mst_edges_from_points(cxy):
        ax.plot([cxy[i, 0], cxy[j, 0]], [cxy[i, 1], cxy[j, 1]], color=MUTED, lw=0.6, zorder=2)
    ax.scatter(grid.geometry.x, grid.geometry.y, s=4, color=MUTED, lw=0, zorder=3)
    ax.scatter(near.geometry.x, near.geometry.y, s=10, marker="x", color=INK2, lw=0.6, zorder=4)
    if len(inj):
        ax.scatter(inj.geometry.x, inj.geometry.y, s=12, marker="^", facecolor="none", edgecolor=C_HAW, lw=0.6, zorder=4)
    ax.scatter(pool.X_m, pool.Y_m, s=22, facecolor="none", edgecolor=C_UFA, lw=0.8, zorder=5)
    ax.scatter(sel.X_m, sel.Y_m, s=42, marker="D", color=C_CAND, edgecolor="white", lw=0.5, zorder=6)
    ax.scatter(sc.geometry.x, sc.geometry.y, s=14, color=INK, lw=0, zorder=7)
    ax.set_xlim(x0 - pad, x1 + pad); ax.set_ylim(y0 - pad, y1 + pad); ax.set_aspect("equal")
    ax.set_xticks([]); ax.set_yticks([]); ax.set_xlabel(""); ax.set_ylabel("")
    # scale bar of 5 km
    sx, sy = x0 - 0.6 * pad, y0 - 0.6 * pad
    ax.plot([sx, sx + 5000], [sy, sy], color=INK, lw=1.2); ax.text(sx + 2500, sy + 0.12 * pad, "5 km", ha="center", va="bottom", fontsize=6.5)
    ax.set_title(f"Upper Floridan component {comp}: {len(sc)} wells, {len(pool)} pool sites, {len(sel)} B-GAS site{'s' if len(sel) != 1 else ''}", fontsize=7)
    panel(ax, letter)
h = [Line2D([], [], marker="o", ls="", color=INK, ms=3.5, label="existing well"),
     Line2D([], [], color=MUTED, lw=0.8, label="MST edge"),
     Patch(facecolor=C_UFA, alpha=0.2, edgecolor=C_UFA, label="support domain"),
     Line2D([], [], marker="o", ls="", color=MUTED, ms=2, label="hexagonal grid point"),
     Line2D([], [], marker="x", ls="", color=INK2, ms=3.5, label="grid point too close to a well"),
     Line2D([], [], marker="^", ls="", mfc="none", mec=C_HAW, ms=3.5, label="injected point"),
     Line2D([], [], marker="o", ls="", mfc="none", mec=C_UFA, ms=4, label="candidate pool (after thinning and land mask)"),
     Line2D([], [], marker="D", ls="", color=C_CAND, ms=4, label="site selected by B-GAS")]
fig.legend(handles=h, loc="lower center", ncol=4, fontsize=6.3, frameon=False, bbox_to_anchor=(0.5, -0.01))
fig.subplots_adjust(left=0.02, right=0.98, top=0.93, bottom=0.17, wspace=0.06)
save(fig, "FigS1_candidate_generation")
