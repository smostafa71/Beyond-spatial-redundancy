"""Tables (markdown) and figure captions of the revised manuscript. Values come from analysis_r1/ outputs."""
import json
import sys, os
import numpy as np
import pandas as pd
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

A = "analysis_r1/"
REF = A + "reference/"

TABLE1 = """Table: **Table 1** Steps of the GAS framework: inputs, operations and outputs. Steps 1–3 and 5 (B-GAS part) are shared by both configurations; step 4 and the E-GAS part of step 5 form the enhanced configuration

| Step | Inputs | Operation (equations) | Outputs |
|:-----------|:-------------|:-------------------------|:-----------------|
| 0 Data preparation (Sect. 2.2) | District station inventory (2,069 records) | SID consolidation; exclusion of confining-unit wells; aquifer group from the hydrostratigraphic unit | [[n_wells]] wells with aquifer group, chloride (2013–2020 median), trend class, depth, status, designation |
| 1 Graph construction (Sect. 2.4) | well coordinates by aquifer group | MST, long-edge cut, neighbourhood length, distance weights (Eqs. 3–5) | components, ℓ~a~, neighbours and *w*~*ij*~, isolated wells, redundancy clusters |
| 2 Evidence (Sect. 2.5) | well attributes, neighbours | nine retention scores with uncertainties; adjacency, strength and cohesion within clusters (Eqs. 6–15) | *P*~*ij*~, *u*~*ij*~, *A*~*ij*~, Strength, Cohesion, *S*~GI~ |
| 3 Resolution (Sect. 2.6) | scores, uncertainties, clusters, designation | entropy weights, utility, Beta Monte Carlo, cluster rule, calibration and votes, stability (Eqs. 16–21) | class probabilities, ISI; KEEP or CANDIDATE_REMOVE (B-GAS screening) |
| 4 Confirmation, E-GAS (Sect. 2.7) | screened wells; LOO error, *S*~GI~, *P*~chl,adj~ | removal-risk safeguard (Eq. 22) | confirmed CANDIDATE_REMOVE or REVIEW |
| 5 Candidate sites (Sect. 2.8) | wells with uncertainty, *S*~GI~, features; LOO of screened wells of the same aquifer group | domain and grid on land (Eq. 23); active sensing (Eqs. 24–25); B-GAS greedy (Eq. 26); E-GAS fusion, Hydro-LIMG, validation gain, greedy (Eqs. 27–30) | ≤ 20 ranked plan-view sites per aquifer group |
| 6 Evaluation (Sect. 2.9) | decisions; 2021–2026 record | comparison of the configurations and equal-budget baselines (Eqs. 31–32); independent 2021–2026 test; spatial withholding test; sensitivity | Sects. 3.4–3.7; ESM S5–S7 |
"""


def table2():
    W = pd.read_csv(REF + "Retention_probabilities_perSID_B4_9_GRAPH_AWARE_ACTIVE_SENSING.csv", dtype={"SID": str})
    T = pd.read_csv(A + "structure_aquifers.csv").set_index("aquifer")
    CB = pd.read_csv(REF + "Candidate_new_wells_BGAS.csv"); CE = pd.read_csv(REF + "Candidate_new_wells_B4_9.csv")
    rows = []
    for a, lab in [("upper floridan", "Upper Floridan"), ("hawthorn", "Hawthorn"), ("surficial", "Surficial")]:
        g = W[W.Aquifer_group == a]; r = T.loc[a]
        rows.append([lab, len(g), f"{r.ell_m:,.0f}", f"{int(r.n_components)} ({int(r.dominant_size)})", int(r.n_isolated),
                     int(g.IsCritical.astype(int).sum()), int((g.FinalDecision_BGAS == "CANDIDATE_REMOVE").sum()),
                     int((g.FinalDecision == "CANDIDATE_REMOVE").sum()), int((g.FinalDecision == "REVIEW").sum()),
                     int((CB.Aquifer_group == a).sum()), int((CE.Aquifer_group == a).sum())])
    tot = ["Total", sum(r[1] for r in rows), "–", f"{sum(int(r[3].split()[0]) for r in rows)}", sum(r[4] for r in rows)] + [sum(r[i] for r in rows) for i in range(5, 11)]
    rows.append(tot)
    hdr = ["Aquifer group", "Wells", "ℓ~a~ (m)", "Comp. (largest)", "Isol.", "Crit.", "Screened", "Confirmed",
           "REVIEW", "Sites B-GAS", "Sites E-GAS"]
    md = "Table: **Table 2** Network structure and decisions by aquifer group. Comp.: connected components (size of the largest); Isol.: isolated wells; Crit.: wells with a District critical designation (excluded from removal by Eq. 2); Screened: CANDIDATE_REMOVE after detection (B-GAS); Confirmed: screened wells without a removal-risk signal (E-GAS, Eq. 22); REVIEW: screened wells returned to the active network by the E-GAS safeguard. Sites: candidate sites for new wells\n\n"
    md += "| " + " | ".join(hdr) + " |\n|" + "|".join([":" + "-" * 12] + ["-" * w + ":" for w in [8, 9, 10, 7, 7, 10, 11, 9, 9, 9]]) + "|\n"
    for r in rows:
        md += "| " + " | ".join(str(x) for x in r) + " |\n"
    return md


def table3():
    """Comparison of the two configurations (same backbone)."""
    W = pd.read_csv(REF + "Retention_probabilities_perSID_B4_9_GRAPH_AWARE_ACTIVE_SENSING.csv", dtype={"SID": str})
    import r1common as rc
    scr = W[W.FinalDecision_BGAS == "CANDIDATE_REMOVE"]; conf = W[W.FinalDecision == "CANDIDATE_REMOVE"]
    tr = lambda c: scr[c].astype(str).str.lower() == "true"
    CB = pd.read_csv(REF + "Candidate_new_wells_BGAS.csv"); CE = pd.read_csv(REF + "Candidate_new_wells_B4_9.csv")
    cnt = CB.Aquifer_group.value_counts()
    CEq = pd.concat([CE[CE.Aquifer_group == a].sort_values("CandidateRank_inAquifer").head(n) for a, n in cnt.items()])
    ncomp = lambda D: D.groupby(["Aquifer_group", "SourceComponentID"]).ngroups
    nhaw = lambda D: D[D.Aquifer_group == "hawthorn"].SourceComponentID.nunique()
    nh = W[W.Aquifer_group == "hawthorn"].Component_id.nunique()
    rows = [
        ("Wells proposed for removal", len(scr), len(conf)),
        ("Wells kept under REVIEW (active)", 0, int((scr.FinalDecision == "REVIEW").sum())),
        ("Removed wells with a critical designation", int(scr.IsCritical.astype(int).sum()), int(conf.IsCritical.astype(int).sum())),
        ("Removed wells with LOO error ≥ *Q*~85~ (criterion i)", int(tr("Safeguard_trig_LOO").sum()), 0),
        ("Removed wells with *P*~chl,adj~ ≥ 0.85 (criterion iii)", int(tr("Safeguard_trig_CHL").sum()), 0),
        ("ΔNN of the operational network (m, Eq. 31)", f"{rc.delta_nn(W, list(scr.SID)):.0f}", f"{rc.delta_nn(W, list(conf.SID)):.0f}"),
        ("Candidate sites", len(CB), len(CE)),
        ("Components covered by the sites", ncomp(CB), ncomp(CE)),
        (f"Components covered with {len(CB)} sites (same number per aquifer group)", ncomp(CB), ncomp(CEq)),
        (f"Hawthorn components covered (of {nh})", nhaw(CB), nhaw(CE)),
        ("Mean distance of the sites to the nearest well of the aquifer group (km)", f"{_dist_km(CB, W):.1f}", f"{_dist_km(CE, W):.1f}"),
    ]
    md = ("Table: **Table 3** Outcome of the two configurations, which share the graph, the retention evidence and the probabilistic "
          "resolution. B-GAS proposes every screened well for removal; E-GAS confirms only screened wells without a removal-risk signal (Eq. 22; "
          "one screened well meets criteria i and iii). "
          "ΔNN: change in aquifer-weighted mean nearest-neighbour distance of the wells that remain active (KEEP and REVIEW). Components covered: "
          "components of the existing network from which the candidate sites were generated\n\n")
    md += "| | B-GAS | E-GAS |\n|:" + "-" * 50 + "|" + "-" * 9 + ":|" + "-" * 9 + ":|\n"
    for r in rows:
        md += f"| {r[0]} | {r[1]} | {r[2]} |\n"
    return md


def _dist_km(C, W):
    from scipy.spatial import cKDTree
    d = []
    for a, g in C.groupby("Aquifer_group"):
        ww = W[W.Aquifer_group == a]
        d += list(cKDTree(ww[["X_m", "Y_m"]].to_numpy(float)).query(g[["X_m", "Y_m"]].to_numpy(float), k=1)[0])
    return float(np.mean(d)) / 1000


def table4():
    B = pd.read_csv(A + "baselines_equal_budget.csv")
    q = B[B.pool == "all wells"].set_index("method")
    md = ("Table: **Table 4** GAS (B-GAS) compared with established reduction methods at an equal budget of [[n_screened]] removals, all applied "
          "to the same [[n_wells]] wells. Jaccard: overlap with the B-GAS set; Critical: removed wells with a District critical designation; ΔNN: "
          "aquifer-weighted change in mean nearest-neighbour distance (Eq. 31); Comp.: components touched by the removals; LOO: mean (median) "
          "leave-one-out chloride error of the removed wells (Eq. 32). Random removal sets, measures from the 2021–2026 record and the methods "
          "restricted to the wells without a critical designation are given in ESM S5\n\n")
    hdr = ["Method", "Jaccard", "Critical", "ΔNN (m)", "Comp.", "LOO (mg/L)"]
    md += "| " + " | ".join(hdr) + " |\n|:" + "-" * 22 + "|" + "|".join(["-" * 9 + ":"] * (len(hdr) - 1)) + "|\n"
    for m, ml in [("GAS (B-GAS screening)", "GAS (B-GAS)"), ("Distance thinning", "Distance thinning"),
                  ("Reconstructability", "Reconstructability"), ("Kriging variance", "Kriging variance")]:
        r = q.loc[m]
        md += (f"| {ml} | {r.jaccard_vs_GAS:.2f} | {int(r.n_critical)} | {r.dNN_m:.0f} | {int(r.n_components)} | "
               f"{r.loo_mean_mgL:,.0f} ({r.loo_median_mgL:,.0f}) |\n")
    return md


FIGS = {
    "Fig1": ("figures_r1/Fig1_study_area.png", 14.0,
             "**Fig. 1** Study area. **a** Location of the study area (red box) in Florida, USA. **b** Monitoring wells analysed: wells of the Upper "
             "Floridan aquifer (n = [[n_ufa]]), the Hawthorn aquifer system (n = [[n_haw]]) and the surficial aquifer (n = [[n_sur]]), and wells open to "
             "confining units (crosses, n = [[n_confining]]), which were excluded. Grey lines are county boundaries. **c** Schematic north–south hydrostratigraphic section along the Gulf coast, after LaRoche and "
             "Horstman (2023); not to scale and not a single transect. The Hawthorn aquifer system pinches out north of central Hillsborough County; the "
             "Avon Park high-permeability zone is part of the Upper Floridan aquifer north of central Polk County and part of the Lower Floridan aquifer, "
             "below middle confining unit I, south of it. Base maps: US Census Bureau (2023) and Natural Earth (www.naturalearthdata.com)"),
    "Fig2": ("figures_r1/Fig2_framework.png", 14.5,
             "**Fig. 2** Architecture of the graph-aware active-sensing (GAS) framework, with the equations used in each step. The baseline configuration "
             "(B-GAS, blue) ends after detection; the enhanced configuration (E-GAS, orange) adds the confirmation stage and the Hydro-LIMG and "
             "validation-gain scores for candidate sites. The evaluation (grey) uses information that does not feed back into the decisions. "
             "KEEP: retained; CANDIDATE_REMOVE: screened as potentially redundant (detection); REVIEW: undecided class of the probabilistic resolution, or "
             "screened well with a removal-risk signal (REVIEW wells remain active); confirmed CANDIDATE_REMOVE: screened well without a removal-risk signal. *u* uncertainty of a score; *S*~GI~ graph-influence "
             "score; LOO leave-one-out chloride error"),
    "Fig3": ("figures_r1/Fig3_network_topology.png", 16.0,
             "**Fig. 3** Monitoring-network topology. **a** Minimum spanning tree (MST) of each aquifer group after the long-edge cut (Eq. 3): coloured "
             "lines are kept edges and dashed grey lines cut edges; filled circles are wells of the largest component of each aquifer group, open circles "
             "wells of smaller components and open squares isolated wells (no neighbour within ℓ~a~, Eq. 4). Red diamonds are wells screened by B-GAS and returned to REVIEW by the E-GAS safeguard (Eq. 22), black diamonds screened "
             "wells confirmed by E-GAS. The red box marks panel b. **b** Northern part of the dominant Upper Floridan component (Citrus, Hernando and Pasco "
             "counties): light-blue lines connect neighbours within ℓ~a~; grey circles are wells with a District critical designation and open circles "
             "wells without it; diamonds as in panel a, labelled with their SIDs"),
    "Fig4": ("figures_r1/Fig4_detection_confirmation.png", 15.0,
             "**Fig. 4** Detection and confirmation. **a** Probability of the CANDIDATE_REMOVE class in the Monte Carlo realizations versus mean utility "
             "(Eq. 17) for all wells; symbols distinguish isolated wells, wells with and without a critical designation, and the [[n_screened]] screened wells (black: confirmed by E-GAS). **b** "
             "Mean retention scores of the screened wells and of retained wells with neighbours, with 95 % bootstrap intervals. **c** Removal-risk "
             "safeguard (Eq. 22) for the screened wells: leave-one-out chloride error versus chloride keep score. The blue band marks criterion (iii) "
             "and the red band criterion (i); removal can be confirmed only outside both bands and with *S*~GI~ < 0.80. Black diamonds are the wells "
             "confirmed by E-GAS; labels identify them, the Hawthorn well and the wells that triggered criterion (i). **d** Entropy-derived weights of the nine retention scores (Eq. 16); blue bars form "
             "the network family, whose total is capped at 0.36"),
    "Fig5": ("figures_r1/Fig5_candidates.png", 14.5,
             "**Fig. 5** Candidate sites for new wells ranked by **a** B-GAS (active-sensing score, Eqs. 24–26) and **b** E-GAS (fusion of active "
             "sensing, Hydro-LIMG and validation gain, Eqs. 27–30). Colour gives the aquifer group and marker area the final score after sequential "
             "greedy selection; numbers give the rank of the three highest-scoring sites in each aquifer group; grey dots are existing wells. Sites are "
             "plan-view locations; depth and screened interval are left to site design"),
    "Fig6": ("figures_r1/Fig6_validation.png", 15.0,
             "**Fig. 6** Independent tests with data not used by the framework. **a** Leave-one-out chloride error (Eq. 32) of each well in the "
             "design period against the same error computed from the 2021–2026 medians ([[sg_n]] wells; dashed line 1:1); the red dotted line is "
             "the criterion-(i) threshold of the confirmation stage (Eq. 22); diamonds are the screened wells, kept under REVIEW by criterion (iii) "
             "(open) or (i) (red), or confirmed by E-GAS (black). **b** Error factor of the 2021–2026 reconstruction (Eq. 32 on log~10~ chloride) "
             "for the other wells with neighbours, the screened wells and the screened wells kept under REVIEW by criterion (i); boxes show quartiles "
             "and medians, numbers the median factor. **c** Spatial withholding test (all wells within 1.5ℓ~a~ of a random well withheld; "
             "[[ppb_reps]] replicates): share of replicates with at least one site in the gap (filled) and share of withheld wells with a site "
             "within ℓ~a~ (dotted). Random sites are drawn from the GAS candidate pool in the number selected by E-GAS; space-filling sites are the "
             "pool sites farthest from existing wells"),
}
