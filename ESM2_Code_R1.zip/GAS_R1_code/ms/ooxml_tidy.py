"""Puts the property elements of a .docx in the order required by the OOXML schema (ISO/IEC 29500), so that the files
are schema-valid whatever produced them (pandoc, python-docx, LibreOffice). The order is read from the schema files
themselves; only the order of child elements changes, plus four value fixes:
  * <m:nor/> and <m:sty/> are alternatives in a math run; <m:sty/> is dropped when <m:nor/> is present (no visible
    change: normal text is upright);
  * page margins without header/footer/gutter distances get Word's defaults (720, 720, 0 twips);
  * list identifiers (w:nsid) shorter than 8 hex digits are zero-padded; a zoom setting without percentage gets 100.

The schema files (ISO/IEC 29500-4 transitional wml.xsd and shared-math.xsd) are looked up in $OOXML_SCHEMAS or ms/schemas;
without them the step is skipped.

  python ms/ooxml_tidy.py FILE.docx [...]"""
import os, re, sys, zipfile
from lxml import etree

XS = "{http://www.w3.org/2001/XMLSchema}"
W = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
M = "http://schemas.openxmlformats.org/officeDocument/2006/math"
SCHEMA_DIRS = [os.environ.get("OOXML_SCHEMAS", ""), os.path.join(os.path.dirname(os.path.abspath(__file__)), "schemas")]


def _schema(name):
    for d in SCHEMA_DIRS:
        p = os.path.join(d, name)
        if os.path.exists(p):
            return etree.parse(p).getroot()
    raise FileNotFoundError(name)


class Order:
    def __init__(self, root):
        self.types = {e.get("name"): e for e in root.iter(XS + "complexType") if e.get("name")}
        self.groups = {e.get("name"): e for e in root.iter(XS + "group") if e.get("name")}
        self.cache = {}

    def _walk(self, node, out):
        for ch in node:
            tag = ch.tag
            if tag == XS + "element":
                nm = ch.get("name") or ch.get("ref", "").split(":")[-1]
                if nm not in out:
                    out.append(nm)
            elif tag in (XS + "sequence", XS + "choice", XS + "all"):
                self._walk(ch, out)
            elif tag == XS + "group" and ch.get("ref"):
                self._walk(self.groups[ch.get("ref").split(":")[-1]], out)
            elif tag in (XS + "complexContent",):
                self._walk(ch, out)
            elif tag == XS + "extension":
                base = ch.get("base").split(":")[-1]
                if base in self.types:
                    self._walk(self.types[base], out)
                self._walk(ch, out)

    def order(self, ctype):
        if ctype not in self.cache:
            out = []
            self._walk(self.types[ctype], out)
            self.cache[ctype] = {n: i for i, n in enumerate(out)}
        return self.cache[ctype]


try:
    WML = Order(_schema("wml.xsd"))
    MATH = Order(_schema("shared-math.xsd"))
except FileNotFoundError:  # schema files not available: the documents are written as produced (Word opens them)
    WML = MATH = None
# element (namespace, local name, parent local name or None) -> complex type
TYPES_W = {"pPr": "CT_PPr", "tblPr": "CT_TblPr", "tcPr": "CT_TcPr", "trPr": "CT_TrPr", "sectPr": "CT_SectPr",
           "style": "CT_Style", "settings": "CT_Settings", "tblStylePr": "CT_TblStylePr", "pPrDefault": "CT_PPrDefault",
           "rPrDefault": "CT_RPrDefault", "lvl": "CT_Lvl", "abstractNum": "CT_AbstractNum",
           "footnotePr": "CT_FtnDocProps", "endnotePr": "CT_EdnDocProps", "compat": "CT_Compat"}
TYPES_M = {"rPr": "CT_RPR", "mcPr": "CT_MCPr", "dPr": "CT_DPr", "fPr": "CT_FPr", "naryPr": "CT_NaryPr",
           "sSubPr": "CT_SSubPr", "sSupPr": "CT_SSupPr", "sSubSupPr": "CT_SSubSupPr", "accPr": "CT_AccPr",
           "funcPr": "CT_FuncPr", "mPr": "CT_MPr", "eqArrPr": "CT_EqArrPr", "limLowPr": "CT_LimLowPr",
           "limUppPr": "CT_LimUppPr", "barPr": "CT_BarPr", "radPr": "CT_RadPr", "oMathParaPr": "CT_OMathParaPr",
           "mathPr": "CT_MathPr"}


def _ctype(el):
    ns, _, ln = el.tag[1:].partition("}")
    if ns == W:
        if ln == "rPr":
            par = el.getparent()
            pl = etree.QName(par).localname if par is not None else ""
            return WML, ("CT_ParaRPr" if pl == "pPr" else "CT_RPr")
        if ln in TYPES_W:
            return WML, TYPES_W[ln]
    elif ns == M and ln in TYPES_M:
        return MATH, TYPES_M[ln]
    return None, None


def tidy_xml(data):
    root = etree.fromstring(data)
    n = 0
    for el in root.iter():
        if not isinstance(el.tag, str):
            continue
        ln = etree.QName(el).localname
        ns = etree.QName(el).namespace
        if ns == M and ln == "rPr" and el.find(f"{{{M}}}nor") is not None:
            for s in el.findall(f"{{{M}}}sty") + el.findall(f"{{{M}}}scr"):
                el.remove(s); n += 1
        if ns == W and ln == "pgMar":
            for a, v in (("header", "720"), ("footer", "720"), ("gutter", "0")):
                if el.get(f"{{{W}}}{a}") is None:
                    el.set(f"{{{W}}}{a}", v); n += 1
        if ns == W and ln == "zoom" and el.get(f"{{{W}}}percent") is None:
            el.set(f"{{{W}}}percent", "100"); n += 1
        if ns == W and ln in ("nsid", "tmpl") and el.get(f"{{{W}}}val") and len(el.get(f"{{{W}}}val")) < 8:
            el.set(f"{{{W}}}val", el.get(f"{{{W}}}val").zfill(8)); n += 1
        sch, ct = _ctype(el)
        if ct is None:
            continue
        order = sch.order(ct)
        kids = [k for k in el if isinstance(k.tag, str)]
        if len(kids) < 2 or any(not isinstance(k.tag, str) for k in el):
            continue
        key = [order.get(etree.QName(k).localname, len(order)) for k in kids]
        if key != sorted(key):
            new = [k for _, _, k in sorted(zip(key, range(len(kids)), kids))]
            for k in kids:
                el.remove(k)
            for k in new:
                el.append(k)
            n += 1
    return etree.tostring(root, xml_declaration=True, encoding="UTF-8", standalone=True), n


def tidy_docx(path):
    if WML is None:
        return "skipped (OOXML schema files wml.xsd and shared-math.xsd not found)"
    tmp = path + ".tidy"
    total = 0
    with zipfile.ZipFile(path) as zin, zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED) as zout:
        for it in zin.infolist():
            data = zin.read(it.filename)
            if re.match(r"word/(document|styles|settings|numbering|footer\d*|header\d*|footnotes|endnotes)\.xml$", it.filename):
                data, n = tidy_xml(data); total += n
            zout.writestr(it, data)
    os.replace(tmp, path)
    return total


if __name__ == "__main__":
    for f in sys.argv[1:]:
        print(f, "schema-order fixes:", tidy_docx(f))
