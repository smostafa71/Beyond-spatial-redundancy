# Abstract

Groundwater monitoring networks are reviewed periodically to decide which wells can be discontinued and where new wells would add most. Spatial proximity is the usual indicator of redundancy, but in layered coastal aquifers neighbouring wells may sample different units or different positions relative to the freshwater–saltwater transition. A graph-based, uncertainty-aware framework is presented that treats both decisions together: each aquifer's monitoring network is represented as a graph, evidence of replaceability (spatial redundancy, hydrochemical overlap, structural role, data reliability) is combined with explicit uncertainty propagation, and sites for new wells are ranked with the evidence from existing wells. A baseline configuration is compared with an enhanced one that separates the detection of potentially redundant wells from the confirmation that their removal is safe. Applied to [[n_wells]] wells in three aquifer units of west-central Florida (USA), the baseline detected [[n_screened]] potentially redundant wells, [[scr_dom_n]] of them in the largest connected parts of the networks; the enhanced configuration confirmed [[n_confirmed_w]] and kept the others under review. In the independent 2021–2026 chloride record, the [[sg_ci_n]] wells it kept because neighbours reconstruct them poorly remained about [[sg_ratio]] times harder to reconstruct than other wells. At equal numbers of removals, distance- and kriging-based reduction, which ignore the water management district's designation of critical wells, selected different wells, removed critical wells and increased well spacing [[ext_ratio_min]]–[[ext_ratio_max]] times more. Proximity is a poor guide to redundancy in this layered coastal system, and separating detection from confirmation protects wells whose information the network cannot replace.

**Keywords** Groundwater monitoring · Monitoring network design · Graph theory · Uncertainty analysis · Salt-water/fresh-water relations

# Abbreviations

AS, active sensing; B-GAS, baseline configuration of the graph-aware active-sensing framework; E-GAS, enhanced configuration (removal-risk safeguard and Hydro-LIMG); EDP, Environmental Data Portal of the Southwest Florida Water Management District; ESM, electronic supplementary material; GAS, graph-aware active sensing; Hydro-LIMG, hydrogeologic multi-level information gain; ISI, information stability index; LOO, leave-one-out; MAD, median absolute deviation; MST, minimum spanning tree; NN, nearest neighbour; PRCC, partial rank correlation coefficient; ROMP, Regional Observation and Monitor-well Program; S~GI~, graph-influence score; SID, station identifier; SWFWMD, Southwest Florida Water Management District

# 1 Introduction

Groundwater monitoring networks are rarely the product of systematic design. Most accumulate through incremental decisions—wells added for emerging concerns, removed under budget pressure and kept through institutional inertia—so that they reflect the history of management rather than the structure of the monitored system and are over-instrumented in some areas and blind in others (Loaiciga et al. 1992; Reed and Kollat 2012).

Design methods include simulation–optimization and multi-objective designs that trade cost, coverage and reliability (Reed et al. 2000; Kollat and Reed 2006; Li and Hilton 2007; Kollat et al. 2008; Reed and Kollat 2012; Luo et al. 2016; Gu et al. 2025), geostatistical designs that minimize kriging variance (Gladish et al. 2023), information-theoretic designs based on entropy and transinformation (Caselton and Zidek 1984; Yang and Burn 1994; Mishra and Coulibaly 2009; Keum et al. 2017; Hosseini and Kerachian 2017), and data-driven methods that reconstruct the observed field from a subset of stations (Ohmer et al. 2022; Chen et al. 2022; Teimoori et al. 2023; Meggiorin et al. 2024; Wang et al. 2024; Dhapre et al. 2025). Many of them account for dependence among locations, but the decision is still expressed for the individual location—a well is ranked, retained, removed or added by its marginal score—and the network is not represented as a connected object. A well whose chloride can be reconstructed from its neighbours may nevertheless be the only link between two parts of the network, or the only well that samples a particular interval. Graph theory makes such structural roles explicit in ecological and infrastructure networks (Bunn et al. 2000; Urban and Keitt 2001; Newman 2010) and is used for groundwater data (Taccari et al. 2024), but not for the redesign of monitoring networks.

Second, reduction and reinforcement are usually treated separately, although the evidence that makes a well removable or indispensable—its uncertainty, its structural role, how well neighbours reproduce its record—also shows where the network is weak. Active-sensing strategies, which select locations sequentially by their marginal information gain (Krause and Guestrin 2007; Krause et al. 2008; Meggiorin et al. 2024), offer a basis for this coupling but have been applied to candidate selection alone. Third, network-reduction frameworks mostly resolve ambiguous removal decisions through deterministic thresholds, which treats the absence of evidence for retention as evidence for removal (Mishra and Coulibaly 2009; Nowak et al. 2010). Data-worth analysis and Bayesian experimental design propagate uncertainty into such decisions in the wider hydrogeological literature (Nowak et al. 2010; Thibaut et al. 2021; Delottier et al. 2026), but have rarely been applied to the reduction of operational networks.

The value of a monitoring well can only be judged against a stated objective (Loaiciga et al. 1992); water-level and water-quality networks, for example, sample variables with different spatial correlation and need different criteria. The network studied here is a groundwater-quality network in a coastal aquifer system whose principal management concern is salinity. Its objective is taken to be the characterization of the chloride concentration of the freshwater resource in each aquifer unit. A well is redundant only when its chloride level and trend class are duplicated by neighbours in the same aquifer unit and its removal does not disrupt the structure of the network.

This study presents a graph-aware active-sensing (GAS) framework that addresses the three limitations for this objective. Wells are nodes of aquifer-specific graphs; removability is conditioned jointly on spatial redundancy, information overlap, hydrochemical dependency and graph role, with uncertainty propagated by Monte Carlo simulation; and candidate sites for new wells are scored with the evidence from existing wells. Network redesign is formulated as a decision problem under asymmetric loss (Sect. 2.3). Two configurations are compared to isolate the contribution of each component: a baseline (B-GAS) and an enhanced configuration (E-GAS) that separates the detection of potentially redundant wells from the confirmation of their removal and adds a hydrogeologic multi-level information-gain score (Hydro-LIMG) for candidate sites. Both are applied to [[n_wells]] wells in west-central Florida and evaluated against established reduction methods at an equal budget, with an independent later chloride record, a spatial withholding test and a joint perturbation of [[lhs_k]] fixed parameters.

# 2 Materials and methods

## 2.1 Study area and hydrogeologic setting

The study area lies along the Gulf of Mexico coast of west-central Florida, from Levy and Citrus counties in the north to Charlotte and DeSoto counties in the south (stations at 26.8–29.0°N, 81.6–82.8°W; Fig. 1), within the Southwest Florida Water Management District (SWFWMD). The hydrostratigraphy follows LaRoche and Horstman (2023) (see also Miller 1986; Williams and Kuniansky 2016). Three units are monitored (Fig. 1c). The surficial aquifer, in unconsolidated sand and shell, is absent or thin in much of the north. The Hawthorn aquifer system (formerly the intermediate aquifer system) comprises up to three aquifers in the clastic and carbonate rocks of the Hawthorn Group—the Peace River, upper Arcadia and lower Arcadia aquifers—separated by clay-rich confining units; it pinches out north of central Hillsborough County and thickens southwards from about 15 to 90 m. The Floridan aquifer system consists of Eocene to Oligocene limestone and dolostone; its upper part, the Upper Floridan aquifer, is the principal water-supply aquifer of the region, confined where the Hawthorn Group clays are continuous, but unconfined or thinly confined and karstic in much of the north (Upchurch et al. 2019). The Avon Park high-permeability zone belongs to the Upper Floridan aquifer north of an east–west line through central Polk County and to the Lower Floridan aquifer, below middle confining unit I, south of it (LaRoche and Horstman 2023).

Chloride increases towards the coast and with depth; in the Floridan aquifer system the freshwater–saltwater transition zone lies within the monitored interval along much of the coast (Reese 2000), and in the Hawthorn aquifer system brackish water occurs in the deeper aquifers and near the coast (Schmerge 2001). Two wells close together in plan view may therefore monitor different water.

## 2.2 Monitoring network and data

The District groundwater-quality station inventory contains 2,069 records for [[n_sids]] stations (SIDs), consolidated by SID (medians; dominant categories). [[n_confining_w]] wells open to confining units were excluded. The remaining [[n_wells]] wells (Fig. 1b) form three aquifer groups, assigned from the hydrostratigraphic unit of the inventory as in the original analysis: Upper Floridan aquifer ([[n_ufa]], including [[n_appz]] wells assigned to the Avon Park high-permeability zone, [[n_appz_south]] of them south of central Polk County, kept in this group as in the original analysis), Hawthorn aquifer system ([[n_haw]]: Peace River 2, upper Arcadia 15, lower Arcadia 24, not assigned to a named aquifer 47) and surficial aquifer ([[n_sur]]). Distances are computed in the Florida Albers Equal Area projection (EPSG:3087).

<<Fig1>>

The inputs for each well are aquifer group, chloride concentration and trend class, reported total depth (missing for [[n_depth_missing]] wells; median 80 m), operational status and the District network-review designation ("critical" or "supporting"). Chloride concentration (median of the 2013–2020 record) and trend class (decreasing, stable or increasing; [[n_trend_dec]], [[n_trend_sta]] and [[n_trend_inc]] wells) are attributes of the District station inventory, derived by the District from the 2013–2020 record, and are used as in the original analysis. Dissolved-chloride records (parameter WQ_139) of the District's Environmental Data Portal (EDP) from January 2021 to July 2026 were used only for the tests of Sect. 2.9; the 2013–2020 EDP medians serve only as a check of the concentration input and in one sensitivity variant (Sect. 3.7). Processing details are given in the electronic supplementary material (ESM S2). Of the [[n_wells]] wells, [[n_critical]] carry a "critical" designation in at least one of their District programmes; as in the original analysis, such wells are treated as critical ([[n_critical_dom]] are critical in the majority of their records; Sect. 3.7).

## 2.3 Decision problem and framework overview

Let *x*~*i*~ = 1 if well *i* is discontinued and 0 otherwise, and let *π*~*i*~ be the probability that well *i* is replaceable, that is, that its contribution to the monitoring objective is duplicated by the rest of the network. With an asymmetric loss in which wrongly discontinuing a well (cost *c*~R~) is worse than keeping a redundant one (cost *c*~K~ < *c*~R~), the removal decision is

$$\min_{\mathbf{x}}\;\sum_{i}\left[x_i\,c_\mathrm{R}\,(1-\pi_i)+(1-x_i)\,c_\mathrm{K}\,\pi_i\right] \qquad (1)$$

subject to

$$x_i=0\quad \forall\, i\in\mathcal{K}\cup\mathcal{I}\cup\mathcal{R};\qquad \sum_{c}y_c\le n_\mathrm{c}\ \text{per aquifer} \qquad (2)$$

where $\mathcal{K}$ is the set of wells with a critical designation, $\mathcal{I}$ the isolated wells (no neighbour within the aquifer-specific length ℓ~a~, Eq. 4), $\mathcal{R}$ the wells with a removal-risk signal (Eq. 22), and *y*~*c*~ = 1 if candidate site *c* is selected (*n*~c~ = 20). Eq. (1) is separable—the constraints fix individual wells—and its solution is the Bayes decision rule: a free well is discontinued only when *π*~*i*~ exceeds *c*~R~/(*c*~R~ + *c*~K~) (Raiffa and Schlaifer 1961; Freeze et al. 1990). GAS approximates this rule with explicit, traceable steps: *π*~*i*~ is estimated by the Monte Carlo frequency of the class CANDIDATE_REMOVE (Eq. 19); a well is screened when that class is the most probable, ambiguous cases being resolved by the calibration and voting rules with ties going to KEEP (Eq. 20); and the asymmetry of the loss is imposed through the constraints of Eq. (2)—critical and isolated wells are never removed, and the confirmation stage (Eq. 22) defines $\mathcal{R}$—rather than through a numerical cost ratio (Sect. 4.4). Candidate sites are selected greedily by their gain (Eqs. 24–30), the standard approach to sensor placement (Krause et al. 2008).

Four classes are used throughout: KEEP (retained); CANDIDATE_REMOVE, or screened (potentially redundant at detection); REVIEW (undecided, or screened with a removal-risk signal; the well remains active); and confirmed CANDIDATE_REMOVE (screened without a removal-risk signal). Two configurations share the graph, the retention evidence and the probabilistic resolution (Sects. 2.4–2.6; Fig. 2; Table 1). The baseline (B-GAS) proposes every screened well for removal and ranks candidate sites by the active-sensing score. The enhanced configuration (E-GAS) adds two components: a confirmation stage, which releases a screened well for removal only when no removal-risk signal is present (Sect. 2.7), and the Hydro-LIMG and validation-gain scores for candidate sites (Sect. 2.8). Because the backbone is identical, the differences between the two configurations are attributable to these components. All parameters and the source of each value are listed in ESM Table S1.

<<Table1>>

<<Fig2>>

## 2.4 Graph construction

For each aquifer group *a*, a minimum spanning tree (MST) is built from the Euclidean distances between the *n*~*a*~ wells (input: the *n*~*a*~ × 2 coordinate matrix; output: *n*~*a*~ − 1 edges), providing the minimal connected backbone (Bunn et al. 2000). Edges longer than

$$T_\mathrm{cut}=\mathrm{median}(L)+3\,\mathrm{MAD}(L) \qquad (3)$$

where *L* is the vector of MST edge lengths and MAD the median absolute deviation (Rousseeuw and Croux 1993; Leys et al. 2013), are removed (the 95th percentile of *L* is used when MAD = 0). The remaining edges partition the wells into connected components, the organizational units of all later steps. The neighbourhood length

$$\ell_a=P_{90}\left(d_\mathrm{NN}\right) \qquad (4)$$

is the 90th percentile of nearest-neighbour (NN) distances within components (bounded to 250–20,000 m, rounded to 10 m). Two wells of the same component closer than ℓ~a~ are neighbours, with distance weight

$$w_{ij}=\exp\left(-d_{ij}/\ell_a\right) \qquad (5)$$

Wells without a neighbour are isolated and are never screened; neighbours linked through chains of neighbours form redundancy clusters, within which the decision rule of Eq. (19) operates. The graph describes monitoring-network topology, not hydraulic connection (Sect. 4.3); terms such as bridge or connectivity refer to this topology.

## 2.5 Evidence for the retention of existing wells

Nine retention ("keep") scores *P* in [0, 1] describe each well; a high value is evidence for retention, and each score carries an uncertainty *u* in [0, 1] (ESM Table S1).

*Chloride concentration.* Chloride concentration *C* (mg/L) is scored with a logistic function centred on the regional salinity management threshold:

$$P_\mathrm{chl}=\left[1+\exp\left(-\frac{2000-C}{400}\right)\right]^{-1} \qquad (6)$$

This function assigns high retention support to freshwater wells and low support to high-salinity wells. The midpoint of 2,000 mg/L is the regional salinity management threshold recommended by District hydrogeologists. For water of seawater composition (chloride about 55 % of dissolved solids; Hem 1985) it corresponds to about 3,600 mg/L dissolved solids, just above the 3,000 mg/L limit between fresh and moderately saline water used in the District's water-use permitting (SWFWMD 2022), and it lies within the coastal mixing zone of the Floridan aquifer, between 250 and 19,000 mg/L chloride (Causseaux and Fretwell 1983). With the 400 mg/L transition width, the score falls from 0.9 to 0.1 between about 1,100 and 2,900 mg/L.

*Chloride trend.* As in the original analysis, the trend class of the District inventory is mapped to

$$P_\mathrm{trend}=\begin{cases}1.0 & \text{decreasing}\\ 0.5 & \text{stable}\\ 0.0 & \text{increasing}\end{cases} \qquad (7)$$

because declining trends increase monitoring value. The rule follows the same logic as Eq. (6): the framework decides whether an existing well is kept, and a well whose chloride increases moves towards saline water, so that its value for monitoring the freshwater resource decreases. A well without a trend class would receive 0.55 with high uncertainty. The trend class enters only as an attribute of the well: the analysis of chloride trends is not an objective of this study. The joint-quality layer (Eq. 8) lowers the support of saline wells with an increasing trend and raises that of fresh wells with a decreasing trend. The status score is 0.85 for active and 0.2 for inactive wells; the depth score, 0.35 + 0.55 × rarity, rewards depths that are rare within the aquifer group (Gaussian kernel density).

*Joint quality.* This term combines the chloride level and trend scores. With *r* = 1 − *P*, joint low support (*b*, *h*^−^) lowers the scores and joint high support (*P*~JQ~^0^, *h*^+^) raises them:

$$P_\mathrm{JQ}^{0}=P_\mathrm{chl}P_\mathrm{trend},\quad b=r_\mathrm{chl}r_\mathrm{trend},\quad h^{-}=r_\mathrm{status}\left(1-P_\mathrm{JQ}^{0}\right),\quad h^{+}=P_\mathrm{status}P_\mathrm{JQ}^{0}$$

$$P_\mathrm{chl,adj}=P_\mathrm{chl}-0.22\,b+0.04\,P_\mathrm{JQ}^{0},\qquad P_\mathrm{trend,adj}=P_\mathrm{trend}-0.22\,b+0.10\,P_\mathrm{JQ}^{0}$$

$$P_\mathrm{status,adj}=P_\mathrm{status}-0.10\,h^{-}+0.05\,h^{+},\qquad P_\mathrm{JQ}=P_\mathrm{JQ}^{0}-0.10\,h^{-}+0.05\,h^{+} \qquad (8)$$

and the depth score is shifted by 0.03(*P*~JQ~^0^ − 0.5); all values are limited to [0, 1].

*Spatial redundancy.* Within each redundancy cluster, the neighbour count *N*\*, the aggregate proximity weight *W*\* (Σ~*j*~ *w*~*ij*~, Eq. 5) and the mean neighbour distance *D*\* of each well are min–max scaled over the wells of the cluster and combined into the proximity intensity

$$\mathrm{Prox}_i=0.6\,W_i^{*}+0.4\,(1-D_i^{*}) \qquad (9)$$

and, with the redundancy intensity Red~*i*~, the distance keep score

$$\mathrm{Red}_i=0.40\,N_i^{*}+0.42\,\mathrm{Prox}_i+0.18\,\mathrm{Comp}_i,\qquad \mathrm{Comp}_i=\mathrm{clip}\!\left(0.5+0.5\left[(1-D_i^{*})-\mathrm{Prox}_i\right],0,1\right),\qquad P_{\mathrm{dist},i}=1-\mathrm{Red}_i \qquad (10)$$

where clip(*x*, *a*, *b*) limits *x* to [*a*, *b*] and the compactness Comp~*i*~ rewards wells that sit in tighter clusters than their proximity intensity alone suggests.

*Information uniqueness.* A feature vector **x**~*i*~ encodes the hydrochemical identity of a well, with all four features in [0, 1]: chloride and depth min–max scaled (over all wells and within the aquifer group), and the trend and status scores:

$$s_{ij}^{\mathrm{info}}=\exp\left(-\frac{\lVert\mathbf{x}_i-\mathbf{x}_j\rVert}{1.25}\right),\qquad P_{\mathrm{info},i}=1-\frac{\sum_j w_{ij}\,s_{ij}^{\mathrm{info}}}{\sum_j w_{ij}} \qquad (11)$$

*Dependency uniqueness.* Hydrochemical duplication is measured by the weighted agreement in trend, chloride, depth and status, each agreement *a* being one minus the absolute difference of the normalized attribute:

$$s_{ij}^{\mathrm{dep}}=0.35\,a_{ij}^{\mathrm{tr}}+0.30\,a_{ij}^{\mathrm{cl}}+0.20\,a_{ij}^{\mathrm{dp}}+0.15\,a_{ij}^{\mathrm{st}},\qquad P_{\mathrm{dep},i}=1-\frac{\sum_j w_{ij}\,s_{ij}^{\mathrm{dep}}}{\sum_j w_{ij}} \qquad (12)$$

*Graph role.* In each cluster the adjacency matrix *A*~*ij*~ = *s*~*ij*~^dep^ *w*~*ij*~ (entries below 0.05 set to zero) defines, for the neighbours $\mathcal{N}_i$ of well *i* (*A*~*ij*~ > 0), the node strength, the cohesion of the neighbourhood and the spread of the neighbours' features:

$$\mathrm{Strength}_i=\sum_j A_{ij},\qquad \mathrm{Cohesion}_i=\frac{\sum_{j\ne k\in\mathcal{N}_i}A_{jk}}{|\mathcal{N}_i|\left(|\mathcal{N}_i|-1\right)},\qquad \mathrm{Spread}_i=\overline{\left|\mathbf{x}_j-\bar{\mathbf{x}}_{\mathcal{N}_i}\right|}$$

$$\mathrm{Bridge}_i=\mathrm{Strength}_i^{*}\,(1-\mathrm{Cohesion}_i),\qquad P_{\mathrm{graph},i}=0.65\,\mathrm{Bridge}_i+0.20\,(1-\mathrm{Cohesion}_i)+0.15\,\mathrm{Spread}_i^{*} \qquad (13)$$

where the asterisk denotes min–max scaling within the cluster and Cohesion~*i*~ = 0 for fewer than two neighbours. A well with high strength but low cohesion bridges neighbours that are weakly connected to each other. In clusters of fewer than three wells, *P*~graph~ is shrunk towards the neutral value, *P*~graph~ ← 0.5 + 0.55(*P*~graph~ − 0.5). The structural consequence of removing a well is measured by the leave-one-out graph-influence score

$$S_{\mathrm{GI},i}=0.45\,\Delta_i^{\mathrm{comp}}+0.35\,\Delta_i^{\mathrm{str}}+0.20\,\Delta_i^{\mathrm{MST}} \qquad (14)$$

where Δ~*i*~^comp^, Δ~*i*~^str^ and Δ~*i*~^MST^ are the normalized increase in the number of connected components, the loss of total adjacency strength and the increase in MST length when well *i* is removed from its cluster. *P*~info~, *P*~dep~ and *P*~graph~ are partly decorrelated from the proximity signal (strengths 0.10, 0.34 and 0.30) and rescaled within each cluster (ESM Table S1); isolated wells receive 1.

*Aquifer reliability.* Because well counts differ strongly between aquifer groups, the scores are shrunk towards the neutral value by the reliability *r*~*a*~,

$$P_\mathrm{adj}=0.5+r_a\left(P-0.5\right),\qquad r_a=0.35+0.65\,\mathrm{clip}\!\left(\frac{n_a-5}{15},0,1\right) \qquad (15)$$

chloride concentration being shrunk with the weaker effective reliability 1 − 0.35(1 − *r*~*a*~); the uncertainties are increased by (1 − *r*~*a*~) times 0.08–0.20, depending on the score. *r*~*a*~ is 1 for the Upper Floridan aquifer and the Hawthorn aquifer system and 0.35 for the five-well surficial aquifer.

## 2.6 Weights, utility and probabilistic resolution

The weights of the nine scores are derived from their information entropy (entropy weight method; Zou et al. 2006), so that scores that vary more across the wells receive more weight. For score *j* over *n* wells, with *p*~*ij*~ = *P*~*ij*~/Σ~*i*~*P*~*ij*~,

$$H_j=-\frac{1}{\ln n}\sum_i p_{ij}\ln p_{ij},\qquad \omega_j=\frac{1-H_j}{\sum_k\left(1-H_k\right)} \qquad (16)$$

A global and an aquifer-balanced weight vector are blended equally and constrained so that the correlated network family {information, dependency, graph role} carries at most 0.36, joint quality at most 0.18 and each score at least 0.03 (Keum et al. 2017). The retention utility of a well is

$$U_i=\sum_j\omega_j\,P_{ij} \qquad (17)$$

Uncertainty is propagated by Monte Carlo simulation (*N* = 3,000 realizations, seed 12345). In each realization every score is drawn from a Beta distribution with mean *m* = *P* and concentration

$$\kappa=2+48\,(1-u),\qquad \alpha=m\,\kappa,\qquad \beta=(1-m)\,\kappa \qquad (18)$$

so that a certain score is sampled from a peaked and an uncertain score from a nearly uniform distribution. Within each redundancy cluster, the well with the highest sampled utility is the anchor and is always retained; in clusters of at least three wells that are spatially extended (maximum distance ≥ 1.2ℓ~a~) or heterogeneous, a second anchor is retained when its deterministic utility is at least 0.64 and close to that of the first. Every other well *i* of the cluster is classified in realization *k* as

$$\mathrm{class}_i^{(k)}=\begin{cases}\mathrm{REVIEW} & U_i^{(k)}\ge 0.66\ \text{or}\ i\in\mathcal{K}\\ \mathrm{CANDIDATE\_REMOVE} & \text{otherwise}\end{cases} \qquad (19)$$

Isolated wells are KEEP (REVIEW if *U*~*i*~^(*k*)^ < 0.35). After *N* realizations each well has empirical probabilities *P*(KEEP), *P*(REVIEW) and *P*(CANDIDATE_REMOVE) and is assigned the most probable class. Cases with a small probability margin (≤ 0.12) and high composite uncertainty (≥ 0.42) are set to REVIEW. The other REVIEW wells are calibrated: they become KEEP when *P*(KEEP) ≥ 0.42, the mean utility *Ū* ≥ 0.50 and the structural value (mean of *P*~info~, *P*~dep~, *P*~graph~ and *S*~GI~) ≥ 0.52, and CANDIDATE_REMOVE (if not critical) when *P*(CANDIDATE_REMOVE) ≥ 0.46, *Ū* ≤ 0.50, structural value ≤ 0.46, *P*~dist~ ≤ 0.48 and composite uncertainty ≤ 0.42 (ESM Table S1). The remaining REVIEW wells are resolved by consensus votes on the probabilities, mean utility, structural value, stability (Eq. 21) and composite uncertainty:

$$V_\mathrm{keep}=[P(\mathrm{KEEP})\ge0.50]+[\bar U\ge0.52]+[\mathrm{struct}\ge0.54]+[\mathrm{ISI}\ge0.58]$$

$$V_\mathrm{remove}=[P(\mathrm{CR})\ge0.52]+[\bar U\le0.48]+[\mathrm{struct}\le0.46]+[\mathrm{ISI}\le0.50]+[\bar u\le0.44] \qquad (20)$$

where CR stands for CANDIDATE_REMOVE and [·] is 1 if the condition holds and 0 otherwise. *V*~keep~ ≥ 2 (and *V*~keep~ > *V*~remove~) gives KEEP, *V*~remove~ ≥ 3 (and *V*~remove~ > *V*~keep~) gives CANDIDATE_REMOVE, and ties default to KEEP; critical wells are KEEP before votes are counted, and a cluster in which no well would otherwise be KEEP keeps its best-supported well. Decision stability is summarized by the information stability index

$$\mathrm{ISI}=0.40\,\delta_\mathrm{dec}+0.25\,\delta_\mathrm{margin}+0.20\,\delta_\mathrm{unc}+0.15\,\delta_\mathrm{util} \qquad (21)$$

where δ~dec~ is the dominant-class probability, δ~margin~ the gap between the two most probable classes, δ~unc~ one minus the composite uncertainty and δ~util~ = |2*Ū* − 1|; ISI ≥ 0.80 is high, 0.60–0.80 medium and < 0.60 low stability.

## 2.7 Confirmation of screened wells (E-GAS)

The evidence that a well is potentially redundant (detection) is not evidence that its removal is safe (confirmation). E-GAS therefore returns a screened well to REVIEW when at least one of three removal-risk criteria (the removal-risk safeguard) holds:

$$i\in\mathcal{R}\iff \mathrm{LOO}_i\ge Q_{85}\ \lor\ S_{\mathrm{GI},i}\ge0.80\ \lor\ P_{\mathrm{chl,adj},i}\ge0.85 \qquad (22)$$

(i) the leave-one-out (LOO) error of the well's chloride, reconstructed by inverse-distance weighting from all other wells of its aquifer group (Eq. 32), reaches the 85th percentile of the screened set; (ii) its removal would substantially change the network structure; or (iii) its chemical evidence strongly favours retention. Removal is confirmed only when none applies; REVIEW wells remain active.

## 2.8 Candidate generation and scoring

Candidate sites are plan-view locations within an aquifer group; depth and screened interval are left to site design. For each component a support domain combines point buffers of 0.55ℓ~a~ around wells, corridors of 0.40ℓ~a~ along MST edges and an alpha-shape envelope (Edelsbrunner and Mücke 1994) of radius max(1.15ℓ~a~, 1.25*g*). A hexagonal grid of spacing

$$g=\mathrm{clip}\left(0.75\,\ell_a,\ 1000\ \mathrm{m},\ 10{,}000\ \mathrm{m}\right) \qquad (23)$$

is placed in the domain (ESM Fig. S1); points closer than 0.60ℓ~a~ to an existing well or in open water (outside the 1:500,000 shoreline of Florida; US Census Bureau 2023) are discarded, and points are added between distant pairs of high-uncertainty wells and around high-influence wells (top 20 %). Each candidate *c* receives the active-sensing score

$$\mathrm{AS}(c)=w_\mathrm{unc}g_\mathrm{unc}(c)+w_\mathrm{sup}g_\mathrm{sup}(c)+w_\mathrm{gra}g_\mathrm{gra}(c)+w_\mathrm{rep}g_\mathrm{rep}(c)+w_\mathrm{dep}g_\mathrm{dep}(c) \qquad (24)$$

where *g*~unc~ is the distance-weighted mean uncertainty of the surrounding wells, *g*~sup~ the distance to the nearest well relative to ℓ~a~, *g*~gra~ their weighted mean graph influence, and *g*~rep~ and *g*~dep~ the weighted dispersion of their feature and dependency attributes, each min–max scaled. The base weights (0.34, 0.24, 0.20, 0.14, 0.08) are adapted to the component from which the site was generated,

$$w_k=\frac{w_k^{0}\left[1+a_k\left(\rho_k-0.5\right)\right]}{\sum_l w_l^{0}\left[1+a_l\left(\rho_l-0.5\right)\right]} \qquad (25)$$

with *a* = 0.3 for the first three terms and 0.2 for the last two, and ρ~*k*~ the corresponding pressure indicator of the wells of the component (mean uncertainty, median NN distance relative to ℓ~a~, mean graph influence, feature and dependency dispersion). Sites are selected greedily; after each pick the scores of the remaining sites are updated as

$$\mathrm{AS}'(c)=\mathrm{AS}(c)\left[1-0.45\,e^{-d_c/0.7\ell_a}\right]\left[1-0.3\max\left(0,\,1-\frac{d_c}{1.5\ell_a}\right)\right] \qquad (26)$$

where *d*~*c*~ is the distance to the site just selected (B-GAS). E-GAS combines three scores before greedy selection,

$$\mathrm{Score}_\mathrm{E}(c)=0.35\,\mathrm{AS}(c)+0.35\,\mathrm{LIMG}(c)+0.30\,V(c) \qquad (27)$$

The Hydro-LIMG score evaluates each site at four levels,

$$\mathrm{LIMG}(c)=0.25\,L_\mathrm{glob}+0.15\,L_\mathrm{aq}+0.40\,L_\mathrm{loc}+0.20\,L_\mathrm{bl} \qquad (28)$$

each contrasting how far the wells around *c* deviate from the aquifer mean with how much they vary: the distance-weighted wells around *c* about their own mean (global) or about the aquifer mean (aquifer), the *k* = 8 nearest wells against their distance and graph influence (local), and the uncertainty and graph influence of the surrounding wells (blended); the definitions are given in ESM S1 (Eqs. S1–S4). The validation gain

$$V(c)=\frac{\sum_i e^{-d_{ci}/1.1\ell_a}\,\mathrm{LOO}_i}{\sum_i e^{-d_{ci}/1.1\ell_a}} \qquad (29)$$

summed over the screened wells of the same aquifer group and min–max scaled, directs sites towards places where screened wells are poorly reconstructed; with one screened well *V* is constant and without screened wells it is zero, so that E-GAS scores are comparable only within an aquifer group. The E-GAS greedy update multiplies the remaining scores by one minus

$$\mathrm{pen}(c)=0.45\,e^{-d_c/0.7\ell_a}+0.30\,\mathrm{sim}_\mathrm{LIMG}(c)+0.25\,\mathrm{sim}_\mathrm{signal}(c) \qquad (30)$$

where the similarities compare the Hydro-LIMG score and the vector of gain terms of *c* with those of the site just selected. At most 20 sites per aquifer group are kept, at least 0.85*g* (and 0.8ℓ~a~) apart.

## 2.9 Evaluation

The configurations are compared with each other and with established reduction methods at an equal budget, and the decisions are tested with an independent later record, a withholding test and a sensitivity analysis.

*Configuration comparison.* B-GAS and E-GAS are described by their outcomes: wells proposed for removal, wells kept under REVIEW, the aquifer-weighted change in mean nearest-neighbour (NN) distance of the wells that remain active (KEEP and REVIEW, because REVIEW wells stay in operation),

$$\Delta\mathrm{NN}=\frac{\sum_a n_a^\mathrm{ret}\left(\overline{d}_{\mathrm{NN},a}^\mathrm{ret}-\overline{d}_{\mathrm{NN},a}\right)}{\sum_a n_a^\mathrm{ret}} \qquad (31)$$

and the components of the network covered by the candidate sites. The number of wells released for removal is itself an outcome of the confirmation rule, not an input; these quantities therefore describe what each configuration does. The contribution of the added components is assessed with comparisons that do not depend on that number: the coverage of candidate sites at an equal number of sites, and the independent tests below.

*Equal-budget comparison with established methods.* Three established reduction methods were applied to the same wells and held to the same number of removals as B-GAS: distance thinning (repeated removal of the well with the smallest NN distance), reconstructability (removal of the wells whose chloride is best reproduced by their dependency-weighted neighbours, representing information-based designs) and kriging variance (repeated removal of the well whose deletion least increases the mean ordinary-kriging variance of log~10~ chloride, with an exponential variogram for each aquifer group; ESM S5). The sets are compared by ΔNN, the number of components touched, the Jaccard overlap |*A* ∩ *B*|/|*A* ∪ *B*| with the B-GAS set (Jaccard 1912), the number of critical wells removed and the LOO error of the removed wells, each predicted from all other wells of its aquifer group by

$$\hat z_0=\frac{\sum_i d_{0i}^{-2}z_i}{\sum_i d_{0i}^{-2}} \qquad (32)$$

ESM S5 adds 1,000 random sets of the same size, the methods restricted to the wells without a critical designation, and measures from the 2021–2026 record.

*Independent temporal test.* The 2021–2026 chloride record (median [[val_n_median]] sampling days per well) is not used by the framework. Eq. (32) is applied to the 2021–2026 medians in the same way as to the design data, and two questions are asked. First, is the reconstruction difficulty on which criterion (i) of the confirmation stage and the validation gain (Eq. 29) rest a persistent property of the network? The design-period and later LOO errors are compared by the Spearman rank correlation, and the later errors of the wells with a design-period error above the criterion-(i) threshold, and of the screened wells kept under REVIEW by criterion (i), with those of the other wells (one-sided Mann–Whitney tests; errors on log~10~ chloride, reported as factors). Second, if detection alone established redundancy, the 2021–2026 chloride of the screened wells should be reconstructed from neighbouring wells better than that of other wells. The trend of the later record is evaluated with the two-sided Mann–Kendall test on the sampling-day values (p ≤ 0.05, at least six dates over three years; Mann 1945; Sen 1968; Kendall 1975; Helsel et al. 2020).

*Spatial withholding test.* All wells within 1.5ℓ~a~ of a randomly chosen well were withheld ([[ppb_reps]] replicates), which opens a monitoring gap; the framework was rerun on the remaining wells (Monte Carlo *N* = 1,000, which gives the same reference decisions), and the candidate sites were compared with the gap: the share of replicates in which at least one site falls within ℓ~a~ of a withheld well, and the share of withheld wells with a site within ℓ~a~. GAS was compared with sites drawn at random from its candidate pool (200 draws) and with space-filling selection (repeatedly the pool site farthest from existing and selected sites), both in the number of sites selected by E-GAS. A design that withholds 15 % of the wells at random is reported in ESM S6.

*Sensitivity.* Fixed parameters were varied one at a time, and structural choices were changed: critical designation by dominant record or not applied, the 2013–2020 EDP median instead of the inventory chloride concentration, the uncorrected MST, and graphs without MST edges between hydrostratigraphic zones (Upper Floridan aquifer and Avon Park high-permeability zone; Peace River, upper and lower Arcadia aquifers), strict or lenient for wells without an assigned zone. Finally, [[lhs_n]] parameter sets were drawn by Latin hypercube sampling (McKay et al. 1979) for [[lhs_k]] fixed parameters, within ±25 % of their reference values (±10 % for the cluster review, second-anchor and hard-resolver thresholds, ±0.10 for the safeguard thresholds and the 80th–95th percentile for ℓ~a~; ESM S7), and run jointly (*N* = 1,000), so that interactions among the sequential thresholds are included (Razavi and Gupta 2015; Pianosi et al. 2016; Hermans et al. 2023). Parameter influence was summarized by partial rank correlation coefficients (PRCC; Marino et al. 2008), and the variance not explained by an additive rank model indicates interactions.

## 2.10 Reproducibility

The framework is implemented in Python. With the original inputs and the safeguard thresholds of the original Supporting Information, the original code reproduces the published results (23 screened and 2 confirmed wells; ESM Table S5). The revised results differ for two reasons (step by step in ESM S3): where the code differed from the values stated in the manuscript (Eqs. 7, 13, 20, 22, 25 and 27–29) the manuscript values are now used, the validation gain uses only the screened wells of the candidate's aquifer group, and candidate sites are restricted to land; and the MST, which ignored wells sharing coordinates with another well, is now built on the complete distance graph. The code is available at [[code_url]] and as ESM 2 (ESM S8).
