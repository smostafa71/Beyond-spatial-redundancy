"""Reference document for pandoc: Times New Roman 10 pt (Hydrogeology Journal instructions), double spacing, black headings (Hydrogeology Journal layout)."""
import sys
from docx import Document
from docx.shared import Pt, RGBColor, Cm
from docx.enum.text import WD_LINE_SPACING
from docx.oxml.ns import qn

src, dst = sys.argv[1], sys.argv[2]
d = Document(src)
STY = {s.name: s for s in d.styles}
FONT = "Times New Roman"


def fix_font(style, size=None, bold=None, italic=None, color=True):
    f = style.font
    f.name = FONT
    if size:
        f.size = Pt(size)
    if bold is not None:
        f.bold = bold
    if italic is not None:
        f.italic = italic
    if color:
        f.color.rgb = RGBColor(0, 0, 0)
    rpr = style.element.get_or_add_rPr()
    rf = rpr.find(qn("w:rFonts"))
    if rf is None:
        rf = rpr.makeelement(qn("w:rFonts"), {}); rpr.append(rf)
    for att in ("w:asciiTheme", "w:hAnsiTheme", "w:eastAsiaTheme", "w:cstheme"):
        if rf.get(qn(att)) is not None:
            del rf.attrib[qn(att)]
    for att in ("w:ascii", "w:hAnsi", "w:cs", "w:eastAsia"):
        rf.set(qn(att), FONT)


for st in d.styles:
    try:
        if st.type == 1:          # paragraph styles
            fix_font(st)
            pf = st.paragraph_format
            pf.space_before = Pt(0); pf.space_after = Pt(0)
    except Exception:
        pass
for name in ["Normal", "Body Text", "First Paragraph", "Compact", "Block Text"]:
    if name in STY:
        st = STY[name]
        fix_font(st, 10)
        st.paragraph_format.line_spacing_rule = WD_LINE_SPACING.DOUBLE
        st.paragraph_format.space_after = Pt(0)
for name, sz, it in [("Heading 1", 11, False), ("Heading 2", 10, False), ("Heading 3", 10, True), ("Title", 12, False)]:
    if name in STY:
        st = STY[name]
        fix_font(st, sz, bold=True, italic=it)
        st.paragraph_format.space_before = Pt(12); st.paragraph_format.space_after = Pt(0)
        st.paragraph_format.line_spacing_rule = WD_LINE_SPACING.DOUBLE
        st.paragraph_format.keep_with_next = True
for name in ["Caption", "Table Caption", "Image Caption"]:
    if name in STY:
        st = STY[name]
        fix_font(st, 10, italic=False)
        st.paragraph_format.line_spacing_rule = WD_LINE_SPACING.ONE_POINT_FIVE
        st.paragraph_format.space_before = Pt(6); st.paragraph_format.space_after = Pt(6)
# character styles (hyperlinks etc.) keep their font but use the body font
for st in d.styles:
    if st.type == 2:
        try:
            fix_font(st, color=False)
        except Exception:
            pass
sec = d.sections[0]
sec.page_height = Cm(27.94); sec.page_width = Cm(21.59)
for side in ["left_margin", "right_margin", "top_margin", "bottom_margin"]:
    setattr(sec, side, Cm(2.54))
d.save(dst)
print("reference written", dst)
