"""Post-processing of the native Word equations (OMML) written by pandoc, so that they display identically in Word and in
other renderers (LibreOffice, PDF builders of submission systems).

  * <m:sepChr m:val=""/> is removed from every delimiter that holds one element: it has no effect in Word there, but
    LibreOffice then reads the closing bracket as ")" ("[ ... )", "| ... )").
  * a superscript asterisk "*" (normalised variable, e.g. W_i^*) is written as U+2217 ASTERISK OPERATOR, the math
    asterisk; LibreOffice reads a bare "*" as a multiplication sign without operand.
  * the words "sup" and "sim" (subscripts), names with an underscore (CANDIDATE_REMOVE) and a lone "+" superscript
    (h^+) are written as normal text (m:nor):
    upright in Word as before; LibreOffice otherwise parses them as formula commands.
  * the overbar accent U+203E is written as U+0305 COMBINING OVERLINE, the character Word itself uses for \\bar.
  * consecutive letter runs with identical properties (upright names such as Strength, Prox, clip) are merged
    into one run; Word renders the merged run identically."""
import copy
from collections import Counter

M = "http://schemas.openxmlformats.org/officeDocument/2006/math"
# words used in the equations that are formula keywords in LibreOffice (sup = superscript, sim = ~): written as normal
# text, which Word renders upright as before and LibreOffice no longer parses
LO_KEYWORDS = {"sup", "sim"}


def _q(tag):
    return f"{{{M}}}{tag}"


def _run_key(r):
    """Return (rPr xml, text) for a math run that holds only optional properties and one letter text, else None."""
    kids = list(r)
    if not kids or kids[-1].tag != _q("t"):
        return None
    if len(kids) > 2 or (len(kids) == 2 and kids[0].tag != _q("rPr")):
        return None
    txt = kids[-1].text or ""
    if not txt or not all((ch.isalpha() or ch == "_") and ch.isascii() for ch in txt):
        return None
    from lxml import etree
    rpr = etree.tostring(kids[0]) if len(kids) == 2 else b""
    return rpr, txt


def fix_math(root):
    """root: lxml element of the document body (python-docx: Document.element). Returns a Counter of changes."""
    n = Counter()
    for dpr in list(root.iter(_q("dPr"))):
        d = dpr.getparent()
        if len(d.findall(_q("e"))) != 1:  # several elements: the separator is visible, keep it
            n["delimiters with separators kept"] += 1; continue
        for sep in dpr.findall(_q("sepChr")):
            if sep.get(_q("val"), None) == "":
                dpr.remove(sep); n["sepChr removed"] += 1
    for t in root.iter(_q("t")):
        if t.text == "*":
            t.text = "∗"; n["asterisk"] += 1
    for c in root.iter(_q("chr")):
        if c.get(_q("val")) == "‾":
            c.set(_q("val"), "̅"); n["overbar"] += 1
    for parent in list(root.iter()):
        kids = list(parent)
        i = 0
        while i < len(kids):
            if kids[i].tag != _q("r") or _run_key(kids[i]) is None:
                i += 1; continue
            key = _run_key(kids[i])[0]
            j = i + 1
            while j < len(kids) and kids[j].tag == _q("r") and _run_key(kids[j]) is not None and _run_key(kids[j])[0] == key:
                j += 1
            if j - i > 1:
                text = "".join(_run_key(k)[1] for k in kids[i:j])
                kids[i][-1].text = text
                for k in kids[i + 1:j]:
                    parent.remove(k)
                n["runs merged"] += j - i - 1
            i = j
    for r in root.iter(_q("r")):
        t = r.find(_q("t"))
        if t is None:
            continue
        lone_sup = t.text in ("+", "\u2212") and r.getparent().tag == _q("sup") and len(r.getparent()) == 1
        if t.text in LO_KEYWORDS or (lone_sup and t.text == "+") or ("_" in (t.text or "") and len(t.text) > 1):
            rpr = r.find(_q("rPr"))
            if rpr is None:
                rpr = r.makeelement(_q("rPr"), {}); r.insert(0, rpr)
            if rpr.find(_q("nor")) is None:
                for k in list(rpr):
                    if k.tag in (_q("sty"), _q("scr")):
                        rpr.remove(k)
                rpr.insert(0 if rpr.find(_q("lit")) is None else 1, rpr.makeelement(_q("nor"), {}))
                n["normal-text runs"] += 1
    return n


if __name__ == "__main__":
    import sys
    from docx import Document
    d = Document(sys.argv[1]); print(fix_math(d.element)); d.save(sys.argv[2])
