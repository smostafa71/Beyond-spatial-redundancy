Data for ESM 2 (HYJO-D-26-00546, revision 1)

The data are not part of this archive. They are available from the corresponding author on request
(Seyed Mostafa Biazar, Southwest Florida Water Management District). Place them here as

  data/GW_Stations_Final.shp, .shx, .dbf, .prj, .cpg   District groundwater-quality station inventory
  data/edp/                                            EDP export of the chloride record (parameter WQ_139)

and run  bash run_all.sh  from the top folder.
