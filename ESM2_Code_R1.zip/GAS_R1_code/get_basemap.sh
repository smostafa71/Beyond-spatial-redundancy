#!/usr/bin/env bash
# Base maps for Figs. 1, 3 and 5: US Census cartographic boundary files 2023 (1:500,000) and Natural Earth 10 m.
set -euo pipefail
mkdir -p basemap && cd basemap
for f in cb_2023_us_county_500k cb_2023_us_state_500k; do
  curl -sSLO "https://www2.census.gov/geo/tiger/GENZ2023/shp/$f.zip" && unzip -oq "$f.zip" -d "$f"
done
for f in ne_10m_admin_0_countries ne_10m_coastline ne_10m_lakes; do
  case $f in *countries) c=cultural;; *) c=physical;; esac
  curl -sSLO "https://naciscdn.org/naturalearth/10m/$c/$f.zip" && unzip -oq "$f.zip" -d "$f"
done
