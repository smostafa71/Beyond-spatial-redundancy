"""Analysis inputs and the EDP chloride record used for the tests of the revision.

Chloride concentration and the chloride trend class of every station are attributes of the District station
inventory (GW_Stations_Final.shp: CHLORIDE, CHLORIDE_T = DECREASING / STABLE / INCREASING), derived by the District
from the 2013-2020 record, and are used as in the original analysis. The trend class is used as given; the
analysis of chloride trends is not part of this study.

The District Environmental Data Portal (EDP / KiWIS) record of dissolved chloride (parameter WQ_139) is used for the
tests of Sect. 2.9: the 2021-2026 station medians and trends (out-of-period test, equal-budget comparison) and, as a
check, the 2013-2020 station medians compared with the inventory concentration (ESM Table S4).
  * WQ_140 (total chloride, 148 records) is a different determinand and is excluded;
  * exact duplicates (same SID, timestamp, value) removed; non-numeric and non-positive values removed;
  * samples on the same calendar day combined by their median (sampling-day value);
  * station value = median of the sampling-day values of the period;
  * 2021-2026 trend = two-sided Mann-Kendall test (p <= 0.05) on calendar-year medians, Theil-Sen slope.

Outputs (analysis_r1/): edp_daily_chloride.csv, edp_station_chloride.csv, edp_build_log.json, attribute_vs_edp.csv
and the engine inputs:
  inputs/GW_input_attr.gpkg   inventory as received (analysis input of the revision)
  inputs/GW_input_edpC.gpkg   EDP 2013-2020 median concentration, inventory trend class (sensitivity variant)
"""
import json, os
import numpy as np
import pandas as pd
import geopandas as gpd
from scipy import stats

RAW = "data/" if os.path.isdir("data/edp") else "raw_input/"   # data/ in the ESM 2 package
E = RAW + "edp/"
OUT = "analysis_r1/"
DEV = ("2013-01-01", "2020-12-31")
VAL = ("2021-01-01", "2026-12-31")      # validation period: all post-design data (record ends Jul 2026)
MIN_YEARS = 6
MIN_N_VAL, MIN_SPAN_VAL = 6, 3.0
ALPHA = 0.05


def mann_kendall(t, y):
    """Mann-Kendall S, two-sided p (normal approximation, tie and continuity corrected) and Theil-Sen slope."""
    t = np.asarray(t, float); y = np.asarray(y, float)
    o = np.argsort(t, kind="stable"); t, y = t[o], y[o]
    n = len(y)
    s = 0.0
    for i in range(n - 1):
        s += np.sign(y[i + 1:] - y[i]).sum()
    _, cnt = np.unique(y, return_counts=True)
    var = (n * (n - 1) * (2 * n + 5) - np.sum(cnt * (cnt - 1) * (2 * cnt + 5))) / 18.0
    z = 0.0 if var <= 0 else ((s - 1) / np.sqrt(var) if s > 0 else ((s + 1) / np.sqrt(var) if s < 0 else 0.0))
    p = 2 * (1 - stats.norm.cdf(abs(z)))
    slope = stats.theilslopes(y, t)[0] if n >= 2 else np.nan
    return s, p, slope


def direction(s, p):
    if p <= ALPHA and s > 0:
        return "RISING"
    if p <= ALPHA and s < 0:
        return "FALLING"
    return "NO TREND"


def period_stats(g, prefix, trend_on_years=True):
    out = {f"{prefix}_n": int(len(g)), f"{prefix}_dir": "NOT DETERMINED"}
    if len(g) == 0:
        return out
    out.update({f"{prefix}_first": g.date.min().date().isoformat(), f"{prefix}_last": g.date.max().date().isoformat(),
                f"{prefix}_median": float(g.cl.median()), f"{prefix}_max": float(g.cl.max()),
                f"{prefix}_n_years": int(g.date.dt.year.nunique())})
    if trend_on_years:
        a = g.groupby(g.date.dt.year).cl.median()
        if len(a) >= MIN_YEARS:
            s, p, sl = mann_kendall(a.index.to_numpy(float), a.to_numpy())
            out.update({f"{prefix}_mk_S": s, f"{prefix}_mk_p": p, f"{prefix}_sen_mg_yr": sl,
                        f"{prefix}_sen_pct_yr": 100 * sl / out[f"{prefix}_median"], f"{prefix}_dir": direction(s, p)})
    else:
        span = (g.date.max() - g.date.min()).days / 365.25
        if len(g) >= MIN_N_VAL and span >= MIN_SPAN_VAL:
            tt = g.date.dt.year + (g.date.dt.dayofyear - 1) / 365.25
            s, p, sl = mann_kendall(tt.to_numpy(), g.cl.to_numpy())
            out.update({f"{prefix}_mk_p": p, f"{prefix}_sen_mg_yr": sl,
                        f"{prefix}_sen_pct_yr": 100 * sl / out[f"{prefix}_median"], f"{prefix}_dir": direction(s, p)})
    return out


def main():
    os.makedirs(OUT, exist_ok=True); os.makedirs("inputs", exist_ok=True)
    raw = pd.read_csv(E + "EDP_Chloride_RAW_COMPLETE.csv")
    log = {"raw_records": len(raw), "raw_stations": int(raw.requested_SID.nunique())}
    assert (raw.station_no.astype(str) == raw.requested_SID.astype(str)).all()
    r = raw[raw.requested_parameter_code == "WQ_139"].copy()
    log["wq139_records"] = len(r)
    log["wq140_records_excluded"] = int((raw.requested_parameter_code == "WQ_140").sum())
    r = r.drop_duplicates(subset=["requested_SID", "timestamp", "value"])
    log["after_exact_duplicate_removal"] = len(r)
    r["value"] = pd.to_numeric(r.value, errors="coerce")
    log["non_numeric_removed"] = int(r.value.isna().sum())
    log["non_positive_removed"] = int((r.value <= 0).sum())
    r = r[r.value > 0]
    log["valid_records"] = len(r)
    assert r.timestamp.str[-6:].eq("-05:00").all()
    r["date"] = pd.to_datetime(r.timestamp.str[:10])
    multi = r.groupby(["requested_SID", "date"]).value.agg(["size", "nunique"])
    log["days_with_several_records"] = int((multi["size"] > 1).sum())
    log["days_with_differing_values"] = int((multi["nunique"] > 1).sum())
    d = (r.groupby(["requested_SID", "date"]).value.median().reset_index()
         .rename(columns={"requested_SID": "SID", "value": "cl"}))
    d["SID"] = d.SID.astype(str)
    d.to_csv(OUT + "edp_daily_chloride.csv", index=False)
    log.update({"sampling_days": len(d), "stations": int(d.SID.nunique()),
                "first_date": d.date.min().date().isoformat(), "last_date": d.date.max().date().isoformat()})

    rows = []
    for sid, g in d.groupby("SID"):
        g = g.sort_values("date")
        dev = g[(g.date >= DEV[0]) & (g.date <= DEV[1])]
        val = g[(g.date >= VAL[0]) & (g.date <= VAL[1])]
        rows.append({"SID": sid, **period_stats(dev, "dev", True), **period_stats(val, "val", False)})
    S = pd.DataFrame(rows)
    S["val_dev_ratio"] = S.val_median / S.dev_median
    S.to_csv(OUT + "edp_station_chloride.csv", index=False)
    log["dev_direction_counts"] = S.dev_dir.value_counts().to_dict()
    log["val_direction_counts"] = S.val_dir.value_counts().to_dict()

    # ---- inventory: District attribute vs EDP (SID level, original consolidation rule) ----
    import final6_patched as g6
    inv = gpd.read_file(RAW + "GW_Stations_Final.shp")
    inv["SID"] = inv.SID.astype(str)
    att = inv.groupby("SID").agg(CHLORIDE_ATTR=("CHLORIDE", "median"), CHLORIDE_T_ATTR=("CHLORIDE_T", g6.mode_nonnull),
                                 WATERBODY_=("WATERBODY_", g6.mode_nonnull), Waterbod_1=("Waterbod_1", g6.mode_nonnull)).reset_index()
    A = att.merge(S, on="SID", how="left")
    A["ratio_attr_edp"] = A.CHLORIDE_ATTR / A.dev_median
    A.to_csv(OUT + "attribute_vs_edp.csv", index=False)
    log["stations_without_2013_2020_chloride"] = A.loc[A.dev_n.fillna(0) == 0, "SID"].tolist()

    m = S.set_index("SID")
    inv["CHLORIDE_ATTR"], inv["CHLORIDE_T_ATTR"] = inv["CHLORIDE"], inv["CHLORIDE_T"]
    inv["Cl_EDP_median"] = inv.SID.map(m.dev_median)
    inv["Cl_EDP_n_dates"] = inv.SID.map(m.dev_n).fillna(0).astype(int)
    inv["Cl_EDP_n_years"] = inv.SID.map(m.dev_n_years).fillna(0).astype(int)
    inv.to_file("inputs/GW_input_attr.gpkg", driver="GPKG")
    a = inv.copy()
    a["CHLORIDE"] = a.Cl_EDP_median
    a.to_file("inputs/GW_input_edpC.gpkg", driver="GPKG")
    with open(OUT + "edp_build_log.json", "w") as f:
        json.dump(log, f, indent=1)
    print(json.dumps(log, indent=1))


if __name__ == "__main__":
    main()
