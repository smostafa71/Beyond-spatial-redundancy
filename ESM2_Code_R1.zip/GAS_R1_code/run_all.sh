#!/usr/bin/env bash
# Reproduces all numbers, tables, figures and documents of the revision (HYJO-D-26-00546, R1).
#   bash run_all.sh              full run (several hours on two cores)
#   bash run_all.sh --reference  inputs and the reference run only
# The data are available on request; place them in data/ first (see data/README.txt).
set -euo pipefail
cd "$(dirname "$0")"
MODE=${1:-}
PROCS=${PROCS:-2}
[ -f data/GW_Stations_Final.shp ] && [ -d data/edp ] || { echo "data/ is empty: see data/README.txt"; exit 1; }

python3 tools/build_engine.py final6_patched.py gas_engine.py          # framework (all changes listed in tools/build_engine.py)
python3 build_input_r1.py                                              # inventory -> inputs/GW_input_attr.gpkg; EDP record for the tests
if [ "$MODE" == "--reference" ]; then
  python3 analyses_r1.py reference --procs "$PROCS"; echo "reference run in analysis_r1/reference/"; exit 0
fi
python3 ledger.py                                                      # ESM Table S5 (L0-L4)
python3 analyses_r1.py reference structure baselines temporal oat --procs "$PROCS"
python3 analyses_r1.py prospective --reps 50 --procs "$PROCS"          # pseudo-prospective test, random withholding (Sect. 2.9)
python3 analyses_r1.py blocks --reps 60 --procs "$PROCS"               # pseudo-prospective test, spatial gaps (Sect. 2.9)
python3 analyses_r1.py safeguard                                       # independent check with the 2021-2026 record (Sect. 3.6)
python3 analyses_r1.py lhs --n-lhs 400 --procs "$PROCS"                # joint sensitivity (Sect. 2.9)
[ -d basemap ] || bash get_basemap.sh                                  # base maps (figures, county names)
python3 collect_numbers_r1.py                                          # analysis_r1/numbers.json

for f in figs_r1/fig*.py; do PYTHONPATH=figs_r1:. python3 "$f"; done

mkdir -p deliverables
python3 ms/build_ms_r1.py deliverables/Biazar_Manuscript_R1_clean.docx
python3 ms/build_esm_r1.py deliverables/ESM1_Supporting_Information_R1.docx
if command -v soffice >/dev/null; then
  (cd deliverables && soffice --headless --convert-to pdf Biazar_Manuscript_R1_clean.docx ESM1_Supporting_Information_R1.docx >/dev/null)
fi
echo "done"
